import { DeleteObjectCommand } from '@aws-sdk/client-s3';
import {
  createR2Client,
  getR2Config,
  sanitizeR2Key,
  verifySupabaseAuthToken,
} from './_r2Config';

function extractKeyFromUrlOrPath(input: string): string | null {
  const trimmed = String(input || '').trim();
  if (!trimmed) return null;

  if (/^https?:\/\//i.test(trimmed)) {
    try {
      const parsed = new URL(trimmed);
      const host = parsed.hostname.toLowerCase();
      if (host !== 'r2.dev' && !host.endsWith('.r2.dev')) {
        return null;
      }
      return sanitizeR2Key(decodeURIComponent(parsed.pathname));
    } catch {
      return null;
    }
  }

  return sanitizeR2Key(trimmed);
}

export const handler = async (event: any) => {
  if (event.httpMethod !== 'POST' && event.httpMethod !== 'DELETE') {
    return {
      statusCode: 405,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Method Not Allowed' }),
    };
  }

  try {
    const authHeader = event.headers?.authorization || event.headers?.Authorization;
    const auth = await verifySupabaseAuthToken(authHeader);

    if (!auth.authenticated || !auth.userId) {
      return {
        statusCode: 401,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: auth.error || 'Unauthorized: Authentication required.' }),
      };
    }

    const body = typeof event.body === 'string' ? JSON.parse(event.body || '{}') : event.body || {};
    const key = extractKeyFromUrlOrPath(String(body.key || body.url || ''));

    if (!key) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Valid R2 object key or .r2.dev URL is required.' }),
      };
    }

    const cleanAuthUser = auth.userId.replace(/[^a-zA-Z0-9_-]/g, '');
    const ownerPrefix = `${cleanAuthUser}/`;
    if (!key.startsWith(ownerPrefix) && !auth.isAdmin) {
      return {
        statusCode: 403,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: 'Forbidden: Artists and users can only delete their own uploaded files.',
        }),
      };
    }

    const r2Config = getR2Config();
    if (!r2Config.isConfigured) {
      return {
        statusCode: 503,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: 'Cloudflare R2 credentials are not configured on the server.',
        }),
      };
    }

    const r2Client = createR2Client();
    await r2Client.send(
      new DeleteObjectCommand({
        Bucket: r2Config.bucketName,
        Key: key,
      })
    );

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ success: true, key, bucket: r2Config.bucketName }),
    };
  } catch (err: any) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: err?.message || 'Failed to delete file from R2.' }),
    };
  }
};
