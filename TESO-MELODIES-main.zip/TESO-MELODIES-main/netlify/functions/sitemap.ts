import {
  resolveOriginFromHeaders,
  buildDynamicSitemapXml,
  buildFallbackSitemapXml,
} from './_socialShare';

export const handler = async (event: any) => {
  if (event.httpMethod && !['GET', 'HEAD'].includes(event.httpMethod.toUpperCase())) {
    return {
      statusCode: 405,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
      body: 'Method Not Allowed',
    };
  }

  const origin = resolveOriginFromHeaders(event.headers, event.rawUrl);
  let xml: string;
  try {
    xml = await buildDynamicSitemapXml(origin);
    if (!xml || !xml.trimStart().startsWith('<?xml')) {
      xml = buildFallbackSitemapXml(origin);
    }
  } catch {
    xml = buildFallbackSitemapXml(origin);
  }

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/xml; charset=utf-8',
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'public, max-age=300, s-maxage=900',
      'Netlify-CDN-Cache-Control': 'public, max-age=300, stale-while-revalidate=3600',
    },
    body: event.httpMethod?.toUpperCase() === 'HEAD' ? '' : xml,
  };
};
