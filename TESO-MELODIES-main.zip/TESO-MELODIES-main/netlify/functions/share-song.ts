import {
  resolveOriginFromHeaders,
  extractRouteItemId,
  buildSongShareMetadata,
  readBuiltIndexHtml,
  renderSocialShareHtml,
} from './_socialShare';

export const handler = async (event: any) => {
  if (event.httpMethod && !['GET', 'HEAD'].includes(event.httpMethod.toUpperCase())) {
    return {
      statusCode: 405,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
      body: 'Method Not Allowed',
    };
  }

  const origin = resolveOriginFromHeaders(event.headers, event.rawUrl);
  const queryId = event.queryStringParameters?.id;
  const songId = extractRouteItemId(queryId, event.path, event.rawUrl, 'song');

  const meta = await buildSongShareMetadata(songId, origin);
  const templateHtml = await readBuiltIndexHtml(origin);
  const fallbackAppUrl = songId ? `/?song=${encodeURIComponent(songId)}` : '/';
  const html = renderSocialShareHtml(templateHtml, meta, fallbackAppUrl);

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'public, max-age=60, s-maxage=300',
      'X-Robots-Tag': 'all',
    },
    body: event.httpMethod?.toUpperCase() === 'HEAD' ? '' : html,
  };
};
