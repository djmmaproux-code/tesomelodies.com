import { PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import {
  createR2Client,
  getR2Config,
  validateR2UploadInput,
  verifySupabaseAuthToken,
} from './_r2Config';

export const handler = async (event: any) => {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Method Not Allowed' }),
    };
  }

  try {
    const authHeader = event.headers?.authorization || event.headers?.Authorization;
    const auth = await verifySupabaseAuthToken(authHeader);

    if (!auth.authenticated || !auth.userId) {
      return {
        statusCode: 401,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: auth.error || 'Unauthorized: Valid Supabase session required.' }),
      };
    }

    const body = typeof event.body === 'string' ? JSON.parse(event.body || '{}') : event.body || {};
    const { filePath, featureName, contentType, fileSize } = body;

    if (!filePath || !contentType) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Missing filePath or contentType' }),
      };
    }

    const validation = validateR2UploadInput({
      authenticatedUserId: auth.userId,
      isAdmin: auth.isAdmin,
      filePath: String(filePath),
      featureName: featureName ? String(featureName) : undefined,
      contentType: String(contentType),
      fileSize: fileSize !== undefined ? Number(fileSize) : undefined,
    });

    if (!validation.ok) {
      const fail = validation as { ok: false; statusCode: number; error: string };
      return {
        statusCode: fail.statusCode,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: fail.error }),
      };
    }

    const r2Config = getR2Config();
    if (!r2Config.isConfigured) {
      return {
        statusCode: 503,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error:
            'Cloudflare R2 credentials are not configured in server environment variables.',
        }),
      };
    }

    const r2Client = createR2Client();
    const command = new PutObjectCommand({
      Bucket: r2Config.bucketName,
      Key: validation.key,
      ContentType: validation.contentType,
    });

    const presignedUrl = await getSignedUrl(r2Client, command, { expiresIn: 900 });
    const publicUrl = `${r2Config.publicBaseUrl}/${validation.key}`;

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        presignedUrl,
        publicUrl,
        path: validation.key,
        key: validation.key,
        bucket: r2Config.bucketName,
        userId: auth.userId,
        contentType: validation.contentType,
        fileSize: fileSize !== undefined ? Number(fileSize) : undefined,
      }),
    };
  } catch (err: any) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: err?.message || 'Failed to generate R2 upload URL' }),
    };
  }
};
