import { GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import {
  createR2Client,
  getR2Config,
  isPrivateR2Key,
  sanitizeR2Key,
  verifySupabaseAuthToken,
} from './_r2Config';

const sanitizeFilename = (raw?: string, fallbackExt = '.mp3'): string => {
  const cleaned = (raw || `TesoMelodies_File${fallbackExt}`)
    .replace(/["\r\n\/\\?%*:|<>]/g, '_')
    .trim();
  if (!cleaned) return `TesoMelodies_File${fallbackExt}`;
  if (/\.[a-z0-9]{2,5}$/i.test(cleaned)) return cleaned;
  return `${cleaned}${fallbackExt}`;
};

const inferMimeFromKey = (key: string): string => {
  const lower = key.toLowerCase();
  if (lower.endsWith('.mp3')) return 'audio/mpeg';
  if (lower.endsWith('.wav')) return 'audio/wav';
  if (lower.endsWith('.aac')) return 'audio/aac';
  if (lower.endsWith('.flac')) return 'audio/flac';
  if (lower.endsWith('.m4a')) return 'audio/mp4';
  if (lower.endsWith('.ogg')) return 'audio/ogg';
  if (lower.endsWith('.mp4')) return 'video/mp4';
  if (lower.endsWith('.webm')) return 'video/webm';
  if (lower.endsWith('.mov')) return 'video/quicktime';
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.webp')) return 'image/webp';
  if (lower.endsWith('.pdf')) return 'application/pdf';
  if (lower.endsWith('.json')) return 'application/json';
  return 'application/octet-stream';
};

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
      body: '',
    };
  }

  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Method Not Allowed' }),
    };
  }

  try {
    const params = event.queryStringParameters || {};
    const rawUrl = String(params.url || '').trim();
    const wantsJson = params.format === 'json';
    const explicitPrivate = params.private === '1' || params.private === 'true';

    if (!rawUrl) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Missing url query parameter' }),
      };
    }

    let parsed: URL;
    try {
      parsed = new URL(rawUrl);
    } catch {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Invalid URL' }),
      };
    }

    if (!['http:', 'https:'].includes(parsed.protocol)) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Invalid protocol' }),
      };
    }

    const host = parsed.hostname.toLowerCase();
    let downloadUrl = '';
    let safeFilename = sanitizeFilename(params.filename, '.mp3');

    if (host === 'r2.dev' || host.endsWith('.r2.dev')) {
      const key = sanitizeR2Key(decodeURIComponent(parsed.pathname.replace(/^\/+/, '')));
      if (!key) {
        return {
          statusCode: 400,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ error: 'Invalid or missing R2 object key' }),
        };
      }

      // Protect private files and private attachments with Supabase JWT ownership verification
      if (explicitPrivate || isPrivateR2Key(key)) {
        const authHeader =
          event.headers?.authorization ||
          event.headers?.Authorization ||
          (params.token ? `Bearer ${params.token}` : '');
        const auth = await verifySupabaseAuthToken(authHeader);

        if (!auth.authenticated || !auth.userId) {
          return {
            statusCode: 401,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error: 'Authentication required to download this private file.' }),
          };
        }

        const cleanAuthUser = auth.userId.replace(/[^a-zA-Z0-9_-]/g, '');
        if (!key.startsWith(`${cleanAuthUser}/`) && !auth.isAdmin) {
          return {
            statusCode: 403,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error: 'Forbidden: You are not authorized to access this private file.' }),
          };
        }
      }

      const r2Config = getR2Config();
      if (!r2Config.isConfigured) {
        return {
          statusCode: 503,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ error: 'Cloudflare R2 credentials are not configured on the server.' }),
        };
      }

      const keyExtMatch = key.match(/(\.[a-z0-9]{2,5})$/i);
      const fallbackExt = keyExtMatch ? keyExtMatch[1] : '.mp3';
      safeFilename = sanitizeFilename(params.filename, fallbackExt);

      const r2Client = createR2Client();
      const command = new GetObjectCommand({
        Bucket: r2Config.bucketName,
        Key: key,
        ResponseContentDisposition: `attachment; filename="${safeFilename}"`,
        ResponseContentType: inferMimeFromKey(key),
      });

      downloadUrl = await getSignedUrl(r2Client, command, { expiresIn: 300 });
    } else if (host.endsWith('.supabase.co') && parsed.pathname.includes('/storage/v1/object/public/')) {
      parsed.searchParams.set('download', safeFilename);
      downloadUrl = parsed.toString();
    } else {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Unsupported media host' }),
      };
    }

    if (wantsJson) {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-store',
        },
        body: JSON.stringify({ downloadUrl, filename: safeFilename }),
      };
    }

    return {
      statusCode: 302,
      headers: {
        Location: downloadUrl,
        'Content-Disposition': `attachment; filename="${safeFilename}"`,
        'Cache-Control': 'no-store',
      },
      body: '',
    };
  } catch (err: any) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: err?.message || 'Failed to prepare R2 attachment download' }),
    };
  }
};
