import {
  resolveOriginFromHeaders,
  extractRouteItemId,
  buildGenreSeoMetadata,
  readBuiltIndexHtml,
  renderSocialShareHtml,
} from './_socialShare';

export const handler = async (event: any) => {
  if (event.httpMethod && !['GET', 'HEAD'].includes(event.httpMethod.toUpperCase())) {
    return {
      statusCode: 405,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
      body: 'Method Not Allowed',
    };
  }

  const origin = resolveOriginFromHeaders(event.headers, event.rawUrl);
  const querySlug = event.queryStringParameters?.slug || event.queryStringParameters?.id;
  const genreSlug = extractRouteItemId(querySlug, event.path, event.rawUrl, 'genre');

  const meta = await buildGenreSeoMetadata(genreSlug, origin);
  const templateHtml = await readBuiltIndexHtml(origin);
  const fallbackAppUrl = genreSlug ? `/music?genre=${encodeURIComponent(genreSlug)}` : '/music';
  const html = renderSocialShareHtml(templateHtml, meta, fallbackAppUrl);

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'public, max-age=60, s-maxage=300',
      'X-Robots-Tag': 'index, follow',
    },
    body: event.httpMethod?.toUpperCase() === 'HEAD' ? '' : html,
  };
};
