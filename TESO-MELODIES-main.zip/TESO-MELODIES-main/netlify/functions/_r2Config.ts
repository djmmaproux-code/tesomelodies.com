import { S3Client } from '@aws-sdk/client-s3';

const DEFAULT_SUPABASE_URL = 'https://csguerwyvykvzlnikwbf.supabase.co';
const DEFAULT_SUPABASE_PUBLIC_KEY = 'sb_publishable_oEIwYhatHiDPIC12hLmZPA_XrH8F1lA';
const DEFAULT_R2_BUCKET = 'hesomelodies-files';
const DEFAULT_R2_PUBLIC_URL = 'https://pub-ed44af9b41f345169fbf124e602171bd.r2.dev';
export const ADMIN_EMAIL = 'tesomelodies@gmail.com';

export function getSupabaseAuthConfig() {
  const rawUrl =
    process.env.SUPABASE_URL ||
    process.env.VITE_SUPABASE_URL ||
    DEFAULT_SUPABASE_URL;
  const supabaseUrl = rawUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');
  const supabaseKey =
    process.env.SUPABASE_ANON_KEY ||
    process.env.VITE_SUPABASE_ANON_KEY ||
    DEFAULT_SUPABASE_PUBLIC_KEY;
  return { supabaseUrl, supabaseKey };
}

export function getR2Config() {
  const rawEndpoint =
    process.env.R2_ENDPOINT ||
    (process.env.R2_ACCOUNT_ID
      ? `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`
      : '');
  const endpoint = rawEndpoint
    .replace(/\/hesomelodies-files\/?$/, '')
    .replace(/\/+$/, '');
  const accessKeyId = (process.env.R2_ACCESS_KEY_ID || '').trim();
  const secretAccessKey = (process.env.R2_SECRET_ACCESS_KEY || '').trim();
  const bucketName = (process.env.R2_BUCKET_NAME || DEFAULT_R2_BUCKET).trim();
  const publicBaseUrl = (process.env.R2_PUBLIC_URL || DEFAULT_R2_PUBLIC_URL)
    .trim()
    .replace(/\/+$/, '');

  const isConfigured = Boolean(endpoint && accessKeyId && secretAccessKey && bucketName);

  return {
    endpoint,
    accessKeyId,
    secretAccessKey,
    bucketName,
    publicBaseUrl,
    isConfigured,
  };
}

export function createR2Client(): S3Client {
  const { endpoint, accessKeyId, secretAccessKey } = getR2Config();
  return new S3Client({
    region: 'auto',
    endpoint: endpoint || 'https://invalid.r2.cloudflarestorage.com',
    credentials: {
      accessKeyId,
      secretAccessKey,
    },
  });
}

export interface VerifiedSupabaseUser {
  authenticated: boolean;
  userId?: string;
  email?: string;
  isAdmin?: boolean;
  error?: string;
}

export async function verifySupabaseAuthToken(
  authHeader?: string | null
): Promise<VerifiedSupabaseUser> {
  const raw = String(authHeader || '').trim();
  if (!raw.toLowerCase().startsWith('bearer ')) {
    return { authenticated: false, error: 'Unauthorized: Missing Bearer token.' };
  }

  const token = raw.slice(7).trim();
  if (!token) {
    return { authenticated: false, error: 'Unauthorized: Empty authentication token.' };
  }

  try {
    const { supabaseUrl, supabaseKey } = getSupabaseAuthConfig();
    const res = await fetch(`${supabaseUrl}/auth/v1/user`, {
      method: 'GET',
      headers: {
        apikey: supabaseKey,
        Authorization: `Bearer ${token}`,
      },
    });

    if (!res.ok) {
      return {
        authenticated: false,
        error: `Unauthorized: Invalid or expired session (HTTP ${res.status}).`,
      };
    }

    const user: any = await res.json();
    if (!user?.id) {
      return { authenticated: false, error: 'Unauthorized: Could not verify Supabase user.' };
    }

    const email = user.email ? String(user.email).trim().toLowerCase() : undefined;
    return {
      authenticated: true,
      userId: String(user.id),
      email,
      isAdmin: email === ADMIN_EMAIL,
    };
  } catch (err: any) {
    return {
      authenticated: false,
      error: err?.message || 'Authentication verification failed.',
    };
  }
}

export const ALLOWED_FEATURES = new Set([
  'tracks',
  'covers',
  'avatars',
  'thumbnails',
  'videos',
  'attachments',
  'private',
]);

export const MAX_FILE_SIZE_BY_FEATURE: Record<string, number> = {
  tracks: 250 * 1024 * 1024, // 250 MB for MP3/WAV/FLAC/DJ mixes
  videos: 500 * 1024 * 1024, // 500 MB for music videos
  covers: 25 * 1024 * 1024, // 25 MB for high-res cover artwork
  avatars: 25 * 1024 * 1024, // 25 MB for profile avatars
  thumbnails: 25 * 1024 * 1024, // 25 MB for video thumbnails
  attachments: 50 * 1024 * 1024, // 50 MB for documents / metadata attachments
  private: 100 * 1024 * 1024, // 100 MB for private user files
};

const BLOCKED_EXTENSIONS = new Set([
  'html',
  'htm',
  'xhtml',
  'svg',
  'js',
  'mjs',
  'cjs',
  'ts',
  'jsx',
  'tsx',
  'php',
  'sh',
  'bash',
  'bat',
  'cmd',
  'exe',
  'dll',
  'msi',
  'ps1',
  'vbs',
]);

const ALLOWED_AUDIO_MIMES = new Set([
  'audio/mpeg',
  'audio/mp3',
  'audio/wav',
  'audio/x-wav',
  'audio/wave',
  'audio/aac',
  'audio/x-aac',
  'audio/flac',
  'audio/x-flac',
  'audio/mp4',
  'audio/x-m4a',
  'audio/m4a',
  'audio/ogg',
  'audio/opus',
  'audio/webm',
]);

const ALLOWED_IMAGE_MIMES = new Set([
  'image/jpeg',
  'image/jpg',
  'image/pjpeg',
  'image/png',
  'image/webp',
  'image/gif',
  'image/avif',
]);

const ALLOWED_VIDEO_MIMES = new Set([
  'video/mp4',
  'video/webm',
  'video/quicktime',
  'video/x-matroska',
  'video/ogg',
  'video/x-m4v',
]);

const ALLOWED_DOCUMENT_MIMES = new Set([
  'application/json',
  'text/plain',
  'application/pdf',
  'application/zip',
  'application/x-zip-compressed',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/octet-stream',
]);

export function sanitizeR2Key(rawPath: string): string | null {
  if (!rawPath || typeof rawPath !== 'string') return null;
  if (rawPath.includes('\0') || rawPath.includes('\\')) return null;

  const trimmed = rawPath.trim().replace(/^\/+/, '');
  if (!trimmed) return null;

  const segments = trimmed.split('/').filter(Boolean);
  if (segments.length < 2) return null;
  if (segments.some((seg) => seg === '.' || seg === '..' || !/^[a-zA-Z0-9._-]+$/.test(seg))) {
    return null;
  }

  return segments.join('/');
}

export function validateR2UploadInput(params: {
  authenticatedUserId: string;
  isAdmin?: boolean;
  filePath: string;
  featureName?: string;
  contentType: string;
  fileSize?: number;
}): { ok: true; key: string; contentType: string; feature: string } | { ok: false; statusCode: number; error: string } {
  const safeKey = sanitizeR2Key(params.filePath);
  if (!safeKey) {
    return { ok: false, statusCode: 400, error: 'Invalid filePath format.' };
  }

  const segments = safeKey.split('/');
  const cleanAuthUser = params.authenticatedUserId.replace(/[^a-zA-Z0-9_-]/g, '');

  // Enforce strict user ownership of upload folder
  if (segments[0] !== cleanAuthUser && !params.isAdmin) {
    return {
      ok: false,
      statusCode: 403,
      error: 'Forbidden: You can only upload files inside your own account directory.',
    };
  }

  const candidateFeature = (params.featureName || segments[1] || '').toLowerCase().trim();
  const feature = ALLOWED_FEATURES.has(candidateFeature) ? candidateFeature : 'attachments';

  const fileName = segments[segments.length - 1] || '';
  const ext = fileName.includes('.') ? fileName.split('.').pop()?.toLowerCase() || '' : '';
  if (ext && BLOCKED_EXTENSIONS.has(ext)) {
    return {
      ok: false,
      statusCode: 400,
      error: `Unsupported or unsafe file extension (.${ext}).`,
    };
  }

  const rawContentType = String(params.contentType || '').split(';')[0].trim().toLowerCase();
  if (!rawContentType) {
    return { ok: false, statusCode: 400, error: 'Missing contentType.' };
  }

  const isAudio = ALLOWED_AUDIO_MIMES.has(rawContentType);
  const isImage = ALLOWED_IMAGE_MIMES.has(rawContentType);
  const isVideo = ALLOWED_VIDEO_MIMES.has(rawContentType);
  const isDoc = ALLOWED_DOCUMENT_MIMES.has(rawContentType);

  if (!isAudio && !isImage && !isVideo && !isDoc) {
    return {
      ok: false,
      statusCode: 400,
      error: `Unsupported file content type: ${rawContentType}`,
    };
  }

  if (feature === 'tracks' && !isAudio && rawContentType !== 'application/octet-stream') {
    return { ok: false, statusCode: 400, error: 'Only supported audio formats are allowed for music tracks.' };
  }
  if (['covers', 'avatars', 'thumbnails'].includes(feature) && !isImage) {
    return { ok: false, statusCode: 400, error: 'Only supported image formats (JPG, PNG, WebP, GIF) are allowed for artwork/avatars.' };
  }
  if (feature === 'videos' && !isVideo && rawContentType !== 'application/octet-stream') {
    return { ok: false, statusCode: 400, error: 'Only supported video formats (MP4, WebM, MOV, MKV) are allowed for videos.' };
  }

  if (params.fileSize !== undefined && params.fileSize !== null) {
    const sizeNum = Number(params.fileSize);
    const maxBytes = MAX_FILE_SIZE_BY_FEATURE[feature] || 500 * 1024 * 1024;
    if (!Number.isFinite(sizeNum) || sizeNum <= 0) {
      return { ok: false, statusCode: 400, error: 'File must be greater than 0 bytes.' };
    }
    if (sizeNum > maxBytes) {
      const maxMb = Math.round(maxBytes / (1024 * 1024));
      return { ok: false, statusCode: 400, error: `File exceeds the ${maxMb} MB limit for ${feature}.` };
    }
  }

  return {
    ok: true,
    key: safeKey,
    contentType: rawContentType,
    feature,
  };
}

export function isPrivateR2Key(key: string): boolean {
  const segments = String(key || '')
    .replace(/^\/+/, '')
    .split('/')
    .map((s) => s.toLowerCase());
  if (segments.includes('private')) return true;
  if (segments[1] === 'attachments' && segments[segments.length - 1] !== 'video-meta.json') {
    return true;
  }
  return false;
}
