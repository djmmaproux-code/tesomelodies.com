import fs from 'fs';
import path from 'path';

export interface SocialShareMetadata {
  kind: 'song' | 'video' | 'artist' | 'genre' | 'site';
  id?: string;
  title: string;
  description: string;
  image: string;
  imageType?: string;
  imageAlt: string;
  url: string;
  type: 'music.song' | 'video.other' | 'profile' | 'website';
  siteName: string;
  artist?: string;
  categoryOrGenre?: string;
  duration?: string;
  mediaUrl?: string;
  schemaGraph?: Record<string, any>[];
  seoBodyHtml?: string;
  found: boolean;
}

const DEFAULT_SITE_URL = 'https://tesomelodies.com';
const DEFAULT_SUPABASE_URL = 'https://csguerwyvykvzlnikwbf.supabase.co';
const DEFAULT_SUPABASE_PUBLIC_KEY = 'sb_publishable_oEIwYhatHiDPIC12hLmZPA_XrH8F1lA';
const DEFAULT_R2_PUBLIC_URL = 'https://pub-ed44af9b41f345169fbf124e602171bd.r2.dev';

export interface GenreSeoConfig {
  slug: string;
  displayName: string;
  headline: string;
  titleTemplate: string;
  matchDbGenres: string[] | 'ALL';
  summaryFocus: string;
}

export const REGIONAL_GENRE_CONFIGS: GenreSeoConfig[] = [
  {
    slug: 'teso-music',
    displayName: 'Teso Music',
    headline: 'Teso Music & Latest Ateso Songs (MP3 Download)',
    titleTemplate: 'Teso Music – Free MP3 Download & Latest Ateso Songs | Teso Melodies',
    matchDbGenres: 'ALL',
    summaryFocus: 'authentic Teso and Ateso songs from Uganda',
  },
  {
    slug: 'teso-gospel-music',
    displayName: 'Teso Gospel Music',
    headline: 'Teso Gospel Music & Worship Songs (MP3 Download)',
    titleTemplate: 'Teso Gospel Music & Worship Songs – Free MP3 Download | Teso Melodies',
    matchDbGenres: ['teso worship', 'gospel'],
    summaryFocus: 'Teso gospel and Ateso worship songs',
  },
  {
    slug: 'ugandan-music',
    displayName: 'Ugandan Music',
    headline: 'Ugandan Music & New MP3 Downloads',
    titleTemplate: 'Ugandan Music – Free MP3 Download & Listen Online | Teso Melodies',
    matchDbGenres: 'ALL',
    summaryFocus: 'Ugandan artists across gospel, dancehall, afrobeat, and regional genres',
  },
  {
    slug: 'african-music',
    displayName: 'African Music',
    headline: 'African Music – Stream & Free MP3 Downloads',
    titleTemplate: 'African Music – Free MP3 Download & Online Streaming | Teso Melodies',
    matchDbGenres: 'ALL',
    summaryFocus: 'East African and Ugandan songs available to stream and download',
  },
];

function getSupabaseConfig() {
  const rawUrl =
    process.env.SUPABASE_URL ||
    process.env.VITE_SUPABASE_URL ||
    DEFAULT_SUPABASE_URL;
  const supabaseUrl = rawUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');
  const supabaseKey =
    process.env.SUPABASE_ANON_KEY ||
    process.env.VITE_SUPABASE_ANON_KEY ||
    DEFAULT_SUPABASE_PUBLIC_KEY;
  return { supabaseUrl, supabaseKey };
}

function getR2PublicBase(): string {
  return (
    process.env.R2_PUBLIC_URL ||
    process.env.VITE_R2_PUBLIC_URL ||
    DEFAULT_R2_PUBLIC_URL
  ).replace(/\/+$/, '');
}

export function slugifySeo(value?: string | null): string {
  return String(value || '')
    .toLowerCase()
    .trim()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function canonicalArtistSlug(value?: string | null): string {
  return String(value || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'artist';
}

export function canonicalGenreSlug(value?: string | null): string {
  const raw = String(value || '').toLowerCase().trim();
  if (raw === 'r&b' || raw === 'rnb' || raw === 'r-b') return 'r-b';
  return raw.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'music';
}

function formatIsoDuration(duration?: string | null, durationSec?: number | null): string | undefined {
  if (typeof durationSec === 'number' && Number.isFinite(durationSec) && durationSec > 0) {
    const mins = Math.floor(durationSec / 60);
    const secs = Math.floor(durationSec % 60);
    return `PT${mins}M${secs}S`;
  }
  const clean = String(duration || '').trim();
  const match = clean.match(/^(\d{1,2}):(\d{2})$/);
  if (match) {
    const mins = parseInt(match[1], 10);
    const secs = parseInt(match[2], 10);
    if (mins > 0 || secs > 0) {
      return `PT${mins}M${secs}S`;
    }
  }
  return undefined;
}

function formatGenreDisplayName(raw: string): string {
  const clean = String(raw || '').trim();
  if (!clean) return 'Music';
  if (clean.toLowerCase() === 'r&b' || clean.toLowerCase() === 'r-b') return 'R&B';
  if (clean.toLowerCase() === 'teso worship') return 'Teso Worship';
  return clean
    .split(/\s+/)
    .map((word) => (word.length > 0 ? word[0].toUpperCase() + word.slice(1) : word))
    .join(' ');
}

/**
 * Resolves the canonical site origin for OG tags, canonical links, and sitemap URLs.
 * Canonicalizes tesomelodies.com / www.tesomelodies.com to https://tesomelodies.com.
 */
export function resolveOriginFromHeaders(
  headers?: Record<string, string | string[] | undefined>,
  rawUrl?: string
): string {
  const getHeader = (name: string): string => {
    if (!headers) return '';
    const direct = headers[name] ?? headers[name.toLowerCase()];
    if (Array.isArray(direct)) return String(direct[0] || '');
    return direct ? String(direct) : '';
  };

  const xfHost = getHeader('x-forwarded-host').split(',')[0].trim();
  const host = xfHost || getHeader('host').trim();
  const xfProto = getHeader('x-forwarded-proto').split(',')[0].trim();

  if (host) {
    const cleanHost = host.toLowerCase();
    if (cleanHost === 'tesomelodies.com' || cleanHost === 'www.tesomelodies.com') {
      return DEFAULT_SITE_URL;
    }
    const isLocal =
      cleanHost.startsWith('localhost') ||
      cleanHost.startsWith('127.0.0.1') ||
      cleanHost.startsWith('0.0.0.0');
    const proto = xfProto || (isLocal ? 'http' : 'https');
    return `${proto}://${host}`;
  }

  if (rawUrl) {
    try {
      const u = new URL(rawUrl);
      if (u.hostname === 'tesomelodies.com' || u.hostname === 'www.tesomelodies.com') {
        return DEFAULT_SITE_URL;
      }
      return u.origin;
    } catch {
      // ignore
    }
  }

  const envUrl = process.env.SITE_URL || process.env.URL || DEFAULT_SITE_URL;
  return envUrl.replace(/\/+$/, '');
}

/**
 * Extracts a clean song, video, artist, or genre identifier from Netlify function events or Express requests.
 */
export function extractRouteItemId(
  queryId?: string | null,
  requestPath?: string | null,
  rawUrl?: string | null,
  prefix: 'song' | 'video' | 'artist' | 'genre' = 'song'
): string {
  const cleanId = (val: string): string => {
    let v = val.trim();
    const re = new RegExp(`^\\/?${prefix}\\/`, 'i');
    v = v.replace(re, '');
    v = v.split('?')[0].split('#')[0].replace(/\/+$/, '');
    try {
      return decodeURIComponent(v).trim();
    } catch {
      return v.trim();
    }
  };

  if (queryId && String(queryId).trim()) {
    const cleaned = cleanId(String(queryId));
    if (cleaned) return cleaned;
  }

  const pathMatchRe = new RegExp(`/${prefix}/([^/?#]+)`, 'i');
  if (requestPath) {
    const m = requestPath.match(pathMatchRe);
    if (m?.[1]) return cleanId(m[1]);
  }

  if (rawUrl) {
    const m = rawUrl.match(pathMatchRe);
    if (m?.[1]) return cleanId(m[1]);
    try {
      const parsed = new URL(rawUrl);
      const qId = parsed.searchParams.get('id') || parsed.searchParams.get('slug');
      if (qId) return cleanId(qId);
    } catch {
      // ignore
    }
  }

  return '';
}

/**
 * Normalizes Supabase Storage, Cloudflare R2 (including bare r2.dev), and relative paths
 * into a publicly accessible HTTPS URL suitable for Googlebot, WhatsApp, and social crawlers.
 */
export function normalizePublicMediaUrl(
  rawUrl?: string | null,
  siteOrigin: string = DEFAULT_SITE_URL
): string | undefined {
  if (!rawUrl) return undefined;
  let trimmed = String(rawUrl).trim();
  if (!trimmed) return undefined;

  if (trimmed.startsWith('data:') || trimmed.startsWith('blob:') || trimmed.startsWith('/src/')) {
    return undefined;
  }

  const r2Base = getR2PublicBase();
  trimmed = trimmed.replace(/^https?:\/\/r2\.dev(?=\/|$)/i, r2Base);

  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed;
  }

  if (trimmed.startsWith('/')) {
    const cleanOrigin = siteOrigin.replace(/\/+$/, '');
    return `${cleanOrigin}${trimmed}`;
  }

  return undefined;
}

function getDefaultArtworkUrl(siteOrigin: string): string {
  const isLocal = /^http:\/\/(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?$/i.test(siteOrigin);
  const publicBase = isLocal ? DEFAULT_SITE_URL : siteOrigin.replace(/\/+$/, '');
  return `${publicBase}/teso_melodies_download_cover.jpg`;
}

function inferImageMimeType(url: string): string | undefined {
  const clean = url.split('?')[0].toLowerCase();
  if (clean.endsWith('.png')) return 'image/png';
  if (clean.endsWith('.webp')) return 'image/webp';
  if (clean.endsWith('.gif')) return 'image/gif';
  if (clean.endsWith('.jpg') || clean.endsWith('.jpeg')) return 'image/jpeg';
  return undefined;
}

export function escapeHtml(value: string): string {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function escapeXml(value: string): string {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function truncateText(text: string, maxLen: number): string {
  const clean = text.replace(/\s+/g, ' ').trim();
  if (clean.length <= maxLen) return clean;
  return `${clean.slice(0, maxLen - 1).trimEnd()}…`;
}

async function supabaseRestGet<T = any>(tableAndQuery: string, timeoutMs = 6000): Promise<T[] | null> {
  const { supabaseUrl, supabaseKey } = getSupabaseConfig();
  const endpoint = `${supabaseUrl}/rest/v1/${tableAndQuery}`;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(endpoint, {
      method: 'GET',
      headers: {
        apikey: supabaseKey,
        Authorization: `Bearer ${supabaseKey}`,
        Accept: 'application/json',
      },
      signal: controller.signal,
    });

    if (!res.ok) {
      return null;
    }

    const json = await res.json();
    return Array.isArray(json) ? (json as T[]) : null;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Fetches all published non-video songs from Supabase (paginated so large catalogs remain complete).
 */
async function fetchAllPublishedSongsFromRest(maxRows = 2000): Promise<any[]> {
  const pageSize = 500;
  const all: any[] = [];
  for (let offset = 0; offset < maxRows; offset += pageSize) {
    const rows = await supabaseRestGet<any>(
      `songs?select=id,title,artist,genre,category,duration,duration_sec,plays,likes,downloads_count,cover_url,audio_url,user_id,created_at&order=created_at.desc&limit=${pageSize}&offset=${offset}`
    );
    if (!rows || rows.length === 0) break;
    rows.forEach((r) => {
      if (String(r.category || '').toLowerCase() !== 'video') {
        all.push(r);
      }
    });
    if (rows.length < pageSize) break;
  }
  return all;
}

/**
 * Lightweight paginated fetch specifically for XML sitemap generation (only minimal columns needed for URLs & dates).
 */
async function fetchSitemapSongsFromRest(maxRows = 3000): Promise<any[]> {
  const pageSize = 1000;
  const all: any[] = [];
  for (let offset = 0; offset < maxRows; offset += pageSize) {
    const rows = await supabaseRestGet<any>(
      `songs?select=id,artist,genre,category,created_at&order=created_at.desc&limit=${pageSize}&offset=${offset}`,
      5500
    );
    if (!rows || rows.length === 0) break;
    rows.forEach((r) => {
      if (String(r.category || '').toLowerCase() !== 'video') {
        all.push(r);
      }
    });
    if (rows.length < pageSize) break;
  }
  return all;
}

async function fetchProfileFallback(
  userId?: string | null
): Promise<{ full_name?: string; avatar_url?: string; bio?: string } | null> {
  if (!userId) return null;
  try {
    const rows = await supabaseRestGet<{ full_name?: string; avatar_url?: string; bio?: string }>(
      `profiles?id=eq.${encodeURIComponent(userId)}&select=full_name,avatar_url,bio&limit=1`
    );
    return rows?.[0] || null;
  } catch {
    return null;
  }
}

async function fetchVideoSidecarMetadata(userId?: string | null, videoId?: string): Promise<any | null> {
  if (!userId || !videoId) return null;
  const { supabaseUrl } = getSupabaseConfig();
  const r2Base = getR2PublicBase();
  const cleanUser = userId.replace(/[^a-zA-Z0-9_-]/g, '');
  const cleanVideo = videoId.replace(/[^a-zA-Z0-9_-]/g, '');
  const candidates = [
    `${r2Base}/${cleanUser}/attachments/${cleanVideo}/video-meta.json`,
    `${supabaseUrl}/storage/v1/object/public/songs/${userId}/attachments/${videoId}/video-meta.json`,
    `${supabaseUrl}/storage/v1/object/public/app-files/${userId}/attachments/${videoId}/video-meta.json`,
  ];
  for (const url of candidates) {
    try {
      const res = await fetch(url);
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // ignore
    }
  }
  return null;
}

export function buildFallbackSiteMetadata(siteOrigin: string, pathSuffix = '/'): SocialShareMetadata {
  const cleanOrigin = siteOrigin.replace(/\/+$/, '');
  const cleanPath = pathSuffix.startsWith('/') ? pathSuffix : `/${pathSuffix}`;
  return {
    kind: 'site',
    title: 'Free Teso Music, Ugandan Songs & Gospel MP3 Downloads | TESO MELODIES',
    description:
      'Stream and download free Teso music, Teso gospel and worship songs, Ugandan dancehall, and Afrobeat MP3 tracks online on TESO MELODIES.',
    image: getDefaultArtworkUrl(cleanOrigin),
    imageType: 'image/jpeg',
    imageAlt: 'TESO MELODIES Official Cover',
    url: `${cleanOrigin}${cleanPath}`,
    type: 'website',
    siteName: 'TESO MELODIES',
    found: false,
  };
}

/**
 * 1. SONG PAGE SEO + SOCIAL METADATA (/song/:id)
 *    Generates unique keyword-optimized metadata, MusicRecording + BreadcrumbList JSON-LD,
 *    and crawlable semantic HTML with real internal links to artist, genre, and related songs.
 */
export async function buildSongShareMetadata(
  songId: string,
  siteOrigin: string = DEFAULT_SITE_URL
): Promise<SocialShareMetadata> {
  const cleanOrigin = siteOrigin.replace(/\/+$/, '');
  const canonicalUrl = `${cleanOrigin}/song/${encodeURIComponent(songId)}`;
  if (!songId) {
    return buildFallbackSiteMetadata(cleanOrigin, '/');
  }

  try {
    const rows = await supabaseRestGet<any>(
      `songs?id=eq.${encodeURIComponent(songId)}&select=*&limit=1`
    );
    const row = rows?.[0];

    if (!row) {
      return {
        ...buildFallbackSiteMetadata(cleanOrigin, `/song/${encodeURIComponent(songId)}`),
        url: canonicalUrl,
      };
    }

    const profile = !row.cover_url || !row.artist ? await fetchProfileFallback(row.user_id) : null;
    const songTitle = String(row.title || 'Untitled Track').trim();
    const artistName = String(row.artist || profile?.full_name || 'Independent Artist').trim();
    const rawGenre = String(row.genre || 'Teso Music').trim();
    const genreDisplay = formatGenreDisplayName(rawGenre);
    const artistSlug = canonicalArtistSlug(artistName);
    const genreSlug = canonicalGenreSlug(rawGenre);
    const artistUrl = `${cleanOrigin}/artist/${encodeURIComponent(artistSlug)}`;
    const genreUrl = `${cleanOrigin}/genre/${encodeURIComponent(genreSlug)}`;
    const duration = row.duration ? String(row.duration).trim() : '';
    const isoDuration = formatIsoDuration(duration, row.duration_sec);
    const customDescription = row.description ? String(row.description).trim() : '';
    const playsCount = Math.max(0, Number(row.plays) || 0);
    const likesCount = Math.max(0, Number(row.likes) || 0);
    const downloadsCount = Math.max(0, Number(row.downloads_count) || 0);

    const image =
      normalizePublicMediaUrl(row.cover_url, cleanOrigin) ||
      normalizePublicMediaUrl(profile?.avatar_url, cleanOrigin) ||
      getDefaultArtworkUrl(cleanOrigin);

    const audioUrl = normalizePublicMediaUrl(row.audio_url, cleanOrigin);

    // Fetch real related songs by the same artist & in the same genre for crawlable internal linking
    const [artistSongsRaw, genreSongsRaw] = await Promise.all([
      supabaseRestGet<any>(
        `songs?artist=ilike.${encodeURIComponent(artistName)}&select=id,title,artist,genre,duration,category&order=likes.desc&limit=8`
      ).catch(() => null),
      supabaseRestGet<any>(
        `songs?genre=ilike.${encodeURIComponent(rawGenre)}&select=id,title,artist,genre,duration,category&order=likes.desc&limit=8`
      ).catch(() => null),
    ]);

    const moreByArtist = (artistSongsRaw || [])
      .filter((s) => String(s.id) !== String(row.id) && String(s.category || '') !== 'video')
      .slice(0, 6);
    const relatedInGenre = (genreSongsRaw || [])
      .filter(
        (s) =>
          String(s.id) !== String(row.id) &&
          String(s.category || '') !== 'video' &&
          !moreByArtist.some((m) => String(m.id) === String(s.id))
      )
      .slice(0, 6);

    // Organic search-first title (song title + artist + MP3 download / listen online)
    const metaTitle = truncateText(
      `${songTitle} by ${artistName} – MP3 Download & Listen Online | TESO MELODIES`,
      95
    );

    const naturalSummary = customDescription
      ? `${customDescription} Listen online or download "${songTitle}" by ${artistName} (${genreDisplay}${duration ? `, ${duration}` : ''}) as free MP3 on TESO MELODIES.`
      : `Listen online and download "${songTitle}" by ${artistName} in ${genreDisplay}${duration ? ` (${duration})` : ''}. Free Ugandan & Teso music MP3 download on TESO MELODIES.`;

    const description = truncateText(naturalSummary, 165);

    const interactionStatistics: Record<string, any>[] = [];
    if (playsCount > 0) {
      interactionStatistics.push({
        '@type': 'InteractionCounter',
        interactionType: 'https://schema.org/ListenAction',
        userInteractionCount: playsCount,
      });
    }
    if (likesCount > 0) {
      interactionStatistics.push({
        '@type': 'InteractionCounter',
        interactionType: 'https://schema.org/LikeAction',
        userInteractionCount: likesCount,
      });
    }
    if (downloadsCount > 0) {
      interactionStatistics.push({
        '@type': 'InteractionCounter',
        interactionType: 'https://schema.org/DownloadAction',
        userInteractionCount: downloadsCount,
      });
    }

    const musicRecordingSchema: Record<string, any> = {
      '@type': 'MusicRecording',
      '@id': `${canonicalUrl}#recording`,
      name: songTitle,
      url: canonicalUrl,
      image,
      genre: genreDisplay,
      description,
      isAccessibleForFree: true,
      byArtist: {
        '@type': 'MusicGroup',
        name: artistName,
        url: artistUrl,
      },
      ...(isoDuration ? { duration: isoDuration } : {}),
      ...(row.created_at ? { datePublished: String(row.created_at) } : {}),
      ...(audioUrl
        ? {
            audio: {
              '@type': 'AudioObject',
              contentUrl: audioUrl,
              encodingFormat: row.audio_mime_type || 'audio/mpeg',
            },
          }
        : {}),
      ...(interactionStatistics.length > 0 ? { interactionStatistic: interactionStatistics } : {}),
    };

    const breadcrumbSchema = {
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: `${cleanOrigin}/` },
        { '@type': 'ListItem', position: 2, name: genreDisplay, item: genreUrl },
        { '@type': 'ListItem', position: 3, name: artistName, item: artistUrl },
        { '@type': 'ListItem', position: 4, name: songTitle, item: canonicalUrl },
      ],
    };

    const moreByArtistLinks = moreByArtist
      .map(
        (s) =>
          `<li><a href="/song/${encodeURIComponent(String(s.id))}">${escapeHtml(String(s.title))} by ${escapeHtml(String(s.artist || artistName))} – MP3 Download</a></li>`
      )
      .join('');

    const relatedGenreLinks = relatedInGenre
      .map(
        (s) =>
          `<li><a href="/song/${encodeURIComponent(String(s.id))}">${escapeHtml(String(s.title))} by ${escapeHtml(String(s.artist || 'Artist'))} (${escapeHtml(formatGenreDisplayName(s.genre || rawGenre))})</a></li>`
      )
      .join('');

    const seoBodyHtml = `<main style="max-width:960px;margin:0 auto;padding:24px;font-family:system-ui,-apple-system,sans-serif;color:#f8fafc;">
      <nav aria-label="Breadcrumb" style="font-size:13px;margin-bottom:12px;">
        <a href="/">Home</a> &rsaquo; <a href="/genre/${encodeURIComponent(genreSlug)}">${escapeHtml(genreDisplay)}</a> &rsaquo; <a href="/artist/${encodeURIComponent(artistSlug)}">${escapeHtml(artistName)}</a>
      </nav>
      <h1>${escapeHtml(songTitle)} by ${escapeHtml(artistName)} – Free MP3 Download &amp; Listen Online</h1>
      <p>${escapeHtml(naturalSummary)}</p>
      <p>Artist: <a href="/artist/${encodeURIComponent(artistSlug)}">${escapeHtml(artistName)}</a> | Genre: <a href="/genre/${encodeURIComponent(genreSlug)}">${escapeHtml(genreDisplay)}</a>${duration ? ` | Duration: ${escapeHtml(duration)}` : ''}</p>
      ${moreByArtistLinks ? `<section><h2>More Songs by ${escapeHtml(artistName)}</h2><ul>${moreByArtistLinks}</ul></section>` : ''}
      ${relatedGenreLinks ? `<section><h2>Related ${escapeHtml(genreDisplay)} Songs</h2><ul>${relatedGenreLinks}</ul></section>` : ''}
      <p><a href="/genre/teso-music">Explore Teso Music</a> | <a href="/genre/teso-gospel-music">Teso Gospel Music</a> | <a href="/artists">All Artists</a></p>
    </main>`;

    return {
      kind: 'song',
      id: String(row.id),
      title: metaTitle,
      description,
      image,
      imageType: inferImageMimeType(image),
      imageAlt: `${songTitle} by ${artistName} cover artwork`,
      url: canonicalUrl,
      type: 'music.song',
      siteName: 'TESO MELODIES',
      artist: artistName,
      categoryOrGenre: genreDisplay,
      duration,
      mediaUrl: audioUrl,
      schemaGraph: [musicRecordingSchema, breadcrumbSchema],
      seoBodyHtml,
      found: true,
    };
  } catch (err) {
    console.warn('[socialShare] Failed fetching song metadata:', err);
    return {
      ...buildFallbackSiteMetadata(cleanOrigin, `/song/${encodeURIComponent(songId)}`),
      url: canonicalUrl,
    };
  }
}

/**
 * 2. ARTIST PAGE SEO (/artist/:slug)
 *    Generates unique artist metadata, MusicGroup/Person JSON-LD, factual biography (only if in DB),
 *    genres, real follower count, and real HTML links to all published songs by the artist.
 */
export async function buildArtistSeoMetadata(
  artistSlugInput: string,
  siteOrigin: string = DEFAULT_SITE_URL
): Promise<SocialShareMetadata> {
  const cleanOrigin = siteOrigin.replace(/\/+$/, '');
  const cleanSlug = canonicalArtistSlug(artistSlugInput);
  const canonicalUrl = `${cleanOrigin}/artist/${encodeURIComponent(cleanSlug)}`;
  if (!artistSlugInput) {
    return buildFallbackSiteMetadata(cleanOrigin, '/artists');
  }

  try {
    const [statRows, allSongs, profiles] = await Promise.all([
      supabaseRestGet<any>(
        `artist_follower_stats?artist_slug=eq.${encodeURIComponent(cleanSlug)}&select=*&limit=1`
      ).catch(() => null),
      fetchAllPublishedSongsFromRest(1500),
      supabaseRestGet<any>('profiles?select=id,full_name,username,avatar_url,role,bio&limit=300').catch(
        () => null
      ),
    ]);

    const statRow = statRows?.[0] || null;
    const targetLower = artistSlugInput.toLowerCase().trim();

    const matchedSongs = allSongs.filter((s) => {
      const aName = String(s.artist || '').trim();
      if (!aName) return false;
      const aSlug = canonicalArtistSlug(aName);
      return (
        aSlug === cleanSlug ||
        aName.toLowerCase() === targetLower ||
        (statRow && aName.toLowerCase() === String(statRow.artist_name || '').toLowerCase().trim())
      );
    });

    const matchedProfile = (profiles || []).find((p: any) => {
      const pName = String(p.full_name || p.username || '').trim();
      if (!pName) return false;
      const pSlug = canonicalArtistSlug(pName);
      return (
        pSlug === cleanSlug ||
        pName.toLowerCase() === targetLower ||
        (statRow && pName.toLowerCase() === String(statRow.artist_name || '').toLowerCase().trim())
      );
    });

    if (!statRow && matchedSongs.length === 0 && !matchedProfile) {
      return {
        ...buildFallbackSiteMetadata(cleanOrigin, `/artist/${encodeURIComponent(cleanSlug)}`),
        url: canonicalUrl,
      };
    }

    const artistName = String(
      statRow?.artist_name ||
        matchedProfile?.full_name ||
        matchedSongs[0]?.artist ||
        artistSlugInput
    ).trim();

    const realBio =
      matchedProfile?.bio && String(matchedProfile.bio).trim().length > 0
        ? String(matchedProfile.bio).trim()
        : '';

    const uniqueGenres = Array.from(
      new Set(
        matchedSongs
          .map((s) => formatGenreDisplayName(String(s.genre || '').trim()))
          .filter(Boolean)
      )
    );
    const primaryGenresText =
      uniqueGenres.length > 0 ? uniqueGenres.slice(0, 3).join(', ') : 'Teso & Ugandan Music';

    const songCount = Math.max(matchedSongs.length, Number(statRow?.song_count) || 0);
    const totalFollowers = Math.max(0, Number(statRow?.total_followers) || 0);

    const sortedSongs = [...matchedSongs].sort(
      (a, b) =>
        (Number(b.likes) || 0) +
        (Number(b.downloads_count) || 0) +
        (Number(b.plays) || 0) -
        ((Number(a.likes) || 0) + (Number(a.downloads_count) || 0) + (Number(a.plays) || 0))
    );

    const topSongTitles = sortedSongs
      .slice(0, 3)
      .map((s) => `"${String(s.title).trim()}"`)
      .filter(Boolean);

    const image =
      normalizePublicMediaUrl(matchedProfile?.avatar_url, cleanOrigin) ||
      normalizePublicMediaUrl(sortedSongs[0]?.cover_url, cleanOrigin) ||
      getDefaultArtworkUrl(cleanOrigin);

    const metaTitle = truncateText(
      `${artistName} Songs – Free MP3 Download & Artist Profile | TESO MELODIES`,
      95
    );

    const factualDescription = realBio
      ? `${realBio} Stream and download ${songCount} ${songCount === 1 ? 'song' : 'songs'} by ${artistName} (${primaryGenresText}) on TESO MELODIES.`
      : songCount > 0
      ? `Listen online and download ${songCount} ${songCount === 1 ? 'song' : 'songs'} by ${artistName}${topSongTitles.length > 0 ? `, including ${topSongTitles.join(', ')}` : ''}, in ${primaryGenresText}. Free MP3 downloads on TESO MELODIES.`
      : `Explore music, profile, and updates from ${artistName} on TESO MELODIES.`;

    const description = truncateText(factualDescription, 165);

    const artistSchema: Record<string, any> = {
      '@type': 'MusicGroup',
      '@id': `${canonicalUrl}#artist`,
      name: artistName,
      url: canonicalUrl,
      image,
      description,
      ...(uniqueGenres.length > 0 ? { genre: uniqueGenres } : {}),
      ...(totalFollowers > 0
        ? {
            interactionStatistic: {
              '@type': 'InteractionCounter',
              interactionType: 'https://schema.org/FollowAction',
              userInteractionCount: totalFollowers,
            },
          }
        : {}),
      ...(sortedSongs.length > 0
        ? {
            track: sortedSongs.slice(0, 25).map((s) => ({
              '@type': 'MusicRecording',
              name: String(s.title || '').trim(),
              url: `${cleanOrigin}/song/${encodeURIComponent(String(s.id))}`,
              genre: formatGenreDisplayName(String(s.genre || '')),
              ...(formatIsoDuration(s.duration, s.duration_sec)
                ? { duration: formatIsoDuration(s.duration, s.duration_sec) }
                : {}),
            })),
          }
        : {}),
    };

    const breadcrumbSchema = {
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: `${cleanOrigin}/` },
        { '@type': 'ListItem', position: 2, name: 'Artists', item: `${cleanOrigin}/artists` },
        { '@type': 'ListItem', position: 3, name: artistName, item: canonicalUrl },
      ],
    };

    const genreLinksHtml = uniqueGenres
      .map(
        (g) =>
          `<a href="/genre/${encodeURIComponent(canonicalGenreSlug(g))}">${escapeHtml(g)}</a>`
      )
      .join(' · ');

    const songsListHtml = sortedSongs
      .map(
        (s) =>
          `<li><a href="/song/${encodeURIComponent(String(s.id))}">${escapeHtml(String(s.title))} – ${escapeHtml(artistName)} (${escapeHtml(formatGenreDisplayName(s.genre || ''))}) MP3 Download</a></li>`
      )
      .join('');

    const seoBodyHtml = `<main style="max-width:960px;margin:0 auto;padding:24px;font-family:system-ui,-apple-system,sans-serif;color:#f8fafc;">
      <nav aria-label="Breadcrumb" style="font-size:13px;margin-bottom:12px;">
        <a href="/">Home</a> &rsaquo; <a href="/artists">Artists</a> &rsaquo; <span>${escapeHtml(artistName)}</span>
      </nav>
      <h1>${escapeHtml(artistName)} – Songs, MP3 Downloads &amp; Music Profile</h1>
      ${realBio ? `<p>${escapeHtml(realBio)}</p>` : `<p>${escapeHtml(factualDescription)}</p>`}
      <p>Songs: ${songCount}${totalFollowers > 0 ? ` | Followers: ${totalFollowers.toLocaleString()}` : ''}${genreLinksHtml ? ` | Genres: ${genreLinksHtml}` : ''}</p>
      ${songsListHtml ? `<section><h2>All Published Songs by ${escapeHtml(artistName)}</h2><ul>${songsListHtml}</ul></section>` : ''}
      <p><a href="/artists">Browse All Artists</a> | <a href="/genre/teso-music">Teso Music</a> | <a href="/genre/teso-gospel-music">Teso Gospel Music</a></p>
    </main>`;

    return {
      kind: 'artist',
      id: cleanSlug,
      title: metaTitle,
      description,
      image,
      imageType: inferImageMimeType(image),
      imageAlt: `${artistName} official artist photo`,
      url: canonicalUrl,
      type: 'profile',
      siteName: 'TESO MELODIES',
      artist: artistName,
      categoryOrGenre: primaryGenresText,
      schemaGraph: [artistSchema, breadcrumbSchema],
      seoBodyHtml,
      found: true,
    };
  } catch (err) {
    console.warn('[socialShare] Failed fetching artist SEO metadata:', err);
    return {
      ...buildFallbackSiteMetadata(cleanOrigin, `/artist/${encodeURIComponent(cleanSlug)}`),
      url: canonicalUrl,
    };
  }
}

/**
 * 3. GENRE PAGE SEO (/genre/:slug)
 *    Supports both actual DB genres (e.g. teso-worship, teso-dancehall, afrobeat, gospel, reggae, amapiano)
 *    and high-intent regional collections (teso-music, teso-gospel-music, ugandan-music, african-music).
 */
export async function buildGenreSeoMetadata(
  genreSlugInput: string,
  siteOrigin: string = DEFAULT_SITE_URL
): Promise<SocialShareMetadata> {
  const cleanOrigin = siteOrigin.replace(/\/+$/, '');
  const cleanSlug = canonicalGenreSlug(genreSlugInput);
  const canonicalUrl = `${cleanOrigin}/genre/${encodeURIComponent(cleanSlug)}`;
  if (!genreSlugInput) {
    return buildFallbackSiteMetadata(cleanOrigin, '/music');
  }

  try {
    const allSongs = await fetchAllPublishedSongsFromRest(1500);
    const regionalConfig = REGIONAL_GENRE_CONFIGS.find((c) => c.slug === cleanSlug) || null;

    let matchingSongs: any[] = [];
    let displayName = '';

    if (regionalConfig) {
      displayName = regionalConfig.displayName;
      matchingSongs =
        regionalConfig.matchDbGenres === 'ALL'
          ? allSongs
          : allSongs.filter((s) =>
              regionalConfig.matchDbGenres.includes(String(s.genre || '').toLowerCase().trim())
            );
    } else {
      matchingSongs = allSongs.filter((s) => {
        const gSlug = canonicalGenreSlug(s.genre);
        return gSlug === cleanSlug;
      });
      displayName = matchingSongs[0]?.genre
        ? formatGenreDisplayName(String(matchingSongs[0].genre))
        : formatGenreDisplayName(genreSlugInput.replace(/-/g, ' '));
    }

    const sortedSongs = [...matchingSongs].sort(
      (a, b) =>
        (Number(b.likes) || 0) +
        (Number(b.downloads_count) || 0) +
        (Number(b.plays) || 0) -
        ((Number(a.likes) || 0) + (Number(a.downloads_count) || 0) + (Number(a.plays) || 0))
    );

    const uniqueArtistMap = new Map<string, string>();
    for (const s of sortedSongs) {
      const rawName = String(s.artist || '').trim();
      if (!rawName) continue;
      const key = canonicalArtistSlug(rawName);
      if (!uniqueArtistMap.has(key)) {
        uniqueArtistMap.set(key, rawName);
      }
    }
    const uniqueArtists = Array.from(uniqueArtistMap.values());

    const image =
      normalizePublicMediaUrl(sortedSongs[0]?.cover_url, cleanOrigin) ||
      getDefaultArtworkUrl(cleanOrigin);

    const metaTitle = regionalConfig
      ? truncateText(regionalConfig.titleTemplate, 95)
      : truncateText(
          `${displayName} Songs – Free MP3 Download & Listen Online | TESO MELODIES`,
          95
        );

    const featuredArtistsText =
      uniqueArtists.length > 0 ? ` featuring ${uniqueArtists.slice(0, 4).join(', ')}` : '';
    const factualSummary =
      sortedSongs.length > 0
        ? `Stream and download ${sortedSongs.length} ${displayName} ${sortedSongs.length === 1 ? 'song' : 'songs'}${featuredArtistsText}. Free MP3 downloads and online audio streaming on TESO MELODIES.`
        : `Explore ${displayName} songs and free MP3 music downloads from Teso and Uganda on TESO MELODIES.`;

    const description = truncateText(factualSummary, 165);

    const collectionSchema: Record<string, any> = {
      '@type': 'CollectionPage',
      '@id': `${canonicalUrl}#genre`,
      name: regionalConfig ? regionalConfig.headline : `${displayName} Songs & MP3 Downloads`,
      url: canonicalUrl,
      description,
      mainEntity: {
        '@type': 'ItemList',
        numberOfItems: sortedSongs.length,
        itemListElement: sortedSongs.slice(0, 25).map((s, idx) => ({
          '@type': 'ListItem',
          position: idx + 1,
          item: {
            '@type': 'MusicRecording',
            name: String(s.title || '').trim(),
            url: `${cleanOrigin}/song/${encodeURIComponent(String(s.id))}`,
            genre: formatGenreDisplayName(String(s.genre || displayName)),
            byArtist: {
              '@type': 'MusicGroup',
              name: String(s.artist || 'Independent Artist').trim(),
              url: `${cleanOrigin}/artist/${encodeURIComponent(canonicalArtistSlug(s.artist))}`,
            },
          },
        })),
      },
    };

    const breadcrumbSchema = {
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: `${cleanOrigin}/` },
        { '@type': 'ListItem', position: 2, name: 'Music', item: `${cleanOrigin}/music` },
        { '@type': 'ListItem', position: 3, name: displayName, item: canonicalUrl },
      ],
    };

    const songsListHtml = sortedSongs
      .slice(0, 50)
      .map(
        (s) =>
          `<li><a href="/song/${encodeURIComponent(String(s.id))}">${escapeHtml(String(s.title))} by ${escapeHtml(String(s.artist || 'Artist'))} – MP3 Download</a> (<a href="/artist/${encodeURIComponent(canonicalArtistSlug(s.artist))}">${escapeHtml(String(s.artist || 'Artist'))}</a>)</li>`
      )
      .join('');

    const artistLinksHtml = uniqueArtists
      .slice(0, 20)
      .map(
        (name) =>
          `<li><a href="/artist/${encodeURIComponent(canonicalArtistSlug(name))}">${escapeHtml(name)}</a></li>`
      )
      .join('');

    const allGenreSlugs = Array.from(
      new Set([
        ...REGIONAL_GENRE_CONFIGS.map((c) => c.slug),
        ...allSongs.map((s) => canonicalGenreSlug(s.genre)).filter(Boolean),
      ])
    ).filter((s) => s !== cleanSlug);

    const otherGenresHtml = allGenreSlugs
      .slice(0, 12)
      .map((slug) => {
        const reg = REGIONAL_GENRE_CONFIGS.find((c) => c.slug === slug);
        const label = reg ? reg.displayName : formatGenreDisplayName(slug.replace(/-/g, ' '));
        return `<a href="/genre/${encodeURIComponent(slug)}">${escapeHtml(label)}</a>`;
      })
      .join(' · ');

    const seoBodyHtml = `<main style="max-width:960px;margin:0 auto;padding:24px;font-family:system-ui,-apple-system,sans-serif;color:#f8fafc;">
      <nav aria-label="Breadcrumb" style="font-size:13px;margin-bottom:12px;">
        <a href="/">Home</a> &rsaquo; <a href="/music">Music</a> &rsaquo; <span>${escapeHtml(displayName)}</span>
      </nav>
      <h1>${escapeHtml(regionalConfig ? regionalConfig.headline : `${displayName} Songs – Free MP3 Download & Listen Online`)}</h1>
      <p>${escapeHtml(factualSummary)}</p>
      ${songsListHtml ? `<section><h2>Latest ${escapeHtml(displayName)} Tracks</h2><ul>${songsListHtml}</ul></section>` : ''}
      ${artistLinksHtml ? `<section><h2>${escapeHtml(displayName)} Artists</h2><ul>${artistLinksHtml}</ul></section>` : ''}
      ${otherGenresHtml ? `<nav aria-label="Related Genres"><p>Browse Genres: ${otherGenresHtml}</p></nav>` : ''}
    </main>`;

    return {
      kind: 'genre',
      id: cleanSlug,
      title: metaTitle,
      description,
      image,
      imageType: inferImageMimeType(image),
      imageAlt: `${displayName} music on TESO MELODIES`,
      url: canonicalUrl,
      type: 'website',
      siteName: 'TESO MELODIES',
      categoryOrGenre: displayName,
      schemaGraph: [collectionSchema, breadcrumbSchema],
      seoBodyHtml,
      found: sortedSongs.length > 0 || Boolean(regionalConfig),
    };
  } catch (err) {
    console.warn('[socialShare] Failed fetching genre SEO metadata:', err);
    return {
      ...buildFallbackSiteMetadata(cleanOrigin, `/genre/${encodeURIComponent(cleanSlug)}`),
      url: canonicalUrl,
    };
  }
}

/**
 * 4. VIDEO PAGE SEO + SOCIAL METADATA (/video/:id)
 *    Fetches live video metadata from Supabase (`public.videos` primary, `public.songs` category='video' fallback)
 *    with public R2 / Supabase Storage thumbnail resolution and VideoObject + BreadcrumbList schema.
 */
export async function buildVideoShareMetadata(
  videoId: string,
  siteOrigin: string = DEFAULT_SITE_URL
): Promise<SocialShareMetadata> {
  const cleanOrigin = siteOrigin.replace(/\/+$/, '');
  const canonicalUrl = `${cleanOrigin}/video/${encodeURIComponent(videoId)}`;
  if (!videoId) {
    return buildFallbackSiteMetadata(cleanOrigin, '/videos');
  }

  try {
    let row: any = null;
    const videoRows = await supabaseRestGet<any>(
      `videos?id=eq.${encodeURIComponent(videoId)}&select=*&limit=1`
    );
    if (videoRows?.[0]) {
      row = videoRows[0];
    } else {
      const songVideoRows = await supabaseRestGet<any>(
        `songs?id=eq.${encodeURIComponent(videoId)}&category=eq.video&select=*&limit=1`
      );
      if (songVideoRows?.[0]) {
        const sidecar = await fetchVideoSidecarMetadata(songVideoRows[0].user_id, String(videoId));
        row = {
          ...songVideoRows[0],
          ...(sidecar || {}),
        };
      }
    }

    if (!row) {
      return {
        ...buildFallbackSiteMetadata(cleanOrigin, `/video/${encodeURIComponent(videoId)}`),
        url: canonicalUrl,
      };
    }

    const rawThumb = row.thumbnail_url || row.cover_url;
    const profile = !rawThumb || !row.artist ? await fetchProfileFallback(row.user_id) : null;

    const videoTitle = String(row.title || 'Untitled Video').trim();
    const artistName = String(row.artist || profile?.full_name || 'Independent Artist').trim();
    const artistSlug = canonicalArtistSlug(artistName);
    const category = String(
      row.category && row.category !== 'video' ? row.category : row.genre || 'Music Video'
    ).trim();
    const duration = row.duration ? String(row.duration).trim() : '';
    const isoDuration = formatIsoDuration(duration, row.duration_sec);
    const rawDesc = String(row.description || '').trim();

    const image =
      normalizePublicMediaUrl(rawThumb, cleanOrigin) ||
      normalizePublicMediaUrl(profile?.avatar_url, cleanOrigin) ||
      getDefaultArtworkUrl(cleanOrigin);

    const videoUrl = normalizePublicMediaUrl(row.video_url || row.audio_url, cleanOrigin);

    const metaTitle = truncateText(`${videoTitle} by ${artistName} – Official Video | TESO MELODIES`, 95);
    const hasDistinctDescription =
      rawDesc.length > 0 && rawDesc.toLowerCase() !== videoTitle.toLowerCase();

    const description = truncateText(
      hasDistinctDescription
        ? `${rawDesc} — Watch "${videoTitle}" by ${artistName} (${category}) on TESO MELODIES.`
        : `Watch "${videoTitle}" by ${artistName} (${category}${duration ? ` • ${duration}` : ''}) online on TESO MELODIES Videos.`,
      165
    );

    const videoSchema: Record<string, any> = {
      '@type': 'VideoObject',
      name: videoTitle,
      description,
      thumbnailUrl: [image],
      ...(row.created_at ? { uploadDate: String(row.created_at) } : {}),
      ...(isoDuration ? { duration: isoDuration } : {}),
      ...(videoUrl ? { contentUrl: videoUrl } : {}),
      author: {
        '@type': 'Person',
        name: artistName,
        url: `${cleanOrigin}/artist/${encodeURIComponent(artistSlug)}`,
      },
    };

    const breadcrumbSchema = {
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: `${cleanOrigin}/` },
        { '@type': 'ListItem', position: 2, name: 'Videos', item: `${cleanOrigin}/videos` },
        { '@type': 'ListItem', position: 3, name: videoTitle, item: canonicalUrl },
      ],
    };

    const seoBodyHtml = `<main style="max-width:960px;margin:0 auto;padding:24px;font-family:system-ui,-apple-system,sans-serif;color:#f8fafc;">
      <nav aria-label="Breadcrumb"><a href="/">Home</a> &rsaquo; <a href="/videos">Videos</a> &rsaquo; <a href="/artist/${encodeURIComponent(artistSlug)}">${escapeHtml(artistName)}</a></nav>
      <h1>${escapeHtml(videoTitle)} – ${escapeHtml(artistName)}</h1>
      <p>${escapeHtml(description)}</p>
      <p><a href="/artist/${encodeURIComponent(artistSlug)}">More from ${escapeHtml(artistName)}</a> | <a href="/videos">All Music Videos</a></p>
    </main>`;

    return {
      kind: 'video',
      id: String(row.id),
      title: metaTitle,
      description,
      image,
      imageType: inferImageMimeType(image),
      imageAlt: `${videoTitle} by ${artistName} video thumbnail`,
      url: canonicalUrl,
      type: 'video.other',
      siteName: 'TESO MELODIES',
      artist: artistName,
      categoryOrGenre: category,
      duration,
      mediaUrl: videoUrl,
      schemaGraph: [videoSchema, breadcrumbSchema],
      seoBodyHtml,
      found: true,
    };
  } catch (err) {
    console.warn('[socialShare] Failed fetching video metadata:', err);
    return {
      ...buildFallbackSiteMetadata(cleanOrigin, `/video/${encodeURIComponent(videoId)}`),
      url: canonicalUrl,
    };
  }
}

/**
 * Guaranteed valid XML fallback sitemap (used if upstream database is momentarily unreachable)
 * so /sitemap.xml NEVER falls back to an HTML error page.
 */
export function buildFallbackSitemapXml(siteOrigin: string = DEFAULT_SITE_URL): string {
  const cleanOrigin = siteOrigin.replace(/\/+$/, '');
  const nowIso = new Date().toISOString().split('T')[0];
  const corePaths = [
    { path: '/', changefreq: 'daily', priority: '1.0' },
    { path: '/music', changefreq: 'daily', priority: '0.9' },
    { path: '/artists', changefreq: 'daily', priority: '0.9' },
    { path: '/videos', changefreq: 'daily', priority: '0.8' },
    { path: '/news', changefreq: 'daily', priority: '0.7' },
    { path: '/about', changefreq: 'monthly', priority: '0.5' },
    { path: '/privacy-policy', changefreq: 'monthly', priority: '0.3' },
    { path: '/terms-and-conditions', changefreq: 'monthly', priority: '0.3' },
    ...REGIONAL_GENRE_CONFIGS.map((cfg) => ({
      path: `/genre/${encodeURIComponent(cfg.slug)}`,
      changefreq: 'daily',
      priority: '0.9',
    })),
  ];

  const blocks = corePaths
    .map(
      (item) =>
        `  <url>\n    <loc>${escapeXml(`${cleanOrigin}${item.path}`)}</loc>\n    <lastmod>${escapeXml(nowIso)}</lastmod>\n    <changefreq>${item.changefreq}</changefreq>\n    <priority>${item.priority}</priority>\n  </url>`
    )
    .join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${blocks}\n</urlset>\n`;
}

/**
 * 5. AUTOMATIC DYNAMIC XML SITEMAP (/sitemap.xml)
 *    Includes all public pages, all published songs, all artists, all real genres + regional collections, and videos.
 */
export async function buildDynamicSitemapXml(siteOrigin: string = DEFAULT_SITE_URL): Promise<string> {
  const cleanOrigin = siteOrigin.replace(/\/+$/, '');
  const nowIso = new Date().toISOString().split('T')[0];

  const [songs, videos, artistStats] = await Promise.all([
    fetchSitemapSongsFromRest(3000).catch(() => []),
    supabaseRestGet<any>('videos?select=id,created_at&order=created_at.desc&limit=500', 5500).catch(() => []),
    supabaseRestGet<any>('artist_follower_stats?select=artist_slug,artist_name,song_count&order=total_followers.desc', 5500).catch(
      () => []
    ),
  ]);

  interface SitemapEntry {
    loc: string;
    lastmod?: string;
    changefreq: 'daily' | 'weekly' | 'monthly';
    priority: string;
  }

  const entries: SitemapEntry[] = [];
  const seenLocs = new Set<string>();
  const addEntry = (entry: SitemapEntry) => {
    if (seenLocs.has(entry.loc)) return;
    seenLocs.add(entry.loc);
    entries.push(entry);
  };

  // Core public pages
  addEntry({ loc: `${cleanOrigin}/`, lastmod: nowIso, changefreq: 'daily', priority: '1.0' });
  addEntry({ loc: `${cleanOrigin}/music`, lastmod: nowIso, changefreq: 'daily', priority: '0.9' });
  addEntry({ loc: `${cleanOrigin}/artists`, lastmod: nowIso, changefreq: 'daily', priority: '0.9' });
  addEntry({ loc: `${cleanOrigin}/videos`, lastmod: nowIso, changefreq: 'daily', priority: '0.8' });
  addEntry({ loc: `${cleanOrigin}/news`, lastmod: nowIso, changefreq: 'daily', priority: '0.7' });
  addEntry({ loc: `${cleanOrigin}/about`, lastmod: nowIso, changefreq: 'monthly', priority: '0.5' });
  addEntry({ loc: `${cleanOrigin}/privacy-policy`, lastmod: nowIso, changefreq: 'monthly', priority: '0.3' });
  addEntry({ loc: `${cleanOrigin}/terms-and-conditions`, lastmod: nowIso, changefreq: 'monthly', priority: '0.3' });

  // Regional & high-intent music genre pages
  REGIONAL_GENRE_CONFIGS.forEach((cfg) => {
    addEntry({
      loc: `${cleanOrigin}/genre/${encodeURIComponent(cfg.slug)}`,
      lastmod: nowIso,
      changefreq: 'daily',
      priority: '0.9',
    });
  });

  // Actual genres represented in the database
  const dbGenreLatest = new Map<string, string>();
  songs.forEach((s) => {
    const gSlug = canonicalGenreSlug(s.genre);
    if (!gSlug || gSlug === 'music') return;
    const dateStr = s.created_at ? String(s.created_at).split('T')[0] : nowIso;
    if (!dbGenreLatest.has(gSlug) || dateStr > (dbGenreLatest.get(gSlug) || '')) {
      dbGenreLatest.set(gSlug, dateStr);
    }
  });
  dbGenreLatest.forEach((lastmod, slug) => {
    addEntry({
      loc: `${cleanOrigin}/genre/${encodeURIComponent(slug)}`,
      lastmod,
      changefreq: 'daily',
      priority: '0.85',
    });
  });

  // Artist pages from artist_follower_stats + all song artists
  const artistLatest = new Map<string, string>();
  (artistStats || []).forEach((st: any) => {
    const slug = st.artist_slug ? String(st.artist_slug).trim() : canonicalArtistSlug(st.artist_name);
    if (slug) artistLatest.set(slug, nowIso);
  });
  songs.forEach((s) => {
    const slug = canonicalArtistSlug(s.artist);
    if (!slug) return;
    const dateStr = s.created_at ? String(s.created_at).split('T')[0] : nowIso;
    if (!artistLatest.has(slug) || dateStr > (artistLatest.get(slug) || '')) {
      artistLatest.set(slug, dateStr);
    }
  });
  artistLatest.forEach((lastmod, slug) => {
    addEntry({
      loc: `${cleanOrigin}/artist/${encodeURIComponent(slug)}`,
      lastmod,
      changefreq: 'weekly',
      priority: '0.85',
    });
  });

  // All published song pages
  songs.forEach((s) => {
    if (!s.id) return;
    const lastmod = s.created_at ? String(s.created_at).split('T')[0] : nowIso;
    addEntry({
      loc: `${cleanOrigin}/song/${encodeURIComponent(String(s.id))}`,
      lastmod,
      changefreq: 'weekly',
      priority: '0.8',
    });
  });

  // All published video pages
  (videos || []).forEach((v: any) => {
    if (!v.id) return;
    const lastmod = v.created_at ? String(v.created_at).split('T')[0] : nowIso;
    addEntry({
      loc: `${cleanOrigin}/video/${encodeURIComponent(String(v.id))}`,
      lastmod,
      changefreq: 'weekly',
      priority: '0.7',
    });
  });

  const urlBlocks = entries
    .map((e) => {
      const parts = [
        `  <url>`,
        `    <loc>${escapeXml(e.loc)}</loc>`,
        ...(e.lastmod ? [`    <lastmod>${escapeXml(e.lastmod)}</lastmod>`] : []),
        `    <changefreq>${e.changefreq}</changefreq>`,
        `    <priority>${e.priority}</priority>`,
        `  </url>`,
      ];
      return parts.join('\n');
    })
    .join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urlBlocks}\n</urlset>\n`;
}

/**
 * Attempts to locate the built `dist/index.html` on disk (bundled via netlify.toml included_files)
 * or falls back to fetching `/index.html` from the live origin.
 */
export async function readBuiltIndexHtml(siteOrigin: string): Promise<string | null> {
  const candidates = [
    path.resolve(process.cwd(), 'dist', 'index.html'),
    path.resolve(process.cwd(), 'index.html'),
    path.resolve(process.cwd(), '..', '..', 'dist', 'index.html'),
  ];

  for (const filePath of candidates) {
    try {
      if (fs.existsSync(filePath)) {
        const html = fs.readFileSync(filePath, 'utf-8');
        if (html && html.includes('<head')) {
          return html;
        }
      }
    } catch {
      // try next path
    }
  }

  if (siteOrigin && /^https?:\/\//i.test(siteOrigin) && !siteOrigin.includes('localhost')) {
    try {
      const res = await fetch(`${siteOrigin.replace(/\/+$/, '')}/index.html`);
      if (res.ok) {
        const html = await res.text();
        if (html && html.includes('<head')) {
          return html;
        }
      }
    } catch {
      // fall through to standalone HTML shell
    }
  }

  return null;
}

function buildHeadMetaBlock(meta: SocialShareMetadata): string {
  const escapedTitle = escapeHtml(meta.title);
  const escapedDesc = escapeHtml(meta.description);
  const escapedUrl = escapeHtml(meta.url);
  const escapedImage = escapeHtml(meta.image);
  const escapedImageAlt = escapeHtml(meta.imageAlt);
  const escapedSiteName = escapeHtml(meta.siteName);

  const schemaPayload =
    meta.schemaGraph && meta.schemaGraph.length > 0
      ? {
          '@context': 'https://schema.org',
          '@graph': meta.schemaGraph,
        }
      : null;

  const lines = [
    `<title>${escapedTitle}</title>`,
    `<meta name="description" content="${escapedDesc}" />`,
    `<meta name="robots" content="index, follow, max-image-preview:large" />`,
    `<link rel="canonical" href="${escapedUrl}" />`,
    `<meta property="og:site_name" content="${escapedSiteName}" />`,
    `<meta property="og:type" content="${escapeHtml(meta.type)}" />`,
    `<meta property="og:title" content="${escapedTitle}" />`,
    `<meta property="og:description" content="${escapedDesc}" />`,
    `<meta property="og:url" content="${escapedUrl}" />`,
    `<meta property="og:image" content="${escapedImage}" />`,
    `<meta property="og:image:secure_url" content="${escapedImage}" />`,
    ...(meta.imageType ? [`<meta property="og:image:type" content="${escapeHtml(meta.imageType)}" />`] : []),
    `<meta property="og:image:alt" content="${escapedImageAlt}" />`,
    ...(meta.kind === 'song' && meta.mediaUrl
      ? [`<meta property="og:audio" content="${escapeHtml(meta.mediaUrl)}" />`]
      : []),
    `<meta name="twitter:card" content="summary_large_image" />`,
    `<meta name="twitter:title" content="${escapedTitle}" />`,
    `<meta name="twitter:description" content="${escapedDesc}" />`,
    `<meta name="twitter:image" content="${escapedImage}" />`,
    `<meta name="twitter:image:alt" content="${escapedImageAlt}" />`,
    ...(schemaPayload
      ? [
          `<script id="ssr-seo-jsonld" type="application/ld+json">${JSON.stringify(schemaPayload).replace(/</g, '\\u003c')}</script>`,
        ]
      : []),
  ];

  return lines.join('\n    ');
}

/**
 * Injects dynamic SEO & social metadata (plus crawlable semantic HTML inside #root that React
 * seamlessly replaces on hydration) into the built Vite HTML template.
 */
export function renderSocialShareHtml(
  templateHtml: string | null,
  meta: SocialShareMetadata,
  fallbackAppRedirectPath: string
): string {
  const metaBlock = buildHeadMetaBlock(meta);

  if (templateHtml && templateHtml.includes('<head')) {
    let cleaned = templateHtml
      .replace(/<title>[\s\S]*?<\/title>/gi, '')
      .replace(/<meta\b[^>]*\bname=["']description["'][^>]*>/gi, '')
      .replace(/<meta\b[^>]*\bname=["']robots["'][^>]*>/gi, '')
      .replace(/<meta\b[^>]*\bproperty=["']og:[^"']+["'][^>]*>/gi, '')
      .replace(/<meta\b[^>]*\bname=["']twitter:[^"']+["'][^>]*>/gi, '')
      .replace(/<link\b[^>]*\brel=["']canonical["'][^>]*>/gi, '')
      .replace(/<script\b[^>]*\btype=["']application\/ld\+json["'][^>]*>[\s\S]*?<\/script>/gi, '');

    if (/<head[^>]*>/i.test(cleaned)) {
      cleaned = cleaned.replace(/<head([^>]*)>/i, `<head$1>\n    ${metaBlock}\n`);
    }

    // Inject crawlable semantic HTML inside <div id="root"> so Googlebot sees full content & real links immediately;
    // ReactDOM.createRoot(...).render() cleanly replaces #root on client mount with zero layout changes.
    if (meta.seoBodyHtml && /<div\s+id=["']root["']\s*><\/div>/i.test(cleaned)) {
      cleaned = cleaned.replace(
        /<div\s+id=["']root["']\s*><\/div>/i,
        `<div id="root">${meta.seoBodyHtml}</div>`
      );
    }

    return cleaned;
  }

  const escapedUrl = escapeHtml(fallbackAppRedirectPath);
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    ${metaBlock}
  </head>
  <body style="margin:0;background:#011d4d;color:#fff;font-family:system-ui,-apple-system,sans-serif;min-height:100vh;padding:24px;">
    ${meta.seoBodyHtml || `<div><h1>${escapeHtml(meta.title)}</h1><p>${escapeHtml(meta.description)}</p></div>`}
    <p style="text-align:center;margin-top:20px;"><a href="${escapedUrl}" style="display:inline-block;padding:12px 24px;border-radius:12px;background:#FFCC00;color:#000;font-weight:800;text-decoration:none;">Open on TESO MELODIES</a></p>
  </body>
</html>`;
}
