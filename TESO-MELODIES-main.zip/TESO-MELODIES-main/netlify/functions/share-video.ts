import {
  resolveOriginFromHeaders,
  extractRouteItemId,
  buildVideoShareMetadata,
  readBuiltIndexHtml,
  renderSocialShareHtml,
} from './_socialShare';

export const handler = async (event: any) => {
  if (event.httpMethod && !['GET', 'HEAD'].includes(event.httpMethod.toUpperCase())) {
    return {
      statusCode: 405,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
      body: 'Method Not Allowed',
    };
  }

  const origin = resolveOriginFromHeaders(event.headers, event.rawUrl);
  const queryId = event.queryStringParameters?.id;
  const videoId = extractRouteItemId(queryId, event.path, event.rawUrl, 'video');

  const meta = await buildVideoShareMetadata(videoId, origin);
  const templateHtml = await readBuiltIndexHtml(origin);
  const fallbackAppUrl = videoId ? `/videos?video=${encodeURIComponent(videoId)}` : '/videos';
  const html = renderSocialShareHtml(templateHtml, meta, fallbackAppUrl);

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'public, max-age=60, s-maxage=300',
      'X-Robots-Tag': 'all',
    },
    body: event.httpMethod?.toUpperCase() === 'HEAD' ? '' : html,
  };
};
