-- ==============================================================================
-- TESO MELODIES.COM - REAL SUPABASE DATABASE & STORAGE CONFIGURATION
-- Confirmed real structure:
-- Table: public.songs
-- Table: public.profiles
-- Table: public.user_favorites
-- Storage bucket: songs (Public)
-- ==============================================================================

-- 1. SONGS TABLE (Confirmed Structure)
-- id, user_id, title, artist, genre, duration, duration_sec, category, cover_url, audio_url, plays, likes, rank, created_at, updated_at
CREATE TABLE IF NOT EXISTS public.songs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  artist TEXT NOT NULL,
  genre TEXT DEFAULT 'Afrobeat',
  duration TEXT DEFAULT '03:30',
  duration_sec INTEGER DEFAULT 210,
  category TEXT DEFAULT 'new',
  cover_url TEXT,
  audio_url TEXT NOT NULL,
  plays INTEGER DEFAULT 0 NOT NULL,
  likes INTEGER DEFAULT 0 NOT NULL,
  rank INTEGER,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable Row Level Security (RLS) on songs
ALTER TABLE public.songs ENABLE ROW LEVEL SECURITY;

-- Everyone can view published songs
DROP POLICY IF EXISTS "Public can view songs" ON public.songs;
CREATE POLICY "Public can view songs" ON public.songs
  FOR SELECT USING (true);

-- Authenticated users can upload songs (user_id must match auth.uid())
DROP POLICY IF EXISTS "Users can upload their own songs" ON public.songs;
CREATE POLICY "Users can upload their own songs" ON public.songs
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Artists can update their own songs
DROP POLICY IF EXISTS "Users can update their own songs" ON public.songs;
CREATE POLICY "Users can update their own songs" ON public.songs
  FOR UPDATE USING (auth.uid() = user_id);

-- Artists can delete their own songs
DROP POLICY IF EXISTS "Users can delete their own songs" ON public.songs;
CREATE POLICY "Users can delete their own songs" ON public.songs
  FOR DELETE USING (auth.uid() = user_id);


-- 2. PROFILES TABLE (Confirmed Structure)
-- id, full_name, username, avatar_url, role, bio, created_at, updated_at
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  username TEXT,
  avatar_url TEXT,
  role TEXT DEFAULT 'fan',
  bio TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view profiles" ON public.profiles;
CREATE POLICY "Public can view profiles" ON public.profiles
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
CREATE POLICY "Users can update their own profile" ON public.profiles
  FOR ALL USING (auth.uid() = id);


-- 3. USER FAVORITES TABLE
CREATE TABLE IF NOT EXISTS public.user_favorites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  song_id UUID REFERENCES public.songs(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  CONSTRAINT unique_user_song_favorite UNIQUE (user_id, song_id)
);

ALTER TABLE public.user_favorites ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their favorites" ON public.user_favorites;
CREATE POLICY "Users can view their favorites" ON public.user_favorites
  FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can manage their favorites" ON public.user_favorites;
CREATE POLICY "Users can manage their favorites" ON public.user_favorites
  FOR ALL USING (auth.uid() = user_id);


-- 4. STORAGE BUCKETS: "songs" & "app-files" (PUBLIC, 100MB LIMIT, ALL AUDIO/IMAGE/VIDEO FORMATS)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('songs', 'songs', true, 104857600, NULL)
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 104857600,
  allowed_mime_types = NULL;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('app-files', 'app-files', true, 104857600, NULL)
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 104857600,
  allowed_mime_types = NULL;

-- Storage RLS Policies for "songs" and "app-files" buckets
DROP POLICY IF EXISTS "Public can view and stream audio files" ON storage.objects;
CREATE POLICY "Public can view and stream audio files" ON storage.objects
  FOR SELECT USING (bucket_id IN ('songs', 'app-files'));

DROP POLICY IF EXISTS "Authenticated users can upload audio files" ON storage.objects;
CREATE POLICY "Authenticated users can upload audio files" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id IN ('songs', 'app-files')
    AND auth.uid() IS NOT NULL
  );

DROP POLICY IF EXISTS "Users can update their own storage files" ON storage.objects;
CREATE POLICY "Users can update their own storage files" ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id IN ('songs', 'app-files')
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

DROP POLICY IF EXISTS "Users can delete their own storage files" ON storage.objects;
CREATE POLICY "Users can delete their own storage files" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id IN ('songs', 'app-files')
    AND auth.uid()::text = (storage.foldername(name))[1]
  );


-- 5. SONG COMMENTS & REVIEWS TABLE
-- Stores permanent fan comments, ratings (1-5 stars), appreciation, and nested replies
CREATE TABLE IF NOT EXISTS public.song_comments (
  id TEXT PRIMARY KEY,
  song_id TEXT NOT NULL,
  song_title TEXT,
  artist_name TEXT,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  user_email TEXT,
  user_name TEXT NOT NULL,
  user_avatar TEXT,
  content TEXT NOT NULL,
  rating INTEGER DEFAULT 5,
  likes INTEGER DEFAULT 0 NOT NULL,
  liked_by JSONB DEFAULT '[]'::jsonb,
  reply_to_id TEXT,
  reply_to_user_name TEXT,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable RLS on song_comments
ALTER TABLE public.song_comments ENABLE ROW LEVEL SECURITY;

-- Everyone (public) can read comments and replies
DROP POLICY IF EXISTS "Public can view song comments" ON public.song_comments;
CREATE POLICY "Public can view song comments" ON public.song_comments
  FOR SELECT USING (true);

-- Everyone (both authenticated members and guests) can submit comments and replies
DROP POLICY IF EXISTS "Anyone can insert song comments" ON public.song_comments;
CREATE POLICY "Anyone can insert song comments" ON public.song_comments
  FOR INSERT WITH CHECK (true);

-- Authors and admins can update their comments
DROP POLICY IF EXISTS "Anyone can update their own comment" ON public.song_comments;
CREATE POLICY "Anyone can update their own comment" ON public.song_comments
  FOR UPDATE USING (true);

-- 6. SONG LIKES TABLE (Permanent social likes)
CREATE TABLE IF NOT EXISTS public.song_likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  song_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  user_email TEXT,
  user_name TEXT,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  CONSTRAINT unique_song_user_like UNIQUE (song_id, user_id)
);

ALTER TABLE public.song_likes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view song likes" ON public.song_likes;
CREATE POLICY "Public can view song likes" ON public.song_likes
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can manage song likes" ON public.song_likes;
CREATE POLICY "Users can manage song likes" ON public.song_likes
  FOR ALL USING (true);


-- 7. ARTIST FOLLOWS TABLE (Permanent follower count & relationship)
CREATE TABLE IF NOT EXISTS public.artist_follows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id TEXT NOT NULL,
  artist_name TEXT,
  user_id TEXT NOT NULL,
  user_email TEXT,
  user_name TEXT,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  CONSTRAINT unique_artist_user_follow UNIQUE (artist_id, user_id)
);

ALTER TABLE public.artist_follows ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view artist followers" ON public.artist_follows;
CREATE POLICY "Public can view artist followers" ON public.artist_follows
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can manage artist follows" ON public.artist_follows;
CREATE POLICY "Users can manage artist follows" ON public.artist_follows
  FOR ALL USING (true);


-- 8. SUPABASE REALTIME ENABLEMENT
-- Ensure tables broadcast live changes to all connected listeners
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' AND tablename = 'songs'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.songs;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' AND tablename = 'song_comments'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.song_comments;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' AND tablename = 'song_likes'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.song_likes;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' AND tablename = 'artist_follows'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.artist_follows;
  END IF;
EXCEPTION
  WHEN undefined_object THEN
    NULL;
END $$;


-- 9. VIDEOS TABLE & STORAGE BUCKET (Dedicated Music Videos Section)
CREATE TABLE IF NOT EXISTS public.videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  artist TEXT NOT NULL,
  description TEXT DEFAULT '',
  category TEXT DEFAULT 'Music Video',
  genre TEXT DEFAULT 'Afrobeat',
  thumbnail_url TEXT,
  video_url TEXT NOT NULL,
  quality_urls JSONB DEFAULT '{}'::jsonb,
  default_quality TEXT DEFAULT '720p',
  duration TEXT DEFAULT '00:00',
  duration_sec INTEGER DEFAULT 0,
  views INTEGER DEFAULT 0 NOT NULL,
  likes INTEGER DEFAULT 0 NOT NULL,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'videos'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.videos;
  END IF;
EXCEPTION
  WHEN undefined_object THEN NULL;
  WHEN undefined_table THEN NULL;
END $$;

ALTER TABLE public.videos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view videos" ON public.videos;
CREATE POLICY "Public can view videos" ON public.videos
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can upload their own videos" ON public.videos;
CREATE POLICY "Users can upload their own videos" ON public.videos
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update their own videos" ON public.videos;
CREATE POLICY "Users can update their own videos" ON public.videos
  FOR UPDATE USING (true);

DROP POLICY IF EXISTS "Users and admin can delete videos" ON public.videos;
CREATE POLICY "Users and admin can delete videos" ON public.videos
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id OR lower(auth.jwt() ->> 'email') = 'tesomelodies@gmail.com');

-- Video Likes Table
CREATE TABLE IF NOT EXISTS public.video_likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  CONSTRAINT unique_video_user_like UNIQUE (video_id, user_id)
);

ALTER TABLE public.video_likes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view video likes" ON public.video_likes;
CREATE POLICY "Public can view video likes" ON public.video_likes
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can manage video likes" ON public.video_likes;
CREATE POLICY "Users can manage video likes" ON public.video_likes
  FOR ALL USING (true);

-- Optional dedicated "videos" Storage Bucket (500MB limit)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('videos', 'videos', true, 524288000, NULL)
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 524288000,
  allowed_mime_types = NULL;

DROP POLICY IF EXISTS "Public can view and stream video files" ON storage.objects;
CREATE POLICY "Public can view and stream video files" ON storage.objects
  FOR SELECT USING (bucket_id = 'videos');

DROP POLICY IF EXISTS "Authenticated users can upload video files" ON storage.objects;
CREATE POLICY "Authenticated users can upload video files" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'videos' AND auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can update their own video files" ON storage.objects;
CREATE POLICY "Users can update their own video files" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'videos' AND auth.uid()::text = (storage.foldername(name))[1]);

DROP POLICY IF EXISTS "Users can delete their own video files" ON storage.objects;
CREATE POLICY "Users can delete their own video files" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'videos' AND auth.uid()::text = (storage.foldername(name))[1]);

-- 10. PERMANENT NEWS & ANNOUNCEMENTS TABLE (Admin: tesomelodies@gmail.com)
CREATE TABLE IF NOT EXISTS public.news (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  full_content TEXT DEFAULT '',
  category TEXT DEFAULT 'Portal News',
  badge TEXT DEFAULT 'News',
  image_url TEXT,
  status TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('draft', 'published', 'archived')),
  author_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  author_email TEXT,
  published_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()),
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.news ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view published news" ON public.news;
CREATE POLICY "Public can view published news" ON public.news
  FOR SELECT USING (
    status = 'published'
    OR lower(coalesce(auth.jwt() ->> 'email', '')) = 'tesomelodies@gmail.com'
  );

DROP POLICY IF EXISTS "Admin can manage news" ON public.news;
CREATE POLICY "Admin can manage news" ON public.news
  FOR ALL TO authenticated
  USING (lower(coalesce(auth.jwt() ->> 'email', '')) = 'tesomelodies@gmail.com')
  WITH CHECK (lower(coalesce(auth.jwt() ->> 'email', '')) = 'tesomelodies@gmail.com');




