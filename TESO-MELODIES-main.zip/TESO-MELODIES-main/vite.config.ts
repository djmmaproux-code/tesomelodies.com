import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';
import {VitePWA} from 'vite-plugin-pwa';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: [
          'favicon.png',
          'apple-touch-icon.png',
          'pwa-192x192.png',
          'pwa-512x512.png',
          'pwa-maskable-192x192.png',
          'pwa-maskable-512x512.png',
        ],
        manifest: {
          id: '/',
          name: 'TESO MELODIES',
          short_name: 'TesoMelodies',
          description:
            'Stream and download free Teso music, Ugandan gospel, dancehall, and Afrobeat MP3 songs on TESO MELODIES.',
          theme_color: '#034ea2',
          background_color: '#01010A',
          display: 'standalone',
          orientation: 'portrait-primary',
          start_url: '/',
          scope: '/',
          categories: ['music', 'entertainment'],
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'maskable',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          cleanupOutdatedCaches: true,
          clientsClaim: true,
          skipWaiting: true,
          maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
          globPatterns: [
            'assets/*.{js,css,woff,woff2}',
            'index.html',
          ],
          globIgnores: [
            '**/sitemap.xml',
            '**/robots.txt',
            '**/urllist.txt',
            '**/ads.txt',
            '**/google*.html',
            '**/privacy.html',
            '**/terms.html',
            '**/assets/extracted/**',
            '**/assets/aistudio/**',
          ],
          navigateFallback: '/index.html',
          navigateFallbackDenylist: [
            /^\/api\//i,
            /^\/\.netlify\//i,
            /^\/sitemap/i,
            /^\/robots\.txt$/i,
            /^\/urllist\.txt$/i,
            /^\/ads\.txt$/i,
            /^\/google[a-z0-9._%\s()-]*\.html$/i,
            /^\/(privacy|terms)\.html$/i,
            /\.(mp3|wav|m4a|ogg|aac|flac|opus|mp4|webm|mov|xml|txt|json)$/i,
          ],
          runtimeCaching: [
            // NEVER cache MP3s, audio files, video files, or media streams
            {
              urlPattern: /\.(mp3|wav|m4a|ogg|aac|flac|opus|mp4|webm|mov|m3u8)(\?.*)?$/i,
              handler: 'NetworkOnly',
            },
            // NEVER cache dynamic API endpoints, Netlify Functions, uploads, or downloads
            {
              urlPattern: /^https?:\/\/[^/]+\/(api|\.netlify\/functions)\//i,
              handler: 'NetworkOnly',
            },
            // NEVER cache download URLs
            {
              urlPattern: /[?&]download=/i,
              handler: 'NetworkOnly',
            },
            // NEVER cache live Supabase queries, auth, realtime, or storage
            {
              urlPattern: /^https:\/\/[^/]*supabase\.co\/.*/i,
              handler: 'NetworkOnly',
            },
            // NEVER cache Cloudflare R2 audio streams, downloads, or uploads
            {
              urlPattern: /^https:\/\/[^/]*\.(r2\.dev|r2\.cloudflarestorage\.com)\/.*/i,
              handler: 'NetworkOnly',
            },
            // Cache Google Fonts stylesheets & font files for fast app shell rendering
            {
              urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
              handler: 'StaleWhileRevalidate',
              options: {
                cacheName: 'google-fonts-stylesheets',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 30,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
            {
              urlPattern: /^https:\/\/fonts\.gstatic\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'google-fonts-webfonts',
                expiration: {
                  maxEntries: 15,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
          ],
        },
        devOptions: {
          enabled: true,
          type: 'module',
          navigateFallback: 'index.html',
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      host: '0.0.0.0',
      port: 3000,
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
