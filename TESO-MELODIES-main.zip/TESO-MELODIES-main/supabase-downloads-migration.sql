-- ==============================================================================
-- TESO MELODIES — ADDITIVE SQL MIGRATION: REAL SONG DOWNLOAD TRACKING
-- Target: Existing Supabase Project (https://csguerwyvykvzlnikwbf.supabase.co)
--
-- SAFETY GUARANTEES:
--   * Strictly additive & idempotent (IF NOT EXISTS / CREATE OR REPLACE).
--   * Zero DROP TABLE, TRUNCATE, or deletion of existing songs, videos,
--     profiles, likes, followers, or comments.
--   * Works identically for songs stored on Cloudflare R2 (.r2.dev) AND
--     legacy songs stored on Supabase Storage (.supabase.co/storage).
--   * Public read access so everyone (including non-logged-in visitors) sees
--     real download totals; writes are validated via SECURITY DEFINER RPC with
--     per-song/per-visitor cooldown protection against fake/repeated inflation.
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 1. ADD downloads_count COLUMN TO EXISTING public.songs TABLE
-- ------------------------------------------------------------------------------
ALTER TABLE public.songs
  ADD COLUMN IF NOT EXISTS downloads_count INTEGER NOT NULL DEFAULT 0;

-- Ensure no existing rows have NULL downloads_count
UPDATE public.songs
SET downloads_count = 0
WHERE downloads_count IS NULL;

CREATE INDEX IF NOT EXISTS idx_songs_downloads_count
  ON public.songs (downloads_count DESC);

-- ------------------------------------------------------------------------------
-- 2. CREATE public.song_downloads AUDIT & ANTI-SPAM TRACKING TABLE
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.song_downloads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  song_id UUID NOT NULL REFERENCES public.songs(id) ON DELETE CASCADE,
  actor_id TEXT NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  storage_source TEXT NOT NULL DEFAULT 'r2' CHECK (storage_source IN ('r2', 'supabase', 'other')),
  download_mode TEXT NOT NULL DEFAULT 'branded' CHECK (download_mode IN ('branded', 'direct')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_song_downloads_song_created
  ON public.song_downloads (song_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_song_downloads_dedupe
  ON public.song_downloads (song_id, actor_id, created_at DESC);

ALTER TABLE public.song_downloads ENABLE ROW LEVEL SECURITY;

-- Keep individual downloader identifiers private: no direct client SELECT/INSERT/UPDATE/DELETE.
-- Public aggregate download totals live on public.songs.downloads_count (readable by everyone,
-- including guests not signed in) and are atomically updated via public.record_song_download(...).
DROP POLICY IF EXISTS "Public can view song downloads" ON public.song_downloads;
REVOKE ALL ON TABLE public.song_downloads FROM anon, authenticated;

-- ------------------------------------------------------------------------------
-- 3. ATOMIC ANTI-SPAM RPC: record_song_download
--    - Verifies the song exists in public.songs (unique song ID).
--    - Prevents duplicate/repeated inflation from the same user/visitor
--      within a 10-minute cooldown window per song.
--    - Atomically increments public.songs.downloads_count by 1 on genuine downloads.
-- ------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.record_song_download(
  p_song_id UUID,
  p_actor_id TEXT DEFAULT NULL,
  p_storage_source TEXT DEFAULT 'r2',
  p_download_mode TEXT DEFAULT 'branded'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_actor TEXT := COALESCE(NULLIF(TRIM(p_actor_id), ''), auth.uid()::text);
  v_storage TEXT := LOWER(TRIM(COALESCE(p_storage_source, 'r2')));
  v_mode TEXT := LOWER(TRIM(COALESCE(p_download_mode, 'branded')));
  v_current_count INTEGER := 0;
  v_recent_exists BOOLEAN := FALSE;
  v_cooldown INTERVAL := INTERVAL '10 minutes';
BEGIN
  IF p_song_id IS NULL THEN
    RAISE EXCEPTION 'Song ID is required';
  END IF;

  IF v_actor IS NULL OR LENGTH(v_actor) = 0 THEN
    v_actor := 'anon-' || md5(COALESCE(inet_client_addr()::text, 'unknown'));
  END IF;

  IF LENGTH(v_actor) > 128 THEN
    v_actor := LEFT(v_actor, 128);
  END IF;

  IF v_storage NOT IN ('r2', 'supabase', 'other') THEN
    v_storage := 'other';
  END IF;

  IF v_mode NOT IN ('branded', 'direct') THEN
    v_mode := 'direct';
  END IF;

  -- Serialize concurrent requests for the same (song, actor) pair
  PERFORM pg_advisory_xact_lock(hashtext('download:' || p_song_id::text || ':' || v_actor));

  -- Confirm song exists in public.songs
  SELECT COALESCE(downloads_count, 0)
  INTO v_current_count
  FROM public.songs
  WHERE id = p_song_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'counted', FALSE,
      'downloads_count', 0,
      'reason', 'song_not_found'
    );
  END IF;

  -- Anti-spam deduplication: ignore repeated download counts by same actor within 10 minutes
  SELECT EXISTS (
    SELECT 1
    FROM public.song_downloads
    WHERE song_id = p_song_id
      AND actor_id = v_actor
      AND created_at > (timezone('utc'::text, now()) - v_cooldown)
  ) INTO v_recent_exists;

  IF v_recent_exists THEN
    RETURN jsonb_build_object(
      'counted', FALSE,
      'downloads_count', v_current_count,
      'reason', 'cooldown'
    );
  END IF;

  -- Record genuine download event
  INSERT INTO public.song_downloads (song_id, actor_id, user_id, storage_source, download_mode)
  VALUES (p_song_id, v_actor, auth.uid(), v_storage, v_mode);

  -- Atomically increment the song's public downloads counter
  UPDATE public.songs
  SET downloads_count = COALESCE(downloads_count, 0) + 1,
      updated_at = timezone('utc'::text, now())
  WHERE id = p_song_id
  RETURNING downloads_count INTO v_current_count;

  RETURN jsonb_build_object(
    'counted', TRUE,
    'downloads_count', COALESCE(v_current_count, 0),
    'reason', 'recorded'
  );
END;
$$;

-- Backwards-compatible helper wrapper
CREATE OR REPLACE FUNCTION public.increment_song_download(p_song_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_result JSONB;
BEGIN
  v_result := public.record_song_download(p_song_id, auth.uid()::text, 'r2', 'direct');
  RETURN COALESCE((v_result ->> 'downloads_count')::INTEGER, 0);
END;
$$;

GRANT EXECUTE ON FUNCTION public.record_song_download(UUID, TEXT, TEXT, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.increment_song_download(UUID) TO anon, authenticated;

-- ------------------------------------------------------------------------------
-- 4. ENABLE LIVE REALTIME BROADCASTS FOR DOWNLOAD COUNTS
-- ------------------------------------------------------------------------------
ALTER TABLE public.songs REPLICA IDENTITY FULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'songs'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.songs;
  END IF;
EXCEPTION
  WHEN undefined_object THEN NULL;
  WHEN undefined_table THEN NULL;
END $$;
