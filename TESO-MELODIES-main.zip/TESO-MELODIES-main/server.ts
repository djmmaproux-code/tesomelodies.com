import express, { Response } from 'express';
import http from 'http';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { Readable } from 'stream';
import { fileURLToPath } from 'url';
import { supabase } from './src/supabaseClient.js';
import {
  resolveOriginFromHeaders,
  buildSongShareMetadata,
  buildVideoShareMetadata,
  buildArtistSeoMetadata,
  buildGenreSeoMetadata,
  buildDynamicSitemapXml,
  buildFallbackSitemapXml,
  renderSocialShareHtml,
} from './netlify/functions/_socialShare.ts';
import { handler as r2PresignHandler } from './netlify/functions/r2-presign.ts';
import { handler as r2DeleteHandler } from './netlify/functions/r2-delete.ts';
import { handler as r2DownloadHandler } from './netlify/functions/r2-download.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const DATA_DIR = path.resolve(__dirname, 'data');
const COMMENTS_FILE = path.resolve(DATA_DIR, 'comments.json');
const LIKES_FILE = path.resolve(DATA_DIR, 'song_likes.json');
const FOLLOWS_FILE = path.resolve(DATA_DIR, 'artist_follows.json');
const DOWNLOADS_FILE = path.resolve(DATA_DIR, 'song_downloads.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Ensure database files exist
if (!fs.existsSync(COMMENTS_FILE)) {
  fs.writeFileSync(COMMENTS_FILE, JSON.stringify([], null, 2), 'utf-8');
}
if (!fs.existsSync(LIKES_FILE)) {
  fs.writeFileSync(LIKES_FILE, JSON.stringify([], null, 2), 'utf-8');
}
if (!fs.existsSync(FOLLOWS_FILE)) {
  fs.writeFileSync(FOLLOWS_FILE, JSON.stringify([], null, 2), 'utf-8');
}
if (!fs.existsSync(DOWNLOADS_FILE)) {
  fs.writeFileSync(DOWNLOADS_FILE, JSON.stringify([], null, 2), 'utf-8');
}

// ---------------------------------------------------------------------------
// Type Definitions
// ---------------------------------------------------------------------------
export interface SongCommentRecord {
  id: string;
  songId: string;
  songTitle?: string;
  artistName?: string;
  userId?: string;
  userEmail?: string;
  userName: string;
  userAvatar?: string;
  content: string;
  rating: number;
  likes: number;
  likedBy: string[];
  replyToId?: string;
  replyToUserName?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface SongLikeRecord {
  id: string;
  songId: string;
  userId: string;
  userEmail?: string;
  userName?: string;
  createdAt: string;
}

export interface ArtistFollowRecord {
  id: string;
  artistId: string;
  artistName?: string;
  userId: string;
  userEmail?: string;
  userName?: string;
  createdAt: string;
}

export interface SongDownloadRecord {
  id: string;
  songId: string;
  actorId: string;
  storageSource: 'r2' | 'supabase' | 'other';
  downloadMode: 'branded' | 'direct';
  createdAt: string;
}

// ---------------------------------------------------------------------------
// Storage Helpers (Synchronous atomic file IO with safe fallbacks)
// ---------------------------------------------------------------------------
function readComments(): SongCommentRecord[] {
  try {
    if (!fs.existsSync(COMMENTS_FILE)) return [];
    const data = fs.readFileSync(COMMENTS_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Error reading comments database:', err);
    return [];
  }
}

function writeComments(comments: SongCommentRecord[]): boolean {
  try {
    fs.writeFileSync(COMMENTS_FILE, JSON.stringify(comments, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error writing comments database:', err);
    return false;
  }
}

function readLikes(): SongLikeRecord[] {
  try {
    if (!fs.existsSync(LIKES_FILE)) return [];
    const data = fs.readFileSync(LIKES_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Error reading likes database:', err);
    return [];
  }
}

function writeLikes(likes: SongLikeRecord[]): boolean {
  try {
    fs.writeFileSync(LIKES_FILE, JSON.stringify(likes, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error writing likes database:', err);
    return false;
  }
}

function readFollows(): ArtistFollowRecord[] {
  try {
    if (!fs.existsSync(FOLLOWS_FILE)) return [];
    const data = fs.readFileSync(FOLLOWS_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Error reading follows database:', err);
    return [];
  }
}

function writeFollows(follows: ArtistFollowRecord[]): boolean {
  try {
    fs.writeFileSync(FOLLOWS_FILE, JSON.stringify(follows, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error writing follows database:', err);
    return false;
  }
}

function readDownloads(): SongDownloadRecord[] {
  try {
    if (!fs.existsSync(DOWNLOADS_FILE)) return [];
    const data = fs.readFileSync(DOWNLOADS_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Error reading downloads database:', err);
    return [];
  }
}

function writeDownloads(downloads: SongDownloadRecord[]): boolean {
  try {
    fs.writeFileSync(DOWNLOADS_FILE, JSON.stringify(downloads, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error writing downloads database:', err);
    return false;
  }
}

// ---------------------------------------------------------------------------
// Real-Time Server-Sent Events (SSE) Broadcast System
// ---------------------------------------------------------------------------
const sseClients = new Set<Response>();

function broadcastRealtime(event: string, payload: any) {
  const data = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  sseClients.forEach((client) => {
    try {
      client.write(data);
    } catch {
      sseClients.delete(client);
    }
  });
}

// Keep SSE connections alive with periodic heartbeat ping
setInterval(() => {
  sseClients.forEach((client) => {
    try {
      client.write(':keep-alive\n\n');
    } catch {
      sseClients.delete(client);
    }
  });
}, 20000);

// Basic Spam & Rate Limiting tracking
const commentRateLimit = new Map<string, number>();
const DOWNLOAD_COOLDOWN_MS = 10 * 60 * 1000; // 10-minute per-song/per-actor anti-spam window
const downloadRateWindow = new Map<string, { count: number; windowStart: number }>();

async function startServer() {
  const app = express();
  const httpServer = http.createServer(app);

  app.use(express.json());

  const invokeNetlifyR2Handler = (handlerFn: (event: any) => Promise<any>) => {
    return async (req: express.Request, res: express.Response) => {
      try {
        const result = await handlerFn({
          httpMethod: req.method,
          headers: req.headers,
          queryStringParameters: req.query,
          path: req.path,
          rawUrl: `${req.protocol}://${req.get('host') || 'localhost:3000'}${req.originalUrl}`,
          body: req.body && typeof req.body === 'object' ? JSON.stringify(req.body) : req.body,
        });

        const statusCode = result?.statusCode || 200;
        const headers = result?.headers || {};
        Object.entries(headers).forEach(([k, v]) => {
          if (v !== undefined) res.setHeader(k, String(v));
        });

        if (statusCode === 302 && headers.Location) {
          return res.redirect(302, String(headers.Location));
        }

        return res.status(statusCode).send(result?.body ?? '');
      } catch (err: any) {
        return res.status(500).json({ error: err?.message || 'Cloudflare R2 route error' });
      }
    };
  };

  // Cloudflare R2 presign, authenticated delete, and protected download endpoints
  app.post('/.netlify/functions/r2-presign', invokeNetlifyR2Handler(r2PresignHandler));
  app.post('/.netlify/functions/r2-delete', invokeNetlifyR2Handler(r2DeleteHandler));
  app.delete('/.netlify/functions/r2-delete', invokeNetlifyR2Handler(r2DeleteHandler));
  app.get('/.netlify/functions/r2-download', invokeNetlifyR2Handler(r2DownloadHandler));
  app.options('/.netlify/functions/r2-download', invokeNetlifyR2Handler(r2DownloadHandler));

  // ---------------------------------------------------------------------------
  // 0. GET /api/realtime - Native Server-Sent Events (SSE) Stream
  // ---------------------------------------------------------------------------
  app.get('/api/realtime', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    // Send initial connection confirmation
    res.write(`event: connected\ndata: ${JSON.stringify({ status: 'connected', time: new Date().toISOString() })}\n\n`);

    sseClients.add(res);

    req.on('close', () => {
      sseClients.delete(res);
    });
  });

  // ---------------------------------------------------------------------------
  // 1. REAL-TIME SONG LIKES SYSTEM
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // 1. REAL-TIME SONG LIKES SYSTEM
  // ---------------------------------------------------------------------------

  // GET /api/likes - Returns total like counts per song and liked songs for a user
  app.get('/api/likes', async (req, res) => {
    try {
      const userId = String(req.query.userId || req.headers['x-visitor-id'] || '').trim();
      const allLikes = readLikes();

      // Aggregate counts from persistent database
      const interactiveCounts: Record<string, number> = {};
      const likesMap: Record<string, number> = {};
      const userLikedSongIds: string[] = [];

      allLikes.forEach((l) => {
        const sId = String(l.songId);
        interactiveCounts[sId] = (interactiveCounts[sId] || 0) + 1;
        likesMap[sId] = interactiveCounts[sId];
        if (userId && String(l.userId) === userId) {
          if (!userLikedSongIds.includes(sId)) {
            userLikedSongIds.push(sId);
          }
        }
      });

      // Incorporate genuine database likes from Supabase public.songs
      try {
        const { data: dbSongs } = await supabase.from('songs').select('id, likes');
        if (dbSongs && Array.isArray(dbSongs)) {
          dbSongs.forEach((song) => {
            const sId = String(song.id);
            const userInteractiveLikes = interactiveCounts[sId] || 0;
            const dbLikes = typeof song.likes === 'number' ? Math.max(0, song.likes) : 0;
            likesMap[sId] = dbLikes + userInteractiveLikes;
          });
        }
      } catch (err) {
        console.warn('Notice querying Supabase songs in /api/likes:', err);
      }

      res.json({
        success: true,
        likesMap,
        userLikedSongIds,
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message || 'Failed to fetch likes' });
    }
  });

  // GET /api/likes/user/:userId - Get list of songs liked by a specific user
  app.get('/api/likes/user/:userId', (req, res) => {
    try {
      const { userId } = req.params;
      const allLikes = readLikes();
      const likedSongIds = allLikes
        .filter((l) => String(l.userId) === String(userId))
        .map((l) => String(l.songId));

      res.json({ success: true, likedSongIds: Array.from(new Set(likedSongIds)) });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message });
    }
  });

  // POST /api/likes/toggle - Like / Unlike a song permanently with zero duplicate manipulation
  app.post('/api/likes/toggle', async (req, res) => {
    try {
      const { songId, userId, userEmail, userName, visitorId } = req.body;

      if (!songId) {
        return res.status(400).json({ success: false, error: 'Song ID is required' });
      }

      const uId = String(userId || visitorId || req.headers['x-visitor-id'] || req.query.visitorId || '').trim();
      if (!uId) {
        return res.status(400).json({
          success: false,
          error: 'User or visitor identifier is required to like songs.',
        });
      }

      const sId = String(songId);
      const allLikes = readLikes();

      // Check if user already liked this song
      const existingIndex = allLikes.findIndex(
        (l) => String(l.songId) === sId && String(l.userId) === uId
      );

      let isLiked = false;

      if (existingIndex !== -1) {
        // Unlike: remove like record
        allLikes.splice(existingIndex, 1);
        isLiked = false;
      } else {
        // Like: insert like record
        const newRecord: SongLikeRecord = {
          id: `like-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          songId: sId,
          userId: uId,
          userEmail: userEmail || undefined,
          userName: userName || undefined,
          createdAt: new Date().toISOString(),
        };
        allLikes.push(newRecord);
        isLiked = true;
      }

      writeLikes(allLikes);

      // Compute updated total likes for this song
      const countedLikes = allLikes.filter((l) => String(l.songId) === sId).length;

      // Read genuine base likes from Supabase without artificial minimums
      let baseLikes = 0;
      try {
        const { data: curSong } = await supabase.from('songs').select('likes').eq('id', sId).maybeSingle();
        if (curSong && typeof curSong.likes === 'number') {
          baseLikes = Math.max(0, curSong.likes);
        }
      } catch {
        // ignore
      }

      const totalLikes = Math.max(0, baseLikes + countedLikes);

      // Broadcast real-time update to all connected clients immediately!
      broadcastRealtime('song_like_updated', {
        songId: sId,
        likes: totalLikes,
        userId: uId,
        isLiked,
      });

      res.json({
        success: true,
        isLiked,
        totalLikes,
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message || 'Failed to toggle like' });
    }
  });

  // ---------------------------------------------------------------------------
  // 1B. REAL-TIME SONG DOWNLOADS TRACKING SYSTEM (ANTI-SPAM + SUPABASE + R2)
  // ---------------------------------------------------------------------------

  // GET /api/downloads - Publicly returns total verified download counts per song
  app.get('/api/downloads', async (_req, res) => {
    try {
      const allDownloads = readDownloads();
      const downloadsMap: Record<string, number> = {};

      allDownloads.forEach((rec) => {
        const sId = String(rec.songId || '').trim();
        if (!sId) return;
        downloadsMap[sId] = (downloadsMap[sId] || 0) + 1;
      });

      // Merge live Supabase downloads_count when column is migrated
      try {
        const { data: dbSongs, error } = await supabase
          .from('songs')
          .select('id, downloads_count');
        if (!error && Array.isArray(dbSongs)) {
          dbSongs.forEach((row: any) => {
            if (!row?.id || typeof row.downloads_count !== 'number') return;
            const sId = String(row.id);
            const dbCount = Math.max(0, row.downloads_count);
            downloadsMap[sId] = Math.max(downloadsMap[sId] || 0, dbCount);
          });
        }
      } catch {
        // Supabase column not migrated yet; local verified counts remain authoritative
      }

      res.json({
        success: true,
        downloadsMap,
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message || 'Failed to fetch downloads' });
    }
  });

  // POST /api/downloads/record - Records a verified completed download with anti-spam cooldown & SSE broadcast
  app.post('/api/downloads/record', async (req, res) => {
    try {
      const rawSongId = typeof req.body?.songId === 'string' ? req.body.songId.trim() : '';
      const rawActorId = String(
        req.body?.actorId || req.headers['x-visitor-id'] || req.ip || ''
      ).trim();
      const rawSource = String(req.body?.storageSource || 'r2').toLowerCase().trim();
      const rawMode = String(req.body?.downloadMode || 'branded').toLowerCase().trim();
      const mirrorFromSupabase =
        Boolean(req.body?.mirrorFromSupabase) ||
        typeof req.body?.authoritativeCount === 'number';

      if (!rawSongId || rawSongId.length > 128) {
        return res.status(400).json({ success: false, error: 'Valid songId is required.' });
      }
      if (!rawActorId || rawActorId.length > 128) {
        return res.status(400).json({ success: false, error: 'Valid visitor or user identifier is required.' });
      }

      const storageSource: 'r2' | 'supabase' | 'other' =
        rawSource === 'r2' || rawSource === 'supabase' ? rawSource : 'other';
      const downloadMode: 'branded' | 'direct' =
        rawMode === 'direct' ? 'direct' : 'branded';

      // Per-actor/IP burst rate limit: max 30 download records per minute
      const nowMs = Date.now();
      const rateKey = `${req.ip || 'ip'}:${rawActorId}`;
      const existingRate = downloadRateWindow.get(rateKey);
      if (existingRate && nowMs - existingRate.windowStart < 60_000) {
        if (existingRate.count >= 30) {
          return res.status(429).json({
            success: false,
            counted: false,
            error: 'Too many download requests. Please wait a moment.',
          });
        }
        existingRate.count += 1;
      } else {
        downloadRateWindow.set(rateKey, { count: 1, windowStart: nowMs });
      }

      const allDownloads = readDownloads();

      // If client already recorded via Supabase RPC, verify the authoritative count directly from Supabase
      if (mirrorFromSupabase) {
        let verifiedDbCount: number | null = null;
        try {
          const { data: dbSong, error } = await supabase
            .from('songs')
            .select('downloads_count')
            .eq('id', rawSongId)
            .maybeSingle();
          if (!error && dbSong && typeof (dbSong as any).downloads_count === 'number') {
            verifiedDbCount = Math.max(0, (dbSong as any).downloads_count);
          }
        } catch {
          verifiedDbCount = null;
        }

        if (verifiedDbCount !== null) {
          broadcastRealtime('song_download_updated', {
            songId: rawSongId,
            downloadsCount: verifiedDbCount,
            actorId: rawActorId,
          });

          return res.json({
            success: true,
            counted: true,
            downloadsCount: verifiedDbCount,
            reason: 'verified_from_supabase',
          });
        }
      }

      // Check 10-minute cooldown for the same (songId, actorId) pair to prevent spam inflation
      const inCooldown = allDownloads.some(
        (r) =>
          r.songId === rawSongId &&
          r.actorId === rawActorId &&
          nowMs - new Date(r.createdAt).getTime() < DOWNLOAD_COOLDOWN_MS
      );

      let counted = false;
      if (!inCooldown) {
        allDownloads.push({
          id: `dl-${nowMs}-${Math.random().toString(36).substring(2, 8)}`,
          songId: rawSongId,
          actorId: rawActorId,
          storageSource,
          downloadMode,
          createdAt: new Date(nowMs).toISOString(),
        });
        writeDownloads(allDownloads);
        counted = true;
      }

      let totalDownloads = allDownloads.filter((r) => r.songId === rawSongId).length;

      // Cross-check Supabase downloads_count if already migrated
      try {
        const { data: dbSong, error } = await supabase
          .from('songs')
          .select('downloads_count')
          .eq('id', rawSongId)
          .maybeSingle();
        if (!error && dbSong && typeof (dbSong as any).downloads_count === 'number') {
          totalDownloads = Math.max(totalDownloads, Math.max(0, (dbSong as any).downloads_count));
        }
      } catch {
        // ignore if column does not exist yet
      }

      if (counted) {
        broadcastRealtime('song_download_updated', {
          songId: rawSongId,
          downloadsCount: totalDownloads,
          actorId: rawActorId,
        });
      }

      return res.json({
        success: true,
        counted,
        downloadsCount: totalDownloads,
        reason: counted ? 'recorded' : 'cooldown',
      });
    } catch (err: any) {
      return res.status(500).json({
        success: false,
        counted: false,
        error: err?.message || 'Failed to record download',
      });
    }
  });

  // ---------------------------------------------------------------------------
  // 2. REAL-TIME ARTIST FOLLOW SYSTEM
  // ---------------------------------------------------------------------------

  // GET /api/follows - Returns follower counts per artist and followed artists for a user
  app.get('/api/follows', (req, res) => {
    try {
      const userId = String(req.query.userId || req.headers['x-visitor-id'] || '').trim();
      const allFollows = readFollows();

      // Map canonical artist identity -> Set of unique userIds
      const artistFollowersMap = new Map<string, Set<string>>();
      // Map all alias variants (id, slug, display name) to canonical key
      const aliasToCanonical = new Map<string, string>();

      allFollows.forEach((f) => {
        const rawId = String(f.artistId || '').trim().toLowerCase();
        const rawName = String(f.artistName || '').trim().toLowerCase();
        const canonical = (rawName || rawId).replace(/\s+/g, '-');
        const slugId = rawId.replace(/\s+/g, '-');
        const unslugName = rawName.replace(/-/g, ' ');

        if (!artistFollowersMap.has(canonical)) {
          artistFollowersMap.set(canonical, new Set());
        }
        artistFollowersMap.get(canonical)!.add(String(f.userId));

        // Register all aliases
        [canonical, rawId, slugId, rawName, unslugName].filter(Boolean).forEach((alias) => {
          aliasToCanonical.set(alias, canonical);
        });
      });

      const followsMap: Record<string, number> = {};
      const userFollowedArtistIds: string[] = [];

      aliasToCanonical.forEach((canonical, alias) => {
        const count = artistFollowersMap.get(canonical)?.size || 0;
        followsMap[alias] = count;
      });

      if (userId) {
        aliasToCanonical.forEach((canonical, alias) => {
          const userSet = artistFollowersMap.get(canonical);
          if (userSet && userSet.has(userId)) {
            if (!userFollowedArtistIds.includes(alias)) {
              userFollowedArtistIds.push(alias);
            }
          }
        });
      }

      res.json({
        success: true,
        followsMap,
        userFollowedArtistIds,
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message || 'Failed to fetch follows' });
    }
  });

  // GET /api/follows/user/:userId - Get list of artists followed by user
  app.get('/api/follows/user/:userId', (req, res) => {
    try {
      const { userId } = req.params;
      const allFollows = readFollows();
      const followed = allFollows
        .filter((f) => String(f.userId) === String(userId))
        .map((f) => String(f.artistId).toLowerCase());

      res.json({ success: true, followedArtistIds: Array.from(new Set(followed)) });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message });
    }
  });

  // POST /api/follows/toggle - Follow / Unfollow an artist permanently
  app.post('/api/follows/toggle', async (req, res) => {
    try {
      const { artistId, artistName, artistUserId, userId, userEmail, userName, visitorId } = req.body;

      if (!artistId && !artistName) {
        return res.status(400).json({ success: false, error: 'Artist ID or Name is required' });
      }
      const uId = String(userId || visitorId || req.headers['x-visitor-id'] || req.query.visitorId || '').trim();
      if (!uId) {
        return res.status(400).json({
          success: false,
          error: 'User or visitor identifier is required to follow artists.',
        });
      }
      if (uId.length > 200 || String(artistId || '').length > 200 || String(artistName || '').length > 200) {
        return res.status(400).json({
          success: false,
          error: 'Invalid artist or user identifier length.',
        });
      }

      const rawId = String(artistId || '').trim().toLowerCase();
      const rawName = String(artistName || '').trim().toLowerCase();
      const legacyUid = String(artistUserId || '').trim().toLowerCase();
      const canonical = (rawName || rawId).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || rawId;
      const candidateKeys = Array.from(
        new Set(
          [
            rawId,
            rawName,
            canonical,
            rawId.replace(/\s+/g, '-'),
            rawName.replace(/-/g, ' '),
            legacyUid,
          ].filter(Boolean)
        )
      );

      const allFollows = readFollows();

      // Check if user already follows this artist (matching candidate keys)
      const existingIndex = allFollows.findIndex(
        (f) =>
          String(f.userId) === uId &&
          (candidateKeys.includes(String(f.artistId).toLowerCase().trim()) ||
            (f.artistName && candidateKeys.includes(String(f.artistName).toLowerCase().trim())))
      );

      let isFollowed = false;

      if (existingIndex !== -1) {
        // Unfollow: remove all matching follow records for this user and artist
        for (let i = allFollows.length - 1; i >= 0; i--) {
          const f = allFollows[i];
          if (
            String(f.userId) === uId &&
            (candidateKeys.includes(String(f.artistId).toLowerCase().trim()) ||
              (f.artistName && candidateKeys.includes(String(f.artistName).toLowerCase().trim())))
          ) {
            allFollows.splice(i, 1);
          }
        }
        isFollowed = false;
      } else {
        // Follow: add follow record
        const newRecord: ArtistFollowRecord = {
          id: `flw-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          artistId: canonical,
          artistName: artistName || rawName || canonical,
          userId: uId,
          userEmail: userEmail || undefined,
          userName: userName || undefined,
          createdAt: new Date().toISOString(),
        };
        allFollows.push(newRecord);
        isFollowed = true;
      }

      writeFollows(allFollows);

      // Compute total unique real followers for this artist
      const uniqueFollowers = new Set(
        allFollows
          .filter(
            (f) =>
              candidateKeys.includes(String(f.artistId).toLowerCase().trim()) ||
              (f.artistName && candidateKeys.includes(String(f.artistName).toLowerCase().trim()))
          )
          .map((f) => String(f.userId))
      );
      const totalRealFollowers = uniqueFollowers.size;

      // Broadcast real-time follow update to all connected clients immediately!
      broadcastRealtime('artist_follow_updated', {
        artistId: canonical,
        artistName: artistName || rawName,
        realFollowers: totalRealFollowers,
        followers: totalRealFollowers,
        userId: uId,
        isFollowed,
      });

      res.json({
        success: true,
        isFollowed,
        realFollowers: totalRealFollowers,
        followers: totalRealFollowers,
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message || 'Failed to toggle follow' });
    }
  });

  // ---------------------------------------------------------------------------
  // 3. REAL-TIME COMMENTS & REVIEWS SYSTEM (WITH MODERATION & SPAM PROTECTION)
  // ---------------------------------------------------------------------------

  // GET /api/comments - List comments for a song or all songs
  app.get('/api/comments', (req, res) => {
    try {
      const { songId } = req.query;
      const allComments = readComments();

      if (songId) {
        const forSong = allComments.filter((c) => String(c.songId) === String(songId));
        forSong.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        return res.json({ success: true, comments: forSong });
      }

      allComments.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      res.json({ success: true, comments: allComments });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message || 'Failed to fetch comments' });
    }
  });

  // GET /api/comments/stats - Overall stats & counts for all songs
  app.get('/api/comments/stats', (req, res) => {
    try {
      const all = readComments();
      const map: Record<string, { totalComments: number; totalRatings: number; averageRating: number }> = {};

      all.forEach((c) => {
        const sId = String(c.songId);
        if (!map[sId]) {
          map[sId] = { totalComments: 0, totalRatings: 0, averageRating: 0 };
        }
        map[sId].totalComments += 1;
      });

      Object.keys(map).forEach((sId) => {
        const rated = all.filter((c) => String(c.songId) === sId && typeof c.rating === 'number' && c.rating > 0);
        if (rated.length > 0) {
          map[sId].totalRatings = rated.length;
          map[sId].averageRating = Number(
            (rated.reduce((acc, c) => acc + c.rating, 0) / rated.length).toFixed(1)
          );
        }
      });

      res.json({ success: true, stats: map });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message });
    }
  });

  // POST /api/comments - Create a new comment or reply with SPAM PROTECTION
  app.post('/api/comments', (req, res) => {
    try {
      const {
        songId,
        songTitle,
        artistName,
        content,
        rating = 0,
        userId,
        userEmail,
        userName,
        userAvatar,
        replyToId,
        replyToUserName,
      } = req.body;

      if (!songId) {
        return res.status(400).json({ success: false, error: 'Song ID is required' });
      }

      // 1. Moderate content & strip malicious scripts
      const rawContent = typeof content === 'string' ? content.trim() : '';
      if (!rawContent || rawContent.length < 2) {
        return res.status(400).json({ success: false, error: 'Comment message is too short.' });
      }
      if (rawContent.length > 3000) {
        return res.status(400).json({ success: false, error: 'Comment exceeds maximum allowed length of 3000 characters.' });
      }

      const sanitizedContent = rawContent
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
        .replace(/<[^>]*>/g, '');

      // 2. Anti-spam & rate limit protection
      const callerIdentifier = String(userId || userEmail || req.ip || 'anon');
      const lastPostTime = commentRateLimit.get(callerIdentifier) || 0;
      const nowMs = Date.now();

      if (nowMs - lastPostTime < 2500) {
        return res.status(429).json({
          success: false,
          error: 'Please wait a couple seconds before submitting another comment.',
        });
      }
      commentRateLimit.set(callerIdentifier, nowMs);

      // 3. Duplicate comment detection
      const all = readComments();
      const isDuplicate = all.some(
        (c) =>
          String(c.songId) === String(songId) &&
          c.content.trim().toLowerCase() === sanitizedContent.toLowerCase() &&
          nowMs - new Date(c.createdAt).getTime() < 45000
      );

      if (isDuplicate) {
        return res.status(400).json({
          success: false,
          error: 'You recently submitted this exact message.',
        });
      }

      const commentId = `cmt-${nowMs}-${Math.random().toString(36).substring(2, 8)}`;
      const now = new Date().toISOString();

      const newComment: SongCommentRecord = {
        id: commentId,
        songId: String(songId),
        songTitle: songTitle || 'Song',
        artistName: artistName || 'Artist',
        userId: userId || undefined,
        userEmail: userEmail || undefined,
        userName: userName && userName.trim() ? userName.trim() : 'Teso Music Fan',
        userAvatar: userAvatar || undefined,
        content: sanitizedContent,
        rating: Math.min(5, Math.max(0, Number(rating) || 0)),
        likes: 0,
        likedBy: [],
        replyToId: replyToId || undefined,
        replyToUserName: replyToUserName || undefined,
        createdAt: now,
      };

      all.unshift(newComment);
      writeComments(all);

      // Compute updated review stats for this song
      const songComments = all.filter((c) => String(c.songId) === String(songId));
      const ratedComments = songComments.filter((c) => c.rating > 0);
      const avg =
        ratedComments.length > 0
          ? Number((ratedComments.reduce((acc, c) => acc + c.rating, 0) / ratedComments.length).toFixed(1))
          : 0;

      const stats = {
        totalComments: songComments.length,
        totalRatings: ratedComments.length,
        averageRating: avg,
      };

      // Broadcast real-time comment creation to all visitors immediately!
      broadcastRealtime('comment_created', {
        songId: String(songId),
        comment: newComment,
        stats,
      });

      res.status(201).json({ success: true, comment: newComment });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message || 'Failed to save comment' });
    }
  });

  // POST /api/comments/:id/like - Like or unlike a comment
  app.post('/api/comments/:id/like', (req, res) => {
    try {
      const { id } = req.params;
      const { visitorId = 'anon', songId } = req.body;

      const all = readComments();
      const index = all.findIndex((c) => c.id === id);

      if (index === -1) {
        return res.status(404).json({ success: false, error: 'Comment not found' });
      }

      const comment = all[index];
      const likedBy = Array.isArray(comment.likedBy) ? [...comment.likedBy] : [];
      const alreadyLiked = likedBy.includes(visitorId);

      let updatedLikedBy: string[];
      let updatedLikes: number;

      if (alreadyLiked) {
        updatedLikedBy = likedBy.filter((vId) => vId !== visitorId);
        updatedLikes = Math.max(0, (comment.likes || 1) - 1);
      } else {
        updatedLikedBy = [...likedBy, visitorId];
        updatedLikes = (comment.likes || 0) + 1;
      }

      all[index] = {
        ...comment,
        likes: updatedLikes,
        likedBy: updatedLikedBy,
      };

      writeComments(all);

      // Broadcast like update
      broadcastRealtime('comment_liked', {
        songId: comment.songId || songId,
        commentId: id,
        likes: updatedLikes,
        likedBy: updatedLikedBy,
      });

      res.json({ success: true, likes: updatedLikes, isLiked: !alreadyLiked });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message });
    }
  });

  // PUT /api/comments/:id - Edit a comment
  app.put('/api/comments/:id', (req, res) => {
    try {
      const { id } = req.params;
      const { content, rating, userEmail, userId } = req.body;

      if (!content || !content.trim()) {
        return res.status(400).json({ success: false, error: 'Content cannot be empty' });
      }

      const all = readComments();
      const index = all.findIndex((c) => c.id === id);

      if (index === -1) {
        return res.status(404).json({ success: false, error: 'Comment not found' });
      }

      const comment = all[index];
      const isAdmin = userEmail?.toLowerCase() === 'tesomelodies@gmail.com';
      const isAuthor =
        (userId && comment.userId === userId) ||
        (userEmail && comment.userEmail?.toLowerCase() === userEmail.toLowerCase()) ||
        (!comment.userId && !comment.userEmail);

      if (!isAdmin && !isAuthor) {
        return res.status(403).json({ success: false, error: 'Permission denied to edit comment' });
      }

      all[index] = {
        ...comment,
        content: content.trim(),
        rating: typeof rating === 'number' ? rating : comment.rating,
        updatedAt: new Date().toISOString(),
      };

      writeComments(all);

      broadcastRealtime('comment_updated', {
        songId: comment.songId,
        comment: all[index],
      });

      res.json({ success: true, comment: all[index] });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message });
    }
  });

  // DELETE /api/comments/:id - Delete a comment & its replies
  app.delete('/api/comments/:id', (req, res) => {
    try {
      const { id } = req.params;
      const userEmail = (req.headers['x-user-email'] as string) || req.query.userEmail;
      const userId = (req.headers['x-user-id'] as string) || req.query.userId;

      const all = readComments();
      const target = all.find((c) => c.id === id);

      if (!target) {
        return res.status(404).json({ success: false, error: 'Comment not found' });
      }

      const isAdmin = String(userEmail).toLowerCase() === 'tesomelodies@gmail.com';
      const isAuthor =
        (userId && target.userId === userId) ||
        (userEmail && target.userEmail?.toLowerCase() === String(userEmail).toLowerCase()) ||
        (!target.userId && !target.userEmail);

      if (!isAdmin && !isAuthor) {
        return res.status(403).json({ success: false, error: 'Permission denied to delete comment' });
      }

      const songId = target.songId;
      const remaining = all.filter((c) => c.id !== id && c.replyToId !== id);
      writeComments(remaining);

      // Recompute stats
      const songComments = remaining.filter((c) => String(c.songId) === String(songId));
      const ratedComments = songComments.filter((c) => c.rating > 0);
      const avg =
        ratedComments.length > 0
          ? Number((ratedComments.reduce((acc, c) => acc + c.rating, 0) / ratedComments.length).toFixed(1))
          : 0;

      broadcastRealtime('comment_deleted', {
        songId,
        commentId: id,
        stats: {
          totalComments: songComments.length,
          totalRatings: ratedComments.length,
          averageRating: avg,
        },
      });

      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message });
    }
  });

  // HEAD /api/proxy-audio - Allows client download helper to detect backend proxy availability
  app.head('/api/proxy-audio', (_req, res) => {
    res.setHeader('x-audio-proxy', '1');
    res.status(200).end();
  });

  // GET /api/proxy-audio - Streams audio to avoid CORS blocks and supports Content-Disposition: attachment downloads
  app.get('/api/proxy-audio', async (req, res) => {
    try {
      const url = req.query.url as string;
      if (!url) return res.status(400).send('URL required');
      const parsed = new URL(url);
      if (!['http:', 'https:'].includes(parsed.protocol)) {
        return res.status(400).send('Invalid protocol');
      }
      const response = await fetch(url);
      if (!response.ok) {
        return res.status(response.status).send(`Failed to fetch audio: ${response.statusText}`);
      }
      res.setHeader('x-audio-proxy', '1');
      res.setHeader('Content-Type', response.headers.get('content-type') || 'audio/mpeg');
      const contentLength = response.headers.get('content-length');
      if (contentLength) {
        res.setHeader('Content-Length', contentLength);
      }
      res.setHeader('Access-Control-Allow-Origin', '*');

      const rawFilename = typeof req.query.filename === 'string' ? req.query.filename : '';
      if (req.query.download === '1' || rawFilename) {
        const safeName = (rawFilename || 'TesoMelodies_Track.mp3')
          .replace(/["\r\n\/\\?%*:|<>]/g, '_')
          .trim();
        res.setHeader('Content-Disposition', `attachment; filename="${safeName}"`);
      }

      if (response.body) {
        const nodeStream = Readable.fromWeb(response.body as any);
        nodeStream.on('error', (err) => {
          console.error('Audio proxy stream error:', err);
          if (!res.headersSent) {
            res.status(500).end();
          } else {
            res.destroy(err);
          }
        });
        nodeStream.pipe(res);
      } else {
        const arrayBuffer = await response.arrayBuffer();
        res.send(Buffer.from(arrayBuffer));
      }
    } catch (err: any) {
      if (!res.headersSent) {
        res.status(500).send(err?.message || 'Proxy audio error');
      }
    }
  });

  // ---------------------------------------------------------------------------
  // Vite Integration in Development
  // ---------------------------------------------------------------------------
  // Dynamic XML Sitemap (works identically in local Express and Netlify Functions — never returns HTML)
  app.get(['/sitemap.xml', '/Sitemap.xml', '/sitemap'], async (req, res) => {
    const origin = resolveOriginFromHeaders(req.headers as any, req.originalUrl);
    let xml: string;
    try {
      xml = await buildDynamicSitemapXml(origin);
      if (!xml || !xml.trimStart().startsWith('<?xml')) {
        xml = buildFallbackSitemapXml(origin);
      }
    } catch {
      xml = buildFallbackSitemapXml(origin);
    }
    res
      .status(200)
      .set({
        'Content-Type': 'application/xml; charset=utf-8',
        'X-Content-Type-Options': 'nosniff',
        'Cache-Control': 'public, max-age=300',
      })
      .end(xml);
  });

  const isProd = process.env.NODE_ENV === 'production';

  const handleSeoPageRequest = async (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction,
    getTemplateHtml: (url: string) => Promise<string>
  ) => {
    try {
      const lowerPath = req.path.toLowerCase();
      const itemParam = decodeURIComponent(String(req.params.id || req.params.slug || '')).trim();
      const origin = resolveOriginFromHeaders(req.headers as any, req.originalUrl);

      let meta;
      let fallbackPath = '/';
      if (lowerPath.startsWith('/video/')) {
        meta = await buildVideoShareMetadata(itemParam, origin);
        fallbackPath = `/videos?video=${encodeURIComponent(itemParam)}`;
      } else if (lowerPath.startsWith('/artist/')) {
        meta = await buildArtistSeoMetadata(itemParam, origin);
        fallbackPath = `/artists?artist=${encodeURIComponent(itemParam)}`;
      } else if (lowerPath.startsWith('/genre/')) {
        meta = await buildGenreSeoMetadata(itemParam, origin);
        fallbackPath = `/music?genre=${encodeURIComponent(itemParam)}`;
      } else {
        meta = await buildSongShareMetadata(itemParam, origin);
        fallbackPath = `/?song=${encodeURIComponent(itemParam)}`;
      }

      const templateHtml = await getTemplateHtml(req.originalUrl);
      const html = renderSocialShareHtml(templateHtml, meta, fallbackPath);
      res
        .status(200)
        .set({
          'Content-Type': 'text/html; charset=utf-8',
          'X-Robots-Tag': 'index, follow',
        })
        .end(html);
    } catch (err) {
      next(err);
    }
  };

  if (!isProd) {
    const hmrDisabled = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        ws: { server: httpServer },
        hmr: hmrDisabled ? false : true,
      },
      appType: 'spa',
    });

    app.get(['/song/:id', '/video/:id', '/artist/:slug', '/genre/:slug'], (req, res, next) =>
      handleSeoPageRequest(req, res, next, async (url) => {
        const rawTemplate = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        return vite.transformIndexHtml(url, rawTemplate);
      })
    );

    app.use(vite.middlewares);
  } else {
    app.get(['/song/:id', '/video/:id', '/artist/:slug', '/genre/:slug'], (req, res, next) =>
      handleSeoPageRequest(req, res, next, async () =>
        fs.readFileSync(path.resolve(__dirname, 'dist', 'index.html'), 'utf-8')
      )
    );
    app.use(
      express.static(path.resolve(__dirname, 'dist'), {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('sw.js')) {
            res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
            res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
            res.setHeader('Service-Worker-Allowed', '/');
          } else if (filePath.endsWith('manifest.webmanifest')) {
            res.setHeader('Content-Type', 'application/manifest+json; charset=utf-8');
            res.setHeader('Cache-Control', 'public, max-age=3600');
          }
        },
      })
    );
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`[TESO MELODIES Server] Full-Stack Running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[TESO MELODIES Server] Failed to start:', err);
  process.exit(1);
});
