-- ==============================================================================
-- TESO MELODIES — ADDITIVE SQL MIGRATION: ARTIST FOLLOWERS + 20 PER 5 SONGS BONUS
-- Target: Existing Supabase Project (https://csguerwyvykvzlnikwbf.supabase.co)
--
-- SAFETY GUARANTEES:
--   * Strictly additive & idempotent (IF NOT EXISTS / CREATE OR REPLACE).
--   * Preserves ALL 84+ existing public.artist_follows rows (including legacy
--     UUID artist_ids and existing user_id UUIDs) as well as all songs, videos,
--     profiles, likes, and comments.
--   * Fixes the live PostgreSQL error "operator does not exist: uuid = text"
--     by safely converting artist_follows.user_id from UUID to TEXT (preserving
--     every existing UUID string) so both logged-in users and visitors can follow
--     and unfollow artists reliably without FK or type errors.
--   * Every artist automatically receives +20 milestone followers per 5 songs
--     (floor(song_count / 5) * 20) stacked ON TOP of their real fan followers.
--   * Real fan Follow / Unfollow persists permanently in public.artist_follows
--     with duplicate protection and live Realtime broadcasts.
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 1. ENSURE public.artist_follows SCHEMA, SAFE UUID->TEXT UPGRADE, INDEXES & RLS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.artist_follows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id TEXT NOT NULL,
  artist_name TEXT,
  user_id TEXT NOT NULL,
  user_email TEXT,
  user_name TEXT,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.artist_follows ADD COLUMN IF NOT EXISTS artist_name TEXT;
ALTER TABLE public.artist_follows ADD COLUMN IF NOT EXISTS user_email TEXT;
ALTER TABLE public.artist_follows ADD COLUMN IF NOT EXISTS user_name TEXT;

-- Safely convert legacy UUID user_id / artist_id columns to TEXT while preserving
-- 100% of existing rows. Drops dependent policies/FKs first so Postgres permits
-- ALTER COLUMN TYPE cleanly, then recreates RLS policies right below.
DO $$
DECLARE
  pol RECORD;
  fk RECORD;
  v_user_id_type TEXT;
  v_artist_id_type TEXT;
BEGIN
  SELECT data_type INTO v_user_id_type
  FROM information_schema.columns
  WHERE table_schema = 'public'
    AND table_name = 'artist_follows'
    AND column_name = 'user_id';

  SELECT data_type INTO v_artist_id_type
  FROM information_schema.columns
  WHERE table_schema = 'public'
    AND table_name = 'artist_follows'
    AND column_name = 'artist_id';

  -- Drop existing RLS policies on artist_follows before altering column types
  FOR pol IN
    SELECT policyname
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'artist_follows'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.artist_follows', pol.policyname);
  END LOOP;

  -- Drop foreign key constraints on artist_follows (e.g. artist_follows_user_id_fkey)
  -- so both logged-in Supabase users and fan visitors can follow artists.
  FOR fk IN
    SELECT conname
    FROM pg_constraint
    WHERE conrelid = 'public.artist_follows'::regclass
      AND contype = 'f'
  LOOP
    EXECUTE format('ALTER TABLE public.artist_follows DROP CONSTRAINT IF EXISTS %I', fk.conname);
  END LOOP;

  IF v_user_id_type IS NOT NULL AND v_user_id_type <> 'text' THEN
    ALTER TABLE public.artist_follows
      ALTER COLUMN user_id TYPE TEXT USING user_id::text;
  END IF;

  IF v_artist_id_type IS NOT NULL AND v_artist_id_type <> 'text' THEN
    ALTER TABLE public.artist_follows
      ALTER COLUMN artist_id TYPE TEXT USING artist_id::text;
  END IF;
END $$;

-- Safely deduplicate any exact (lower(trim(artist_id)), user_id) rows
DELETE FROM public.artist_follows a
USING public.artist_follows b
WHERE a.ctid > b.ctid
  AND lower(trim(a.artist_id)) = lower(trim(b.artist_id))
  AND a.user_id = b.user_id;

CREATE UNIQUE INDEX IF NOT EXISTS idx_artist_follows_unique_pair
  ON public.artist_follows (artist_id, user_id);
CREATE INDEX IF NOT EXISTS idx_artist_follows_artist_id
  ON public.artist_follows (artist_id);
CREATE INDEX IF NOT EXISTS idx_artist_follows_artist_name_lower
  ON public.artist_follows (lower(trim(coalesce(artist_name, ''))));
CREATE INDEX IF NOT EXISTS idx_artist_follows_user_id
  ON public.artist_follows (user_id);

ALTER TABLE public.artist_follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.artist_follows REPLICA IDENTITY FULL;

CREATE POLICY "Public can view artist followers" ON public.artist_follows
  FOR SELECT USING (true);

CREATE POLICY "Users can manage artist follows" ON public.artist_follows
  FOR ALL USING (true) WITH CHECK (true);

-- ------------------------------------------------------------------------------
-- 2. MILESTONE FOLLOWER HELPER: +20 FOLLOWERS FOR EVERY 5 SONGS UPLOADED
-- ------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.calculate_artist_milestone_followers(p_song_count INTEGER)
RETURNS INTEGER
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT GREATEST(0, COALESCE(p_song_count, 0) / 5) * 20;
$$;

-- ------------------------------------------------------------------------------
-- 3. PUBLIC LIVE VIEW: artist_follower_stats
--    Shows every artist's song_count, real_followers, bonus_followers (+20 per
--    5 songs), and total_followers (real_followers + bonus_followers).
-- ------------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.artist_follower_stats AS
WITH song_artists AS (
  SELECT
    lower(trim(s.artist)) AS artist_key,
    min(trim(s.artist)) AS artist_name,
    coalesce(
      nullif(trim(both '-' from regexp_replace(lower(trim(s.artist)), '[^a-z0-9]+', '-', 'g')), ''),
      lower(trim(s.artist))
    ) AS artist_slug,
    count(*)::INTEGER AS song_count,
    CASE
      WHEN count(DISTINCT s.user_id) = 1 THEN min(s.user_id::text)
      ELSE NULL
    END AS single_uploader_id
  FROM public.songs s
  WHERE coalesce(s.category, 'new') <> 'video'
    AND nullif(trim(coalesce(s.artist, '')), '') IS NOT NULL
  GROUP BY lower(trim(s.artist))
),
uploader_artist_counts AS (
  SELECT
    s.user_id::text AS uploader_id,
    count(DISTINCT lower(trim(s.artist)))::INTEGER AS distinct_artist_count
  FROM public.songs s
  WHERE coalesce(s.category, 'new') <> 'video'
    AND s.user_id IS NOT NULL
    AND nullif(trim(coalesce(s.artist, '')), '') IS NOT NULL
  GROUP BY s.user_id::text
),
resolved_artists AS (
  SELECT
    sa.artist_key,
    sa.artist_name,
    sa.artist_slug,
    sa.song_count,
    CASE
      WHEN sa.single_uploader_id IS NOT NULL
       AND coalesce(uac.distinct_artist_count, 0) = 1
      THEN sa.single_uploader_id
      ELSE NULL
    END AS legacy_artist_uid
  FROM song_artists sa
  LEFT JOIN uploader_artist_counts uac
    ON uac.uploader_id = sa.single_uploader_id
),
real_counts AS (
  SELECT
    ra.artist_key,
    count(DISTINCT af.user_id::text)::INTEGER AS real_followers
  FROM resolved_artists ra
  LEFT JOIN public.artist_follows af
    ON lower(trim(af.artist_id::text)) IN (
         ra.artist_slug,
         ra.artist_key,
         replace(ra.artist_slug, '-', ' '),
         coalesce(lower(ra.legacy_artist_uid), '__no_uid__')
       )
    OR lower(trim(coalesce(af.artist_name, ''))) IN (
         ra.artist_slug,
         ra.artist_key
       )
  GROUP BY ra.artist_key
)
SELECT
  ra.artist_slug,
  ra.artist_name,
  ra.song_count,
  coalesce(rc.real_followers, 0) AS real_followers,
  public.calculate_artist_milestone_followers(ra.song_count) AS bonus_followers,
  (coalesce(rc.real_followers, 0) + public.calculate_artist_milestone_followers(ra.song_count)) AS total_followers
FROM resolved_artists ra
LEFT JOIN real_counts rc ON rc.artist_key = ra.artist_key
ORDER BY total_followers DESC, ra.song_count DESC;

GRANT SELECT ON public.artist_follower_stats TO anon, authenticated;

-- ------------------------------------------------------------------------------
-- 4. ATOMIC REAL FOLLOW / UNFOLLOW RPC (WITH +20 PER 5 SONGS STACKED ON TOP)
--    Supports both logged-in users and visitors, prevents duplicates, preserves
--    legacy UUID follows, and returns real_followers + bonus_followers + total.
-- ------------------------------------------------------------------------------
-- Replace legacy 5-arg overload so PostgREST/Postgres never hits overload ambiguity
DROP FUNCTION IF EXISTS public.toggle_artist_follow(TEXT, TEXT, TEXT, TEXT, TEXT);

CREATE OR REPLACE FUNCTION public.toggle_artist_follow(
  p_artist_id TEXT,
  p_artist_name TEXT,
  p_actor_id TEXT,
  p_user_email TEXT DEFAULT NULL,
  p_user_name TEXT DEFAULT NULL,
  p_artist_user_id TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_actor TEXT := COALESCE(NULLIF(TRIM(p_actor_id), ''), auth.uid()::text);
  v_canonical TEXT := COALESCE(
    NULLIF(TRIM(BOTH '-' FROM REGEXP_REPLACE(LOWER(TRIM(COALESCE(NULLIF(p_artist_name, ''), p_artist_id))), '[^a-z0-9]+', '-', 'g')), ''),
    'artist'
  );
  v_raw_id TEXT := LOWER(TRIM(COALESCE(p_artist_id, v_canonical)));
  v_raw_name TEXT := LOWER(TRIM(COALESCE(NULLIF(p_artist_name, ''), p_artist_id)));
  v_legacy_uid TEXT := NULLIF(LOWER(TRIM(COALESCE(p_artist_user_id, ''))), '');
  v_deleted_count INTEGER := 0;
  v_real_followers INTEGER := 0;
  v_song_count INTEGER := 0;
  v_bonus_followers INTEGER := 0;
  v_is_followed BOOLEAN := FALSE;
BEGIN
  IF v_actor IS NULL OR v_actor = '' THEN
    RAISE EXCEPTION 'Actor identifier required';
  END IF;

  IF v_canonical = '' THEN
    RAISE EXCEPTION 'Artist identifier required';
  END IF;

  -- Serialize concurrent clicks by the same user on the same artist
  PERFORM pg_advisory_xact_lock(hashtext('follow:' || v_canonical || ':' || v_actor));

  -- Unfollow if this actor already follows the artist under any matching alias/legacy UUID
  DELETE FROM public.artist_follows
  WHERE user_id::text = v_actor
    AND (
      lower(trim(artist_id::text)) IN (
        v_canonical,
        v_raw_id,
        v_raw_name,
        replace(v_raw_name, '-', ' '),
        COALESCE(v_legacy_uid, '__no_uid__')
      )
      OR lower(trim(coalesce(artist_name, ''))) IN (v_canonical, v_raw_id, v_raw_name)
    );
  GET DIAGNOSTICS v_deleted_count = ROW_COUNT;

  IF v_deleted_count > 0 THEN
    v_is_followed := FALSE;
  ELSE
    INSERT INTO public.artist_follows (artist_id, artist_name, user_id, user_email, user_name)
    SELECT
      v_canonical,
      COALESCE(NULLIF(TRIM(p_artist_name), ''), v_canonical),
      v_actor,
      p_user_email,
      p_user_name
    WHERE NOT EXISTS (
      SELECT 1
      FROM public.artist_follows
      WHERE user_id::text = v_actor
        AND (
          lower(trim(artist_id::text)) IN (
            v_canonical,
            v_raw_id,
            v_raw_name,
            replace(v_raw_name, '-', ' '),
            COALESCE(v_legacy_uid, '__no_uid__')
          )
          OR lower(trim(coalesce(artist_name, ''))) IN (v_canonical, v_raw_id, v_raw_name)
        )
    );
    v_is_followed := TRUE;
  END IF;

  -- Count unique real fan followers for this artist
  SELECT COUNT(DISTINCT user_id::text)::INTEGER
  INTO v_real_followers
  FROM public.artist_follows
  WHERE lower(trim(artist_id::text)) IN (
          v_canonical,
          v_raw_id,
          v_raw_name,
          replace(v_raw_name, '-', ' '),
          COALESCE(v_legacy_uid, '__no_uid__')
        )
     OR lower(trim(coalesce(artist_name, ''))) IN (v_canonical, v_raw_id, v_raw_name);

  -- Count this artist's non-video songs to compute +20 per 5 songs bonus
  SELECT COUNT(*)::INTEGER
  INTO v_song_count
  FROM public.songs s
  WHERE coalesce(s.category, 'new') <> 'video'
    AND (
      lower(trim(coalesce(s.artist, ''))) IN (v_raw_name, replace(v_canonical, '-', ' '))
      OR coalesce(
           nullif(trim(both '-' from regexp_replace(lower(trim(coalesce(s.artist, ''))), '[^a-z0-9]+', '-', 'g')), ''),
           ''
         ) = v_canonical
    );

  v_bonus_followers := public.calculate_artist_milestone_followers(v_song_count);

  RETURN jsonb_build_object(
    'is_followed', v_is_followed,
    'real_followers', COALESCE(v_real_followers, 0),
    'song_count', COALESCE(v_song_count, 0),
    'bonus_followers', COALESCE(v_bonus_followers, 0),
    'followers', COALESCE(v_real_followers, 0) + COALESCE(v_bonus_followers, 0)
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.calculate_artist_milestone_followers(INTEGER) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.toggle_artist_follow(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon, authenticated;

-- ------------------------------------------------------------------------------
-- 5. ENABLE LIVE REALTIME FOR public.artist_follows & public.songs
-- ------------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'artist_follows'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.artist_follows;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'songs'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.songs;
  END IF;
EXCEPTION
  WHEN undefined_object THEN NULL;
  WHEN undefined_table THEN NULL;
END $$;
