-- ==============================================================================
-- TESO MELODIES — COMPLETE ARTIST MONETIZATION, EARNINGS & WITHDRAWAL SYSTEM
-- File: supabase-artist-earnings-migration.sql
-- Target: Existing Supabase Project (https://csguerwyvykvzlnikwbf.supabase.co)
-- Authorized Admin: tesomelodies@gmail.com
--
-- COMPATIBILITY & SAFETY GUARANTEES:
--   * Built for the actual existing Teso Melodies schema:
--       auth.users, public.profiles, public.songs, public.song_likes,
--       public.user_favorites, public.artist_follows, public.song_downloads,
--       public.news, public.videos, public.song_comments.
--   * Strictly additive & idempotent (IF NOT EXISTS / CREATE OR REPLACE /
--     DROP POLICY IF EXISTS / DROP TRIGGER IF EXISTS).
--   * Zero DROP TABLE, TRUNCATE, or deletion of any existing users, profiles,
--     songs, videos, likes, followers, downloads, comments, or news.
--   * All earnings, milestone preservation, balances, anti-fraud checks, and
--     withdrawals are computed securely inside PostgreSQL SECURITY DEFINER RPCs.
--   * Private payout profiles are protected by Row Level Security (owner + admin).
--   * Immutable audit logs record every administrative financial action.
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 0. SHARED HELPER FUNCTIONS & TRIGGERS
-- ------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_teso_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
AS $$
  SELECT lower(coalesce(auth.jwt() ->> 'email', '')) = 'tesomelodies@gmail.com';
$$;

CREATE OR REPLACE FUNCTION public.tg_set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := timezone('utc'::text, now());
  RETURN NEW;
END;
$$;

-- ------------------------------------------------------------------------------
-- 1. GENUINE MUSIC STREAM TRACKING TABLE (ANTI-FRAUD STREAMING ROYALTIES)
--    Links directly to existing public.songs(id) and auth.users(id).
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.song_streams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  song_id UUID NOT NULL REFERENCES public.songs(id) ON DELETE CASCADE,
  actor_id TEXT NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  duration_listened_sec INTEGER NOT NULL DEFAULT 30 CHECK (duration_listened_sec >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_song_streams_song_created
  ON public.song_streams (song_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_song_streams_dedupe
  ON public.song_streams (song_id, actor_id, created_at DESC);

ALTER TABLE public.song_streams ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.song_streams FROM anon, authenticated;

-- Atomic anti-fraud stream recorder RPC:
--   - Verifies song exists in public.songs.
--   - Ignores automated/rapid repeat plays from the same listener within 3 minutes.
--   - Atomically increments public.songs.plays on genuine plays.
CREATE OR REPLACE FUNCTION public.record_song_stream(
  p_song_id UUID,
  p_actor_id TEXT DEFAULT NULL,
  p_duration_sec INTEGER DEFAULT 30
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_actor TEXT := COALESCE(NULLIF(TRIM(p_actor_id), ''), auth.uid()::text);
  v_duration INTEGER := GREATEST(0, LEAST(COALESCE(p_duration_sec, 30), 7200));
  v_current_plays INTEGER := 0;
  v_recent_exists BOOLEAN := FALSE;
  v_cooldown INTERVAL := INTERVAL '3 minutes';
BEGIN
  IF p_song_id IS NULL THEN
    RAISE EXCEPTION 'Song ID is required';
  END IF;

  IF v_actor IS NULL OR LENGTH(v_actor) = 0 THEN
    v_actor := 'anon-' || md5(COALESCE(inet_client_addr()::text, 'unknown'));
  END IF;

  IF LENGTH(v_actor) > 128 THEN
    v_actor := LEFT(v_actor, 128);
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('stream:' || p_song_id::text || ':' || v_actor));

  SELECT COALESCE(plays, 0)
  INTO v_current_plays
  FROM public.songs
  WHERE id = p_song_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('counted', FALSE, 'plays', 0, 'reason', 'song_not_found');
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM public.song_streams
    WHERE song_id = p_song_id
      AND actor_id = v_actor
      AND created_at > (timezone('utc'::text, now()) - v_cooldown)
  ) INTO v_recent_exists;

  IF v_recent_exists THEN
    RETURN jsonb_build_object('counted', FALSE, 'plays', v_current_plays, 'reason', 'cooldown');
  END IF;

  INSERT INTO public.song_streams (song_id, actor_id, user_id, duration_listened_sec)
  VALUES (p_song_id, v_actor, auth.uid(), v_duration);

  UPDATE public.songs
  SET plays = COALESCE(plays, 0) + 1,
      updated_at = timezone('utc'::text, now())
  WHERE id = p_song_id
  RETURNING plays INTO v_current_plays;

  RETURN jsonb_build_object(
    'counted', TRUE,
    'plays', COALESCE(v_current_plays, 0),
    'reason', 'recorded'
  );
END;
$$;

-- Backwards-compatible atomic play increment RPC used by existing musicService.ts
CREATE OR REPLACE FUNCTION public.increment_song_play(p_song_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_result JSONB;
BEGIN
  v_result := public.record_song_stream(p_song_id, auth.uid()::text, 30);
  RETURN COALESCE((v_result ->> 'plays')::INTEGER, 0);
END;
$$;

-- ------------------------------------------------------------------------------
-- 2. ROYALTY SETTINGS TABLE (ALL 6 EARNING RATES + MIN WITHDRAWAL CONFIGURABLE)
--    Initial rates:
--      - Likes:      18 UGX per 30 eligible likes
--      - Followers:  700 UGX per 100 eligible genuine followers
--      - Downloads:  5 UGX per 1 eligible download (admin configurable)
--      - Streams:    10 UGX per 25 eligible streams (admin configurable)
--      - Minimum withdrawal: 15,000 UGX
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.artist_earning_settings (
  id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  likes_per_unit INTEGER NOT NULL DEFAULT 30 CHECK (likes_per_unit >= 1),
  likes_rate_ugx NUMERIC(12, 2) NOT NULL DEFAULT 18 CHECK (likes_rate_ugx >= 0),
  followers_per_unit INTEGER NOT NULL DEFAULT 100 CHECK (followers_per_unit >= 1),
  followers_rate_ugx NUMERIC(12, 2) NOT NULL DEFAULT 700 CHECK (followers_rate_ugx >= 0),
  downloads_per_unit INTEGER NOT NULL DEFAULT 1 CHECK (downloads_per_unit >= 1),
  downloads_rate_ugx NUMERIC(12, 2) NOT NULL DEFAULT 5 CHECK (downloads_rate_ugx >= 0),
  streams_per_unit INTEGER NOT NULL DEFAULT 25 CHECK (streams_per_unit >= 1),
  streams_rate_ugx NUMERIC(12, 2) NOT NULL DEFAULT 10 CHECK (streams_rate_ugx >= 0),
  min_withdrawal_ugx NUMERIC(12, 2) NOT NULL DEFAULT 15000 CHECK (min_withdrawal_ugx >= 1000),
  updated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Safe additive upgrades if table already existed from an earlier version
ALTER TABLE public.artist_earning_settings
  ADD COLUMN IF NOT EXISTS streams_per_unit INTEGER NOT NULL DEFAULT 25;
ALTER TABLE public.artist_earning_settings
  ADD COLUMN IF NOT EXISTS streams_rate_ugx NUMERIC(12, 2) NOT NULL DEFAULT 10;

INSERT INTO public.artist_earning_settings (
  id,
  likes_per_unit,
  likes_rate_ugx,
  followers_per_unit,
  followers_rate_ugx,
  downloads_per_unit,
  downloads_rate_ugx,
  streams_per_unit,
  streams_rate_ugx,
  min_withdrawal_ugx
)
VALUES (1, 30, 18, 100, 700, 1, 5, 25, 10, 15000)
ON CONFLICT (id) DO NOTHING;

ALTER TABLE public.artist_earning_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can read earning settings" ON public.artist_earning_settings;
CREATE POLICY "Anyone can read earning settings" ON public.artist_earning_settings
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admin can manage earning settings" ON public.artist_earning_settings;
CREATE POLICY "Admin can manage earning settings" ON public.artist_earning_settings
  FOR ALL TO authenticated
  USING (public.is_teso_admin())
  WITH CHECK (public.is_teso_admin());

DROP TRIGGER IF EXISTS trg_artist_earning_settings_updated_at ON public.artist_earning_settings;
CREATE TRIGGER trg_artist_earning_settings_updated_at
  BEFORE UPDATE ON public.artist_earning_settings
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ------------------------------------------------------------------------------
-- 3. ARTIST EARNINGS ACCOUNTS (1-TO-1 WITH EXISTING auth.users — NO DUPLICATES)
--    Tracks Gmail verification, credited raw counts (preserving qualifying
--    progress between milestones even when future rates change), credited UGX,
--    and suspension state.
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.artist_earnings_accounts (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  registered_email TEXT,
  verified_gmail TEXT,
  earnings_verified BOOLEAN NOT NULL DEFAULT FALSE,
  earnings_verified_at TIMESTAMPTZ,
  verification_method TEXT,
  verification_requested_at TIMESTAMPTZ,
  verification_nonce TEXT,
  is_suspended BOOLEAN NOT NULL DEFAULT FALSE,
  suspended_reason TEXT,
  suspended_at TIMESTAMPTZ,
  suspended_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  credited_likes_count INTEGER NOT NULL DEFAULT 0 CHECK (credited_likes_count >= 0),
  credited_likes_units INTEGER NOT NULL DEFAULT 0 CHECK (credited_likes_units >= 0),
  credited_likes_ugx NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (credited_likes_ugx >= 0),
  credited_followers_count INTEGER NOT NULL DEFAULT 0 CHECK (credited_followers_count >= 0),
  credited_followers_units INTEGER NOT NULL DEFAULT 0 CHECK (credited_followers_units >= 0),
  credited_followers_ugx NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (credited_followers_ugx >= 0),
  credited_downloads_count INTEGER NOT NULL DEFAULT 0 CHECK (credited_downloads_count >= 0),
  credited_downloads_units INTEGER NOT NULL DEFAULT 0 CHECK (credited_downloads_units >= 0),
  credited_downloads_ugx NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (credited_downloads_ugx >= 0),
  credited_streams_count INTEGER NOT NULL DEFAULT 0 CHECK (credited_streams_count >= 0),
  credited_streams_units INTEGER NOT NULL DEFAULT 0 CHECK (credited_streams_units >= 0),
  credited_streams_ugx NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (credited_streams_ugx >= 0),
  manual_adjustment_ugx NUMERIC(14, 2) NOT NULL DEFAULT 0,
  last_synced_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Safe additive column upgrades if migrating from an earlier revision
ALTER TABLE public.artist_earnings_accounts
  ADD COLUMN IF NOT EXISTS credited_likes_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE public.artist_earnings_accounts
  ADD COLUMN IF NOT EXISTS credited_followers_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE public.artist_earnings_accounts
  ADD COLUMN IF NOT EXISTS credited_downloads_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE public.artist_earnings_accounts
  ADD COLUMN IF NOT EXISTS credited_streams_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE public.artist_earnings_accounts
  ADD COLUMN IF NOT EXISTS credited_streams_units INTEGER NOT NULL DEFAULT 0;
ALTER TABLE public.artist_earnings_accounts
  ADD COLUMN IF NOT EXISTS credited_streams_ugx NUMERIC(14, 2) NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_artist_earnings_verified
  ON public.artist_earnings_accounts (earnings_verified, is_suspended);

ALTER TABLE public.artist_earnings_accounts ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.artist_earnings_accounts FROM anon;
REVOKE INSERT, UPDATE, DELETE ON TABLE public.artist_earnings_accounts FROM authenticated;

DROP POLICY IF EXISTS "Artists can view own earnings account" ON public.artist_earnings_accounts;
CREATE POLICY "Artists can view own earnings account" ON public.artist_earnings_accounts
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_teso_admin());

DROP TRIGGER IF EXISTS trg_artist_earnings_accounts_updated_at ON public.artist_earnings_accounts;
CREATE TRIGGER trg_artist_earnings_accounts_updated_at
  BEFORE UPDATE ON public.artist_earnings_accounts
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ------------------------------------------------------------------------------
-- 4. PRIVATE ARTIST PAYOUT INFORMATION (STRICT RLS: OWNER + ADMIN ONLY)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.artist_payout_profiles (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_legal_name TEXT NOT NULL,
  country TEXT NOT NULL DEFAULT 'Uganda',
  phone_number TEXT NOT NULL,
  registered_gmail TEXT NOT NULL,
  mobile_money_provider TEXT NOT NULL CHECK (mobile_money_provider IN ('MTN Mobile Money', 'Airtel Money')),
  mobile_money_number TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.artist_payout_profiles ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.artist_payout_profiles FROM anon;
REVOKE INSERT, UPDATE, DELETE ON TABLE public.artist_payout_profiles FROM authenticated;

DROP POLICY IF EXISTS "Private payout profile access" ON public.artist_payout_profiles;
CREATE POLICY "Private payout profile access" ON public.artist_payout_profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_teso_admin());

DROP TRIGGER IF EXISTS trg_artist_payout_profiles_updated_at ON public.artist_payout_profiles;
CREATE TRIGGER trg_artist_payout_profiles_updated_at
  BEFORE UPDATE ON public.artist_payout_profiles
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ------------------------------------------------------------------------------
-- 5. ARTIST WITHDRAWAL REQUESTS (PENDING -> APPROVED -> PAID | REJECTED)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.artist_withdrawal_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_code TEXT NOT NULL UNIQUE,
  idempotency_key TEXT UNIQUE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  artist_name TEXT NOT NULL,
  registered_gmail TEXT NOT NULL,
  amount_ugx NUMERIC(14, 2) NOT NULL CHECK (amount_ugx >= 1000),
  status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Approved', 'Paid', 'Rejected')),
  payout_full_name TEXT NOT NULL,
  payout_country TEXT NOT NULL,
  payout_phone TEXT NOT NULL,
  mobile_money_provider TEXT NOT NULL,
  mobile_money_number TEXT NOT NULL,
  payment_reference TEXT,
  admin_note TEXT,
  rejection_reason TEXT,
  reviewed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  approved_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  rejected_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_artist_withdrawals_user_created
  ON public.artist_withdrawal_requests (user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_artist_withdrawals_status_created
  ON public.artist_withdrawal_requests (status, created_at DESC);

ALTER TABLE public.artist_withdrawal_requests ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.artist_withdrawal_requests FROM anon;
REVOKE INSERT, UPDATE, DELETE ON TABLE public.artist_withdrawal_requests FROM authenticated;

DROP POLICY IF EXISTS "Artists and admin view withdrawals" ON public.artist_withdrawal_requests;
CREATE POLICY "Artists and admin view withdrawals" ON public.artist_withdrawal_requests
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_teso_admin());

DROP TRIGGER IF EXISTS trg_artist_withdrawals_updated_at ON public.artist_withdrawal_requests;
CREATE TRIGGER trg_artist_withdrawals_updated_at
  BEFORE UPDATE ON public.artist_withdrawal_requests
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ------------------------------------------------------------------------------
-- 6. IMMUTABLE EARNING & PAYMENT TRANSACTIONS LEDGER
--    Categories: Likes Earnings, Followers Earnings, Download Royalties,
--                Streaming Royalties, Withdrawal Requests, Payments
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.artist_earning_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_code TEXT NOT NULL UNIQUE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  transaction_type TEXT NOT NULL,
  category_label TEXT NOT NULL DEFAULT 'Likes Earnings',
  direction TEXT NOT NULL CHECK (direction IN ('credit', 'debit')),
  amount_ugx NUMERIC(14, 2) NOT NULL,
  units_count INTEGER NOT NULL DEFAULT 0,
  rate_applied_ugx NUMERIC(12, 2),
  status TEXT NOT NULL CHECK (status IN ('Credited', 'Pending', 'Approved', 'Paid', 'Rejected')),
  description TEXT NOT NULL,
  withdrawal_id UUID REFERENCES public.artist_withdrawal_requests(id) ON DELETE SET NULL,
  payment_reference TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.artist_earning_transactions
  ADD COLUMN IF NOT EXISTS category_label TEXT NOT NULL DEFAULT 'Likes Earnings';

-- Safely replace check constraint to include streams_earning & payment
DO $$
DECLARE
  con RECORD;
BEGIN
  FOR con IN
    SELECT conname
    FROM pg_constraint
    WHERE conrelid = 'public.artist_earning_transactions'::regclass
      AND contype = 'c'
      AND pg_get_constraintdef(oid) ILIKE '%transaction_type%'
  LOOP
    EXECUTE format('ALTER TABLE public.artist_earning_transactions DROP CONSTRAINT IF EXISTS %I', con.conname);
  END LOOP;
END $$;

ALTER TABLE public.artist_earning_transactions
  ADD CONSTRAINT chk_artist_tx_type CHECK (
    transaction_type IN (
      'likes_earning',
      'followers_earning',
      'downloads_earning',
      'streams_earning',
      'withdrawal',
      'payment',
      'adjustment'
    )
  );

CREATE INDEX IF NOT EXISTS idx_artist_tx_user_created
  ON public.artist_earning_transactions (user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_artist_tx_type_status
  ON public.artist_earning_transactions (transaction_type, status, created_at DESC);

ALTER TABLE public.artist_earning_transactions ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.artist_earning_transactions FROM anon;
REVOKE INSERT, UPDATE, DELETE ON TABLE public.artist_earning_transactions FROM authenticated;

DROP POLICY IF EXISTS "Artists and admin view transactions" ON public.artist_earning_transactions;
CREATE POLICY "Artists and admin view transactions" ON public.artist_earning_transactions
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_teso_admin());

-- Ledger immutability trigger: prevent deleting historical earning or paid records
CREATE OR REPLACE FUNCTION public.tg_protect_financial_ledger()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Historical financial ledger records cannot be deleted';
  END IF;
  IF TG_OP = 'UPDATE' AND OLD.direction = 'credit' AND OLD.status = 'Credited' THEN
    IF NEW.amount_ugx <> OLD.amount_ugx OR NEW.status <> OLD.status THEN
      RAISE EXCEPTION 'Credited earning transactions are immutable';
    END IF;
  END IF;
  IF TG_OP = 'UPDATE' AND OLD.status = 'Paid' THEN
    IF NEW.amount_ugx <> OLD.amount_ugx OR NEW.status <> OLD.status OR COALESCE(NEW.payment_reference, '') <> COALESCE(OLD.payment_reference, '') THEN
      RAISE EXCEPTION 'Confirmed Paid payout transactions are immutable';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_financial_ledger ON public.artist_earning_transactions;
CREATE TRIGGER trg_protect_financial_ledger
  BEFORE UPDATE OR DELETE ON public.artist_earning_transactions
  FOR EACH ROW EXECUTE FUNCTION public.tg_protect_financial_ledger();

DROP TRIGGER IF EXISTS trg_artist_tx_updated_at ON public.artist_earning_transactions;
CREATE TRIGGER trg_artist_tx_updated_at
  BEFORE UPDATE ON public.artist_earning_transactions
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ------------------------------------------------------------------------------
-- 7. ADMINISTRATIVE AUDIT LOGS TABLE (STRICTLY ADMIN-ONLY RLS)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  admin_email TEXT NOT NULL,
  action TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT,
  summary TEXT NOT NULL,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_admin_audit_logs_created
  ON public.admin_audit_logs (created_at DESC);

ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.admin_audit_logs FROM anon;
REVOKE INSERT, UPDATE, DELETE ON TABLE public.admin_audit_logs FROM authenticated;

DROP POLICY IF EXISTS "Admin can read audit logs" ON public.admin_audit_logs;
CREATE POLICY "Admin can read audit logs" ON public.admin_audit_logs
  FOR SELECT TO authenticated
  USING (public.is_teso_admin());

-- ------------------------------------------------------------------------------
-- 8. INTERNAL ELIGIBLE METRICS CALCULATOR (ANTI-DUPLICATE & ANTI-FRAUD)
--    Counts ONLY genuine eligible activity:
--      - Likes:     deduplicated per (song, listener), excludes artist self-likes.
--      - Followers: genuine unique fan followers from artist_follows, excludes
--                   self-follows and excludes song-milestone bonus followers.
--      - Downloads: deduplicated max 1 per (song, listener, UTC day), excludes
--                   artist self-downloads.
--      - Streams:   genuine plays in song_streams, capped at max 3 per
--                   (song, listener, UTC day) with 3-min cooldown, excludes
--                   artist self-streams.
-- ------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public._compute_artist_eligible_metrics(p_user_id UUID)
RETURNS TABLE (
  song_count INTEGER,
  eligible_likes INTEGER,
  monthly_likes INTEGER,
  eligible_followers INTEGER,
  monthly_followers INTEGER,
  eligible_downloads INTEGER,
  monthly_downloads INTEGER,
  eligible_streams INTEGER,
  monthly_streams INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_month_start TIMESTAMPTZ := date_trunc('month', timezone('utc'::text, now()));
  v_uid_text TEXT := p_user_id::text;
  v_stage_name TEXT := '';
  v_full_name TEXT := '';
  v_username TEXT := '';
  v_distinct_song_artists INTEGER := 0;
  v_single_song_artist TEXT := '';
  v_aliases TEXT[] := ARRAY[lower(v_uid_text)];
BEGIN
  SELECT
    coalesce(trim(p.full_name), ''),
    coalesce(trim(p.username), '')
  INTO v_full_name, v_username
  FROM public.profiles p
  WHERE p.id = p_user_id;

  SELECT
    coalesce(trim(u.raw_user_meta_data ->> 'stage_name'), '')
  INTO v_stage_name
  FROM auth.users u
  WHERE u.id = p_user_id;

  SELECT
    count(*)::INTEGER,
    count(DISTINCT lower(trim(s.artist)))::INTEGER,
    coalesce(min(lower(trim(s.artist))), '')
  INTO song_count, v_distinct_song_artists, v_single_song_artist
  FROM public.songs s
  WHERE s.user_id = p_user_id
    AND coalesce(s.category, 'new') <> 'video';

  IF v_stage_name <> '' THEN
    v_aliases := array_append(v_aliases, lower(v_stage_name));
    v_aliases := array_append(v_aliases, trim(both '-' from regexp_replace(lower(v_stage_name), '[^a-z0-9]+', '-', 'g')));
  END IF;

  IF v_full_name <> '' THEN
    v_aliases := array_append(v_aliases, lower(v_full_name));
    v_aliases := array_append(v_aliases, trim(both '-' from regexp_replace(lower(v_full_name), '[^a-z0-9]+', '-', 'g')));
  END IF;

  IF v_username <> '' THEN
    v_aliases := array_append(v_aliases, lower(v_username));
    v_aliases := array_append(v_aliases, trim(both '-' from regexp_replace(lower(v_username), '[^a-z0-9]+', '-', 'g')));
  END IF;

  IF v_distinct_song_artists = 1 AND v_single_song_artist <> '' THEN
    v_aliases := array_append(v_aliases, v_single_song_artist);
    v_aliases := array_append(v_aliases, trim(both '-' from regexp_replace(v_single_song_artist, '[^a-z0-9]+', '-', 'g')));
  END IF;

  SELECT ARRAY(
    SELECT DISTINCT a
    FROM unnest(v_aliases) AS a
    WHERE a IS NOT NULL AND a <> ''
  ) INTO v_aliases;

  -- 1. Eligible Likes (deduplicated per song + listener, excluding self-likes)
  --    Explicit ::text casts ensure full compatibility with live public.song_likes
  --    and public.user_favorites schemas (where song_id is TEXT in production).
  WITH artist_songs AS (
    SELECT s.id AS song_uuid, s.id::text AS song_text
    FROM public.songs s
    WHERE s.user_id = p_user_id
      AND coalesce(s.category, 'new') <> 'video'
  ),
  combined_likes AS (
    SELECT sl.song_id::text AS song_key, sl.user_id::text AS actor_key, min(sl.created_at) AS first_liked_at
    FROM public.song_likes sl
    INNER JOIN artist_songs asg ON asg.song_text = sl.song_id::text
    WHERE coalesce(sl.user_id::text, '') <> v_uid_text
    GROUP BY sl.song_id::text, sl.user_id::text
    UNION
    SELECT uf.song_id::text AS song_key, uf.user_id::text AS actor_key, min(uf.created_at) AS first_liked_at
    FROM public.user_favorites uf
    INNER JOIN artist_songs asg ON asg.song_text = uf.song_id::text
    WHERE coalesce(uf.user_id::text, '') <> v_uid_text
    GROUP BY uf.song_id::text, uf.user_id::text
  ),
  deduped_likes AS (
    SELECT song_key, actor_key, min(first_liked_at) AS first_liked_at
    FROM combined_likes
    GROUP BY song_key, actor_key
  )
  SELECT
    count(*)::INTEGER,
    count(*) FILTER (WHERE first_liked_at >= v_month_start)::INTEGER
  INTO eligible_likes, monthly_likes
  FROM deduped_likes;

  -- 2. Eligible Followers (genuine fan followers only, excluding self-follows & milestone bonuses)
  WITH genuine_follows AS (
    SELECT af.user_id::text AS follower_key, min(af.created_at) AS first_followed_at
    FROM public.artist_follows af
    WHERE coalesce(af.user_id::text, '') <> v_uid_text
      AND (
        lower(trim(coalesce(af.artist_id::text, ''))) = ANY(v_aliases)
        OR lower(trim(coalesce(af.artist_name, ''))) = ANY(v_aliases)
      )
    GROUP BY af.user_id::text
  )
  SELECT
    count(*)::INTEGER,
    count(*) FILTER (WHERE first_followed_at >= v_month_start)::INTEGER
  INTO eligible_followers, monthly_followers
  FROM genuine_follows;

  -- 3. Eligible Downloads (max 1 per listener per song per UTC day, excluding self-downloads)
  WITH artist_songs AS (
    SELECT s.id::text AS song_text
    FROM public.songs s
    WHERE s.user_id = p_user_id
      AND coalesce(s.category, 'new') <> 'video'
  ),
  deduped_downloads AS (
    SELECT
      sd.song_id::text AS song_key,
      coalesce(sd.actor_id::text, '') AS actor_key,
      date_trunc('day', sd.created_at) AS download_day,
      min(sd.created_at) AS first_download_at
    FROM public.song_downloads sd
    INNER JOIN artist_songs asg ON asg.song_text = sd.song_id::text
    WHERE coalesce(sd.actor_id::text, '') <> v_uid_text
      AND (sd.user_id IS NULL OR sd.user_id::text <> v_uid_text)
    GROUP BY sd.song_id::text, coalesce(sd.actor_id::text, ''), date_trunc('day', sd.created_at)
  )
  SELECT
    count(*)::INTEGER,
    count(*) FILTER (WHERE first_download_at >= v_month_start)::INTEGER
  INTO eligible_downloads, monthly_downloads
  FROM deduped_downloads;

  -- 4. Eligible Streams (max 3 per listener per song per UTC day, excluding self-streams)
  WITH artist_songs AS (
    SELECT s.id::text AS song_text
    FROM public.songs s
    WHERE s.user_id = p_user_id
      AND coalesce(s.category, 'new') <> 'video'
  ),
  capped_streams AS (
    SELECT
      st.id,
      st.created_at,
      row_number() OVER (
        PARTITION BY st.song_id::text, coalesce(st.actor_id::text, ''), date_trunc('day', st.created_at)
        ORDER BY st.created_at ASC
      ) AS daily_rank
    FROM public.song_streams st
    INNER JOIN artist_songs asg ON asg.song_text = st.song_id::text
    WHERE coalesce(st.actor_id::text, '') <> v_uid_text
      AND (st.user_id IS NULL OR st.user_id::text <> v_uid_text)
  )
  SELECT
    count(*)::INTEGER,
    count(*) FILTER (WHERE created_at >= v_month_start)::INTEGER
  INTO eligible_streams, monthly_streams
  FROM capped_streams
  WHERE daily_rank <= 3;

  song_count := coalesce(song_count, 0);
  eligible_likes := coalesce(eligible_likes, 0);
  monthly_likes := coalesce(monthly_likes, 0);
  eligible_followers := coalesce(eligible_followers, 0);
  monthly_followers := coalesce(monthly_followers, 0);
  eligible_downloads := coalesce(eligible_downloads, 0);
  monthly_downloads := coalesce(monthly_downloads, 0);
  eligible_streams := coalesce(eligible_streams, 0);
  monthly_streams := coalesce(monthly_streams, 0);

  RETURN NEXT;
END;
$$;

REVOKE ALL ON FUNCTION public._compute_artist_eligible_metrics(UUID) FROM PUBLIC, anon, authenticated;

-- ------------------------------------------------------------------------------
-- 9. INTERNAL LEDGER SYNC HELPER (MILESTONE-BASED, PRESERVES QUALIFYING ACTIVITY
--    BETWEEN MILESTONES, NEVER REWRITES PREVIOUSLY CREDITED EARNINGS)
-- ------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public._sync_artist_earnings_ledger(p_user_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_settings public.artist_earning_settings%ROWTYPE;
  v_account public.artist_earnings_accounts%ROWTYPE;
  v_email TEXT := '';
  v_metrics RECORD;
  v_cur_month_start TIMESTAMPTZ := date_trunc('month', timezone('utc'::text, now()));
  v_prev_month_start TIMESTAMPTZ := date_trunc('month', timezone('utc'::text, now()) - interval '1 month');

  v_uncredited_likes INTEGER := 0;
  v_uncredited_followers INTEGER := 0;
  v_uncredited_downloads INTEGER := 0;
  v_uncredited_streams INTEGER := 0;

  v_new_likes_units INTEGER := 0;
  v_new_followers_units INTEGER := 0;
  v_new_downloads_units INTEGER := 0;
  v_new_streams_units INTEGER := 0;

  v_delta_likes_ugx NUMERIC(14, 2) := 0;
  v_delta_followers_ugx NUMERIC(14, 2) := 0;
  v_delta_downloads_ugx NUMERIC(14, 2) := 0;
  v_delta_streams_ugx NUMERIC(14, 2) := 0;

  v_rem_likes INTEGER := 0;
  v_rem_followers INTEGER := 0;
  v_rem_downloads INTEGER := 0;
  v_rem_streams INTEGER := 0;

  v_pending_earnings NUMERIC(14, 2) := 0;
  v_total_earnings NUMERIC(14, 2) := 0;
  v_amount_withdrawn NUMERIC(14, 2) := 0;
  v_pending_withdrawals NUMERIC(14, 2) := 0;
  v_available_balance NUMERIC(14, 2) := 0;
  v_monthly_earnings NUMERIC(14, 2) := 0;
  v_prev_month_earnings NUMERIC(14, 2) := 0;
  v_ref TEXT;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('earnings-sync:' || p_user_id::text));

  SELECT * INTO v_settings FROM public.artist_earning_settings WHERE id = 1;
  IF NOT FOUND THEN
    INSERT INTO public.artist_earning_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
    SELECT * INTO v_settings FROM public.artist_earning_settings WHERE id = 1;
  END IF;

  SELECT lower(coalesce(u.email, '')) INTO v_email FROM auth.users u WHERE u.id = p_user_id;

  INSERT INTO public.artist_earnings_accounts (user_id, registered_email)
  VALUES (p_user_id, v_email)
  ON CONFLICT (user_id) DO UPDATE
    SET registered_email = COALESCE(NULLIF(v_email, ''), public.artist_earnings_accounts.registered_email),
        updated_at = timezone('utc'::text, now());

  SELECT * INTO v_account FROM public.artist_earnings_accounts WHERE user_id = p_user_id;

  -- Backfill raw counts safely if upgrading from an earlier units-only row
  IF v_account.credited_likes_count = 0 AND v_account.credited_likes_units > 0 THEN
    v_account.credited_likes_count := v_account.credited_likes_units * v_settings.likes_per_unit;
  END IF;
  IF v_account.credited_followers_count = 0 AND v_account.credited_followers_units > 0 THEN
    v_account.credited_followers_count := v_account.credited_followers_units * v_settings.followers_per_unit;
  END IF;
  IF v_account.credited_downloads_count = 0 AND v_account.credited_downloads_units > 0 THEN
    v_account.credited_downloads_count := v_account.credited_downloads_units * v_settings.downloads_per_unit;
  END IF;

  SELECT * INTO v_metrics FROM public._compute_artist_eligible_metrics(p_user_id);

  -- Credit newly completed milestones ONLY when artist Gmail is verified AND not suspended
  IF v_account.earnings_verified AND NOT v_account.is_suspended THEN
    -- 1. Likes milestone credits
    v_uncredited_likes := GREATEST(0, v_metrics.eligible_likes - v_account.credited_likes_count);
    v_new_likes_units := floor(v_uncredited_likes::numeric / GREATEST(1, v_settings.likes_per_unit))::INTEGER;

    IF v_new_likes_units > 0 AND v_settings.likes_rate_ugx > 0 THEN
      v_delta_likes_ugx := ROUND(v_new_likes_units * v_settings.likes_rate_ugx, 2);
      v_ref := 'TM-ERN-LIK-' || upper(substr(replace(p_user_id::text, '-', ''), 1, 6)) || '-' || (v_account.credited_likes_count + (v_new_likes_units * v_settings.likes_per_unit))::text;

      INSERT INTO public.artist_earning_transactions (
        reference_code, user_id, transaction_type, category_label, direction,
        amount_ugx, units_count, rate_applied_ugx, status, description, metadata
      )
      VALUES (
        v_ref, p_user_id, 'likes_earning', 'Likes Earnings', 'credit',
        v_delta_likes_ugx, v_new_likes_units * v_settings.likes_per_unit, v_settings.likes_rate_ugx,
        'Credited',
        format(
          'Likes milestone credit: %s eligible likes (%s × %s UGX per %s likes)',
          (v_new_likes_units * v_settings.likes_per_unit), v_new_likes_units,
          v_settings.likes_rate_ugx, v_settings.likes_per_unit
        ),
        jsonb_build_object(
          'from_count', v_account.credited_likes_count,
          'to_count', v_account.credited_likes_count + (v_new_likes_units * v_settings.likes_per_unit),
          'eligible_likes', v_metrics.eligible_likes
        )
      )
      ON CONFLICT (reference_code) DO NOTHING;

      IF FOUND THEN
        v_account.credited_likes_count := v_account.credited_likes_count + (v_new_likes_units * v_settings.likes_per_unit);
        v_account.credited_likes_units := v_account.credited_likes_units + v_new_likes_units;
        v_account.credited_likes_ugx := v_account.credited_likes_ugx + v_delta_likes_ugx;
      END IF;
    END IF;

    -- 2. Followers milestone credits
    v_uncredited_followers := GREATEST(0, v_metrics.eligible_followers - v_account.credited_followers_count);
    v_new_followers_units := floor(v_uncredited_followers::numeric / GREATEST(1, v_settings.followers_per_unit))::INTEGER;

    IF v_new_followers_units > 0 AND v_settings.followers_rate_ugx > 0 THEN
      v_delta_followers_ugx := ROUND(v_new_followers_units * v_settings.followers_rate_ugx, 2);
      v_ref := 'TM-ERN-FLW-' || upper(substr(replace(p_user_id::text, '-', ''), 1, 6)) || '-' || (v_account.credited_followers_count + (v_new_followers_units * v_settings.followers_per_unit))::text;

      INSERT INTO public.artist_earning_transactions (
        reference_code, user_id, transaction_type, category_label, direction,
        amount_ugx, units_count, rate_applied_ugx, status, description, metadata
      )
      VALUES (
        v_ref, p_user_id, 'followers_earning', 'Followers Earnings', 'credit',
        v_delta_followers_ugx, v_new_followers_units * v_settings.followers_per_unit, v_settings.followers_rate_ugx,
        'Credited',
        format(
          'Followers milestone credit: %s genuine followers (%s × %s UGX per %s followers)',
          (v_new_followers_units * v_settings.followers_per_unit), v_new_followers_units,
          v_settings.followers_rate_ugx, v_settings.followers_per_unit
        ),
        jsonb_build_object(
          'from_count', v_account.credited_followers_count,
          'to_count', v_account.credited_followers_count + (v_new_followers_units * v_settings.followers_per_unit),
          'eligible_followers', v_metrics.eligible_followers
        )
      )
      ON CONFLICT (reference_code) DO NOTHING;

      IF FOUND THEN
        v_account.credited_followers_count := v_account.credited_followers_count + (v_new_followers_units * v_settings.followers_per_unit);
        v_account.credited_followers_units := v_account.credited_followers_units + v_new_followers_units;
        v_account.credited_followers_ugx := v_account.credited_followers_ugx + v_delta_followers_ugx;
      END IF;
    END IF;

    -- 3. Download royalties milestone credits
    v_uncredited_downloads := GREATEST(0, v_metrics.eligible_downloads - v_account.credited_downloads_count);
    v_new_downloads_units := floor(v_uncredited_downloads::numeric / GREATEST(1, v_settings.downloads_per_unit))::INTEGER;

    IF v_new_downloads_units > 0 AND v_settings.downloads_rate_ugx > 0 THEN
      v_delta_downloads_ugx := ROUND(v_new_downloads_units * v_settings.downloads_rate_ugx, 2);
      v_ref := 'TM-ERN-DWN-' || upper(substr(replace(p_user_id::text, '-', ''), 1, 6)) || '-' || (v_account.credited_downloads_count + (v_new_downloads_units * v_settings.downloads_per_unit))::text;

      INSERT INTO public.artist_earning_transactions (
        reference_code, user_id, transaction_type, category_label, direction,
        amount_ugx, units_count, rate_applied_ugx, status, description, metadata
      )
      VALUES (
        v_ref, p_user_id, 'downloads_earning', 'Download Royalties', 'credit',
        v_delta_downloads_ugx, v_new_downloads_units * v_settings.downloads_per_unit, v_settings.downloads_rate_ugx,
        'Credited',
        format(
          'Download royalties: %s eligible downloads (%s × %s UGX per %s downloads)',
          (v_new_downloads_units * v_settings.downloads_per_unit), v_new_downloads_units,
          v_settings.downloads_rate_ugx, v_settings.downloads_per_unit
        ),
        jsonb_build_object(
          'from_count', v_account.credited_downloads_count,
          'to_count', v_account.credited_downloads_count + (v_new_downloads_units * v_settings.downloads_per_unit),
          'eligible_downloads', v_metrics.eligible_downloads
        )
      )
      ON CONFLICT (reference_code) DO NOTHING;

      IF FOUND THEN
        v_account.credited_downloads_count := v_account.credited_downloads_count + (v_new_downloads_units * v_settings.downloads_per_unit);
        v_account.credited_downloads_units := v_account.credited_downloads_units + v_new_downloads_units;
        v_account.credited_downloads_ugx := v_account.credited_downloads_ugx + v_delta_downloads_ugx;
      END IF;
    END IF;

    -- 4. Streaming royalties milestone credits
    v_uncredited_streams := GREATEST(0, v_metrics.eligible_streams - v_account.credited_streams_count);
    v_new_streams_units := floor(v_uncredited_streams::numeric / GREATEST(1, v_settings.streams_per_unit))::INTEGER;

    IF v_new_streams_units > 0 AND v_settings.streams_rate_ugx > 0 THEN
      v_delta_streams_ugx := ROUND(v_new_streams_units * v_settings.streams_rate_ugx, 2);
      v_ref := 'TM-ERN-STR-' || upper(substr(replace(p_user_id::text, '-', ''), 1, 6)) || '-' || (v_account.credited_streams_count + (v_new_streams_units * v_settings.streams_per_unit))::text;

      INSERT INTO public.artist_earning_transactions (
        reference_code, user_id, transaction_type, category_label, direction,
        amount_ugx, units_count, rate_applied_ugx, status, description, metadata
      )
      VALUES (
        v_ref, p_user_id, 'streams_earning', 'Streaming Royalties', 'credit',
        v_delta_streams_ugx, v_new_streams_units * v_settings.streams_per_unit, v_settings.streams_rate_ugx,
        'Credited',
        format(
          'Streaming royalties: %s eligible streams (%s × %s UGX per %s streams)',
          (v_new_streams_units * v_settings.streams_per_unit), v_new_streams_units,
          v_settings.streams_rate_ugx, v_settings.streams_per_unit
        ),
        jsonb_build_object(
          'from_count', v_account.credited_streams_count,
          'to_count', v_account.credited_streams_count + (v_new_streams_units * v_settings.streams_per_unit),
          'eligible_streams', v_metrics.eligible_streams
        )
      )
      ON CONFLICT (reference_code) DO NOTHING;

      IF FOUND THEN
        v_account.credited_streams_count := v_account.credited_streams_count + (v_new_streams_units * v_settings.streams_per_unit);
        v_account.credited_streams_units := v_account.credited_streams_units + v_new_streams_units;
        v_account.credited_streams_ugx := v_account.credited_streams_ugx + v_delta_streams_ugx;
      END IF;
    END IF;

    UPDATE public.artist_earnings_accounts
    SET credited_likes_count = v_account.credited_likes_count,
        credited_likes_units = v_account.credited_likes_units,
        credited_likes_ugx = v_account.credited_likes_ugx,
        credited_followers_count = v_account.credited_followers_count,
        credited_followers_units = v_account.credited_followers_units,
        credited_followers_ugx = v_account.credited_followers_ugx,
        credited_downloads_count = v_account.credited_downloads_count,
        credited_downloads_units = v_account.credited_downloads_units,
        credited_downloads_ugx = v_account.credited_downloads_ugx,
        credited_streams_count = v_account.credited_streams_count,
        credited_streams_units = v_account.credited_streams_units,
        credited_streams_ugx = v_account.credited_streams_ugx,
        last_synced_at = timezone('utc'::text, now()),
        updated_at = timezone('utc'::text, now())
    WHERE user_id = p_user_id;
  END IF;

  -- Preserved qualifying engagement currently between earning milestones
  v_rem_likes := GREATEST(0, v_metrics.eligible_likes - v_account.credited_likes_count);
  v_rem_followers := GREATEST(0, v_metrics.eligible_followers - v_account.credited_followers_count);
  v_rem_downloads := GREATEST(0, v_metrics.eligible_downloads - v_account.credited_downloads_count);
  v_rem_streams := GREATEST(0, v_metrics.eligible_streams - v_account.credited_streams_count);

  v_pending_earnings := ROUND(
    (LEAST(v_rem_likes, v_settings.likes_per_unit)::numeric / GREATEST(1, v_settings.likes_per_unit)) * v_settings.likes_rate_ugx
    + (LEAST(v_rem_followers, v_settings.followers_per_unit)::numeric / GREATEST(1, v_settings.followers_per_unit)) * v_settings.followers_rate_ugx
    + (LEAST(v_rem_downloads, v_settings.downloads_per_unit)::numeric / GREATEST(1, v_settings.downloads_per_unit)) * v_settings.downloads_rate_ugx
    + (LEAST(v_rem_streams, v_settings.streams_per_unit)::numeric / GREATEST(1, v_settings.streams_per_unit)) * v_settings.streams_rate_ugx,
    2
  );

  v_total_earnings := ROUND(
    coalesce(v_account.credited_likes_ugx, 0)
    + coalesce(v_account.credited_followers_ugx, 0)
    + coalesce(v_account.credited_downloads_ugx, 0)
    + coalesce(v_account.credited_streams_ugx, 0)
    + coalesce(v_account.manual_adjustment_ugx, 0),
    2
  );

  SELECT
    coalesce(sum(amount_ugx) FILTER (WHERE status = 'Paid'), 0),
    coalesce(sum(amount_ugx) FILTER (WHERE status IN ('Pending', 'Approved')), 0)
  INTO v_amount_withdrawn, v_pending_withdrawals
  FROM public.artist_withdrawal_requests
  WHERE user_id = p_user_id;

  v_available_balance := GREATEST(0, ROUND(v_total_earnings - v_amount_withdrawn - v_pending_withdrawals, 2));

  -- Current month & previous month credited earnings
  SELECT
    coalesce(sum(amount_ugx) FILTER (WHERE created_at >= v_cur_month_start), 0),
    coalesce(sum(amount_ugx) FILTER (WHERE created_at >= v_prev_month_start AND created_at < v_cur_month_start), 0)
  INTO v_monthly_earnings, v_prev_month_earnings
  FROM public.artist_earning_transactions
  WHERE user_id = p_user_id
    AND direction = 'credit'
    AND status = 'Credited';

  RETURN jsonb_build_object(
    'user_id', p_user_id,
    'registered_email', v_email,
    'is_gmail', (v_email ~* '@(gmail\.com|googlemail\.com)$'),
    'verified_gmail', v_account.verified_gmail,
    'earnings_verified', v_account.earnings_verified,
    'earnings_verified_at', v_account.earnings_verified_at,
    'verification_method', v_account.verification_method,
    'is_suspended', v_account.is_suspended,
    'suspended_reason', v_account.suspended_reason,
    'song_count', v_metrics.song_count,
    'total_likes', v_metrics.eligible_likes,
    'likes_earnings_ugx', coalesce(v_account.credited_likes_ugx, 0),
    'qualifying_likes_progress', v_rem_likes,
    'total_followers', v_metrics.eligible_followers,
    'followers_earnings_ugx', coalesce(v_account.credited_followers_ugx, 0),
    'qualifying_followers_progress', v_rem_followers,
    'total_downloads', v_metrics.eligible_downloads,
    'downloads_earnings_ugx', coalesce(v_account.credited_downloads_ugx, 0),
    'qualifying_downloads_progress', v_rem_downloads,
    'total_streams', v_metrics.eligible_streams,
    'streams_earnings_ugx', coalesce(v_account.credited_streams_ugx, 0),
    'qualifying_streams_progress', v_rem_streams,
    'pending_earnings_ugx', v_pending_earnings,
    'total_earnings_ugx', v_total_earnings,
    'amount_withdrawn_ugx', v_amount_withdrawn,
    'pending_withdrawals_ugx', v_pending_withdrawals,
    'available_balance_ugx', v_available_balance,
    'monthly_likes', v_metrics.monthly_likes,
    'monthly_followers', v_metrics.monthly_followers,
    'monthly_downloads', v_metrics.monthly_downloads,
    'monthly_streams', v_metrics.monthly_streams,
    'monthly_earnings_ugx', v_monthly_earnings,
    'previous_month_earnings_ugx', v_prev_month_earnings,
    'last_synced_at', timezone('utc'::text, now())
  );
END;
$$;

REVOKE ALL ON FUNCTION public._sync_artist_earnings_ledger(UUID) FROM PUBLIC, anon, authenticated;

-- ------------------------------------------------------------------------------
-- 10. ARTIST RPCs (AUTHENTICATED USER ONLY — STRICT auth.uid() SCOPE)
-- ------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.initiate_artist_gmail_verification()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_email TEXT := '';
  v_nonce TEXT := replace(gen_random_uuid()::text, '-', '');
  v_already_verified BOOLEAN := FALSE;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  SELECT lower(coalesce(u.email, '')) INTO v_email FROM auth.users u WHERE u.id = v_uid;

  IF v_email = '' THEN
    RAISE EXCEPTION 'No registered email found on your account';
  END IF;

  IF NOT (v_email ~* '@(gmail\.com|googlemail\.com)$') THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'is_gmail', FALSE,
      'registered_email', v_email,
      'error', 'The Artist Monetization Program requires a registered Gmail address (@gmail.com). Update your existing account email securely to Gmail first.'
    );
  END IF;

  INSERT INTO public.artist_earnings_accounts (
    user_id,
    registered_email,
    verification_requested_at,
    verification_nonce
  )
  VALUES (v_uid, v_email, timezone('utc'::text, now()), v_nonce)
  ON CONFLICT (user_id) DO UPDATE
    SET registered_email = v_email,
        verification_requested_at = CASE
          WHEN public.artist_earnings_accounts.earnings_verified THEN public.artist_earnings_accounts.verification_requested_at
          ELSE timezone('utc'::text, now())
        END,
        verification_nonce = CASE
          WHEN public.artist_earnings_accounts.earnings_verified THEN NULL
          ELSE v_nonce
        END,
        updated_at = timezone('utc'::text, now())
  RETURNING earnings_verified INTO v_already_verified;

  RETURN jsonb_build_object(
    'success', TRUE,
    'is_gmail', TRUE,
    'registered_email', v_email,
    'nonce', CASE WHEN coalesce(v_already_verified, FALSE) THEN NULL ELSE v_nonce END,
    'already_verified', coalesce(v_already_verified, FALSE)
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.complete_artist_gmail_verification(
  p_method TEXT DEFAULT 'gmail_otp',
  p_nonce TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_now TIMESTAMPTZ := timezone('utc'::text, now());
  v_email TEXT := '';
  v_confirmed_at TIMESTAMPTZ;
  v_last_sign_in TIMESTAMPTZ;
  v_account public.artist_earnings_accounts%ROWTYPE;
  v_clean_method TEXT := CASE
    WHEN lower(coalesce(p_method, '')) IN ('gmail_otp', 'gmail_link') THEN lower(p_method)
    ELSE 'gmail_otp'
  END;
  v_fresh_auth_verified BOOLEAN := FALSE;
  v_summary JSONB;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  SELECT lower(coalesce(u.email, '')), u.email_confirmed_at, u.last_sign_in_at
  INTO v_email, v_confirmed_at, v_last_sign_in
  FROM auth.users u
  WHERE u.id = v_uid;

  IF NOT (v_email ~* '@(gmail\.com|googlemail\.com)$') THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Only a verified Gmail address (@gmail.com) can activate Artist Earnings.'
    );
  END IF;

  IF v_confirmed_at IS NULL THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Your Gmail address is not confirmed yet. Enter the 6-digit code sent to your Gmail inbox.'
    );
  END IF;

  SELECT * INTO v_account FROM public.artist_earnings_accounts WHERE user_id = v_uid;

  IF v_account.user_id IS NOT NULL AND v_account.earnings_verified THEN
    v_summary := public._sync_artist_earnings_ledger(v_uid);
    RETURN jsonb_build_object(
      'success', TRUE,
      'already_verified', TRUE,
      'verified_gmail', coalesce(nullif(v_account.verified_gmail, ''), v_email),
      'summary', v_summary
    );
  END IF;

  IF v_account.user_id IS NULL OR v_account.verification_requested_at IS NULL THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Click "Verify Email" first to receive a fresh 6-digit verification code in your Gmail inbox.'
    );
  END IF;

  IF (v_now - v_account.verification_requested_at) > INTERVAL '60 minutes' THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Your verification code has expired. Click "Resend Verification Email" to receive a fresh 6-digit code.'
    );
  END IF;

  v_fresh_auth_verified := (
    (v_last_sign_in IS NOT NULL AND v_last_sign_in >= v_account.verification_requested_at)
    OR (v_confirmed_at IS NOT NULL AND v_confirmed_at >= v_account.verification_requested_at)
  );

  IF NOT v_fresh_auth_verified THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Valid 6-digit Gmail OTP verification is required before unlocking Artist Earnings. Enter the latest 6-digit code from your Gmail.'
    );
  END IF;

  IF p_nonce IS NOT NULL AND length(trim(p_nonce)) > 0 AND v_account.verification_nonce IS NOT NULL THEN
    IF trim(p_nonce) <> v_account.verification_nonce THEN
      RETURN jsonb_build_object(
        'success', FALSE,
        'error', 'This verification request has been superseded by a newer code. Please use the latest 6-digit code sent to your Gmail.'
      );
    END IF;
  END IF;

  UPDATE public.artist_earnings_accounts
  SET registered_email = v_email,
      verified_gmail = v_email,
      earnings_verified = TRUE,
      earnings_verified_at = v_now,
      verification_method = v_clean_method,
      verification_nonce = NULL,
      updated_at = v_now
  WHERE user_id = v_uid;

  v_summary := public._sync_artist_earnings_ledger(v_uid);

  RETURN jsonb_build_object(
    'success', TRUE,
    'verified_gmail', v_email,
    'verification_method', v_clean_method,
    'summary', v_summary
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.get_artist_earnings_dashboard()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_summary JSONB;
  v_settings JSONB;
  v_payout JSONB;
  v_withdrawals JSONB;
  v_transactions JSONB;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  v_summary := public._sync_artist_earnings_ledger(v_uid);

  SELECT to_jsonb(s) INTO v_settings FROM public.artist_earning_settings s WHERE s.id = 1;
  SELECT to_jsonb(p) INTO v_payout FROM public.artist_payout_profiles p WHERE p.user_id = v_uid;

  SELECT coalesce(jsonb_agg(to_jsonb(w) ORDER BY w.created_at DESC), '[]'::jsonb)
  INTO v_withdrawals
  FROM public.artist_withdrawal_requests w
  WHERE w.user_id = v_uid;

  SELECT coalesce(jsonb_agg(to_jsonb(t) ORDER BY t.created_at DESC), '[]'::jsonb)
  INTO v_transactions
  FROM (
    SELECT *
    FROM public.artist_earning_transactions
    WHERE user_id = v_uid
    ORDER BY created_at DESC
    LIMIT 150
  ) t;

  RETURN jsonb_build_object(
    'summary', v_summary,
    'settings', v_settings,
    'payout_profile', v_payout,
    'withdrawals', v_withdrawals,
    'transactions', v_transactions
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.save_artist_payout_profile(
  p_full_legal_name TEXT,
  p_country TEXT,
  p_phone_number TEXT,
  p_mobile_money_provider TEXT,
  p_mobile_money_number TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_account public.artist_earnings_accounts%ROWTYPE;
  v_name TEXT := trim(coalesce(p_full_legal_name, ''));
  v_country TEXT := trim(coalesce(p_country, 'Uganda'));
  v_phone TEXT := trim(coalesce(p_phone_number, ''));
  v_provider TEXT := trim(coalesce(p_mobile_money_provider, ''));
  v_momo TEXT := trim(coalesce(p_mobile_money_number, ''));
  v_gmail TEXT := '';
  v_saved public.artist_payout_profiles%ROWTYPE;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  SELECT * INTO v_account FROM public.artist_earnings_accounts WHERE user_id = v_uid;
  IF NOT FOUND OR NOT v_account.earnings_verified THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Verify your registered Gmail address first to save private payout information.'
    );
  END IF;

  v_gmail := coalesce(nullif(v_account.verified_gmail, ''), v_account.registered_email, '');

  IF length(v_name) < 2 OR length(v_name) > 120 THEN
    RETURN jsonb_build_object('success', FALSE, 'error', 'Please enter your valid full legal name.');
  END IF;
  IF length(v_country) < 2 OR length(v_country) > 80 THEN
    RETURN jsonb_build_object('success', FALSE, 'error', 'Please enter a valid country.');
  END IF;
  IF length(regexp_replace(v_phone, '[^0-9]', '', 'g')) < 9 THEN
    RETURN jsonb_build_object('success', FALSE, 'error', 'Please enter a valid phone number.');
  END IF;
  IF v_provider NOT IN ('MTN Mobile Money', 'Airtel Money') THEN
    RETURN jsonb_build_object('success', FALSE, 'error', 'Select MTN Mobile Money or Airtel Money.');
  END IF;
  IF length(regexp_replace(v_momo, '[^0-9]', '', 'g')) < 9 THEN
    RETURN jsonb_build_object('success', FALSE, 'error', 'Please enter a valid Mobile Money payout number.');
  END IF;

  INSERT INTO public.artist_payout_profiles (
    user_id, full_legal_name, country, phone_number, registered_gmail,
    mobile_money_provider, mobile_money_number
  )
  VALUES (v_uid, v_name, v_country, v_phone, v_gmail, v_provider, v_momo)
  ON CONFLICT (user_id) DO UPDATE
    SET full_legal_name = EXCLUDED.full_legal_name,
        country = EXCLUDED.country,
        phone_number = EXCLUDED.phone_number,
        registered_gmail = EXCLUDED.registered_gmail,
        mobile_money_provider = EXCLUDED.mobile_money_provider,
        mobile_money_number = EXCLUDED.mobile_money_number
  RETURNING * INTO v_saved;

  RETURN jsonb_build_object('success', TRUE, 'payout_profile', to_jsonb(v_saved));
END;
$$;

CREATE OR REPLACE FUNCTION public.request_artist_withdrawal(
  p_amount_ugx NUMERIC,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_amount NUMERIC(14, 2) := ROUND(coalesce(p_amount_ugx, 0), 2);
  v_idem TEXT := NULLIF(trim(coalesce(p_idempotency_key, '')), '');
  v_existing public.artist_withdrawal_requests%ROWTYPE;
  v_settings public.artist_earning_settings%ROWTYPE;
  v_account public.artist_earnings_accounts%ROWTYPE;
  v_payout public.artist_payout_profiles%ROWTYPE;
  v_summary JSONB;
  v_available NUMERIC(14, 2) := 0;
  v_artist_name TEXT := '';
  v_ref TEXT;
  v_created public.artist_withdrawal_requests%ROWTYPE;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('withdraw:' || v_uid::text));

  IF v_idem IS NOT NULL THEN
    SELECT * INTO v_existing
    FROM public.artist_withdrawal_requests
    WHERE idempotency_key = v_idem AND user_id = v_uid;

    IF FOUND THEN
      RETURN jsonb_build_object('success', TRUE, 'duplicate', TRUE, 'withdrawal', to_jsonb(v_existing));
    END IF;
  END IF;

  SELECT * INTO v_settings FROM public.artist_earning_settings WHERE id = 1;
  SELECT * INTO v_account FROM public.artist_earnings_accounts WHERE user_id = v_uid;

  IF NOT FOUND OR NOT v_account.earnings_verified THEN
    RETURN jsonb_build_object('success', FALSE, 'error', 'Verify your registered Gmail address before requesting a withdrawal.');
  END IF;

  IF v_account.is_suspended THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', coalesce('Withdrawals are suspended: ' || nullif(v_account.suspended_reason, ''), 'Your earnings account is temporarily suspended pending review.')
    );
  END IF;

  SELECT * INTO v_payout FROM public.artist_payout_profiles WHERE user_id = v_uid;
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Please save your private Payout Information (Mobile Money details) before requesting a withdrawal.'
    );
  END IF;

  v_summary := public._sync_artist_earnings_ledger(v_uid);
  v_available := coalesce((v_summary ->> 'available_balance_ugx')::numeric, 0);

  IF v_amount < v_settings.min_withdrawal_ugx THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', format('Minimum withdrawal request is UGX %s.', trim(to_char(v_settings.min_withdrawal_ugx, 'FM999,999,999')))
    );
  END IF;

  IF v_amount > v_available THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', format('Requested amount exceeds your available balance (UGX %s).', trim(to_char(v_available, 'FM999,999,999')))
    );
  END IF;

  SELECT coalesce(
    nullif(trim(p.full_name), ''),
    nullif(trim(u.raw_user_meta_data ->> 'stage_name'), ''),
    v_payout.full_legal_name,
    'Artist'
  )
  INTO v_artist_name
  FROM auth.users u
  LEFT JOIN public.profiles p ON p.id = u.id
  WHERE u.id = v_uid;

  v_ref := 'TM-WDR-' || to_char(timezone('utc'::text, now()), 'YYYYMMDD') || '-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));

  INSERT INTO public.artist_withdrawal_requests (
    reference_code, idempotency_key, user_id, artist_name, registered_gmail,
    amount_ugx, status, payout_full_name, payout_country, payout_phone,
    mobile_money_provider, mobile_money_number
  )
  VALUES (
    v_ref, v_idem, v_uid, v_artist_name, v_payout.registered_gmail,
    v_amount, 'Pending', v_payout.full_legal_name, v_payout.country,
    v_payout.phone_number, v_payout.mobile_money_provider, v_payout.mobile_money_number
  )
  RETURNING * INTO v_created;

  INSERT INTO public.artist_earning_transactions (
    reference_code, user_id, transaction_type, category_label, direction,
    amount_ugx, units_count, status, description, withdrawal_id, metadata
  )
  VALUES (
    v_ref, v_uid, 'withdrawal', 'Withdrawal Requests', 'debit',
    v_amount, 1, 'Pending',
    format('Withdrawal request via %s (%s)', v_payout.mobile_money_provider, v_payout.mobile_money_number),
    v_created.id,
    jsonb_build_object(
      'provider', v_payout.mobile_money_provider,
      'payout_number', v_payout.mobile_money_number,
      'payout_name', v_payout.full_legal_name
    )
  );

  RETURN jsonb_build_object('success', TRUE, 'withdrawal', to_jsonb(v_created));
END;
$$;

-- ------------------------------------------------------------------------------
-- 11. ADMIN-ONLY RPCs (STRICT SERVER-SIDE AUTHORIZATION + AUDIT LOGGING)
-- ------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.admin_get_earnings_overview()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_artist RECORD;
  v_artists_arr JSONB := '[]'::jsonb;
  v_summary JSONB;
  v_settings JSONB;
  v_withdrawals JSONB;
  v_transactions JSONB;
  v_audit_logs JSONB;
  v_payout JSONB;
BEGIN
  IF NOT public.is_teso_admin() THEN
    RAISE EXCEPTION 'Permission denied: Administrator access required';
  END IF;

  SELECT to_jsonb(s) INTO v_settings FROM public.artist_earning_settings s WHERE s.id = 1;

  FOR v_artist IN
    SELECT
      u.id AS user_id,
      lower(coalesce(u.email, '')) AS email,
      coalesce(
        nullif(trim(p.full_name), ''),
        nullif(trim(u.raw_user_meta_data ->> 'stage_name'), ''),
        nullif(trim(u.raw_user_meta_data ->> 'full_name'), ''),
        split_part(coalesce(u.email, 'Artist'), '@', 1)
      ) AS artist_name,
      coalesce(p.avatar_url, u.raw_user_meta_data ->> 'avatar_url', '') AS avatar_url,
      coalesce(p.role, u.raw_user_meta_data ->> 'role', 'fan') AS role,
      u.created_at AS joined_at
    FROM auth.users u
    LEFT JOIN public.profiles p ON p.id = u.id
    ORDER BY u.created_at DESC
  LOOP
    v_summary := public._sync_artist_earnings_ledger(v_artist.user_id);

    SELECT to_jsonb(pp)
    INTO v_payout
    FROM public.artist_payout_profiles pp
    WHERE pp.user_id = v_artist.user_id;

    v_artists_arr := v_artists_arr || jsonb_build_array(
      jsonb_build_object(
        'user_id', v_artist.user_id,
        'artist_name', v_artist.artist_name,
        'email', v_artist.email,
        'avatar_url', v_artist.avatar_url,
        'role', v_artist.role,
        'joined_at', v_artist.joined_at,
        'payout_profile', v_payout
      ) || v_summary
    );
  END LOOP;

  SELECT coalesce(jsonb_agg(to_jsonb(w) ORDER BY w.created_at DESC), '[]'::jsonb)
  INTO v_withdrawals
  FROM public.artist_withdrawal_requests w;

  SELECT coalesce(
    jsonb_agg(
      (
        to_jsonb(t) || jsonb_build_object(
          'artist_name', coalesce(
            nullif(trim(p.full_name), ''),
            nullif(trim(u.raw_user_meta_data ->> 'stage_name'), ''),
            split_part(coalesce(u.email, 'Artist'), '@', 1)
          ),
          'artist_email', lower(coalesce(u.email, ''))
        )
      )
      ORDER BY t.created_at DESC
    ),
    '[]'::jsonb
  )
  INTO v_transactions
  FROM (
    SELECT *
    FROM public.artist_earning_transactions
    ORDER BY created_at DESC
    LIMIT 400
  ) t
  LEFT JOIN auth.users u ON u.id = t.user_id
  LEFT JOIN public.profiles p ON p.id = t.user_id;

  SELECT coalesce(jsonb_agg(to_jsonb(a) ORDER BY a.created_at DESC), '[]'::jsonb)
  INTO v_audit_logs
  FROM (
    SELECT *
    FROM public.admin_audit_logs
    ORDER BY created_at DESC
    LIMIT 150
  ) a;

  RETURN jsonb_build_object(
    'settings', v_settings,
    'artists', v_artists_arr,
    'withdrawals', v_withdrawals,
    'transactions', v_transactions,
    'audit_logs', v_audit_logs
  );
END;
$$;

-- Replace older 3-arg signature cleanly before creating full 9-arg configurable settings RPC
DROP FUNCTION IF EXISTS public.admin_update_earning_settings(NUMERIC, INTEGER, NUMERIC);

CREATE OR REPLACE FUNCTION public.admin_update_earning_settings(
  p_downloads_rate_ugx NUMERIC,
  p_downloads_per_unit INTEGER DEFAULT 1,
  p_streams_rate_ugx NUMERIC DEFAULT 10,
  p_streams_per_unit INTEGER DEFAULT 25,
  p_likes_rate_ugx NUMERIC DEFAULT 18,
  p_likes_per_unit INTEGER DEFAULT 30,
  p_followers_rate_ugx NUMERIC DEFAULT 700,
  p_followers_per_unit INTEGER DEFAULT 100,
  p_min_withdrawal_ugx NUMERIC DEFAULT 15000
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_prev public.artist_earning_settings%ROWTYPE;
  v_updated public.artist_earning_settings%ROWTYPE;
  v_admin_email TEXT := lower(coalesce(auth.jwt() ->> 'email', 'tesomelodies@gmail.com'));
BEGIN
  IF NOT public.is_teso_admin() THEN
    RAISE EXCEPTION 'Permission denied: Administrator access required';
  END IF;

  IF p_downloads_rate_ugx < 0 OR p_streams_rate_ugx < 0 OR p_likes_rate_ugx < 0 OR p_followers_rate_ugx < 0 THEN
    RETURN jsonb_build_object('success', FALSE, 'error', 'Earning rates cannot be negative.');
  END IF;

  IF p_downloads_per_unit < 1 OR p_streams_per_unit < 1 OR p_likes_per_unit < 1 OR p_followers_per_unit < 1 THEN
    RETURN jsonb_build_object('success', FALSE, 'error', 'Milestone counts must be at least 1.');
  END IF;

  IF p_min_withdrawal_ugx < 1000 THEN
    RETURN jsonb_build_object('success', FALSE, 'error', 'Minimum withdrawal must be at least 1,000 UGX.');
  END IF;

  SELECT * INTO v_prev FROM public.artist_earning_settings WHERE id = 1;

  UPDATE public.artist_earning_settings
  SET downloads_rate_ugx = ROUND(p_downloads_rate_ugx, 2),
      downloads_per_unit = p_downloads_per_unit,
      streams_rate_ugx = ROUND(p_streams_rate_ugx, 2),
      streams_per_unit = p_streams_per_unit,
      likes_rate_ugx = ROUND(p_likes_rate_ugx, 2),
      likes_per_unit = p_likes_per_unit,
      followers_rate_ugx = ROUND(p_followers_rate_ugx, 2),
      followers_per_unit = p_followers_per_unit,
      min_withdrawal_ugx = ROUND(p_min_withdrawal_ugx, 2),
      updated_by = auth.uid()
  WHERE id = 1
  RETURNING * INTO v_updated;

  INSERT INTO public.admin_audit_logs (admin_id, admin_email, action, target_type, target_id, summary, details)
  VALUES (
    auth.uid(),
    v_admin_email,
    'update_royalty_settings',
    'settings',
    '1',
    format(
      'Updated royalty settings: Likes %s/%s, Followers %s/%s, Downloads %s/%s, Streams %s/%s, Min Withdraw %s UGX',
      v_updated.likes_rate_ugx, v_updated.likes_per_unit,
      v_updated.followers_rate_ugx, v_updated.followers_per_unit,
      v_updated.downloads_rate_ugx, v_updated.downloads_per_unit,
      v_updated.streams_rate_ugx, v_updated.streams_per_unit,
      v_updated.min_withdrawal_ugx
    ),
    jsonb_build_object('previous', to_jsonb(v_prev), 'updated', to_jsonb(v_updated))
  );

  RETURN jsonb_build_object('success', TRUE, 'settings', to_jsonb(v_updated));
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_review_withdrawal(
  p_withdrawal_id UUID,
  p_action TEXT,
  p_payment_reference TEXT DEFAULT NULL,
  p_note TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_req public.artist_withdrawal_requests%ROWTYPE;
  v_action TEXT := lower(trim(coalesce(p_action, '')));
  v_pay_ref TEXT := trim(coalesce(p_payment_reference, ''));
  v_note TEXT := trim(coalesce(p_note, ''));
  v_admin_email TEXT := lower(coalesce(auth.jwt() ->> 'email', 'tesomelodies@gmail.com'));
BEGIN
  IF NOT public.is_teso_admin() THEN
    RAISE EXCEPTION 'Permission denied: Administrator access required';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('review-wdr:' || p_withdrawal_id::text));

  SELECT * INTO v_req FROM public.artist_withdrawal_requests WHERE id = p_withdrawal_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', FALSE, 'error', 'Withdrawal request not found.');
  END IF;

  IF v_action = 'approve' THEN
    IF v_req.status <> 'Pending' THEN
      RETURN jsonb_build_object('success', FALSE, 'error', 'Only Pending withdrawals can be approved.');
    END IF;

    UPDATE public.artist_withdrawal_requests
    SET status = 'Approved',
        approved_at = timezone('utc'::text, now()),
        reviewed_by = auth.uid(),
        admin_note = COALESCE(NULLIF(v_note, ''), admin_note)
    WHERE id = p_withdrawal_id
    RETURNING * INTO v_req;

    UPDATE public.artist_earning_transactions
    SET status = 'Approved'
    WHERE withdrawal_id = p_withdrawal_id;

    INSERT INTO public.admin_audit_logs (admin_id, admin_email, action, target_type, target_id, summary, details)
    VALUES (
      auth.uid(), v_admin_email, 'approve_withdrawal', 'withdrawal', v_req.reference_code,
      format('Approved withdrawal %s (%s UGX) for %s', v_req.reference_code, v_req.amount_ugx, v_req.artist_name),
      jsonb_build_object('withdrawal_id', v_req.id, 'amount_ugx', v_req.amount_ugx, 'note', v_note)
    );

    RETURN jsonb_build_object('success', TRUE, 'withdrawal', to_jsonb(v_req));

  ELSIF v_action = 'mark_paid' THEN
    IF v_req.status <> 'Approved' THEN
      RETURN jsonb_build_object('success', FALSE, 'error', 'Withdrawal must be Approved before recording completed payment.');
    END IF;

    IF length(v_pay_ref) < 3 THEN
      RETURN jsonb_build_object('success', FALSE, 'error', 'Enter a real Mobile Money transaction confirmation reference before marking Paid.');
    END IF;

    UPDATE public.artist_withdrawal_requests
    SET status = 'Paid',
        payment_reference = v_pay_ref,
        paid_at = timezone('utc'::text, now()),
        reviewed_by = auth.uid(),
        admin_note = COALESCE(NULLIF(v_note, ''), admin_note)
    WHERE id = p_withdrawal_id
    RETURNING * INTO v_req;

    UPDATE public.artist_earning_transactions
    SET status = 'Paid',
        category_label = 'Payments',
        payment_reference = v_pay_ref
    WHERE withdrawal_id = p_withdrawal_id;

    INSERT INTO public.admin_audit_logs (admin_id, admin_email, action, target_type, target_id, summary, details)
    VALUES (
      auth.uid(), v_admin_email, 'confirm_payment_paid', 'withdrawal', v_req.reference_code,
      format('Recorded completed payment for %s (%s UGX) — Ref: %s', v_req.reference_code, v_req.amount_ugx, v_pay_ref),
      jsonb_build_object(
        'withdrawal_id', v_req.id,
        'amount_ugx', v_req.amount_ugx,
        'provider', v_req.mobile_money_provider,
        'payout_number', v_req.mobile_money_number,
        'payment_reference', v_pay_ref,
        'note', v_note
      )
    );

    RETURN jsonb_build_object('success', TRUE, 'withdrawal', to_jsonb(v_req));

  ELSIF v_action = 'reject' THEN
    IF v_req.status NOT IN ('Pending', 'Approved') THEN
      RETURN jsonb_build_object('success', FALSE, 'error', 'Paid or already rejected withdrawals cannot be rejected.');
    END IF;

    IF length(v_note) < 3 THEN
      RETURN jsonb_build_object('success', FALSE, 'error', 'Provide a clear reason for rejecting this withdrawal.');
    END IF;

    UPDATE public.artist_withdrawal_requests
    SET status = 'Rejected',
        rejection_reason = v_note,
        rejected_at = timezone('utc'::text, now()),
        reviewed_by = auth.uid()
    WHERE id = p_withdrawal_id
    RETURNING * INTO v_req;

    UPDATE public.artist_earning_transactions
    SET status = 'Rejected'
    WHERE withdrawal_id = p_withdrawal_id;

    INSERT INTO public.admin_audit_logs (admin_id, admin_email, action, target_type, target_id, summary, details)
    VALUES (
      auth.uid(), v_admin_email, 'reject_withdrawal', 'withdrawal', v_req.reference_code,
      format('Rejected withdrawal %s (%s UGX) — funds returned to available balance', v_req.reference_code, v_req.amount_ugx),
      jsonb_build_object('withdrawal_id', v_req.id, 'amount_ugx', v_req.amount_ugx, 'reason', v_note)
    );

    RETURN jsonb_build_object('success', TRUE, 'withdrawal', to_jsonb(v_req));
  ELSE
    RETURN jsonb_build_object('success', FALSE, 'error', 'Invalid action. Use approve, mark_paid, or reject.');
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_toggle_artist_suspension(
  p_user_id UUID,
  p_suspended BOOLEAN,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_reason TEXT := trim(coalesce(p_reason, ''));
  v_email TEXT := '';
  v_admin_email TEXT := lower(coalesce(auth.jwt() ->> 'email', 'tesomelodies@gmail.com'));
BEGIN
  IF NOT public.is_teso_admin() THEN
    RAISE EXCEPTION 'Permission denied: Administrator access required';
  END IF;

  IF p_suspended AND length(v_reason) < 3 THEN
    RETURN jsonb_build_object('success', FALSE, 'error', 'Please provide a suspension reason for suspicious earning activity.');
  END IF;

  SELECT lower(coalesce(u.email, '')) INTO v_email FROM auth.users u WHERE u.id = p_user_id;

  INSERT INTO public.artist_earnings_accounts (user_id, registered_email)
  VALUES (p_user_id, v_email)
  ON CONFLICT (user_id) DO NOTHING;

  UPDATE public.artist_earnings_accounts
  SET is_suspended = p_suspended,
      suspended_reason = CASE WHEN p_suspended THEN v_reason ELSE NULL END,
      suspended_at = CASE WHEN p_suspended THEN timezone('utc'::text, now()) ELSE NULL END,
      suspended_by = CASE WHEN p_suspended THEN auth.uid() ELSE NULL END
  WHERE user_id = p_user_id;

  INSERT INTO public.admin_audit_logs (admin_id, admin_email, action, target_type, target_id, summary, details)
  VALUES (
    auth.uid(),
    v_admin_email,
    CASE WHEN p_suspended THEN 'suspend_artist_earnings' ELSE 'restore_artist_earnings' END,
    'artist',
    p_user_id::text,
    CASE WHEN p_suspended
      THEN format('Suspended earnings for %s: %s', coalesce(nullif(v_email, ''), p_user_id::text), v_reason)
      ELSE format('Restored earnings access for %s', coalesce(nullif(v_email, ''), p_user_id::text))
    END,
    jsonb_build_object('user_id', p_user_id, 'email', v_email, 'suspended', p_suspended, 'reason', v_reason)
  );

  RETURN jsonb_build_object(
    'success', TRUE,
    'user_id', p_user_id,
    'is_suspended', p_suspended,
    'suspended_reason', CASE WHEN p_suspended THEN v_reason ELSE NULL END
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_check_monetization_health()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_tables_ok BOOLEAN := FALSE;
  v_settings_ok BOOLEAN := FALSE;
  v_metrics_ok BOOLEAN := FALSE;
  v_metrics_error TEXT := NULL;
  v_missing_tables TEXT[] := ARRAY[]::TEXT[];
  v_req_table TEXT;
  v_required_tables TEXT[] := ARRAY[
    'song_streams',
    'artist_earning_settings',
    'artist_earnings_accounts',
    'artist_payout_profiles',
    'artist_withdrawal_requests',
    'artist_earning_transactions',
    'admin_audit_logs'
  ];
  v_probe RECORD;
BEGIN
  IF NOT public.is_teso_admin() THEN
    RAISE EXCEPTION 'Permission denied: Administrator access required';
  END IF;

  FOREACH v_req_table IN ARRAY v_required_tables LOOP
    IF to_regclass('public.' || v_req_table) IS NULL THEN
      v_missing_tables := array_append(v_missing_tables, v_req_table);
    END IF;
  END LOOP;

  v_tables_ok := (coalesce(array_length(v_missing_tables, 1), 0) = 0);
  v_settings_ok := EXISTS (SELECT 1 FROM public.artist_earning_settings WHERE id = 1);

  BEGIN
    SELECT * INTO v_probe FROM public._compute_artist_eligible_metrics(auth.uid());
    v_metrics_ok := TRUE;
  EXCEPTION WHEN OTHERS THEN
    v_metrics_ok := FALSE;
    v_metrics_error := SQLERRM;
  END;

  RETURN jsonb_build_object(
    'healthy', (v_tables_ok AND v_settings_ok AND v_metrics_ok),
    'tables_ok', v_tables_ok,
    'missing_tables', to_jsonb(v_missing_tables),
    'settings_ok', v_settings_ok,
    'metrics_ok', v_metrics_ok,
    'metrics_error', v_metrics_error,
    'checked_at', timezone('utc'::text, now())
  );
END;
$$;

-- ------------------------------------------------------------------------------
-- 12. FUNCTION EXECUTION GRANTS
-- ------------------------------------------------------------------------------
GRANT EXECUTE ON FUNCTION public.is_teso_admin() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.record_song_stream(UUID, TEXT, INTEGER) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.increment_song_play(UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.initiate_artist_gmail_verification() TO authenticated;
GRANT EXECUTE ON FUNCTION public.complete_artist_gmail_verification(TEXT, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_artist_earnings_dashboard() TO authenticated;
GRANT EXECUTE ON FUNCTION public.save_artist_payout_profile(TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.request_artist_withdrawal(NUMERIC, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_get_earnings_overview() TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_update_earning_settings(NUMERIC, INTEGER, NUMERIC, INTEGER, NUMERIC, INTEGER, NUMERIC, INTEGER, NUMERIC) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_review_withdrawal(UUID, TEXT, TEXT, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_toggle_artist_suspension(UUID, BOOLEAN, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_check_monetization_health() TO authenticated;

-- ------------------------------------------------------------------------------
-- 13. PUBLISH OFFICIAL MONETIZATION ANNOUNCEMENT TO public.news (IDEMPOTENT)
-- ------------------------------------------------------------------------------
INSERT INTO public.news (
  id,
  title,
  description,
  full_content,
  category,
  badge,
  status,
  author_email,
  published_at
)
VALUES (
  'announcement-artist-earnings-gmail-verify',
  'OFFICIAL TESO MELODIES ARTIST MONETIZATION PROGRAM',
  'We are introducing a new earning opportunity for our registered artists. Verify your Gmail account to activate your Artist Earnings Dashboard, monitor your music performance and start earning from eligible engagement.',
  E'OFFICIAL TESO MELODIES ARTIST MONETIZATION PROGRAM\n\nWe are introducing a new earning opportunity for our registered artists. Verify your Gmail account to activate your Artist Earnings Dashboard, monitor your music performance and start earning from eligible engagement.\n\nVerify your account to unlock your earnings.\n\nInitial Earning Rates:\n- Every 30 eligible genuine likes = 18 UGX\n- Every 100 eligible genuine followers = 700 UGX\n- Eligible downloads & music streams earn royalties at configured platform rates\n- Minimum withdrawal = 15,000 UGX via MTN Mobile Money or Airtel Money\n\nSign in to your existing Teso Melodies account and open your Artist Dashboard to verify your Gmail address. Unverified artists can continue uploading music and managing their profiles normally while their earnings dashboard remains locked until verification.',
  'Announcement',
  'Monetization',
  'published',
  'tesomelodies@gmail.com',
  timezone('utc'::text, now())
)
ON CONFLICT (id) DO UPDATE SET
  title = EXCLUDED.title,
  description = EXCLUDED.description,
  full_content = EXCLUDED.full_content;

-- Refresh PostgREST schema cache immediately after migration
NOTIFY pgrst, 'reload schema';
