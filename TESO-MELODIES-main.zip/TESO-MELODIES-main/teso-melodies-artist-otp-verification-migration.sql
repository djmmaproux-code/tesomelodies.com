-- ==============================================================================
-- TESO MELODIES — ARTIST EMAIL OTP VERIFICATION MIGRATION
-- File: teso-melodies-artist-otp-verification-migration.sql
-- Target: Existing Supabase Project (https://csguerwyvykvzlnikwbf.supabase.co)
--
-- PURPOSE:
--   Hardens server-side Gmail 6-digit OTP verification confirmation and Artist
--   Earnings Dashboard unlock without creating duplicate tables, storing OTPs
--   in plain text, or replacing Supabase Auth.
--
-- SAFETY & COMPATIBILITY GUARANTEES:
--   * Strictly additive & idempotent (CREATE OR REPLACE FUNCTION only).
--   * Zero DROP TABLE, zero TRUNCATE, zero modification of existing artist
--     profiles, songs, likes, followers, downloads, royalty settings, or
--     withdrawal records.
--   * Supabase Auth remains 100% responsible for generating, emailing,
--     expiring, and validating every unique 6-digit OTP code.
--   * No OTP codes are ever stored in database tables.
--   * An artist CANNOT unlock earnings simply by clicking "Verify Email" —
--     PostgreSQL verifies that Supabase Auth actually confirmed a fresh
--     OTP authentication on auth.users AFTER the OTP request was created.
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 1. RECORD ARTIST OTP VERIFICATION REQUEST (AFTER SUPABASE AUTH DISPATCH)
-- ------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.initiate_artist_gmail_verification()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_email TEXT := '';
  v_nonce TEXT := replace(gen_random_uuid()::text, '-', '');
  v_already_verified BOOLEAN := FALSE;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  SELECT lower(coalesce(u.email, ''))
  INTO v_email
  FROM auth.users u
  WHERE u.id = v_uid;

  IF v_email = '' THEN
    RAISE EXCEPTION 'No registered email found on your account';
  END IF;

  IF NOT (v_email ~* '@(gmail\.com|googlemail\.com)$') THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'is_gmail', FALSE,
      'registered_email', v_email,
      'error', 'The Artist Monetization Program requires a registered Gmail address (@gmail.com). Update your existing account email securely to Gmail first.'
    );
  END IF;

  INSERT INTO public.artist_earnings_accounts (
    user_id,
    registered_email,
    verification_requested_at,
    verification_nonce
  )
  VALUES (v_uid, v_email, timezone('utc'::text, now()), v_nonce)
  ON CONFLICT (user_id) DO UPDATE
    SET registered_email = v_email,
        verification_requested_at = CASE
          WHEN public.artist_earnings_accounts.earnings_verified THEN public.artist_earnings_accounts.verification_requested_at
          ELSE timezone('utc'::text, now())
        END,
        verification_nonce = CASE
          WHEN public.artist_earnings_accounts.earnings_verified THEN NULL
          ELSE v_nonce
        END,
        updated_at = timezone('utc'::text, now())
  RETURNING earnings_verified INTO v_already_verified;

  RETURN jsonb_build_object(
    'success', TRUE,
    'is_gmail', TRUE,
    'registered_email', v_email,
    'nonce', CASE WHEN coalesce(v_already_verified, FALSE) THEN NULL ELSE v_nonce END,
    'already_verified', coalesce(v_already_verified, FALSE)
  );
END;
$$;

-- ------------------------------------------------------------------------------
-- 2. COMPLETE OTP VERIFICATION & UNLOCK ARTIST EARNINGS DASHBOARD
--    Enforces all security checks strictly on the server:
--      1) Caller is authenticated (auth.uid() IS NOT NULL).
--      2) Registered auth.users.email is a Gmail address.
--      3) auth.users.email_confirmed_at IS NOT NULL (verified by Supabase Auth).
--      4) An active OTP request was initiated within the last 60 minutes.
--      5) Supabase Auth recorded a fresh OTP verification timestamp
--         (last_sign_in_at or email_confirmed_at >= verification_requested_at).
--      6) Nonce matches if supplied by the active verification session.
--    Only after ALL checks pass does PostgreSQL mark earnings_verified = TRUE
--    and sync eligible UGX royalties (preserving existing rates & records).
-- ------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.complete_artist_gmail_verification(
  p_method TEXT DEFAULT 'gmail_otp',
  p_nonce TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_now TIMESTAMPTZ := timezone('utc'::text, now());
  v_email TEXT := '';
  v_confirmed_at TIMESTAMPTZ;
  v_last_sign_in TIMESTAMPTZ;
  v_account public.artist_earnings_accounts%ROWTYPE;
  v_clean_method TEXT := CASE
    WHEN lower(coalesce(p_method, '')) IN ('gmail_otp', 'gmail_link') THEN lower(p_method)
    ELSE 'gmail_otp'
  END;
  v_fresh_auth_verified BOOLEAN := FALSE;
  v_summary JSONB;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  SELECT lower(coalesce(u.email, '')), u.email_confirmed_at, u.last_sign_in_at
  INTO v_email, v_confirmed_at, v_last_sign_in
  FROM auth.users u
  WHERE u.id = v_uid;

  IF NOT (v_email ~* '@(gmail\.com|googlemail\.com)$') THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Only a verified Gmail address (@gmail.com) can activate Artist Earnings.'
    );
  END IF;

  IF v_confirmed_at IS NULL THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Your Gmail address is not confirmed yet. Enter the 6-digit code sent to your Gmail inbox.'
    );
  END IF;

  SELECT *
  INTO v_account
  FROM public.artist_earnings_accounts
  WHERE user_id = v_uid;

  IF v_account.user_id IS NOT NULL AND v_account.earnings_verified THEN
    v_summary := public._sync_artist_earnings_ledger(v_uid);
    RETURN jsonb_build_object(
      'success', TRUE,
      'already_verified', TRUE,
      'verified_gmail', coalesce(nullif(v_account.verified_gmail, ''), v_email),
      'summary', v_summary
    );
  END IF;

  IF v_account.user_id IS NULL OR v_account.verification_requested_at IS NULL THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Click "Verify Email" first to receive a fresh 6-digit verification code in your Gmail inbox.'
    );
  END IF;

  -- Reject stale verification requests older than 60 minutes
  IF (v_now - v_account.verification_requested_at) > INTERVAL '60 minutes' THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Your verification code has expired. Click "Resend Verification Email" to receive a fresh 6-digit code.'
    );
  END IF;

  -- Strictly prove Supabase Auth completed a real OTP verification AFTER the request was created.
  -- Blocks anyone who simply clicks "Verify Email" or calls this RPC without verifying a 6-digit OTP.
  v_fresh_auth_verified := (
    (v_last_sign_in IS NOT NULL AND v_last_sign_in >= v_account.verification_requested_at)
    OR (v_confirmed_at IS NOT NULL AND v_confirmed_at >= v_account.verification_requested_at)
  );

  IF NOT v_fresh_auth_verified THEN
    RETURN jsonb_build_object(
      'success', FALSE,
      'error', 'Valid 6-digit Gmail OTP verification is required before unlocking Artist Earnings. Enter the latest 6-digit code from your Gmail.'
    );
  END IF;

  IF p_nonce IS NOT NULL AND length(trim(p_nonce)) > 0 AND v_account.verification_nonce IS NOT NULL THEN
    IF trim(p_nonce) <> v_account.verification_nonce THEN
      RETURN jsonb_build_object(
        'success', FALSE,
        'error', 'This verification request has been superseded by a newer code. Please use the latest 6-digit code sent to your Gmail.'
      );
    END IF;
  END IF;

  UPDATE public.artist_earnings_accounts
  SET registered_email = v_email,
      verified_gmail = v_email,
      earnings_verified = TRUE,
      earnings_verified_at = v_now,
      verification_method = v_clean_method,
      verification_nonce = NULL,
      updated_at = v_now
  WHERE user_id = v_uid;

  v_summary := public._sync_artist_earnings_ledger(v_uid);

  RETURN jsonb_build_object(
    'success', TRUE,
    'verified_gmail', v_email,
    'verification_method', v_clean_method,
    'summary', v_summary
  );
END;
$$;

-- ------------------------------------------------------------------------------
-- 3. ENSURE STRICT PERMISSIONS & RLS REMAIN ENFORCED (IDEMPOTENT)
-- ------------------------------------------------------------------------------
ALTER TABLE public.artist_earnings_accounts ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.artist_earnings_accounts FROM anon;
REVOKE INSERT, UPDATE, DELETE ON TABLE public.artist_earnings_accounts FROM authenticated;

REVOKE ALL ON FUNCTION public.initiate_artist_gmail_verification() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.complete_artist_gmail_verification(TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.initiate_artist_gmail_verification() TO authenticated;
GRANT EXECUTE ON FUNCTION public.complete_artist_gmail_verification(TEXT, TEXT) TO authenticated;

-- Refresh PostgREST schema cache immediately
NOTIFY pgrst, 'reload schema';
