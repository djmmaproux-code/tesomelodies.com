-- ==============================================================================
-- TESO MELODIES — ADDITIVE SQL MIGRATION (ADMIN NEWS PANEL + GENUINE LIKES & FOLLOWS)
-- Target: Existing Supabase Project (https://csguerwyvykvzlnikwbf.supabase.co)
-- Admin Account: tesomelodies@gmail.com
--
-- SAFETY GUARANTEES:
--   * Zero DROP TABLE, TRUNCATE, DELETE, or changes to song_comments / videos.
--   * Does NOT duplicate existing tables (uses IF NOT EXISTS on existing names).
--   * Preserves all existing songs, videos, profiles, comments, likes, & follows.
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 1. CREATE public.news TABLE (Admin News Panel — tesomelodies@gmail.com only)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.news (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  full_content TEXT DEFAULT '',
  category TEXT DEFAULT 'Portal News',
  badge TEXT DEFAULT 'News',
  image_url TEXT,
  status TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('draft', 'published', 'archived')),
  author_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  author_email TEXT,
  published_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()),
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_news_status_published_at ON public.news (status, published_at DESC);

ALTER TABLE public.news ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view published news" ON public.news;
CREATE POLICY "Public can view published news" ON public.news
  FOR SELECT USING (
    status = 'published'
    OR lower(coalesce(auth.jwt() ->> 'email', '')) = 'tesomelodies@gmail.com'
  );

DROP POLICY IF EXISTS "Admin can insert news" ON public.news;
CREATE POLICY "Admin can insert news" ON public.news
  FOR INSERT TO authenticated
  WITH CHECK (lower(coalesce(auth.jwt() ->> 'email', '')) = 'tesomelodies@gmail.com');

DROP POLICY IF EXISTS "Admin can update news" ON public.news;
CREATE POLICY "Admin can update news" ON public.news
  FOR UPDATE TO authenticated
  USING (lower(coalesce(auth.jwt() ->> 'email', '')) = 'tesomelodies@gmail.com')
  WITH CHECK (lower(coalesce(auth.jwt() ->> 'email', '')) = 'tesomelodies@gmail.com');

DROP POLICY IF EXISTS "Admin can delete news" ON public.news;
CREATE POLICY "Admin can delete news" ON public.news
  FOR DELETE TO authenticated
  USING (lower(coalesce(auth.jwt() ->> 'email', '')) = 'tesomelodies@gmail.com');

-- ------------------------------------------------------------------------------
-- 2. ENSURE EXISTING song_likes & artist_follows COLUMNS, INDEXES & RLS POLICIES
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.song_likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  song_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  user_email TEXT,
  user_name TEXT,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  CONSTRAINT unique_song_user_like UNIQUE (song_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_song_likes_song_id ON public.song_likes (song_id);
CREATE INDEX IF NOT EXISTS idx_song_likes_user_id ON public.song_likes (user_id);

ALTER TABLE public.song_likes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view song likes" ON public.song_likes;
CREATE POLICY "Public can view song likes" ON public.song_likes
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can manage song likes" ON public.song_likes;
CREATE POLICY "Users can manage song likes" ON public.song_likes
  FOR ALL USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.artist_follows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id TEXT NOT NULL,
  artist_name TEXT,
  user_id TEXT NOT NULL,
  user_email TEXT,
  user_name TEXT,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  CONSTRAINT unique_artist_user_follow UNIQUE (artist_id, user_id)
);

ALTER TABLE public.artist_follows ADD COLUMN IF NOT EXISTS artist_name TEXT;
ALTER TABLE public.artist_follows ADD COLUMN IF NOT EXISTS user_email TEXT;
ALTER TABLE public.artist_follows ADD COLUMN IF NOT EXISTS user_name TEXT;

-- Safely remove any duplicate (artist_id, user_id) rows before ensuring unique index
DELETE FROM public.artist_follows a
USING public.artist_follows b
WHERE a.ctid > b.ctid
  AND lower(trim(a.artist_id)) = lower(trim(b.artist_id))
  AND a.user_id = b.user_id;

CREATE UNIQUE INDEX IF NOT EXISTS idx_artist_follows_unique_pair
  ON public.artist_follows (artist_id, user_id);
CREATE INDEX IF NOT EXISTS idx_artist_follows_artist_id ON public.artist_follows (artist_id);
CREATE INDEX IF NOT EXISTS idx_artist_follows_user_id ON public.artist_follows (user_id);

ALTER TABLE public.artist_follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.artist_follows REPLICA IDENTITY FULL;

DROP POLICY IF EXISTS "Public can view artist followers" ON public.artist_follows;
CREATE POLICY "Public can view artist followers" ON public.artist_follows
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can manage artist follows" ON public.artist_follows;
CREATE POLICY "Users can manage artist follows" ON public.artist_follows
  FOR ALL USING (true) WITH CHECK (true);

-- ------------------------------------------------------------------------------
-- 3. ATOMIC LIKE / UNLIKE & FOLLOW / UNFOLLOW RPCs (PREVENT DUPLICATES)
-- ------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.toggle_song_like(
  p_song_id UUID,
  p_actor_id TEXT,
  p_user_email TEXT DEFAULT NULL,
  p_user_name TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_actor TEXT := COALESCE(NULLIF(TRIM(p_actor_id), ''), auth.uid()::text);
  v_song_text TEXT := p_song_id::text;
  v_deleted_count INTEGER := 0;
  v_inserted_count INTEGER := 0;
  v_next_likes INTEGER := 0;
  v_is_liked BOOLEAN := FALSE;
BEGIN
  IF v_actor IS NULL OR v_actor = '' THEN
    RAISE EXCEPTION 'Actor identifier required';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('like:' || v_song_text || ':' || v_actor));

  DELETE FROM public.song_likes
  WHERE song_id = v_song_text AND user_id = v_actor;
  GET DIAGNOSTICS v_deleted_count = ROW_COUNT;

  IF v_deleted_count > 0 THEN
    IF auth.uid() IS NOT NULL THEN
      DELETE FROM public.user_favorites
      WHERE song_id = p_song_id AND user_id = auth.uid();
    END IF;

    UPDATE public.songs
    SET likes = GREATEST(0, COALESCE(likes, 0) - 1),
        updated_at = timezone('utc'::text, now())
    WHERE id = p_song_id
    RETURNING likes INTO v_next_likes;

    v_is_liked := FALSE;
  ELSE
    INSERT INTO public.song_likes (song_id, user_id, user_email, user_name)
    SELECT v_song_text, v_actor, p_user_email, p_user_name
    WHERE NOT EXISTS (
      SELECT 1 FROM public.song_likes WHERE song_id = v_song_text AND user_id = v_actor
    );
    GET DIAGNOSTICS v_inserted_count = ROW_COUNT;

    IF auth.uid() IS NOT NULL THEN
      INSERT INTO public.user_favorites (user_id, song_id)
      VALUES (auth.uid(), p_song_id)
      ON CONFLICT (user_id, song_id) DO NOTHING;
    END IF;

    IF v_inserted_count > 0 THEN
      UPDATE public.songs
      SET likes = COALESCE(likes, 0) + 1,
          updated_at = timezone('utc'::text, now())
      WHERE id = p_song_id
      RETURNING likes INTO v_next_likes;
    ELSE
      SELECT COALESCE(likes, 0) INTO v_next_likes FROM public.songs WHERE id = p_song_id;
    END IF;

    v_is_liked := TRUE;
  END IF;

  RETURN jsonb_build_object(
    'is_liked', v_is_liked,
    'likes', COALESCE(v_next_likes, 0)
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.toggle_artist_follow(
  p_artist_id TEXT,
  p_artist_name TEXT,
  p_actor_id TEXT,
  p_user_email TEXT DEFAULT NULL,
  p_user_name TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_actor TEXT := COALESCE(NULLIF(TRIM(p_actor_id), ''), auth.uid()::text);
  v_canonical TEXT := COALESCE(
    NULLIF(TRIM(BOTH '-' FROM REGEXP_REPLACE(LOWER(TRIM(COALESCE(NULLIF(p_artist_name, ''), p_artist_id))), '[^a-z0-9]+', '-', 'g')), ''),
    'artist'
  );
  v_raw_id TEXT := LOWER(TRIM(COALESCE(p_artist_id, v_canonical)));
  v_raw_name TEXT := LOWER(TRIM(COALESCE(p_artist_name, p_artist_id)));
  v_deleted_count INTEGER := 0;
  v_followers INTEGER := 0;
  v_is_followed BOOLEAN := FALSE;
BEGIN
  IF v_actor IS NULL OR v_actor = '' THEN
    RAISE EXCEPTION 'Actor identifier required';
  END IF;

  IF v_canonical = '' THEN
    RAISE EXCEPTION 'Artist identifier required';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('follow:' || v_canonical || ':' || v_actor));

  DELETE FROM public.artist_follows
  WHERE user_id = v_actor
    AND (
      lower(trim(artist_id)) IN (v_canonical, v_raw_id, v_raw_name, replace(v_raw_name, '-', ' '))
      OR lower(trim(coalesce(artist_name, ''))) IN (v_canonical, v_raw_id, v_raw_name)
    );
  GET DIAGNOSTICS v_deleted_count = ROW_COUNT;

  IF v_deleted_count > 0 THEN
    v_is_followed := FALSE;
  ELSE
    INSERT INTO public.artist_follows (artist_id, artist_name, user_id, user_email, user_name)
    SELECT v_canonical, COALESCE(NULLIF(TRIM(p_artist_name), ''), v_canonical), v_actor, p_user_email, p_user_name
    WHERE NOT EXISTS (
      SELECT 1 FROM public.artist_follows
      WHERE user_id = v_actor
        AND (
          lower(trim(artist_id)) IN (v_canonical, v_raw_id, v_raw_name, replace(v_raw_name, '-', ' '))
          OR lower(trim(coalesce(artist_name, ''))) IN (v_canonical, v_raw_id, v_raw_name)
        )
    );
    v_is_followed := TRUE;
  END IF;

  SELECT COUNT(DISTINCT user_id)::INTEGER
  INTO v_followers
  FROM public.artist_follows
  WHERE lower(trim(artist_id)) IN (v_canonical, v_raw_id, v_raw_name, replace(v_raw_name, '-', ' '))
     OR lower(trim(coalesce(artist_name, ''))) IN (v_canonical, v_raw_id, v_raw_name);

  RETURN jsonb_build_object(
    'is_followed', v_is_followed,
    'followers', COALESCE(v_followers, 0)
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.toggle_song_like(UUID, TEXT, TEXT, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.toggle_artist_follow(TEXT, TEXT, TEXT, TEXT, TEXT) TO anon, authenticated;

-- ------------------------------------------------------------------------------
-- 4. REALTIME PUBLICATION FOR public.news & public.artist_follows
-- ------------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'news'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.news;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'artist_follows'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.artist_follows;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'song_likes'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.song_likes;
  END IF;
EXCEPTION
  WHEN undefined_object THEN NULL;
  WHEN undefined_table THEN NULL;
END $$;
