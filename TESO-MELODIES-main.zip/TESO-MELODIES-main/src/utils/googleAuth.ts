import { supabase } from '../supabaseClient';

export interface GoogleAuthOptions {
  onSuccess?: (user: { email: string; name?: string; avatar?: string }) => void;
  onError?: (errorMessage: string) => void;
}

/**
 * Initiates real Google OAuth authentication using Supabase.
 * Automatically detects if the application is running inside an iframe (like AI Studio preview)
 * where Google Accounts rejects iframe embeds with X-Frame-Options: DENY.
 * In iframe mode, it opens a secure popup window directly to Google's real login screen,
 * listens for completion, and synchronizes the visitor's real Gmail session.
 */
export const initiateRealGoogleLogin = async (
  onLoadingChange: (loading: boolean) => void,
  callbacks?: GoogleAuthOptions
): Promise<void> => {
  onLoadingChange(true);

  try {
    const isIframe = typeof window !== 'undefined' && window.self !== window.top;
    const redirectUrl = `${window.location.origin}/`;

    let popup: Window | null = null;
    let pollTimer: ReturnType<typeof setInterval> | null = null;

    if (isIframe) {
      // Open popup synchronously during user gesture to avoid popup blocker
      const width = 520;
      const height = 650;
      const left = window.screenX + Math.max(0, (window.outerWidth - width) / 2);
      const top = window.screenY + Math.max(0, (window.outerHeight - height) / 2);

      popup = window.open(
        'about:blank',
        'google_oauth_popup',
        `width=${width},height=${height},left=${left},top=${top},menubar=no,toolbar=no,status=no,resizable=yes`
      );
    }

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: redirectUrl,
        skipBrowserRedirect: isIframe,
        queryParams: {
          access_type: 'offline',
          prompt: 'select_account', // Forces real Google account selector
        },
      },
    });

    if (error) {
      if (popup && !popup.closed) popup.close();
      onLoadingChange(false);
      callbacks?.onError?.(error.message);
      return;
    }

    if (!data?.url) {
      if (popup && !popup.closed) popup.close();
      onLoadingChange(false);
      callbacks?.onError?.('Could not initialize Google authentication URL.');
      return;
    }

    if (isIframe && popup && !popup.closed) {
      // Direct the popup to Google Accounts
      popup.location.href = data.url;
      try {
        popup.focus();
      } catch {
        // ignore
      }

      // Poll for popup completion or user closure
      pollTimer = setInterval(async () => {
        try {
          if (popup?.closed) {
            if (pollTimer) clearInterval(pollTimer);
            onLoadingChange(false);

            // Check if real session was established in Supabase
            const {
              data: { session },
            } = await supabase.auth.getSession();
            if (session?.user) {
              const u = session.user;
              callbacks?.onSuccess?.({
                email: u.email || '',
                name: u.user_metadata?.full_name || u.user_metadata?.name || u.email || 'User',
                avatar: u.user_metadata?.avatar_url || u.user_metadata?.picture,
              });
            }
          }
        } catch {
          // ignore cross-origin polling errors
        }
      }, 700);
    } else {
      // Standalone top-level window: direct browser redirect to Google
      window.location.href = data.url;
    }
  } catch (err: any) {
    onLoadingChange(false);
    callbacks?.onError?.(err?.message || 'Failed to start Google sign in. Please try again.');
  }
};
