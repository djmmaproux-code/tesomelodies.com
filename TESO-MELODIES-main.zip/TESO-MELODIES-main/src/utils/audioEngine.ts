/**
 * Web Audio Synthesizer Engine for authentic, reliable music playback
 * Generates rhythmic afro-melodic chords and grooves matching track vibes.
 */

class MusicAudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private timer: number | null = null;
  private currentFrequency = 440;
  private volume = 0.8;
  private masterGain: GainNode | null = null;
  private onTimeUpdateCallback: ((currentTime: number) => void) | null = null;
  private currentTime = 0;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public unlock() {
    try {
      this.initContext();
    } catch {
      // Ignore Web Audio init errors on restricted environments
    }
  }

  public setVolume(val: number) {
    this.volume = Math.max(0, Math.min(1, val));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
    }
  }

  public playTone(freq: number, startTimeOffset = 0, onTimeUpdate?: (t: number) => void) {
    this.initContext();
    if (!this.ctx || !this.masterGain) return;

    this.stop();
    this.currentFrequency = freq || 440;
    this.isPlaying = true;
    this.currentTime = Number.isFinite(startTimeOffset) && startTimeOffset >= 0 ? startTimeOffset : 0;
    this.onTimeUpdateCallback = onTimeUpdate || null;

    let beat = 0;
    // Pentatonic scale degrees for authentic Afrobeat / melodic grooves
    const scaleMultipliers = [1, 1.125, 1.25, 1.5, 1.667, 2, 1.5, 1.25];

    this.timer = window.setInterval(() => {
      if (!this.ctx || !this.isPlaying || !this.masterGain) return;
      this.currentTime += 0.25;
      if (this.onTimeUpdateCallback) {
        this.onTimeUpdateCallback(this.currentTime);
      }

      // Trigger pleasant melodic pluck/pad
      try {
        const osc = this.ctx.createOscillator();
        const noteGain = this.ctx.createGain();

        // Melodic notes progression
        const mult = scaleMultipliers[beat % scaleMultipliers.length];
        osc.type = beat % 2 === 0 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(this.currentFrequency * mult, this.ctx.currentTime);

        const now = this.ctx.currentTime;
        noteGain.gain.setValueAtTime(0.001, now);
        noteGain.gain.exponentialRampToValueAtTime(0.2, now + 0.04);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.4);

        osc.connect(noteGain);
        noteGain.connect(this.masterGain);

        osc.start(now);
        osc.stop(now + 0.45);

        // Warm sub-bass note on quarter notes
        if (beat % 4 === 0) {
          const bass = this.ctx.createOscillator();
          const bassGain = this.ctx.createGain();
          bass.type = 'sine';
          bass.frequency.setValueAtTime(this.currentFrequency / 2, now);
          bassGain.gain.setValueAtTime(0.25, now);
          bassGain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
          bass.connect(bassGain);
          bassGain.connect(this.masterGain);
          bass.start(now);
          bass.stop(now + 0.5);
        }

        beat++;
      } catch {
        // Safe fallback
      }
    }, 250);
  }

  public pause() {
    this.isPlaying = false;
    if (this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  public resume() {
    if (!this.isPlaying && this.currentFrequency) {
      this.playTone(this.currentFrequency, this.currentTime, this.onTimeUpdateCallback || undefined);
    }
  }

  public stop() {
    this.isPlaying = false;
    if (this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
    this.currentTime = 0;
  }

  public seek(sec: number) {
    this.currentTime = Number.isFinite(sec) && sec >= 0 ? sec : 0;
    if (this.onTimeUpdateCallback) {
      this.onTimeUpdateCallback(this.currentTime);
    }
  }
}

export const audioEngine = new MusicAudioEngine();
