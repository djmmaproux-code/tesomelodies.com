import { Artist, Song } from '../types/music';

const SITE_ORIGIN = 'https://tesomelodies.com';
const DEFAULT_IMAGE = `${SITE_ORIGIN}/teso_melodies_download_cover.jpg`;

export function canonicalArtistSlug(value?: string | null): string {
  return (
    String(value || '')
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'artist'
  );
}

export function canonicalGenreSlug(value?: string | null): string {
  const raw = String(value || '').toLowerCase().trim();
  if (raw === 'r&b' || raw === 'rnb' || raw === 'r-b') return 'r-b';
  return raw.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'music';
}

export function getSongSeoPath(songId: string): string {
  return `/song/${encodeURIComponent(songId)}`;
}

export function getArtistSeoPath(artistNameOrSlug: string): string {
  return `/artist/${encodeURIComponent(canonicalArtistSlug(artistNameOrSlug))}`;
}

export function getGenreSeoPath(genreNameOrSlug: string): string {
  return `/genre/${encodeURIComponent(canonicalGenreSlug(genreNameOrSlug))}`;
}

export interface RegionalGenreMatch {
  slug: string;
  label: string;
  matchesSongGenre: (songGenre?: string | null) => boolean;
}

export const REGIONAL_GENRE_MATCHERS: Record<string, RegionalGenreMatch> = {
  'teso-music': {
    slug: 'teso-music',
    label: 'Teso Music',
    matchesSongGenre: () => true,
  },
  'teso-gospel-music': {
    slug: 'teso-gospel-music',
    label: 'Teso Gospel Music',
    matchesSongGenre: (g) => {
      const lower = String(g || '').toLowerCase().trim();
      return lower === 'teso worship' || lower === 'gospel';
    },
  },
  'ugandan-music': {
    slug: 'ugandan-music',
    label: 'Ugandan Music',
    matchesSongGenre: () => true,
  },
  'african-music': {
    slug: 'african-music',
    label: 'African Music',
    matchesSongGenre: () => true,
  },
};

export function resolveGenreLabelFromSlug(slug: string): string {
  const clean = canonicalGenreSlug(slug);
  if (REGIONAL_GENRE_MATCHERS[clean]) {
    return REGIONAL_GENRE_MATCHERS[clean].label;
  }
  const knownMap: Record<string, string> = {
    'teso-worship': 'teso worship',
    'teso-dancehall': 'Teso Dancehall',
    'r-b': 'R&B',
    afrobeat: 'Afrobeat',
    gospel: 'Gospel',
    akoogo: 'Akoogo',
    reggae: 'Reggae',
    rock: 'Rock',
    country: 'Country',
    amapiano: 'Amapiano',
    jazz: 'Jazz',
  };
  if (knownMap[clean]) return knownMap[clean];
  return clean
    .split('-')
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1) : w))
    .join(' ');
}

export function songMatchesSelectedGenre(songGenre: string | undefined, selectedGenre: string | null): boolean {
  if (!selectedGenre) return true;
  const slug = canonicalGenreSlug(selectedGenre);
  if (REGIONAL_GENRE_MATCHERS[slug]) {
    return REGIONAL_GENRE_MATCHERS[slug].matchesSongGenre(songGenre);
  }
  return canonicalGenreSlug(songGenre) === slug;
}

function upsertMetaTag(attr: 'name' | 'property', key: string, content: string) {
  if (typeof document === 'undefined') return;
  let tag = document.querySelector(`meta[${attr}="${key}"]`) as HTMLMetaElement | null;
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute(attr, key);
    document.head.appendChild(tag);
  }
  tag.setAttribute('content', content);
}

function upsertCanonicalLink(href: string) {
  if (typeof document === 'undefined') return;
  let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
  if (!link) {
    link = document.createElement('link');
    link.setAttribute('rel', 'canonical');
    document.head.appendChild(link);
  }
  link.setAttribute('href', href);
}

function upsertDynamicJsonLd(schemaGraph: Record<string, any>[] | null) {
  if (typeof document === 'undefined') return;
  const existing = document.getElementById('dynamic-seo-jsonld');
  if (!schemaGraph || schemaGraph.length === 0) {
    if (existing) existing.remove();
    return;
  }
  let script = existing as HTMLScriptElement | null;
  if (!script) {
    script = document.createElement('script');
    script.id = 'dynamic-seo-jsonld';
    script.type = 'application/ld+json';
    document.head.appendChild(script);
  }
  script.textContent = JSON.stringify({
    '@context': 'https://schema.org',
    '@graph': schemaGraph,
  });
}

function getCanonicalOrigin(): string {
  if (typeof window === 'undefined') return SITE_ORIGIN;
  const host = window.location.hostname.toLowerCase();
  if (host === 'tesomelodies.com' || host === 'www.tesomelodies.com') return SITE_ORIGIN;
  return window.location.origin;
}

export function updateDocumentSeo(params: {
  title: string;
  description: string;
  path: string;
  image?: string;
  ogType?: 'website' | 'music.song' | 'profile';
  schemaGraph?: Record<string, any>[] | null;
}) {
  if (typeof document === 'undefined') return;
  const origin = getCanonicalOrigin();
  const cleanPath = params.path.startsWith('/') ? params.path : `/${params.path}`;
  const canonicalUrl = `${origin}${cleanPath}`;
  const imageUrl =
    params.image && /^https?:\/\//i.test(params.image) ? params.image : DEFAULT_IMAGE;

  document.title = params.title;
  upsertCanonicalLink(canonicalUrl);
  upsertMetaTag('name', 'description', params.description);
  upsertMetaTag('property', 'og:title', params.title);
  upsertMetaTag('property', 'og:description', params.description);
  upsertMetaTag('property', 'og:url', canonicalUrl);
  upsertMetaTag('property', 'og:type', params.ogType || 'website');
  upsertMetaTag('property', 'og:image', imageUrl);
  upsertMetaTag('name', 'twitter:title', params.title);
  upsertMetaTag('name', 'twitter:description', params.description);
  upsertMetaTag('name', 'twitter:image', imageUrl);
  upsertDynamicJsonLd(params.schemaGraph || null);
}

export function buildClientSongSeo(song: Song) {
  const origin = getCanonicalOrigin();
  const songPath = getSongSeoPath(song.id);
  const artistPath = getArtistSeoPath(song.artist);
  const genreName = song.genre || 'Teso Music';
  const title = `${song.title} by ${song.artist} – MP3 Download & Listen Online | TESO MELODIES`;
  const description = `Listen online and download "${song.title}" by ${song.artist} (${genreName}${song.duration ? `, ${song.duration}` : ''}). Free Ugandan & Teso music MP3 download on TESO MELODIES.`;

  return {
    title,
    description,
    path: songPath,
    image: song.coverUrl,
    ogType: 'music.song' as const,
    schemaGraph: [
      {
        '@type': 'MusicRecording',
        name: song.title,
        url: `${origin}${songPath}`,
        genre: genreName,
        image: song.coverUrl,
        description,
        isAccessibleForFree: true,
        byArtist: {
          '@type': 'MusicGroup',
          name: song.artist,
          url: `${origin}${artistPath}`,
        },
      },
    ],
  };
}

export function buildClientArtistSeo(artist: Artist, artistSongs: Song[]) {
  const origin = getCanonicalOrigin();
  const artistPath = getArtistSeoPath(artist.name);
  const songCount = Math.max(artistSongs.length, artist.totalSongs || 0);
  const title = `${artist.name} Songs – Free MP3 Download & Artist Profile | TESO MELODIES`;
  const description =
    songCount > 0
      ? `Listen online and download ${songCount} ${songCount === 1 ? 'song' : 'songs'} by ${artist.name} in ${artist.genre || 'Teso Music'}. Free MP3 downloads on TESO MELODIES.`
      : `Explore songs, followers, and music releases by ${artist.name} on TESO MELODIES.`;

  return {
    title,
    description,
    path: artistPath,
    image: artist.avatar,
    ogType: 'profile' as const,
    schemaGraph: [
      {
        '@type': 'MusicGroup',
        name: artist.name,
        url: `${origin}${artistPath}`,
        image: artist.avatar,
        genre: artist.genre || 'Teso Music',
        description,
        ...(artist.followers > 0
          ? {
              interactionStatistic: {
                '@type': 'InteractionCounter',
                interactionType: 'https://schema.org/FollowAction',
                userInteractionCount: artist.followers,
              },
            }
          : {}),
        ...(artistSongs.length > 0
          ? {
              track: artistSongs.slice(0, 20).map((s) => ({
                '@type': 'MusicRecording',
                name: s.title,
                url: `${origin}${getSongSeoPath(s.id)}`,
                genre: s.genre,
              })),
            }
          : {}),
      },
    ],
  };
}

export function buildClientGenreSeo(genreName: string, matchingSongCount: number) {
  const origin = getCanonicalOrigin();
  const genrePath = getGenreSeoPath(genreName);
  const display = resolveGenreLabelFromSlug(genreName);
  const title = `${display} Songs – Free MP3 Download & Listen Online | TESO MELODIES`;
  const description =
    matchingSongCount > 0
      ? `Stream and download ${matchingSongCount} ${display} songs free online. Discover Teso, Ugandan, and East African music MP3 downloads on TESO MELODIES.`
      : `Stream and download ${display} songs free online on TESO MELODIES.`;

  return {
    title,
    description,
    path: genrePath,
    ogType: 'website' as const,
    schemaGraph: [
      {
        '@type': 'CollectionPage',
        name: `${display} Songs & MP3 Downloads`,
        url: `${origin}${genrePath}`,
        description,
      },
    ],
  };
}
