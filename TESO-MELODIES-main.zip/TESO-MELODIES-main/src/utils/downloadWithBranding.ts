import { ID3Writer } from 'browser-id3-writer';

let cachedCoverBuffer: ArrayBuffer | null = null;
const blobCache = new Map<string, Blob>();

/**
 * Loads and caches the official Teso Melodies artwork image buffer
 * (Official artwork bearing "This Song is Downloaded from TesoMelodies.com")
 */
export async function getOfficialTesoCoverBuffer(): Promise<ArrayBuffer> {
  if (cachedCoverBuffer && cachedCoverBuffer.byteLength > 0) {
    return cachedCoverBuffer;
  }

  try {
    const res = await fetch('/teso_melodies_download_cover.jpg');
    if (res.ok) {
      cachedCoverBuffer = await res.arrayBuffer();
      return cachedCoverBuffer;
    }
  } catch (err) {
    console.warn('Could not load /teso_melodies_download_cover.jpg, trying fallback logo:', err);
  }

  try {
    const fallbackRes = await fetch('/teso_melodies_logo.png');
    if (fallbackRes.ok) {
      cachedCoverBuffer = await fallbackRes.arrayBuffer();
      return cachedCoverBuffer;
    }
  } catch (err) {
    console.warn('Could not load fallback logo:', err);
  }

  throw new Error('Unable to load official Teso Melodies cover image.');
}

const R2_PUBLIC_BASE = 'https://pub-ed44af9b41f345169fbf124e602171bd.r2.dev';
const MAX_ID3_MEMORY_BYTES = 35 * 1024 * 1024; // 35MB safety cap for browser ID3 ArrayBuffer rewriting
const MAX_BLOB_FETCH_BYTES = 80 * 1024 * 1024; // 80MB safety cap for in-memory Blob download

export function normalizeR2Url(url: string): string {
  const trimmed = (url || '').trim();
  return trimmed.replace(/^https?:\/\/r2\.dev(?=\/|$)/i, R2_PUBLIC_BASE);
}

function isAudioContentType(res: Response): boolean {
  if (!res.ok) return false;
  const ct = (res.headers.get('content-type') || '').toLowerCase();
  if (
    ct.includes('text/html') ||
    ct.includes('application/json') ||
    ct.includes('text/plain') ||
    ct.includes('application/xml')
  ) {
    return false;
  }
  return true;
}

function getContentLength(res: Response): number | null {
  const lenHeader = res.headers.get('content-length');
  if (!lenHeader) return null;
  const bytes = Number(lenHeader);
  return Number.isFinite(bytes) && bytes >= 0 ? bytes : null;
}

function isSupabasePublicStorageUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return (
      parsed.hostname.toLowerCase().endsWith('.supabase.co') &&
      parsed.pathname.includes('/storage/v1/object/public/')
    );
  } catch {
    return false;
  }
}

function isR2Url(url: string): boolean {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    return host === 'r2.dev' || host.endsWith('.r2.dev');
  } catch {
    return false;
  }
}

export type StorageSourceType = 'r2' | 'supabase' | 'other';

export interface DownloadSuccessResult {
  mode: 'branded' | 'direct';
  storageSource: StorageSourceType;
  filename: string;
  bytes?: number;
  fromCache?: boolean;
}

export function detectStorageSource(url: string): StorageSourceType {
  const normalized = normalizeR2Url(url);
  if (isR2Url(normalized)) return 'r2';
  if (isSupabasePublicStorageUrl(normalized)) return 'supabase';
  return 'other';
}

function isIOSDevice(): boolean {
  if (typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent || '';
  const platform = navigator.platform || '';
  return (
    /iP(ad|hone|od)/i.test(ua) ||
    (platform === 'MacIntel' && typeof navigator.maxTouchPoints === 'number' && navigator.maxTouchPoints > 1)
  );
}

async function hasExpressAudioProxy(): Promise<boolean> {
  try {
    const headRes = await fetch('/api/proxy-audio', { method: 'HEAD', cache: 'no-store' });
    return headRes.ok && headRes.headers.get('x-audio-proxy') === '1';
  } catch {
    return false;
  }
}

/**
 * Triggers a native browser file download for URLs that serve `Content-Disposition: attachment`
 * without navigating away from tesomelodies.com on Android, iOS/iPadOS, tablets, and desktop.
 */
function triggerAttachmentUrl(attachmentUrl: string, filename: string): void {
  if (isIOSDevice()) {
    // On iOS Safari / iPadOS, a hidden cross-origin iframe can be ignored, whereas clicking
    // an anchor pointing to a `Content-Disposition: attachment` response opens Safari's native
    // download prompt while staying on the current page.
    const anchor = document.createElement('a');
    anchor.href = attachmentUrl;
    anchor.download = filename;
    anchor.rel = 'noopener noreferrer';
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    return;
  }

  const iframe = document.createElement('iframe');
  iframe.style.display = 'none';
  iframe.setAttribute('aria-hidden', 'true');
  iframe.src = attachmentUrl;
  document.body.appendChild(iframe);
  setTimeout(() => {
    try {
      if (iframe.parentNode) {
        iframe.parentNode.removeChild(iframe);
      }
    } catch {
      // Ignore cleanup errors
    }
  }, 60000);
}

/**
 * Resolves a verified same-page attachment download URL (with Content-Disposition: attachment)
 * for large files (>80MB) or CORS-blocked hosts without ever leaving tesomelodies.com.
 */
async function triggerAttachmentDownload(normalizedUrl: string, filename: string): Promise<boolean> {
  // 1. Prefer Netlify Function for .r2.dev (and Supabase) presigned Content-Disposition: attachment URLs
  if (isR2Url(normalizedUrl) || isSupabasePublicStorageUrl(normalizedUrl)) {
    try {
      const fnUrl = `/.netlify/functions/r2-download?format=json&url=${encodeURIComponent(
        normalizedUrl
      )}&filename=${encodeURIComponent(filename)}`;
      const res = await fetch(fnUrl, { cache: 'no-store' });
      const ct = (res.headers.get('content-type') || '').toLowerCase();
      if (res.ok && ct.includes('application/json')) {
        const data = await res.json();
        if (data?.downloadUrl && typeof data.downloadUrl === 'string') {
          triggerAttachmentUrl(data.downloadUrl, filename);
          return true;
        }
      }
    } catch (err) {
      console.warn('r2-download Netlify function unavailable:', err);
    }
  }

  // 2. Supabase Storage natively honors ?download=<filename> with Content-Disposition: attachment
  if (isSupabasePublicStorageUrl(normalizedUrl)) {
    try {
      const headCheck = await fetch(normalizedUrl, {
        method: 'HEAD',
        mode: 'cors',
        credentials: 'omit',
        cache: 'no-store',
      });
      if (!headCheck.ok) {
        return false;
      }
    } catch {
      // If HEAD is blocked by network policy, still allow Supabase native ?download= attempt
    }
    const parsed = new URL(normalizedUrl);
    parsed.searchParams.set('download', filename);
    triggerAttachmentUrl(parsed.toString(), filename);
    return true;
  }

  // 3. Local/Node Express server fallback (/api/proxy-audio?download=1 streams attachment cleanly)
  if (normalizedUrl.startsWith('http') && (await hasExpressAudioProxy())) {
    const proxyAttachmentUrl = `/api/proxy-audio?url=${encodeURIComponent(
      normalizedUrl
    )}&filename=${encodeURIComponent(filename)}&download=1`;
    triggerAttachmentUrl(proxyAttachmentUrl, filename);
    return true;
  }

  return false;
}

/**
 * Downloads an MP3 while keeping the visitor on tesomelodies.com:
 * - <= 35 MB: fetches audio via CORS, embeds official Teso Melodies ID3 tags + artwork, triggers Blob download
 * - 35 MB - 80 MB: fetches audio via CORS into a same-origin Blob (skipping heavy ID3 rewrite on mobile), triggers Blob download
 * - > 80 MB or CORS-blocked: routes through /.netlify/functions/r2-download (or Supabase ?download= / Express proxy) with Content-Disposition: attachment
 * Resolves ONLY when a real download was verified & triggered so failed clicks never inflate download stats.
 */
export async function downloadWithTesoBranding(
  mp3Url: string,
  songTitle: string,
  artistName: string,
  onStatusUpdate?: (status: string) => void
): Promise<DownloadSuccessResult> {
  const normalizedUrl = normalizeR2Url(mp3Url);
  const storageSource = detectStorageSource(normalizedUrl);
  const sanitizedTitle = (songTitle || 'Track').trim();
  const sanitizedArtist = (artistName || 'Teso Artist').trim();
  const filename = `${sanitizedArtist} - ${sanitizedTitle} (TesoMelodies.com).mp3`.replace(/[\/\\?%*:|"<>]/g, '_');
  const cacheKey = `${normalizedUrl}_${sanitizedTitle}_${sanitizedArtist}`;

  // 1. Instant download if already processed and cached in session
  if (blobCache.has(cacheKey)) {
    const cached = blobCache.get(cacheKey)!;
    onStatusUpdate?.('Starting download...');
    triggerBlobDownload(cached, filename);
    return {
      mode: 'branded',
      storageSource,
      filename,
      bytes: cached.size,
      fromCache: true,
    };
  }

  onStatusUpdate?.('Preparing MP3 download...');

  // 2. Start loading cover artwork lazily in parallel (only needed when size <= 35MB)
  const coverPromise = getOfficialTesoCoverBuffer().catch((e) => {
    console.warn('Cover load notice:', e);
    return null;
  });

  let oversizedForBlob = false;
  let audioResponse: Response | null = null;

  // 3. Direct CORS fetch (credentials: 'omit' + cache: 'no-store' prevents poisoned non-CORS <audio> cache)
  try {
    const directRes = await fetch(normalizedUrl, {
      mode: 'cors',
      credentials: 'omit',
      cache: 'no-store',
    });

    if (isAudioContentType(directRes)) {
      const contentLength = getContentLength(directRes);
      if (contentLength !== null && contentLength > MAX_BLOB_FETCH_BYTES) {
        oversizedForBlob = true;
        directRes.body?.cancel?.().catch(() => {});
      } else {
        audioResponse = directRes;
      }
    } else {
      directRes.body?.cancel?.().catch(() => {});
    }
  } catch (directErr) {
    console.warn('Direct CORS fetch unavailable, checking proxy/attachment route:', directErr);
  }

  // 4. If direct CORS was blocked (and not already known > 80MB), try Express proxy if present
  if (!audioResponse && !oversizedForBlob && normalizedUrl.startsWith('http')) {
    if (await hasExpressAudioProxy()) {
      try {
        const proxyUrl = `/api/proxy-audio?url=${encodeURIComponent(normalizedUrl)}`;
        const proxyRes = await fetch(proxyUrl, { cache: 'no-store' });
        if (isAudioContentType(proxyRes)) {
          const contentLength = getContentLength(proxyRes);
          if (contentLength !== null && contentLength > MAX_BLOB_FETCH_BYTES) {
            oversizedForBlob = true;
            proxyRes.body?.cancel?.().catch(() => {});
          } else {
            audioResponse = proxyRes;
          }
        } else {
          proxyRes.body?.cancel?.().catch(() => {});
        }
      } catch (proxyErr) {
        console.warn('Audio proxy fetch skipped:', proxyErr);
      }
    }
  }

  // 5. Large files (> 80MB) or CORS-blocked hosts: trigger native Content-Disposition: attachment download
  if (!audioResponse || oversizedForBlob) {
    onStatusUpdate?.('Starting native MP3 download...');
    const started = await triggerAttachmentDownload(normalizedUrl, filename);
    if (started) {
      return {
        mode: 'direct',
        storageSource,
        filename,
      };
    }
    throw new Error('Unable to start background attachment download for this track.');
  }

  const headerLength = getContentLength(audioResponse);

  // 6. Files between 35 MB and 80 MB: skip ID3 tag rewriting to save mobile RAM and stream directly to Blob
  if (headerLength !== null && headerLength > MAX_ID3_MEMORY_BYTES) {
    onStatusUpdate?.('Downloading MP3 in background...');
    const rawBlob = await audioResponse.blob();
    if (rawBlob.size < 100) {
      throw new Error('Audio file appears empty or unavailable.');
    }
    if (rawBlob.size > MAX_BLOB_FETCH_BYTES) {
      const started = await triggerAttachmentDownload(normalizedUrl, filename);
      if (started) {
        return {
          mode: 'direct',
          storageSource,
          filename,
          bytes: rawBlob.size,
        };
      }
      throw new Error('Audio file exceeds mobile memory cap and attachment route failed.');
    }
    const mp3Blob =
      rawBlob.type && rawBlob.type.startsWith('audio/')
        ? rawBlob
        : new Blob([rawBlob], { type: 'audio/mpeg' });
    blobCache.set(cacheKey, mp3Blob);
    triggerBlobDownload(mp3Blob, filename);
    return {
      mode: 'direct',
      storageSource,
      filename,
      bytes: mp3Blob.size,
    };
  }

  // 7. Unknown length or <= 35 MB: read blob/buffer and check exact size
  onStatusUpdate?.('Fetching track & Teso Melodies artwork...');
  const downloadedBlob = await audioResponse.blob();

  if (downloadedBlob.size < 100) {
    throw new Error('Audio file appears empty or unavailable.');
  }

  if (downloadedBlob.size > MAX_BLOB_FETCH_BYTES) {
    onStatusUpdate?.('Starting native MP3 download...');
    const started = await triggerAttachmentDownload(normalizedUrl, filename);
    if (started) {
      return {
        mode: 'direct',
        storageSource,
        filename,
        bytes: downloadedBlob.size,
      };
    }
    throw new Error('Downloaded audio stream exceeded memory cap and attachment route failed.');
  }

  if (downloadedBlob.size > MAX_ID3_MEMORY_BYTES) {
    const mp3Blob =
      downloadedBlob.type && downloadedBlob.type.startsWith('audio/')
        ? downloadedBlob
        : new Blob([downloadedBlob], { type: 'audio/mpeg' });
    blobCache.set(cacheKey, mp3Blob);
    onStatusUpdate?.('Starting download...');
    triggerBlobDownload(mp3Blob, filename);
    return {
      mode: 'direct',
      storageSource,
      filename,
      bytes: mp3Blob.size,
    };
  }

  // 8. <= 35 MB: embed official Teso Melodies artwork & ID3 tags
  try {
    const [audioBuffer, coverBuffer] = await Promise.all([
      downloadedBlob.arrayBuffer(),
      coverPromise,
    ]);

    onStatusUpdate?.('Embedding Teso Melodies artwork & ID3 metadata...');

    const writer = new ID3Writer(audioBuffer);
    writer
      .setFrame('TIT2', sanitizedTitle)
      .setFrame('TPE1', [sanitizedArtist])
      .setFrame('TALB', 'Teso Melodies')
      .setFrame('TPUB', 'TESO MELODIES (tesomelodies.com)')
      .setFrame('WOAR', 'https://tesomelodies.com')
      .setFrame('COMM', {
        language: 'eng',
        description: 'Download Source',
        text: 'This Song is Downloaded from TesoMelodies.com',
      })
      .setFrame('TXXX', {
        description: 'Website',
        value: 'https://tesomelodies.com',
      });

    if (coverBuffer && coverBuffer.byteLength > 0) {
      writer.setFrame('APIC', {
        type: 3, // Cover (front)
        data: coverBuffer,
        description: 'This Song is Downloaded from TesoMelodies.com',
      });
    }

    writer.addTag();

    const taggedBlob = writer.getBlob();
    blobCache.set(cacheKey, taggedBlob);

    onStatusUpdate?.('Download started!');
    triggerBlobDownload(taggedBlob, filename);
    return {
      mode: 'branded',
      storageSource,
      filename,
      bytes: taggedBlob.size,
    };
  } catch (tagErr) {
    console.warn('ID3 tag injection error, downloading original MP3 blob:', tagErr);
    const fallbackBlob =
      downloadedBlob.type && downloadedBlob.type.startsWith('audio/')
        ? downloadedBlob
        : new Blob([downloadedBlob], { type: 'audio/mpeg' });
    triggerBlobDownload(fallbackBlob, filename);
    return {
      mode: 'direct',
      storageSource,
      filename,
      bytes: fallbackBlob.size,
    };
  }
}

function triggerBlobDownload(blob: Blob, filename: string) {
  const downloadUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = downloadUrl;
  anchor.download = filename;
  anchor.rel = 'noopener noreferrer';
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  setTimeout(() => URL.revokeObjectURL(downloadUrl), 90000);
}


