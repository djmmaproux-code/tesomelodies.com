import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { GenreCards } from './components/GenreCards';
import { MusicColumns } from './components/MusicColumns';
import { Sidebar } from './components/Sidebar';
import { AudioPlayer } from './components/AudioPlayer';
import { Footer } from './components/Footer';
import {
  UploadModal,
  EarnModal,
  AdvertiseModal,
  PostNewsModal,
  PublishLiveModal,
  AnnouncementModal,
  ArtistModal,
  ShareModal,
  SongDetailsModal,
  Toast,
} from './components/Modals';
import { VideosLibrary } from './components/VideosLibrary';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { VideoUploadModal } from './components/VideoUploadModal';
import { AuthModal } from './components/AuthModal';
import { ArtistProfileModal } from './components/ArtistProfileModal';
import { supabase } from './supabaseClient';
import {
  INITIAL_ANNOUNCEMENTS,
  HERO_ASSETS,
} from './data/initialData';
import { Song, Announcement, Artist, UserProfile, VideoItem } from './types/music';
import { Play, Video, Users, Newspaper, Flame, Wallet, Music2, Heart, Search, Sparkles, Download, Check, Trash2, MapPin, Eye, Upload, Shield, ShieldCheck, ArrowRight, MessageCircle, RotateCw } from 'lucide-react';
import { PrivacyPolicyPage } from './components/PrivacyPolicyPage';
import { TermsAndConditionsPage } from './components/TermsAndConditionsPage';
import { AdminLegalModal } from './components/AdminLegalModal';
import { AdminNewsPanel } from './components/AdminNewsPanel';
import { SongCommentsModal } from './components/SongCommentsModal';
import { syncServerComments } from './services/commentsService';
import { isUserAdminEmail, verifyAdminAuthorization } from './services/adminService';
import { fetchPublishedNews } from './services/newsService';
import {
  fetchSongsFromSupabase,
  fetchSongByIdFromSupabase,
  createSongInSupabase,
  deleteSongFromSupabase,
  incrementSongPlayInSupabase,
  toggleMusicLikeInSupabase,
  toggleFollowArtistInSupabase,
  fetchArtistsFromSupabase,
  fetchSongDownloadsMap,
  recordSongDownloadInSupabase,
  formatDownloadCount,
  calculateSongMilestoneFollowers,
  fetchArtistFollowerStatsFromSupabase,
  fetchSingleArtistFollowerStat,
  getOrCreateVisitorId,
  normalizeR2Url,
} from './services/musicService';
import { realtime } from './services/realtimeService';
import { fetchSongLikesData } from './services/socialService';
import { downloadWithTesoBranding } from './utils/downloadWithBranding';
import { audioEngine } from './utils/audioEngine';
import {
  fetchVideosFromSupabase,
  fetchVideoByIdFromSupabase,
  incrementVideoViewsInSupabase,
  fetchLikedVideoIds,
  toggleVideoLikeInSupabase,
  deleteVideoFromSupabase,
  formatVideoViews,
} from './services/videoService';
import {
  canonicalArtistSlug,
  getArtistSeoPath,
  getGenreSeoPath,
  resolveGenreLabelFromSlug,
  songMatchesSelectedGenre,
  updateDocumentSeo,
  buildClientSongSeo,
  buildClientArtistSeo,
  buildClientGenreSeo,
} from './utils/seo';
import { usePWAInstall } from './hooks/usePWAInstall';
import { PWAInstallPrompt, OfflineIndicator } from './components/PWAInstallPrompt';
import { ArtistEarningsSection } from './components/ArtistEarningsSection';
import { ArtistWalletPage } from './components/ArtistWalletPage';

function parseSharedItemFromLocation(): { type: 'song' | 'video'; id: string } | null {
  if (typeof window === 'undefined') return null;
  const pathname = window.location.pathname || '';
  const searchParams = new URLSearchParams(window.location.search || '');
  const hash = window.location.hash || '';

  const songPath = pathname.match(/^\/song\/([^/]+)/i);
  if (songPath?.[1]) {
    try {
      return { type: 'song', id: decodeURIComponent(songPath[1]).trim() };
    } catch {
      return { type: 'song', id: songPath[1].trim() };
    }
  }

  const videoPath = pathname.match(/^\/video\/([^/]+)/i);
  if (videoPath?.[1]) {
    try {
      return { type: 'video', id: decodeURIComponent(videoPath[1]).trim() };
    } catch {
      return { type: 'video', id: videoPath[1].trim() };
    }
  }

  const querySong = searchParams.get('song');
  if (querySong && querySong.trim()) {
    return { type: 'song', id: querySong.trim() };
  }

  const queryVideo = searchParams.get('video');
  if (queryVideo && queryVideo.trim()) {
    return { type: 'video', id: queryVideo.trim() };
  }

  const hashSong = hash.match(/#song=([^&]+)/i);
  if (hashSong?.[1]) {
    try {
      return { type: 'song', id: decodeURIComponent(hashSong[1]).trim() };
    } catch {
      return { type: 'song', id: hashSong[1].trim() };
    }
  }

  return null;
}

export default function App() {
  const pwa = usePWAInstall();

  // Navigation & Search State with direct URL routing support (/privacy-policy, /terms-and-conditions, /song/:id, /video/:id, /artist/:slug, /genre/:slug, etc.)
  const [activeTab, setActiveTab] = useState(() => {
    if (typeof window !== 'undefined') {
      const p = window.location.pathname.toLowerCase();
      const params = new URLSearchParams(window.location.search);
      if (params.get('earnings_verify') === '1') return 'dashboard';
      if (p === '/privacy-policy' || p === '/privacy') return 'privacy-policy';
      if (p === '/terms-and-conditions' || p === '/terms' || p === '/terms-of-service') return 'terms-and-conditions';
      if (p === '/admin') return 'admin';
      if (p === '/dashboard') return 'dashboard';
      if (p === '/wallet') return 'wallet';
      if (p === '/videos' || p.startsWith('/video/')) return 'videos';
      if (p === '/artists' || p.startsWith('/artist/')) return 'artists';
      if (p === '/music' || p.startsWith('/genre/')) return 'music';
      if (p === '/news') return 'news';
      if (p === '/charts') return 'charts';
      if (p === '/about') return 'about';
    }
    return 'home';
  });

  const [searchQuery, setSearchQuery] = useState(() => {
    if (typeof window !== 'undefined') {
      const q = new URLSearchParams(window.location.search).get('q');
      if (q && q.trim()) return q.trim();
    }
    return '';
  });

  const [selectedGenre, setSelectedGenre] = useState<string | null>(() => {
    if (typeof window !== 'undefined') {
      const match = window.location.pathname.match(/^\/genre\/([^/]+)/i);
      if (match?.[1]) {
        try {
          return resolveGenreLabelFromSlug(decodeURIComponent(match[1]));
        } catch {
          return resolveGenreLabelFromSlug(match[1]);
        }
      }
      const genreParam = new URLSearchParams(window.location.search).get('genre');
      if (genreParam && genreParam.trim()) {
        return resolveGenreLabelFromSlug(genreParam.trim());
      }
    }
    return null;
  });

  // Admin Legal Page Editor Modal
  const [adminLegalModal, setAdminLegalModal] = useState<{
    isOpen: boolean;
    docType: 'privacy' | 'terms';
  }>({
    isOpen: false,
    docType: 'privacy',
  });

  // Tracks real Gmail Artist Monetization verification status for dashboard badge
  const [isEarningsVerified, setIsEarningsVerified] = useState<boolean | null>(null);

  // Genre filter selection with canonical /genre/:slug URL synchronization
  const handleSelectGenre = (genre: string | null) => {
    const resolved = genre ? resolveGenreLabelFromSlug(genre) : null;
    setSelectedGenre(resolved);
    if (resolved) {
      showToast(`Showing ${resolved} songs`);
      if (typeof window !== 'undefined') {
        const targetPath = getGenreSeoPath(resolved);
        if (window.location.pathname !== targetPath) {
          window.history.pushState({ genre: resolved }, '', targetPath);
        }
      }
    } else if (typeof window !== 'undefined' && window.location.pathname.toLowerCase().startsWith('/genre/')) {
      window.history.pushState({}, '', activeTab === 'music' ? '/music' : '/');
    }
  };

  // Smooth URL and history synchronization
  const handleNavigate = (tabId: string) => {
    if (tabId.startsWith('genre:')) {
      const slug = tabId.slice('genre:'.length);
      const label = resolveGenreLabelFromSlug(slug);
      setActiveTab('music');
      setSelectedGenre(label);
      if (typeof window !== 'undefined') {
        window.history.pushState({ genre: label }, '', getGenreSeoPath(slug));
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
      return;
    }

    if (tabId === 'wallet' || tabId === 'dashboard') {
      if (!currentUser.isLoggedIn) {
        showToast('Please sign in to access your artist account.');
        setAuthModal({ isOpen: true, mode: 'signin' });
        return;
      }
    }

    if (tabId === 'admin') {
      if (!currentUser.isLoggedIn) {
        showToast('Please sign in with the authorized administrator account.');
        setAuthModal({ isOpen: true, mode: 'signin' });
        return;
      }
      if (!isUserAdminEmail(currentUser.email)) {
        showToast('Access denied: Admin Dashboard is restricted to tesomelodies@gmail.com.');
        return;
      }
    }

    if (tabId === 'home' && selectedGenre) {
      setSelectedGenre(null);
    }

    setActiveTab(tabId);
    if (typeof window !== 'undefined') {
      if (tabId === 'privacy-policy') {
        window.history.pushState({}, '', '/privacy-policy');
      } else if (tabId === 'terms-and-conditions') {
        window.history.pushState({}, '', '/terms-and-conditions');
      } else if (tabId === 'home') {
        window.history.pushState({}, '', '/');
      } else {
        window.history.pushState({}, '', `/${tabId}`);
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Popstate event listener for browser Back/Forward buttons
  useEffect(() => {
    const handlePopState = () => {
      const rawPath = window.location.pathname || '';
      const p = rawPath.toLowerCase();
      const params = new URLSearchParams(window.location.search);

      if (p === '/privacy-policy' || p === '/privacy') {
        setActiveTab('privacy-policy');
      } else if (p === '/terms-and-conditions' || p === '/terms' || p === '/terms-of-service') {
        setActiveTab('terms-and-conditions');
      } else if (p === '/admin') {
        setActiveTab('admin');
      } else if (p === '/dashboard') {
        setActiveTab('dashboard');
      } else if (p === '/wallet') {
        setActiveTab('wallet');
      } else if (p === '/videos' || p.startsWith('/video/')) {
        setActiveTab('videos');
      } else if (p === '/artists' || p.startsWith('/artist/')) {
        setActiveTab('artists');
      } else if (p === '/music' || p.startsWith('/genre/')) {
        setActiveTab('music');
      } else if (p === '/news') {
        setActiveTab('news');
      } else if (p === '/charts' || p === '/hot100' || p === '/trending') {
        setActiveTab('charts');
      } else if (p === '/about') {
        setActiveTab('about');
      } else {
        setActiveTab('home');
      }

      const genreMatch = rawPath.match(/^\/genre\/([^/]+)/i);
      if (genreMatch?.[1]) {
        try {
          setSelectedGenre(resolveGenreLabelFromSlug(decodeURIComponent(genreMatch[1])));
        } catch {
          setSelectedGenre(resolveGenreLabelFromSlug(genreMatch[1]));
        }
      } else if (params.get('genre')) {
        setSelectedGenre(resolveGenreLabelFromSlug(params.get('genre')!));
      } else {
        setSelectedGenre(null);
      }

      // Close open modals when navigating back if parameters/paths are removed
      if (!params.has('artist') && !p.startsWith('/artist/')) {
        setSelectedArtist(null);
      }
      if (!params.has('comments')) {
        setSelectedSongForComments(null);
      }
      if (!params.has('video') && !p.startsWith('/video/')) {
        setSelectedVideo(null);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Authenticated user ID in Supabase
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  // Music State (Empty by default — populated strictly by real artist uploads from Supabase)
  const [newSongs, setNewSongs] = useState<Song[]>([]);
  const [trendingSongs, setTrendingSongs] = useState<Song[]>([]);
  const [hot100Songs, setHot100Songs] = useState<Song[]>([]);
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [likedSongIds, setLikedSongIds] = useState<Set<string>>(new Set<string>());
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const suppressPauseSyncRef = useRef<boolean>(false);
  const activePlaybackSongIdRef = useRef<string | null>(null);
  const likeInFlightRef = useRef<Set<string>>(new Set());
  const followInFlightRef = useRef<Set<string>>(new Set());
  const downloadInFlightRef = useRef<Set<string>>(new Set());
  const [downloadingSongId, setDownloadingSongId] = useState<string | null>(null);

  // Sidebar & Announcements State
  const [announcements, setAnnouncements] = useState<Announcement[]>(INITIAL_ANNOUNCEMENTS);
  const [topArtist, setTopArtist] = useState<Artist | null>(null);
  const [realArtists, setRealArtists] = useState<Artist[]>([]);
  const [artistSearchQuery, setArtistSearchQuery] = useState('');

  // Videos State (Populated strictly by real Supabase uploads — zero sample videos)
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [selectedVideo, setSelectedVideo] = useState<VideoItem | null>(null);
  const [isLoadingVideos, setIsLoadingVideos] = useState<boolean>(true);
  const [videosError, setVideosError] = useState<string | null>(null);
  const [likedVideoIds, setLikedVideoIds] = useState<Set<string>>(new Set<string>());

  // User Profile State
  const [currentUser, setCurrentUser] = useState<UserProfile>({
    name: '',
    username: '',
    email: '',
    isLoggedIn: false,
    role: 'fan',
  });

  // Modal States
  const [authModal, setAuthModal] = useState<{ isOpen: boolean; mode: 'signin' | 'signup' }>({
    isOpen: false,
    mode: 'signin',
  });
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isVideoUploadOpen, setIsVideoUploadOpen] = useState(false);
  const [isEarnOpen, setIsEarnOpen] = useState(false);
  const [isAdvertiseOpen, setIsAdvertiseOpen] = useState(false);
  const [isPostNewsOpen, setIsPostNewsOpen] = useState(false);
  const [isPublishLiveOpen, setIsPublishLiveOpen] = useState(false);
  const [isArtistSetupOpen, setIsArtistSetupOpen] = useState(false);
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);
  const [selectedArtist, setSelectedArtist] = useState<Artist | null>(null);
  const [shareSong, setShareSong] = useState<Song | null>(null);
  const [shareVideo, setShareVideo] = useState<VideoItem | null>(null);
  const [selectedSongDetails, setSelectedSongDetails] = useState<Song | null>(null);
  const [selectedSongForComments, setSelectedSongForComments] = useState<Song | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const deepLinkedSongIdRef = useRef<string | null>(null);
  const deepLinkedVideoIdRef = useRef<string | null>(null);

  // Songs Loading State
  const [isLoadingSongs, setIsLoadingSongs] = useState<boolean>(true);

  // Sync videos catalog & user video likes from Supabase
  const syncVideosData = useCallback(async (userId?: string | null) => {
    setIsLoadingVideos(true);
    setVideosError(null);
    try {
      const vid = getOrCreateVisitorId();
      const effectiveId = userId || vid;
      const [{ videos: dbVideos, error: dbVideosError }, likedIds] = await Promise.all([
        fetchVideosFromSupabase(),
        fetchLikedVideoIds(effectiveId),
      ]);

      let mergedVideos = dbVideos;
      const shared = parseSharedItemFromLocation();
      if (shared?.type === 'video' && shared.id && deepLinkedVideoIdRef.current !== shared.id) {
        let found = dbVideos.find((v) => v.id === shared.id) || null;
        if (!found) {
          found = await fetchVideoByIdFromSupabase(shared.id);
          if (found) {
            mergedVideos = [found, ...dbVideos];
          }
        }
        if (found) {
          deepLinkedVideoIdRef.current = found.id;
          setActiveTab('videos');
          setSelectedVideo(found);
          if (typeof document !== 'undefined') {
            document.title = `${found.title} — ${found.artist} | TESO MELODIES Videos`;
          }
          incrementVideoViewsInSupabase(found.id).catch(() => {});
        }
      }

      setVideos(mergedVideos);
      setLikedVideoIds(likedIds);
      if (dbVideosError) {
        setVideosError(dbVideosError);
      }
    } catch (err: any) {
      setVideosError(err?.message || 'Unable to load videos from server.');
    } finally {
      setIsLoadingVideos(false);
    }
  }, []);

  const refreshPublishedNews = useCallback(async () => {
    try {
      const newsRes = await fetchPublishedNews();
      if (!newsRes.tableMissing) {
        setAnnouncements(newsRes.announcements);
      }
    } catch {
      // keep existing announcements on transient network failure
    }
  }, []);

  // Sync all songs, likes, news, settings, and artist data directly from Supabase
  const syncSongsAndUserData = useCallback(async (userId?: string | null) => {
    setIsLoadingSongs(true);
    try {
      syncServerComments();
      const vid = getOrCreateVisitorId();
      const effectiveId = userId || currentUserId || vid;
      syncVideosData(effectiveId);
      refreshPublishedNews();

      const [dbSongs, likesData, downloadsMap] = await Promise.all([
        fetchSongsFromSupabase(),
        fetchSongLikesData(effectiveId),
        fetchSongDownloadsMap(),
      ]);

      if (dbSongs && dbSongs.length > 0) {
        const markedReal = dbSongs.map((s) => {
          const dbLikes = typeof s.likes === 'number' ? Math.max(0, s.likes) : 0;
          const hasServerLikes =
            likesData?.likesMap && typeof likesData.likesMap[s.id] === 'number';
          const resolvedLikes = hasServerLikes
            ? Math.max(0, likesData!.likesMap[s.id])
            : dbLikes;
          const resolvedDownloads = Math.max(
            typeof s.downloadsCount === 'number' ? Math.max(0, s.downloadsCount) : 0,
            typeof downloadsMap?.[s.id] === 'number' ? Math.max(0, downloadsMap[s.id]) : 0
          );
          return {
            ...s,
            isRealUpload: true,
            likes: resolvedLikes,
            downloadsCount: resolvedDownloads,
          };
        });

        // Newest songs first
        setNewSongs(markedReal);

        // Trending songs: strictly ranked by real likes & plays
        const trending = [...markedReal].sort(
          (a, b) =>
            (b.likes || 0) - (a.likes || 0) ||
            (b.plays || 0) - (a.plays || 0) ||
            new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
        );
        setTrendingSongs(trending);

        // Hot 100 songs: ranked by genuine popularity
        const hot100 = [...markedReal]
          .sort(
            (a, b) =>
              (b.likes || 0) + (b.plays || 0) + (b.downloadsCount || 0) -
              ((a.likes || 0) + (a.plays || 0) + (a.downloadsCount || 0))
          )
          .map((s, idx) => ({ ...s, rank: idx + 1 }));
        setHot100Songs(hot100);

        const dbArtists = await fetchArtistsFromSupabase(markedReal, effectiveId);
        if (dbArtists && dbArtists.length > 0) {
          setRealArtists(dbArtists);
          const sortedArtists = [...dbArtists].sort(
            (a, b) =>
              (b.followers || 0) - (a.followers || 0) ||
              (b.totalLikes || 0) - (a.totalLikes || 0) ||
              (b.totalSongs || 0) - (a.totalSongs || 0)
          );
          setTopArtist(sortedArtists[0] || null);
        } else {
          setRealArtists([]);
          setTopArtist(null);
        }

        if (typeof window !== 'undefined') {
          const params = new URLSearchParams(window.location.search);
          const artistPathMatch = window.location.pathname.match(/^\/artist\/([^/]+)/i);
          let rawArtistParam = params.get('artist');
          if (!rawArtistParam && artistPathMatch?.[1]) {
            try {
              rawArtistParam = decodeURIComponent(artistPathMatch[1]);
            } catch {
              rawArtistParam = artistPathMatch[1];
            }
          }
          if (rawArtistParam && dbArtists && dbArtists.length > 0) {
            const target = rawArtistParam.toLowerCase().trim();
            const targetSlug = canonicalArtistSlug(rawArtistParam);
            const found = dbArtists.find(
              (a) =>
                a.id.toLowerCase() === target ||
                a.id.toLowerCase() === targetSlug ||
                canonicalArtistSlug(a.name) === targetSlug ||
                a.name.toLowerCase().trim() === target
            );
            if (found) setSelectedArtist(found);
          }
        }
      } else {
        setNewSongs([]);
        setTrendingSongs([]);
        setHot100Songs([]);
        const dbArtists = await fetchArtistsFromSupabase([], effectiveId);
        setRealArtists(dbArtists || []);
        setTopArtist(dbArtists?.[0] || null);
      }

      if (likesData?.userLikedSongIds) {
        setLikedSongIds(new Set(likesData.userLikedSongIds));
      }

      // Restore open comments or shared song (/song/:id or #song=:id) on page load
      if (typeof window !== 'undefined') {
        const params = new URLSearchParams(window.location.search);

        const commentsParam = params.get('comments');
        if (commentsParam && dbSongs && dbSongs.length > 0) {
          const found = dbSongs.find((s) => s.id === commentsParam);
          if (found) setSelectedSongForComments(found);
        }

        const shared = parseSharedItemFromLocation();
        if (shared?.type === 'song' && shared.id && deepLinkedSongIdRef.current !== shared.id) {
          let targetSong = dbSongs?.find((s) => s.id === shared.id) || null;
          if (!targetSong) {
            targetSong = await fetchSongByIdFromSupabase(shared.id);
          }
          if (targetSong) {
            deepLinkedSongIdRef.current = targetSong.id;
            setCurrentSong(targetSong);
            if (typeof document !== 'undefined') {
              document.title = `${targetSong.title} — ${targetSong.artist} | TESO MELODIES`;
            }
            if (targetSong.audioUrl && audioRef.current) {
              const audio = audioRef.current;
              const trimmedUrl = normalizeR2Url(targetSong.audioUrl) || targetSong.audioUrl.trim();
              if (audio.getAttribute('src') !== trimmedUrl) {
                audio.setAttribute('src', trimmedUrl);
                audio.preload = 'metadata';
                audio.load();
              }
            }
            setToastMessage(`Loaded shared track: "${targetSong.title}" by ${targetSong.artist}`);
          }
        }
      }
    } catch (err) {
      console.warn('Sync notice:', err);
    } finally {
      setIsLoadingSongs(false);
    }
  }, []);

  // Check initial Supabase Auth session, route protection & listen to state changes
  useEffect(() => {
    const extractAndLoginUser = async (u: any) => {
      let displayName =
        u.user_metadata?.stage_name ||
        u.user_metadata?.full_name ||
        u.user_metadata?.name ||
        u.email ||
        'User';
      let avatar =
        u.user_metadata?.avatar_url ||
        u.user_metadata?.picture;
      let role: 'fan' | 'artist' = (u.user_metadata?.role as 'fan' | 'artist') || 'fan';
      let stageName = u.user_metadata?.stage_name;
      let genre = u.user_metadata?.genre;
      let bio = u.user_metadata?.bio;
      let location = u.user_metadata?.location || 'Teso, Uganda';

      // Check public.profiles in Supabase
      try {
        const { data: prof } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', u.id)
          .maybeSingle();
        if (prof) {
          if (prof.role) role = prof.role as 'fan' | 'artist';
          if (prof.full_name) {
            stageName = prof.full_name;
            displayName = prof.full_name;
          }
          if (prof.avatar_url) avatar = prof.avatar_url;
          if (prof.bio) bio = prof.bio;
        }
      } catch {
        // ignore
      }

      handleLogin(displayName, u.email || undefined, avatar, role, stageName, genre, bio, location, u.id);
    };

    const checkAuthAndRoute = async () => {
      // 0. Handle OAuth callback if opened in a popup window
      if (typeof window !== 'undefined' && window.opener && window.name === 'google_oauth_popup') {
        const {
          data: { session: popupSession },
        } = await supabase.auth.getSession();
        if (popupSession?.user) {
          try {
            window.opener.postMessage({ type: 'SUPABASE_AUTH_SUCCESS' }, '*');
          } catch {
            // ignore
          }
          setTimeout(() => {
            window.close();
          }, 350);
          return;
        }
      }

      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (session?.user) {
        setCurrentUserId(session.user.id);
        await extractAndLoginUser(session.user);
      } else {
        setCurrentUserId(null);
      }

      // Initial database load
      syncSongsAndUserData(session?.user?.id);

      // Protect private pages & /admin route with real server-backed authorization
      const currentPath = window.location.pathname.toLowerCase();
      if (currentPath === '/admin') {
        if (!session) {
          setAuthModal({ isOpen: true, mode: 'signin' });
          setActiveTab('home');
          if (typeof window !== 'undefined') {
            window.history.replaceState({}, '', '/');
          }
          return;
        }
        const adminCheck = await verifyAdminAuthorization();
        if (!adminCheck.authorized) {
          showToast(adminCheck.error || 'Access denied: Authorized admin only.');
          setActiveTab('home');
          if (typeof window !== 'undefined') {
            window.history.replaceState({}, '', '/');
          }
          return;
        }
      }

      const privateRoutes = ['/upload', '/dashboard', '/wallet', '/profile', '/account', '/earnings', '/creator'];
      const isPrivateRoute = privateRoutes.some((route) => currentPath.startsWith(route));

      if (isPrivateRoute && !session) {
        setAuthModal({ isOpen: true, mode: 'signin' });
        setActiveTab('home');
        if (typeof window !== 'undefined') {
          window.history.replaceState({}, '', '/');
        }
        return;
      }

      // If on /login: show login modal smoothly without hard reload
      if (currentPath === '/login') {
        if (!session) {
          setAuthModal({ isOpen: true, mode: 'signin' });
        }
        if (typeof window !== 'undefined') {
          window.history.replaceState({}, '', '/');
        }
      }
    };

    checkAuthAndRoute();

    // Listen for popup messages when Google OAuth completes
    const handlePopupMessage = async (event: MessageEvent) => {
      if (event.data?.type === 'SUPABASE_AUTH_SUCCESS') {
        const {
          data: { session: newSession },
        } = await supabase.auth.getSession();
        if (newSession?.user) {
          setCurrentUserId(newSession.user.id);
          await extractAndLoginUser(newSession.user);
          syncSongsAndUserData(newSession.user.id);
        }
      }
    };
    window.addEventListener('message', handlePopupMessage);

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.user) {
        setCurrentUserId(session.user.id);
        await extractAndLoginUser(session.user);
        syncSongsAndUserData(session.user.id);
      } else {
        setCurrentUserId(null);
      }
    });

    // 1. Real-time song like updates
    const unsubLikes = realtime.onSongLike(({ songId, likes, userId, isLiked }) => {
      const updateList = (list: Song[]) =>
        list.map((s) => (s.id === songId ? { ...s, likes } : s));

      setNewSongs(updateList);
      setTrendingSongs((prev) => {
        const updated = updateList(prev);
        return [...updated].sort(
          (a, b) =>
            (b.likes || 0) - (a.likes || 0) ||
            (b.plays || 0) - (a.plays || 0)
        );
      });
      setHot100Songs(updateList);

      // Sync user liked state if action matches current session
      if (userId && isLiked !== undefined) {
        setLikedSongIds((prev) => {
          const next = new Set(prev);
          if (isLiked) next.add(songId);
          else next.delete(songId);
          return next;
        });
      }
    });

    // 2. Real-time artist follow & milestone updates from public.artist_follower_stats
    const unsubFollows = realtime.onArtistFollow(
      ({
        artistId,
        artistName,
        followers,
        realFollowers,
        bonusFollowers,
        totalFollowers,
        songCount,
        userId,
        isFollowed,
      }) => {
        const aIdLower = String(artistId || '').toLowerCase().trim();
        const aNameLower = String(artistName || '').toLowerCase().trim();
        const aSlug = (aNameLower || aIdLower).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
        const vid = getOrCreateVisitorId();
        const isActingUser = Boolean(userId && (userId === currentUserId || userId === vid));
        const hasAuthoritativeViewStats =
          typeof realFollowers === 'number' && typeof bonusFollowers === 'number';
        const hasExactRealOnly = !hasAuthoritativeViewStats && typeof realFollowers === 'number';
        const hasLegacyRealOnly = !hasAuthoritativeViewStats && typeof followers === 'number';

        const applyArtistUpdate = (artist: Artist): Artist => {
          const artistSlug = artist.name
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-|-$/g, '');
          const matches =
            artist.id.toLowerCase() === aIdLower ||
            (aSlug && (artist.id.toLowerCase() === aSlug || artistSlug === aSlug)) ||
            (aNameLower && artist.name.toLowerCase().trim() === aNameLower) ||
            (artist.legacyFollowUserId && artist.legacyFollowUserId.toLowerCase() === aIdLower);
          if (!matches) return artist;

          const nextBonus = hasAuthoritativeViewStats
            ? Math.max(0, bonusFollowers!)
            : typeof artist.songBonusFollowers === 'number'
            ? artist.songBonusFollowers
            : calculateSongMilestoneFollowers(artist.totalSongs || 0);
          const nextReal = hasAuthoritativeViewStats
            ? Math.max(0, realFollowers!)
            : hasExactRealOnly
            ? Math.max(0, realFollowers!)
            : hasLegacyRealOnly
            ? Math.max(0, followers!)
            : Math.max(0, artist.realFollowers ?? (artist.followers - nextBonus));
          const nextTotal =
            hasAuthoritativeViewStats && typeof totalFollowers === 'number'
              ? Math.max(0, totalFollowers)
              : nextReal + nextBonus;

          return {
            ...artist,
            realFollowers: nextReal,
            songBonusFollowers: nextBonus,
            followers: nextTotal,
            totalSongs: typeof songCount === 'number' ? Math.max(artist.totalSongs || 0, songCount) : artist.totalSongs,
            isFollowed: isActingUser && isFollowed !== undefined ? isFollowed : artist.isFollowed,
          };
        };

        setRealArtists((prev) => {
          const updated = prev.map(applyArtistUpdate).sort(
            (a, b) =>
              (b.followers || 0) - (a.followers || 0) ||
              (b.totalLikes || 0) - (a.totalLikes || 0) ||
              (b.totalSongs || 0) - (a.totalSongs || 0)
          );
          if (updated.length > 0) {
            setTopArtist(updated[0]);
          }
          return updated;
        });
        setSelectedArtist((prev) => (prev ? applyArtistUpdate(prev) : prev));
      }
    );

    // 2b. Periodic + tab-focus automatic sync directly from public.artist_follower_stats
    const refreshArtistStatsFromView = async () => {
      try {
        const { byKey } = await fetchArtistFollowerStatsFromSupabase();
        if (byKey.size === 0) return;
        const applyStat = (artist: Artist): Artist => {
          const slug = artist.name
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-|-$/g, '');
          const stat =
            byKey.get(slug) ||
            byKey.get(artist.id.toLowerCase().trim()) ||
            byKey.get(artist.name.toLowerCase().trim());
          if (!stat) return artist;
          if (
            artist.followers === stat.total_followers &&
            artist.realFollowers === stat.real_followers &&
            artist.songBonusFollowers === stat.bonus_followers
          ) {
            return artist;
          }
          return {
            ...artist,
            realFollowers: stat.real_followers,
            songBonusFollowers: stat.bonus_followers,
            followers: stat.total_followers,
            totalSongs: Math.max(artist.totalSongs || 0, stat.song_count),
          };
        };
        setRealArtists((prev) => {
          if (prev.length === 0) return prev;
          const updated = prev.map(applyStat).sort(
            (a, b) =>
              (b.followers || 0) - (a.followers || 0) ||
              (b.totalLikes || 0) - (a.totalLikes || 0) ||
              (b.totalSongs || 0) - (a.totalSongs || 0)
          );
          if (updated.length > 0) setTopArtist(updated[0]);
          return updated;
        });
        setSelectedArtist((prev) => (prev ? applyStat(prev) : prev));
      } catch {
        // ignore background refresh failures
      }
    };

    const handleVisibilityRefresh = () => {
      if (document.visibilityState === 'visible') {
        refreshArtistStatsFromView();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityRefresh);
    const statsIntervalId = window.setInterval(refreshArtistStatsFromView, 60000);

    // 3. Real-time song download updates (live sync across all open tabs & visitors)
    const unsubDownloads = realtime.onSongDownload(({ songId, downloadsCount }) => {
      const safeCount = Math.max(0, downloadsCount);
      const updateList = (list: Song[]) =>
        list.map((s) => (s.id === songId ? { ...s, downloadsCount: safeCount } : s));

      setNewSongs(updateList);
      setTrendingSongs(updateList);
      setHot100Songs((prev) => {
        const updated = updateList(prev);
        return [...updated]
          .sort(
            (a, b) =>
              (b.likes || 0) + (b.plays || 0) + (b.downloadsCount || 0) -
              ((a.likes || 0) + (a.plays || 0) + (a.downloadsCount || 0))
          )
          .map((s, idx) => ({ ...s, rank: idx + 1 }));
      });
      setCurrentSong((prev) => (prev && prev.id === songId ? { ...prev, downloadsCount: safeCount } : prev));
      setShareSong((prev) => (prev && prev.id === songId ? { ...prev, downloadsCount: safeCount } : prev));
      setSelectedSongDetails((prev) =>
        prev && prev.id === songId ? { ...prev, downloadsCount: safeCount } : prev
      );
    });

    return () => {
      window.removeEventListener('message', handlePopupMessage);
      document.removeEventListener('visibilitychange', handleVisibilityRefresh);
      window.clearInterval(statsIntervalId);
      subscription.unsubscribe();
      unsubLikes();
      unsubFollows();
      unsubDownloads();
    };
  }, [syncSongsAndUserData]);

  // Protected action guard
  const handleProtectedAction = async (action: () => void) => {
    if (currentUser.isLoggedIn && (currentUserId || currentUser.id)) {
      action();
      return;
    }

    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (session?.user) {
        setCurrentUserId(session.user.id);
        action();
        return;
      }
    } catch {
      // ignore
    }

    showToast('Please sign in or create an artist account to upload music.');
    setAuthModal({ isOpen: true, mode: 'signin' });
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  // Audio Playback Handlers - start HTML5 audio synchronously inside user gesture & sync play count
  const startSongElementPlayback = useCallback((song: Song) => {
    activePlaybackSongIdRef.current = song.id;
    setCurrentSong(song);

    if (song.audioUrl) {
      audioEngine.stop();
      const audio = audioRef.current;
      const trimmedUrl = normalizeR2Url(song.audioUrl) || song.audioUrl.trim();
      if (audio) {
        suppressPauseSyncRef.current = true;
        try {
          audio.pause();
          audio.preload = 'auto';
          if (audio.getAttribute('src') !== trimmedUrl) {
            audio.setAttribute('src', trimmedUrl);
            audio.load();
          }
          setIsPlaying(true);
          const playPromise = audio.play();
          if (playPromise && typeof playPromise.then === 'function') {
            playPromise
              .then(() => {
                if (activePlaybackSongIdRef.current === song.id) {
                  suppressPauseSyncRef.current = false;
                  setIsPlaying(true);
                }
              })
              .catch((err) => {
                suppressPauseSyncRef.current = false;
                if (err?.name === 'AbortError') return;
                console.warn('Audio playback start prevented or failed:', err);
                if (activePlaybackSongIdRef.current === song.id) {
                  setIsPlaying(false);
                  if (err?.name === 'NotAllowedError') {
                    showToast('Tap the Play button in the player bar to start audio.');
                  }
                }
              });
          } else {
            suppressPauseSyncRef.current = false;
          }
        } catch (err) {
          suppressPauseSyncRef.current = false;
          console.warn('Audio start error:', err);
          setIsPlaying(false);
        }
        return;
      }
      setIsPlaying(true);
    } else {
      const audio = audioRef.current;
      if (audio) {
        suppressPauseSyncRef.current = true;
        audio.pause();
        audio.removeAttribute('src');
        audio.load();
        setTimeout(() => {
          suppressPauseSyncRef.current = false;
        }, 50);
      }
      audioEngine.unlock();
      setIsPlaying(true);
    }
  }, []);

  const toggleCurrentPlayback = useCallback(() => {
    if (!currentSong) return;

    if (currentSong.audioUrl && audioRef.current) {
      const audio = audioRef.current;
      const trimmedUrl = normalizeR2Url(currentSong.audioUrl) || currentSong.audioUrl.trim();

      if (audio.paused) {
        if (audio.getAttribute('src') !== trimmedUrl) {
          suppressPauseSyncRef.current = true;
          audio.setAttribute('src', trimmedUrl);
          audio.load();
        }
        audio.preload = 'auto';
        setIsPlaying(true);
        const playPromise = audio.play();
        if (playPromise && typeof playPromise.then === 'function') {
          playPromise
            .then(() => {
              suppressPauseSyncRef.current = false;
              setIsPlaying(true);
            })
            .catch((err) => {
              suppressPauseSyncRef.current = false;
              if (err?.name === 'AbortError') return;
              console.warn('Audio resume error:', err);
              setIsPlaying(false);
              if (err?.name === 'NotAllowedError') {
                showToast('Tap Play again to allow audio playback.');
              } else {
                showToast('Unable to stream this track right now.');
              }
            });
        } else {
          suppressPauseSyncRef.current = false;
        }
      } else {
        suppressPauseSyncRef.current = false;
        audio.pause();
        setIsPlaying(false);
      }
      return;
    }

    audioEngine.unlock();
    setIsPlaying((prev) => !prev);
  }, [currentSong]);

  const handleClosePlayer = useCallback(() => {
    activePlaybackSongIdRef.current = null;
    suppressPauseSyncRef.current = true;
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.removeAttribute('src');
      audioRef.current.load();
    }
    audioEngine.stop();
    setIsPlaying(false);
    setCurrentSong(null);
    setTimeout(() => {
      suppressPauseSyncRef.current = false;
    }, 50);
  }, []);

  const handlePlaySong = (song: Song) => {
    if (currentSong?.id === song.id) {
      toggleCurrentPlayback();
    } else {
      startSongElementPlayback(song);
      showToast(`Now Playing: ${song.title} • ${song.artist}`);

      // Sync updated play count & eligible stream record to Supabase via atomic RPC
      const newPlays = (song.plays || 0) + 1;
      incrementSongPlayInSupabase(
        song.id,
        newPlays,
        currentUserId || getOrCreateVisitorId()
      ).catch(() => {});
      setNewSongs((prev) => prev.map((s) => (s.id === song.id ? { ...s, plays: newPlays } : s)));
      setTrendingSongs((prev) => prev.map((s) => (s.id === song.id ? { ...s, plays: newPlays } : s)));
      setHot100Songs((prev) => prev.map((s) => (s.id === song.id ? { ...s, plays: newPlays } : s)));
    }
  };

  const allSongs = useMemo(() => {
    const map = new Map<string, Song>();
    [...newSongs, ...trendingSongs, ...hot100Songs].forEach((s) => map.set(s.id, s));
    return Array.from(map.values());
  }, [newSongs, trendingSongs, hot100Songs]);

  const handleNextSong = () => {
    if (!currentSong || allSongs.length === 0) return;
    const currentIndex = allSongs.findIndex((s) => s.id === currentSong.id);
    const nextIndex = (currentIndex + 1) % allSongs.length;
    startSongElementPlayback(allSongs[nextIndex]);
  };

  const handlePrevSong = () => {
    if (!currentSong || allSongs.length === 0) return;
    const currentIndex = allSongs.findIndex((s) => s.id === currentSong.id);
    const prevIndex = (currentIndex - 1 + allSongs.length) % allSongs.length;
    startSongElementPlayback(allSongs[prevIndex]);
  };

  // Combined list of real registered artists and top featured artists (strictly deduplicated by ID and normalized name)
  const allDisplayedArtists = useMemo(() => {
    const list: Artist[] = [];
    const seenNames = new Set<string>();
    const seenIds = new Set<string>();

    realArtists.forEach((a) => {
      const normName = a.name.toLowerCase().trim();
      const normId = a.id.toLowerCase().trim();
      if (!normName || seenNames.has(normName) || seenIds.has(normId)) return;
      seenNames.add(normName);
      seenIds.add(normId);
      list.push(a);
    });

    if (topArtist) {
      const topNorm = topArtist.name.toLowerCase().trim();
      const topId = topArtist.id.toLowerCase().trim();
      if (!seenNames.has(topNorm) && !seenIds.has(topId)) {
        list.push(topArtist);
      }
    }

    return list;
  }, [realArtists, topArtist]);

  // Open / Close Artist Modal with canonical /artist/:slug URL sync + live Supabase artist_follower_stats sync
  const handleOpenArtist = (artist: Artist) => {
    setSelectedArtist(artist);
    if (typeof window !== 'undefined') {
      const targetUrl = getArtistSeoPath(artist.name || artist.id);
      if (window.location.pathname !== targetUrl) {
        window.history.pushState({ modal: 'artist', id: artist.id }, '', targetUrl);
      }
    }
    // Refresh this artist's live combined count directly from public.artist_follower_stats
    fetchSingleArtistFollowerStat(artist.id, artist.name)
      .then((stat) => {
        if (!stat) return;
        const patchArtist = (a: Artist): Artist => {
          const same =
            a.id.toLowerCase() === artist.id.toLowerCase() ||
            a.name.toLowerCase().trim() === artist.name.toLowerCase().trim();
          if (!same) return a;
          return {
            ...a,
            realFollowers: stat.real_followers,
            songBonusFollowers: stat.bonus_followers,
            followers: stat.total_followers,
            totalSongs: Math.max(a.totalSongs || 0, stat.song_count),
          };
        };
        setSelectedArtist((prev) => (prev ? patchArtist(prev) : prev));
        setRealArtists((prev) => prev.map(patchArtist));
        setTopArtist((prev) => (prev ? patchArtist(prev) : prev));
      })
      .catch(() => {});
  };

  const handleCloseArtist = () => {
    setSelectedArtist(null);
    if (
      typeof window !== 'undefined' &&
      (window.location.pathname.toLowerCase().startsWith('/artist/') ||
        window.location.search.includes('artist='))
    ) {
      window.history.pushState({}, '', activeTab === 'artists' ? '/artists' : '/');
    }
  };

  const handleViewArtistByName = (artistName: string) => {
    const normalizeKey = (val: string) =>
      String(val || '')
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9]+/g, '');
    const targetNorm = normalizeKey(artistName);
    const targetSlug = artistName
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
    const found = allDisplayedArtists.find(
      (a) =>
        a.name.toLowerCase().trim() === artistName.toLowerCase().trim() ||
        (targetNorm && normalizeKey(a.name) === targetNorm) ||
        (targetSlug && a.id.toLowerCase() === targetSlug)
    );
    if (found) {
      handleOpenArtist(found);
      return;
    }
    const artistTracks = allSongs.filter(
      (s) => s.artist.toLowerCase().trim() === artistName.toLowerCase().trim()
    );
    const realLikes = artistTracks.reduce((acc, s) => acc + (s.likes || 0), 0);
    const songBonusFollowers = calculateSongMilestoneFollowers(artistTracks.length);
    handleOpenArtist({
      id: targetSlug || artistName.toLowerCase().trim().replace(/\s+/g, '-'),
      name: artistName,
      genre: artistTracks[0]?.genre || 'Afrobeat / Gospel',
      followers: songBonusFollowers,
      realFollowers: 0,
      songBonusFollowers,
      isFollowed: false,
      avatar: artistTracks[0]?.coverUrl || HERO_ASSETS.announcement,
      bio: `${artistName} is an active recording artist on Teso Melodies.`,
      monthlyListeners: `${realLikes} likes`,
      totalLikes: realLikes,
      totalSongs: artistTracks.length,
    });
  };

  // Open / Close Song Comments Modal with URL sync
  const handleOpenComments = (song: Song) => {
    setSelectedSongForComments(song);
    if (typeof window !== 'undefined') {
      window.history.pushState({ modal: 'comments', songId: song.id }, '', `?comments=${encodeURIComponent(song.id)}`);
    }
  };

  const handleCloseComments = () => {
    setSelectedSongForComments(null);
    if (typeof window !== 'undefined' && window.location.search.includes('comments=')) {
      const cleanPath = window.location.pathname === '/login' ? '/' : window.location.pathname;
      window.history.pushState({}, '', cleanPath);
    }
  };

  // Like Song - sync likes permanently to Supabase without duplicates
  const handleLikeSong = async (songId: string) => {
    if (likeInFlightRef.current.has(songId)) return;
    likeInFlightRef.current.add(songId);

    const isCurrentlyLiked = likedSongIds.has(songId);
    const visitorId = getOrCreateVisitorId();
    const effectiveUserId = currentUserId || visitorId;

    // Optimistic UI update
    setLikedSongIds((prev) => {
      const next = new Set(prev);
      if (isCurrentlyLiked) {
        next.delete(songId);
        showToast('Song removed from your Favorites');
      } else {
        next.add(songId);
        showToast('Song added to your Favorites ❤️');
      }
      return next;
    });

    const delta = isCurrentlyLiked ? -1 : 1;
    const updateSongList = (songs: Song[]) =>
      songs.map((s) => (s.id === songId ? { ...s, likes: Math.max(0, (s.likes || 0) + delta) } : s));

    setNewSongs(updateSongList);

    setTrendingSongs((prev) => {
      const updated = updateSongList(prev);
      return [...updated].sort(
        (a, b) =>
          (b.likes || 0) - (a.likes || 0) ||
          (b.plays || 0) - (a.plays || 0)
      );
    });

    setHot100Songs(updateSongList);

    const targetSong = allSongs.find((s) => s.id === songId);
    if (targetSong) {
      const artistNameLower = targetSong.artist.toLowerCase().trim();
      setRealArtists((prev) =>
        prev.map((artist) => {
          if (artist.name.toLowerCase().trim() === artistNameLower) {
            return {
              ...artist,
              totalLikes: Math.max(0, (artist.totalLikes || 0) + delta),
            };
          }
          return artist;
        })
      );
      setTopArtist((prev) => {
        if (!prev) return null;
        if (prev.name.toLowerCase().trim() === artistNameLower) {
          return {
            ...prev,
            totalLikes: Math.max(0, (prev.totalLikes || 0) + delta),
          };
        }
        return prev;
      });
    }

    try {
      const res = await toggleMusicLikeInSupabase(
        songId,
        effectiveUserId,
        visitorId,
        isCurrentlyLiked,
        currentUser.email,
        currentUser.stageName || currentUser.name
      );

      setLikedSongIds((prev) => {
        const next = new Set(prev);
        if (res.isLiked) next.add(songId);
        else next.delete(songId);
        return next;
      });

      if (typeof res.totalLikes === 'number') {
        const liveCount = res.totalLikes;
        const applyExactCount = (songs: Song[]) =>
          songs.map((s) => (s.id === songId ? { ...s, likes: liveCount } : s));
        setNewSongs(applyExactCount);
        setTrendingSongs((prev) => {
          const updated = applyExactCount(prev);
          return [...updated].sort(
            (a, b) => (b.likes || 0) - (a.likes || 0) || (b.plays || 0) - (a.plays || 0)
          );
        });
        setHot100Songs(applyExactCount);
      }
    } catch (err) {
      console.warn('Notice syncing like:', err);
    } finally {
      likeInFlightRef.current.delete(songId);
    }
  };

  const applySongDownloadsUpdate = useCallback((songId: string, nextDownloadsCount: number) => {
    const safeCount = Math.max(0, nextDownloadsCount);
    const updateSongList = (songs: Song[]) =>
      songs.map((s) => (s.id === songId ? { ...s, downloadsCount: safeCount } : s));

    setNewSongs(updateSongList);
    setTrendingSongs(updateSongList);
    setHot100Songs((prev) => {
      const updated = updateSongList(prev);
      return [...updated]
        .sort(
          (a, b) =>
            (b.likes || 0) + (b.plays || 0) + (b.downloadsCount || 0) -
            ((a.likes || 0) + (a.plays || 0) + (a.downloadsCount || 0))
        )
        .map((s, idx) => ({ ...s, rank: idx + 1 }));
    });
    setCurrentSong((prev) => (prev && prev.id === songId ? { ...prev, downloadsCount: safeCount } : prev));
    setShareSong((prev) => (prev && prev.id === songId ? { ...prev, downloadsCount: safeCount } : prev));
    setSelectedSongDetails((prev) =>
      prev && prev.id === songId ? { ...prev, downloadsCount: safeCount } : prev
    );
  }, []);

  // Download Song (Free MP3) - downloads real audio from Supabase Storage or Cloudflare R2 and ONLY counts genuine completed downloads
  const handleDownloadSong = async (song: Song) => {
    if (!song?.id) return;

    if (!song.audioUrl || !song.audioUrl.trim()) {
      showToast('Audio file is not available for download on this track yet.');
      return;
    }

    if (downloadInFlightRef.current.has(song.id)) {
      return;
    }
    downloadInFlightRef.current.add(song.id);
    setDownloadingSongId(song.id);

    showToast(`Preparing "${song.title}.mp3" for download...`);

    try {
      // 1. Perform actual verified download first (works on Android, iPhone, tablets & desktop across Supabase + Cloudflare R2)
      const dlResult = await downloadWithTesoBranding(song.audioUrl, song.title, song.artist, (status) => {
        showToast(status);
      });

      // 2. Only record & increment download counter AFTER the audio file download succeeded
      const recordRes = await recordSongDownloadInSupabase(song.id, {
        currentDownloads: song.downloadsCount || 0,
        userId: currentUserId,
        storageSource: dlResult.storageSource,
        downloadMode: dlResult.mode,
      });

      if (typeof recordRes.downloadsCount === 'number') {
        applySongDownloadsUpdate(song.id, recordRes.downloadsCount);
      }

      if (dlResult.mode === 'branded') {
        showToast(`Download complete: "${song.title}" with Teso Melodies artwork!`);
      } else {
        showToast(`Download started: "${song.title}.mp3"`);
      }
    } catch (err) {
      console.warn('Download error (counter NOT incremented):', err);
      showToast('Could not complete download right now. Please check your connection and try again.');
    } finally {
      downloadInFlightRef.current.delete(song.id);
      setDownloadingSongId((prev) => (prev === song.id ? null : prev));
    }
  };

  // Follow Artist - sync to persistent database and Supabase without duplicate records
  const handleFollowArtist = async (artistId: string) => {
    const targetArtist =
      allDisplayedArtists.find(
        (a) => a.id === artistId || a.name.toLowerCase().trim() === artistId.toLowerCase().trim()
      ) ||
      (selectedArtist &&
      (selectedArtist.id === artistId ||
        selectedArtist.name.toLowerCase().trim() === artistId.toLowerCase().trim())
        ? selectedArtist
        : null);

    if (!targetArtist) return;

    const lockKey = (targetArtist.name || targetArtist.id).toLowerCase().trim();
    if (followInFlightRef.current.has(lockKey)) return;
    followInFlightRef.current.add(lockKey);

    const visitorId = getOrCreateVisitorId();
    const effectiveUserId = currentUserId || visitorId;
    const isSameArtist = (a: Artist) =>
      a.id === artistId ||
      (targetArtist.name && a.name.toLowerCase().trim() === targetArtist.name.toLowerCase().trim());

    const prevFollowed = Boolean(targetArtist.isFollowed);
    const artistSongsCount =
      typeof targetArtist.totalSongs === 'number'
        ? targetArtist.totalSongs
        : allSongs.filter(
            (s) => s.artist.toLowerCase().trim() === targetArtist.name.toLowerCase().trim()
          ).length;
    const bonusFollowers =
      typeof targetArtist.songBonusFollowers === 'number'
        ? targetArtist.songBonusFollowers
        : calculateSongMilestoneFollowers(artistSongsCount);
    const prevFollowers = Math.max(bonusFollowers, targetArtist.followers || bonusFollowers);
    const prevRealFollowers = Math.max(0, targetArtist.realFollowers ?? (prevFollowers - bonusFollowers));
    const nextFollow = !prevFollowed;
    const optimisticReal = nextFollow ? prevRealFollowers + 1 : Math.max(0, prevRealFollowers - 1);

    const applyFollowState = (
      artist: Artist,
      nextIsFollowed: boolean,
      nextReal: number,
      nextBonus: number
    ): Artist => ({
      ...artist,
      isFollowed: nextIsFollowed,
      realFollowers: nextReal,
      songBonusFollowers: nextBonus,
      followers: nextReal + nextBonus,
    });

    // 1. Immediately update Top Artist, Real Artists, and Artist Modal optimistically
    if (topArtist && isSameArtist(topArtist)) {
      setTopArtist((prev) =>
        prev ? applyFollowState(prev, nextFollow, optimisticReal, bonusFollowers) : null
      );
    }

    setRealArtists((prev) =>
      prev.map((a) =>
        isSameArtist(a) ? applyFollowState(a, nextFollow, optimisticReal, bonusFollowers) : a
      )
    );

    setSelectedArtist((prev) =>
      prev && isSameArtist(prev)
        ? applyFollowState(prev, nextFollow, optimisticReal, bonusFollowers)
        : prev
    );

    showToast(nextFollow ? `Following ${targetArtist.name}! ❤️` : `Unfollowed ${targetArtist.name}`);

    // 4. Save follow asynchronously to Supabase and backend
    try {
      const res = await toggleFollowArtistInSupabase(
        effectiveUserId,
        artistId,
        prevFollowed,
        targetArtist.name,
        currentUser.email,
        currentUser.stageName || currentUser.name,
        {
          artistUserId: targetArtist.legacyFollowUserId,
          songCount: artistSongsCount,
        }
      );

      if (!res.success && typeof res.followers !== 'number') {
        setTopArtist((prev) =>
          prev && isSameArtist(prev)
            ? applyFollowState(prev, prevFollowed, prevRealFollowers, bonusFollowers)
            : prev
        );
        setRealArtists((prev) =>
          prev.map((a) =>
            isSameArtist(a)
              ? applyFollowState(a, prevFollowed, prevRealFollowers, bonusFollowers)
              : a
          )
        );
        setSelectedArtist((prev) =>
          prev && isSameArtist(prev)
            ? applyFollowState(prev, prevFollowed, prevRealFollowers, bonusFollowers)
            : prev
        );
        showToast(res.error || 'Could not update follow status right now.');
      } else if (typeof res.followers === 'number') {
        const liveBonus =
          typeof res.bonusFollowers === 'number' ? Math.max(0, res.bonusFollowers) : bonusFollowers;
        const liveReal =
          typeof res.realFollowers === 'number'
            ? Math.max(0, res.realFollowers)
            : Math.max(0, res.followers - liveBonus);
        const liveFollowed = res.isFollowed;

        setRealArtists((prev) => {
          const updated = prev
            .map((a) =>
              isSameArtist(a) ? applyFollowState(a, liveFollowed, liveReal, liveBonus) : a
            )
            .sort(
              (a, b) =>
                (b.followers || 0) - (a.followers || 0) ||
                (b.totalLikes || 0) - (a.totalLikes || 0) ||
                (b.totalSongs || 0) - (a.totalSongs || 0)
            );
          if (updated.length > 0) {
            setTopArtist(updated[0]);
          }
          return updated;
        });
        setSelectedArtist((prev) =>
          prev && isSameArtist(prev)
            ? applyFollowState(prev, liveFollowed, liveReal, liveBonus)
            : prev
        );
      }
    } catch (err) {
      console.warn('Notice saving artist follow:', err);
      setTopArtist((prev) =>
        prev && isSameArtist(prev)
          ? applyFollowState(prev, prevFollowed, prevRealFollowers, bonusFollowers)
          : prev
      );
      setRealArtists((prev) =>
        prev.map((a) =>
          isSameArtist(a)
            ? applyFollowState(a, prevFollowed, prevRealFollowers, bonusFollowers)
            : a
        )
      );
      setSelectedArtist((prev) =>
        prev && isSameArtist(prev)
          ? applyFollowState(prev, prevFollowed, prevRealFollowers, bonusFollowers)
          : prev
      );
      showToast('Could not save follow status. Please try again.');
    } finally {
      followInFlightRef.current.delete(lockKey);
    }
  };

  // User Auth
  const handleLogin = (
    identifier: string,
    userEmail?: string,
    avatarUrl?: string,
    role?: 'fan' | 'artist',
    stageName?: string,
    genre?: string,
    bio?: string,
    location?: string,
    userId?: string
  ) => {
    const finalUserId = userId || currentUserId || undefined;
    const finalEmail = userEmail || (identifier.includes('@') ? identifier : undefined);

    // Auto-detect stage name and artist role if user has uploaded songs in public.songs
    const userTracks = allSongs.filter(
      (s) =>
        (finalUserId && s.userId === finalUserId) ||
        (finalEmail && s.userId && s.artist && s.artist.toLowerCase() === finalEmail.split('@')[0].toLowerCase())
    );

    const detectedStageName = stageName || (userTracks.length > 0 ? userTracks[0].artist : undefined);
    const cleanName = detectedStageName || (identifier.includes('@') ? identifier.split('@')[0] : identifier);
    const resolvedEmail = finalEmail || `${cleanName.toLowerCase().replace(/[^a-z0-9_]/g, '')}@gmail.com`;
    const resolvedRole = userTracks.length > 0 || detectedStageName || role === 'artist' ? 'artist' : (role || 'fan');

    if (finalUserId) {
      setCurrentUserId(finalUserId);
    }

    setCurrentUser({
      id: finalUserId,
      name: cleanName,
      username: cleanName.toLowerCase().replace(/[^a-z0-9_]/g, '_'),
      email: resolvedEmail,
      avatar: avatarUrl || (userTracks[0]?.coverUrl) || undefined,
      isLoggedIn: true,
      role: resolvedRole,
      stageName: detectedStageName,
      genre: genre || userTracks[0]?.genre || undefined,
      bio: bio || undefined,
      location: location || 'Teso, Uganda',
    });

    // Ensure currentUserId is populated from active Supabase session & sync data
    supabase.auth.getSession().then(({ data: { session } }) => {
      const activeUid = session?.user?.id || finalUserId;
      if (activeUid) {
        setCurrentUserId(activeUid);

        // Migrate unique guest follows to Supabase for this logged-in account
        if (typeof window !== 'undefined') {
          try {
            const guestRaw = localStorage.getItem('teso_guest_followed_artists');
            if (guestRaw) {
              const guestFollows = JSON.parse(guestRaw);
              if (Array.isArray(guestFollows) && guestFollows.length > 0) {
                const uniqueSlugs = Array.from(
                  new Set(
                    guestFollows
                      .map((k: string) =>
                        String(k || '')
                          .toLowerCase()
                          .trim()
                          .replace(/[^a-z0-9]+/g, '-')
                          .replace(/^-|-$/g, '')
                      )
                      .filter(Boolean)
                  )
                );
                uniqueSlugs.forEach((slug) => {
                  const matched = allDisplayedArtists.find(
                    (a) =>
                      a.id.toLowerCase() === slug ||
                      a.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') === slug
                  );
                  if (!matched?.isFollowed) {
                    toggleFollowArtistInSupabase(activeUid, slug, false, matched?.name || slug, undefined, undefined, {
                      artistUserId: matched?.legacyFollowUserId,
                      songCount: matched?.totalSongs || 0,
                    });
                  }
                });
                localStorage.removeItem('teso_guest_followed_artists');
              }
            }
          } catch {
            // ignore
          }
        }

        // Re-fetch all songs and artists for this user
        syncSongsAndUserData(activeUid);
      }
    });

    showToast(`Welcome, ${cleanName}! ${resolvedRole === 'artist' ? '🎵 Artist Account' : '🎧 Member Account'}`);
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
    } catch {
      // ignore
    }
    setCurrentUserId(null);
    setCurrentUser({
      name: '',
      username: '',
      email: '',
      isLoggedIn: false,
      role: 'fan',
    });
    if (activeTab === 'admin' || activeTab === 'dashboard' || activeTab === 'wallet') {
      handleNavigate('home');
    }
    // Re-fetch artists without user session to reset followed states
    syncSongsAndUserData(null);
    showToast('You have been logged out.');
  };

  // CREATE Song - Insert new item into Supabase database & make publicly available
  const handleUploadSuccess = async (newSongData: Partial<Song>) => {
    const {
      data: { session },
    } = await supabase.auth.getSession();
    const effectiveUid = session?.user?.id || currentUserId || currentUser.id;

    const { song: dbCreatedSong, error: createError } = await createSongInSupabase(
      newSongData,
      effectiveUid || undefined
    );

    if (createError || !dbCreatedSong) {
      showToast(`Upload error: ${createError || 'Could not save song to database.'}`);
      return;
    }

    // Increment artist's song count and immediately stack +20 followers per 5 songs milestone
    const uploadedArtistName = (dbCreatedSong.artist || newSongData.artist || '').trim().toLowerCase();
    setRealArtists((prev) => {
      let found = false;
      const updated = prev.map((artist) => {
        if (artist.name.toLowerCase().trim() === uploadedArtistName) {
          found = true;
          const nextSongs = (artist.totalSongs || 0) + 1;
          const prevBonus =
            typeof artist.songBonusFollowers === 'number'
              ? artist.songBonusFollowers
              : calculateSongMilestoneFollowers(artist.totalSongs || 0);
          const realCount = Math.max(0, artist.realFollowers ?? (artist.followers - prevBonus));
          const nextBonus = calculateSongMilestoneFollowers(nextSongs);
          return {
            ...artist,
            totalSongs: nextSongs,
            realFollowers: realCount,
            songBonusFollowers: nextBonus,
            followers: realCount + nextBonus,
          };
        }
        return artist;
      });
      if (!found && dbCreatedSong.artist) {
        updated.push({
          id: (dbCreatedSong.artist || 'artist').toLowerCase().trim().replace(/[^a-z0-9]/g, '-'),
          name: dbCreatedSong.artist,
          genre: dbCreatedSong.genre || 'Afrobeat',
          followers: 0,
          realFollowers: 0,
          songBonusFollowers: 0,
          totalLikes: 0,
          totalSongs: 1,
          avatar: dbCreatedSong.coverUrl || HERO_ASSETS.announcement,
          bio: `${dbCreatedSong.artist} is an active recording artist on Teso Melodies.`,
          monthlyListeners: '0 likes',
          isRealArtist: true,
          topTracks: [dbCreatedSong.title || 'Untitled'],
        });
      }
      return updated;
    });

    setTopArtist((prev) => {
      if (prev && prev.name.toLowerCase().trim() === uploadedArtistName) {
        const nextSongs = (prev.totalSongs || 0) + 1;
        const prevBonus =
          typeof prev.songBonusFollowers === 'number'
            ? prev.songBonusFollowers
            : calculateSongMilestoneFollowers(prev.totalSongs || 0);
        const realCount = Math.max(0, prev.realFollowers ?? (prev.followers - prevBonus));
        const nextBonus = calculateSongMilestoneFollowers(nextSongs);
        return {
          ...prev,
          totalSongs: nextSongs,
          realFollowers: realCount,
          songBonusFollowers: nextBonus,
          followers: realCount + nextBonus,
        };
      }
      return prev;
    });

    // Refresh song list automatically from Supabase without manual page refresh
    await syncSongsAndUserData(effectiveUid);

    showToast(`"${dbCreatedSong.title}" uploaded & published on Teso Melodies!`);
  };

  // DELETE Song - Remove item and files from Supabase Storage & database
  const handleDeleteSong = async (songId: string) => {
    const songToDelete = allSongs.find((s) => s.id === songId);
    await deleteSongFromSupabase(songId, songToDelete?.audioUrl, songToDelete?.coverUrl);

    setNewSongs((prev) => prev.filter((s) => s.id !== songId));
    setTrendingSongs((prev) => prev.filter((s) => s.id !== songId));
    setHot100Songs((prev) => prev.filter((s) => s.id !== songId));

    if (currentSong?.id === songId) {
      handleClosePlayer();
    }
    showToast('Track deleted successfully.');
  };

  // --- Video System Handlers (Strictly isolated from audio tracks) ---
  const handleSelectVideo = useCallback((video: VideoItem) => {
    // Pause any active audio track so video audio plays cleanly
    if (audioRef.current && !audioRef.current.paused) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
    audioEngine.stop();

    const nextViews = (video.viewsCount || 0) + 1;
    const optimisticVideo: VideoItem = {
      ...video,
      viewsCount: nextViews,
      views: formatVideoViews(nextViews),
    };

    setSelectedVideo(optimisticVideo);
    setVideos((prev) => prev.map((v) => (v.id === video.id ? optimisticVideo : v)));

    if (typeof window !== 'undefined') {
      const targetUrl = `/video/${encodeURIComponent(video.id)}`;
      if (window.location.pathname !== targetUrl) {
        window.history.pushState({ modal: 'video', videoId: video.id }, '', targetUrl);
      }
      document.title = `${video.title} — ${video.artist} | TESO MELODIES Videos`;
    }

    incrementVideoViewsInSupabase(video.id).then((persistedViews) => {
      if (typeof persistedViews === 'number') {
        const syncedFmt = formatVideoViews(persistedViews);
        setVideos((prev) =>
          prev.map((v) => (v.id === video.id ? { ...v, viewsCount: persistedViews, views: syncedFmt } : v))
        );
        setSelectedVideo((prev) =>
          prev && prev.id === video.id ? { ...prev, viewsCount: persistedViews, views: syncedFmt } : prev
        );
      }
    });
  }, []);

  const handleCloseVideo = useCallback(() => {
    setSelectedVideo(null);
    if (typeof window !== 'undefined') {
      if (window.location.pathname.toLowerCase().startsWith('/video/') || window.location.search.includes('video=')) {
        window.history.pushState({}, '', '/videos');
      }
      document.title = 'TESO MELODIES - Music Unites Us | Stream, Download & Share';
    }
  }, []);

  const handleLikeVideo = useCallback(
    async (videoId: string) => {
      const currentlyLiked = likedVideoIds.has(videoId);
      const effectiveUserId = currentUserId || getOrCreateVisitorId();
      const delta = currentlyLiked ? -1 : 1;

      setLikedVideoIds((prev) => {
        const next = new Set(prev);
        if (currentlyLiked) next.delete(videoId);
        else next.add(videoId);
        return next;
      });

      setVideos((prev) =>
        prev.map((v) => (v.id === videoId ? { ...v, likes: Math.max(0, (v.likes || 0) + delta) } : v))
      );
      setSelectedVideo((prev) =>
        prev && prev.id === videoId ? { ...prev, likes: Math.max(0, (prev.likes || 0) + delta) } : prev
      );

      showToast(currentlyLiked ? 'Removed video like' : 'Liked video!');

      const res = await toggleVideoLikeInSupabase(videoId, effectiveUserId, currentlyLiked);
      if (typeof res.likesCount === 'number') {
        const exactLikes = res.likesCount;
        setVideos((prev) => prev.map((v) => (v.id === videoId ? { ...v, likes: exactLikes } : v)));
        setSelectedVideo((prev) =>
          prev && prev.id === videoId ? { ...prev, likes: exactLikes } : prev
        );
      }
    },
    [likedVideoIds, currentUserId]
  );

  const handleDeleteVideo = useCallback(async (video: VideoItem) => {
    const res = await deleteVideoFromSupabase(video);
    if (!res.success) {
      showToast(`Delete failed: ${res.error || 'Could not remove video.'}`);
      return;
    }
    setVideos((prev) => prev.filter((v) => v.id !== video.id));
    setSelectedVideo((prev) => {
      if (prev?.id === video.id) {
        if (
          typeof window !== 'undefined' &&
          (window.location.pathname.toLowerCase().startsWith('/video/') ||
            window.location.search.includes('video='))
        ) {
          window.history.pushState({}, '', '/videos');
        }
        return null;
      }
      return prev;
    });
    showToast(`Video "${video.title}" deleted.`);
  }, []);

  const handleShareVideo = useCallback((video: VideoItem) => {
    setShareSong(null);
    setShareVideo(video);
  }, []);

  const handleVideoCreated = useCallback((newVideo: VideoItem) => {
    setVideos((prev) => [newVideo, ...prev.filter((v) => v.id !== newVideo.id)]);
    setVideosError(null);
    if (activeTab !== 'videos') {
      handleNavigate('videos');
    }
    showToast(`Video "${newVideo.title}" uploaded & live in Videos!`);
  }, [activeTab]);

  // My Uploaded Songs for Artist Dashboard & Management
  const myUploadedSongs = useMemo(() => {
    const effectiveUserId = currentUserId || currentUser.id;
    if (!effectiveUserId && !currentUser.stageName && !currentUser.name && !currentUser.email) return [];

    return allSongs.filter((s) => {
      // 1. Authoritative user_id match
      if (effectiveUserId && s.userId && s.userId === effectiveUserId) return true;

      // 2. Stage name match (case-insensitive)
      if (currentUser.stageName && s.artist && s.artist.toLowerCase().trim() === currentUser.stageName.toLowerCase().trim()) return true;

      // 3. User display name match (case-insensitive)
      if (currentUser.name && s.artist && s.artist.toLowerCase().trim() === currentUser.name.toLowerCase().trim()) return true;

      // 4. Email prefix match
      if (currentUser.email && s.artist) {
        const prefix = currentUser.email.split('@')[0].toLowerCase().trim();
        const artistLower = s.artist.toLowerCase().trim();
        if (artistLower.includes(prefix) || prefix.includes(artistLower)) return true;
      }

      return false;
    });
  }, [allSongs, currentUserId, currentUser.id, currentUser.stageName, currentUser.name, currentUser.email]);

  const totalMyLikes = useMemo(() => {
    return myUploadedSongs.reduce((sum, s) => sum + (s.likes || 0), 0);
  }, [myUploadedSongs]);

  const totalMyDownloads = useMemo(() => {
    return myUploadedSongs.reduce((sum, s) => sum + (s.downloadsCount || 0), 0);
  }, [myUploadedSongs]);

  // Filtered Songs based on Search or Selected Genre (supports exact DB genres & regional collections like Teso Gospel Music)
  const filteredNewSongs = useMemo(() => {
    return newSongs.filter((s) => {
      const matchesSearch =
        !searchQuery ||
        s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.artist.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesGenre = songMatchesSelectedGenre(s.genre, selectedGenre);
      return matchesSearch && matchesGenre;
    });
  }, [newSongs, searchQuery, selectedGenre]);

  const filteredTrendingSongs = useMemo(() => {
    return trendingSongs.filter((s) => {
      const matchesSearch =
        !searchQuery ||
        s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.artist.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesGenre = songMatchesSelectedGenre(s.genre, selectedGenre);
      return matchesSearch && matchesGenre;
    });
  }, [trendingSongs, searchQuery, selectedGenre]);

  const filteredHot100Songs = useMemo(() => {
    return hot100Songs.filter((s) => {
      const matchesSearch =
        !searchQuery ||
        s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.artist.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesGenre = songMatchesSelectedGenre(s.genre, selectedGenre);
      return matchesSearch && matchesGenre;
    });
  }, [hot100Songs, searchQuery, selectedGenre]);

  // Dynamic Client-Side SEO Metadata & Structured Data Synchronization
  useEffect(() => {
    if (selectedSongDetails) {
      updateDocumentSeo(buildClientSongSeo(selectedSongDetails));
      return;
    }

    if (selectedArtist) {
      const artistSongs = allSongs.filter(
        (s) =>
          s.artist.toLowerCase().trim() === selectedArtist.name.toLowerCase().trim() ||
          (selectedArtist.userId && s.userId === selectedArtist.userId)
      );
      updateDocumentSeo(buildClientArtistSeo(selectedArtist, artistSongs));
      return;
    }

    if (selectedVideo) {
      updateDocumentSeo({
        title: `${selectedVideo.title} by ${selectedVideo.artist} – Official Music Video | TESO MELODIES`,
        description: `Watch "${selectedVideo.title}" by ${selectedVideo.artist} (${selectedVideo.category || 'Music Video'}) online on TESO MELODIES.`,
        path: `/video/${encodeURIComponent(selectedVideo.id)}`,
        image: selectedVideo.thumbnail,
      });
      return;
    }

    if (
      typeof window !== 'undefined' &&
      window.location.pathname.toLowerCase().startsWith('/song/') &&
      currentSong
    ) {
      updateDocumentSeo(buildClientSongSeo(currentSong));
      return;
    }

    if (selectedGenre) {
      updateDocumentSeo(buildClientGenreSeo(selectedGenre, filteredNewSongs.length));
      return;
    }

    if (activeTab === 'music') {
      updateDocumentSeo({
        title: 'All Teso & Ugandan Songs – Free MP3 Downloads & Streaming | TESO MELODIES',
        description: `Browse, stream online, and download ${allSongs.length || ''} Teso, Ugandan, Gospel, Dancehall, and Afrobeat MP3 songs free on TESO MELODIES.`.replace(/\s+/g, ' '),
        path: '/music',
      });
    } else if (activeTab === 'artists') {
      updateDocumentSeo({
        title: 'Teso & Ugandan Music Artists – Profiles, Songs & MP3 Downloads | TESO MELODIES',
        description: 'Explore verified Teso and Ugandan musicians, gospel singers, and dancehall artists. Listen to full discographies and download MP3 tracks free.',
        path: '/artists',
      });
    } else if (activeTab === 'videos') {
      updateDocumentSeo({
        title: 'Teso & Ugandan Music Videos – Watch Official Videos Online | TESO MELODIES',
        description: 'Watch official Teso, Ugandan, and East African music videos, worship sessions, and live performances free on TESO MELODIES.',
        path: '/videos',
      });
    } else if (activeTab === 'charts') {
      updateDocumentSeo({
        title: 'Top Teso & Ugandan Music Charts – Trending & Hot 100 MP3s | TESO MELODIES',
        description: 'Discover the hottest trending Teso worship, dancehall, gospel, and Afrobeat songs ranked by real listens, likes, and MP3 downloads.',
        path: '/charts',
      });
    } else if (activeTab === 'news') {
      updateDocumentSeo({
        title: 'Teso Music News, Releases & Announcements | TESO MELODIES',
        description: 'Read official music announcements, new song release updates, and artist news from Teso and Uganda.',
        path: '/news',
      });
    } else if (activeTab === 'about') {
      updateDocumentSeo({
        title: 'About TESO MELODIES – Ugandan & Teso Music Streaming & MP3 Downloads',
        description: 'Learn about TESO MELODIES, East Africa\'s music platform connecting Teso and Ugandan artists with fans worldwide.',
        path: '/about',
      });
    } else if (activeTab === 'privacy-policy') {
      updateDocumentSeo({
        title: 'Privacy Policy | TESO MELODIES',
        description: 'Read the official TESO MELODIES Privacy Policy covering listener privacy, artist profiles, and platform data protection.',
        path: '/privacy-policy',
      });
    } else if (activeTab === 'wallet') {
      updateDocumentSeo({
        title: 'Artist Wallet | TESO MELODIES',
        description: 'View your verified UGX available balance, total earnings, pending earnings, withdrawals, and transaction history on TESO MELODIES.',
        path: '/wallet',
      });
    } else if (activeTab === 'terms-and-conditions') {
      updateDocumentSeo({
        title: 'Terms and Conditions | TESO MELODIES',
        description: 'Review TESO MELODIES Terms and Conditions, artist copyright ownership, and content publishing guidelines.',
        path: '/terms-and-conditions',
      });
    } else {
      updateDocumentSeo({
        title: 'TESO MELODIES – Free Teso, Ugandan & African Music MP3 Downloads & Streaming',
        description: 'Stream and download the latest Teso music, Teso gospel & worship songs, Teso dancehall, Afrobeat, and Ugandan MP3 hits free online.',
        path: '/',
      });
    }
  }, [
    selectedSongDetails,
    selectedArtist,
    selectedVideo,
    selectedGenre,
    activeTab,
    currentSong,
    allSongs,
    filteredNewSongs.length,
  ]);

  const matchingSearchArtists = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return [];
    return allDisplayedArtists.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        (a.genre && a.genre.toLowerCase().includes(q))
    );
  }, [allDisplayedArtists, searchQuery]);

  const effectiveArtistSearch = (artistSearchQuery || searchQuery).trim();

  const isLegalTab = activeTab === 'privacy-policy' || activeTab === 'terms-and-conditions';
  const isWideTab = isLegalTab || activeTab === 'admin';

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0055d4] via-[#0066eb] to-[#012f86] text-slate-100 flex flex-col font-sans selection:bg-[#FFCC00] selection:text-black">
      
      {/* 1. Header Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={handleNavigate}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenLogin={() => setAuthModal({ isOpen: true, mode: 'signin' })}
        onOpenSignUp={() => setAuthModal({ isOpen: true, mode: 'signup' })}
        currentUser={currentUser}
        onLogout={handleLogout}
        showInstallApp={!pwa.isInstalled}
        onOpenInstallApp={pwa.openInstallModal}
      />

      {/* 2. Main Dashboard Container */}
      <main className="flex-1 max-w-[1520px] w-full mx-auto px-3 sm:px-5 lg:px-6 py-4 md:py-6">
        
        {/* Active Search / Genre Filter Banner if active */}
        {(searchQuery || selectedGenre) && (
          <div className="mb-4 space-y-3">
            <div className="p-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 flex items-center justify-between">
              <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-2 flex-wrap">
                <span>Filtering by:</span>
                {searchQuery && (
                  <span className="px-2.5 py-1 bg-yellow-400 text-black rounded-full font-bold">
                    "{searchQuery}"
                  </span>
                )}
                {selectedGenre && (
                  <span className="px-2.5 py-1 bg-[#0072ce] text-white rounded-full font-bold">
                    Genre: {selectedGenre}
                  </span>
                )}
              </div>
              <button
                onClick={() => {
                  setSearchQuery('');
                  handleSelectGenre(null);
                }}
                className="text-xs text-yellow-300 hover:text-white font-bold underline cursor-pointer shrink-0"
              >
                Clear Filters
              </button>
            </div>

            {/* Matching Artist Search Results with live combined followers from artist_follower_stats */}
            {searchQuery.trim() &&
              activeTab !== 'artists' &&
              activeTab !== 'admin' &&
              matchingSearchArtists.length > 0 && (
                <div className="bg-white rounded-2xl p-4 shadow-xl border border-slate-100">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-black text-[#032b69] flex items-center gap-2">
                      <Users className="w-4 h-4 text-[#e91e63]" />
                      <span>Matching Artists ({matchingSearchArtists.length})</span>
                    </h3>
                    <button
                      onClick={() => {
                        setArtistSearchQuery(searchQuery);
                        handleNavigate('artists');
                      }}
                      className="text-xs font-bold text-[#0072ce] hover:underline cursor-pointer"
                    >
                      View in Artists →
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {matchingSearchArtists.slice(0, 6).map((artist, idx) => (
                      <div
                        key={`search-artist-${artist.id}-${idx}`}
                        className="flex items-center justify-between gap-2.5 p-2.5 rounded-xl bg-slate-50 hover:bg-blue-50/70 border border-slate-200/80 transition-colors"
                      >
                        <a
                          href={getArtistSeoPath(artist.name)}
                          onClick={(e) => {
                            if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
                            e.preventDefault();
                            handleOpenArtist(artist);
                          }}
                          className="flex items-center gap-2.5 min-w-0 flex-1 text-left cursor-pointer group"
                        >
                          <div className="w-11 h-11 rounded-full overflow-hidden shrink-0 ring-2 ring-yellow-400 bg-slate-200">
                            <img
                              src={artist.avatar || HERO_ASSETS.announcement}
                              alt={artist.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                          <div className="min-w-0">
                            <div className="text-xs font-black text-slate-900 group-hover:text-[#0072ce] truncate">
                              {artist.name}
                            </div>
                            <div className="text-[11px] text-slate-500 font-semibold truncate">
                              {artist.followers === 1
                                ? '1 follower'
                                : `${(artist.followers || 0).toLocaleString()} followers`}
                              {typeof artist.totalSongs === 'number' && artist.totalSongs > 0
                                ? ` • ${artist.totalSongs} ${artist.totalSongs === 1 ? 'song' : 'songs'}`
                                : ''}
                            </div>
                          </div>
                        </a>
                        <button
                          type="button"
                          onClick={() => handleFollowArtist(artist.id)}
                          className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer shrink-0 ${
                            artist.isFollowed
                              ? 'bg-slate-200 text-slate-800 hover:bg-slate-300'
                              : 'bg-[#0072ce] hover:bg-[#005fb8] text-white'
                          }`}
                        >
                          {artist.isFollowed ? 'Following' : 'Follow'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
          </div>
        )}

        {/* Master Two-Column Grid: Main Content (Left) + Sidebar (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 xl:gap-6 items-start">
          
          {/* LEFT SECTION (Hero, Genres, 3 Columns OR Active Tab View) */}
          <div
            className={`${
              activeTab === 'admin'
                ? 'lg:col-span-12 w-full'
                : isLegalTab
                ? 'lg:col-span-12 max-w-5xl mx-auto w-full'
                : 'lg:col-span-8 xl:col-span-9'
            } space-y-5 xl:space-y-6`}
          >
            
            {/* Active Tab View: Private Admin News Panel (tesomelodies@gmail.com only) */}
            {activeTab === 'admin' ? (
              <AdminNewsPanel
                currentUser={currentUser}
                onBackToSite={() => handleNavigate('home')}
                onToast={showToast}
                onNewsChanged={refreshPublishedNews}
              />
            ) : activeTab === 'wallet' ? (
              <ArtistWalletPage
                currentUser={currentUser}
                currentUserId={currentUserId}
                onBackToDashboard={() => handleNavigate('dashboard')}
                onToast={showToast}
                onVerificationChange={setIsEarningsVerified}
              />
            ) : activeTab === 'dashboard' ? (
              <div className="space-y-5">
                {/* 1. Artist Profile Card / Banner */}
                <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5 pb-5 border-b border-slate-100">
                    <div className="flex items-center gap-4">
                      <div className="relative group">
                        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden bg-gradient-to-tr from-[#0055d4] to-yellow-400 p-0.5 shadow-md flex-shrink-0">
                          {currentUser.avatar ? (
                            <img
                              src={currentUser.avatar}
                              alt={currentUser.stageName || currentUser.name || 'Artist'}
                              className="w-full h-full object-cover rounded-[14px]"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-full h-full bg-slate-900 flex items-center justify-center text-yellow-400 font-black text-2xl rounded-[14px]">
                              {(currentUser.stageName || currentUser.name || 'A').charAt(0).toUpperCase()}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <h2 className="text-xl sm:text-2xl font-black text-[#032b69] tracking-tight">
                            {currentUser.stageName || currentUser.name || 'Artist Portal'}
                          </h2>
                          {isEarningsVerified === true ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-[11px] font-black rounded-full border border-emerald-200">
                              <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                              <span>Verified Artist</span>
                            </span>
                          ) : isEarningsVerified === false ? (
                            <span className="px-2.5 py-0.5 bg-amber-100 text-amber-900 text-[11px] font-black rounded-full border border-amber-200">
                              Unverified Account
                            </span>
                          ) : (
                            <span className="px-2.5 py-0.5 bg-yellow-400/20 text-[#032b69] text-[11px] font-black rounded-full border border-yellow-400/40">
                              {currentUser.role === 'artist' ? 'Artist Account' : 'Member Account'}
                            </span>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-500 font-medium">
                          <span className="flex items-center gap-1 text-slate-600">
                            <MapPin className="w-3.5 h-3.5 text-[#0072ce]" />
                            {currentUser.location || 'Teso, Uganda'}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1 text-slate-600">
                            <Music2 className="w-3.5 h-3.5 text-[#0072ce]" />
                            {currentUser.genre || 'Afrobeat'}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1 text-[#032b69] font-bold">
                            <Users className="w-3.5 h-3.5 text-[#0072ce]" />
                            {(() => {
                              const myArtist = allDisplayedArtists.find(
                                (a) =>
                                  (currentUserId && a.userId === currentUserId) ||
                                  (currentUser.stageName &&
                                    a.name.toLowerCase().trim() ===
                                      currentUser.stageName.toLowerCase().trim()) ||
                                  (currentUser.name &&
                                    a.name.toLowerCase().trim() ===
                                      currentUser.name.toLowerCase().trim())
                              );
                              const count = myArtist?.followers || 0;
                              return count === 1
                                ? '1 follower'
                                : `${count.toLocaleString()} followers`;
                            })()}
                          </span>
                          {currentUser.email && (
                            <>
                              <span>•</span>
                              <span className="text-slate-400">{currentUser.email}</span>
                            </>
                          )}
                        </div>

                        {currentUser.bio && (
                          <p className="text-xs text-slate-600 line-clamp-2 pt-1 font-normal max-w-xl">
                            "{currentUser.bio}"
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Quick Profile Actions */}
                    <div className="flex flex-wrap items-center gap-2 self-stretch sm:self-auto">
                      <button
                        onClick={() => setIsArtistSetupOpen(true)}
                        className="flex-1 sm:flex-none px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-yellow-600" />
                        <span>Edit Profile</span>
                      </button>
                      <button
                        onClick={() => handleNavigate('wallet')}
                        className="flex-1 sm:flex-none px-3.5 py-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Wallet className="w-3.5 h-3.5" />
                        <span>Artist Wallet</span>
                      </button>
                      <button
                        onClick={() => handleProtectedAction(() => setIsUploadOpen(true))}
                        className="w-full sm:w-auto px-4 py-2 bg-[#0072ce] hover:bg-blue-600 text-white font-bold text-xs rounded-xl shadow transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload Music</span>
                      </button>
                    </div>
                  </div>

                  {/* 2. Artist Metrics Grid: 3 Balanced Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 mt-5">
                    {/* Card 1: Uploaded Tracks */}
                    <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm flex flex-col justify-between">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-slate-600">My Uploads</span>
                        <div className="w-8 h-8 rounded-lg bg-blue-100 text-[#0072ce] flex items-center justify-center">
                          <Music2 className="w-4 h-4" />
                        </div>
                      </div>
                      <div>
                        <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight tabular-nums">
                          {myUploadedSongs.length}
                        </div>
                        <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium mt-0.5">Permanent songs</p>
                      </div>
                    </div>

                    {/* Card 2: Total Likes */}
                    <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm flex flex-col justify-between">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-slate-600">Total Likes</span>
                        <div className="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
                          <Heart className="w-4 h-4" />
                        </div>
                      </div>
                      <div>
                        <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight tabular-nums">
                          {totalMyLikes}
                        </div>
                        <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium mt-0.5">Fan appreciations</p>
                      </div>
                    </div>

                    {/* Card 3: Total Downloads */}
                    <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm flex flex-col justify-between">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-slate-600">Downloads</span>
                        <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
                          <Download className="w-4 h-4" />
                        </div>
                      </div>
                      <div>
                        <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight tabular-nums">
                          {totalMyDownloads}
                        </div>
                        <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium mt-0.5">Listener downloads</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2B. Artist Verification, Earnings (UGX), Transactions, Payout Info & Withdrawals */}
                <ArtistEarningsSection
                  currentUser={currentUser}
                  currentUserId={currentUserId}
                  onToast={showToast}
                  onVerificationChange={setIsEarningsVerified}
                  onOpenWallet={() => handleNavigate('wallet')}
                />

                {/* 3. My Uploaded Songs (Music Management Section) */}
                <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100">
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg sm:text-xl font-black text-[#032b69] tracking-tight">
                        My Uploaded Songs
                      </h3>
                      <span className="px-2.5 py-0.5 bg-blue-50 text-[#0072ce] text-xs font-bold rounded-full">
                        {myUploadedSongs.length} {myUploadedSongs.length === 1 ? 'Track' : 'Tracks'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={async () => {
                          const activeUid = currentUserId || currentUser.id;
                          await syncSongsAndUserData(activeUid);
                          showToast('Refreshed your songs from database!');
                        }}
                        disabled={isLoadingSongs}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                        title="Sync with Supabase"
                      >
                        <RotateCw className={`w-3.5 h-3.5 ${isLoadingSongs ? 'animate-spin text-[#0072ce]' : ''}`} />
                        <span>Refresh</span>
                      </button>

                      <button
                        onClick={() => handleProtectedAction(() => setIsUploadOpen(true))}
                        className="px-3.5 py-1.5 bg-[#0072ce] hover:bg-blue-600 text-white font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload New Song</span>
                      </button>
                    </div>
                  </div>

                  {isLoadingSongs ? (
                    <div className="py-12 px-4 text-center rounded-2xl border border-slate-200 bg-slate-50/50">
                      <div className="w-10 h-10 mx-auto mb-3 rounded-xl bg-blue-100 text-[#0072ce] flex items-center justify-center animate-spin">
                        <RotateCw className="w-5 h-5" />
                      </div>
                      <h4 className="text-sm font-bold text-slate-800">Loading your tracks...</h4>
                      <p className="text-xs text-slate-400 mt-1">Retrieving songs from Supabase database</p>
                    </div>
                  ) : myUploadedSongs.length === 0 ? (
                    <div className="py-12 px-4 text-center rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50/50">
                      <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-blue-100 text-[#0072ce] flex items-center justify-center">
                        <Music2 className="w-7 h-7" />
                      </div>
                      <h4 className="text-base font-bold text-slate-800">No tracks uploaded yet</h4>
                      <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4 font-normal">
                        Upload your audio files with artwork directly to Supabase Storage. Your music will be permanently saved, publicly streamable, and downloadable worldwide!
                      </p>
                      <button
                        onClick={() => handleProtectedAction(() => setIsUploadOpen(true))}
                        className="px-4 py-2 bg-yellow-400 hover:bg-yellow-500 text-slate-950 font-bold text-xs rounded-xl shadow transition-all cursor-pointer inline-flex items-center gap-1.5"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload Your First Song</span>
                      </button>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100">
                      {myUploadedSongs.map((song, sIdx) => {
                        const isCurrentPlaying = currentSong?.id === song.id && isPlaying;
                        return (
                          <div
                            key={`uploaded-song-${song.id}-${sIdx}`}
                            className={`py-3.5 px-3 rounded-xl transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                              isCurrentPlaying ? 'bg-blue-50/70 border border-blue-200/60' : 'hover:bg-slate-50'
                            }`}
                          >
                            {/* Track Info */}
                            <div className="flex items-center gap-3 min-w-0 flex-1">
                              <div
                                onClick={() => handlePlaySong(song)}
                                className="relative w-12 h-12 rounded-xl overflow-hidden bg-slate-900 flex-shrink-0 cursor-pointer group shadow-sm"
                              >
                                <img
                                  src={song.coverUrl || HERO_ASSETS.announcement}
                                  alt={song.title}
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                                  referrerPolicy="no-referrer"
                                  onError={(e) => {
                                    (e.currentTarget as HTMLImageElement).src = HERO_ASSETS.announcement;
                                  }}
                                />
                                <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/60 transition-colors">
                                  {isCurrentPlaying ? (
                                    <div className="w-6 h-6 rounded-full bg-yellow-400 text-black flex items-center justify-center shadow">
                                      <div className="w-2 h-2 bg-black rounded-xs" />
                                    </div>
                                  ) : (
                                    <Play className="w-4 h-4 text-white fill-current ml-0.5" />
                                  )}
                                </div>
                              </div>

                              <div className="min-w-0 flex-1">
                                <h4 className="text-sm font-bold text-slate-900 leading-snug break-words">
                                  {song.title}
                                </h4>
                                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-medium mt-0.5">
                                  <span className="font-semibold text-slate-700 break-words">{song.artist}</span>
                                  <span>•</span>
                                  <span className="px-2 py-0.5 bg-slate-200/70 text-slate-700 text-[10px] font-bold rounded">
                                    {song.genre}
                                  </span>
                                  {song.createdAt && (
                                    <>
                                      <span>•</span>
                                      <span className="text-slate-400 text-[11px]">
                                        {new Date(song.createdAt).toLocaleDateString()}
                                      </span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>

                            {/* Metrics & Actions */}
                            <div className="flex items-center justify-between sm:justify-end gap-3 sm:gap-4 pl-15 sm:pl-0">
                              <div className="flex items-center gap-3 text-xs text-slate-500">
                                <span className="flex items-center gap-1" title="Plays">
                                  <Play className="w-3 h-3 text-slate-400" />
                                  <strong className="text-slate-700">{song.plays || 0}</strong>
                                </span>
                                <span className="flex items-center gap-1" title="Likes">
                                  <Heart className="w-3 h-3 text-red-500 fill-red-500/20" />
                                  <strong className="text-slate-700">{song.likes || 0}</strong>
                                </span>
                                <span className="flex items-center gap-1" title="Downloads">
                                  <Download className="w-3 h-3 text-emerald-600" />
                                  <strong className="text-slate-700">{song.downloadsCount || 0}</strong>
                                </span>
                              </div>

                              <div className="flex items-center gap-1.5">
                                <button
                                  onClick={() => handlePlaySong(song)}
                                  className={`p-2 rounded-lg font-bold text-xs transition-all cursor-pointer ${
                                    isCurrentPlaying
                                      ? 'bg-yellow-400 text-black'
                                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                                  }`}
                                  title={isCurrentPlaying ? 'Pause' : 'Play Song'}
                                >
                                  <Play className="w-3.5 h-3.5 fill-current" />
                                </button>
                                <button
                                  onClick={() => handleDownloadSong(song)}
                                  className="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg font-bold text-xs transition-all cursor-pointer"
                                  title="Download Original Audio"
                                >
                                  <Download className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => handleOpenComments(song)}
                                  className="p-2 bg-blue-50 hover:bg-blue-100 text-[#0072ce] rounded-lg font-bold text-xs transition-all cursor-pointer"
                                  title="View Reviews & Fan Comments"
                                >
                                  <MessageCircle className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => {
                                    if (window.confirm(`Permanently delete "${song.title}" from Supabase database and storage?`)) {
                                      handleDeleteSong(song.id);
                                    }
                                  }}
                                  className="p-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg font-bold text-xs transition-all cursor-pointer"
                                  title="Delete Song"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* 3. Legal & Creator Compliance Card */}
                <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#0072ce] flex items-center justify-center">
                        <ShieldCheck className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-base font-bold text-[#032b69]">Legal Policies & Creator Compliance</h3>
                        <p className="text-xs text-slate-500">
                          Official copyright terms, creator intellectual property protections, and privacy guidelines.
                        </p>
                      </div>
                    </div>
                    {isUserAdminEmail(currentUser.email) && (
                      <button
                        onClick={() => setAdminLegalModal({ isOpen: true, docType: 'privacy' })}
                        className="px-3.5 py-1.5 bg-[#032b69] hover:bg-[#0055d4] text-white text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 shadow-sm cursor-pointer self-start sm:self-auto"
                      >
                        <Shield className="w-3.5 h-3.5 text-yellow-400" />
                        Admin: Manage Legal Pages
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    <div
                      onClick={() => handleNavigate('privacy-policy')}
                      className="p-4 rounded-2xl bg-slate-50 hover:bg-blue-50/60 border border-slate-200/80 hover:border-blue-200 transition-all cursor-pointer group"
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                          <h4 className="text-sm font-bold text-[#032b69] group-hover:text-[#0072ce] transition-colors">
                            Privacy Policy
                          </h4>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#0072ce] group-hover:translate-x-0.5 transition-all" />
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        Learn how your artist profile, audio files, uploaded cover art, and account security are safeguarded under Uganda privacy laws.
                      </p>
                    </div>

                    <div
                      onClick={() => handleNavigate('terms-and-conditions')}
                      className="p-4 rounded-2xl bg-slate-50 hover:bg-blue-50/60 border border-slate-200/80 hover:border-blue-200 transition-all cursor-pointer group"
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                          <h4 className="text-sm font-bold text-[#032b69] group-hover:text-[#0072ce] transition-colors">
                            Terms & Conditions
                          </h4>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#0072ce] group-hover:translate-x-0.5 transition-all" />
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        Creators retain 100% intellectual property ownership of all uploaded music. Review streaming rules and copyright takedown procedures.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : activeTab === 'music' ? (
              <div className="space-y-5">
                {/* Music Catalog Header */}
                <div className="bg-gradient-to-r from-[#032b69] via-[#0055d4] to-[#0072ce] rounded-2xl md:rounded-3xl p-5 sm:p-7 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div className="space-y-1.5">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-xs text-yellow-300 text-xs font-black uppercase tracking-wider">
                      <Music2 className="w-3.5 h-3.5" />
                      <span>Free Streaming & MP3 Downloads</span>
                    </div>
                    <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                      All Released Music Library
                    </h2>
                    <p className="text-xs sm:text-sm text-blue-100 max-w-xl font-normal">
                      Discover, stream, and download authentic recordings from verified Ugandan and regional artists. Over {allSongs.length} songs permanently stored in high-definition audio.
                    </p>
                  </div>

                  <div className="flex items-center gap-2.5 shrink-0 self-stretch md:self-auto">
                    <button
                      onClick={async () => {
                        const activeUid = currentUserId || currentUser.id;
                        await syncSongsAndUserData(activeUid);
                        showToast('Catalog refreshed from Supabase database!');
                      }}
                      disabled={isLoadingSongs}
                      className="flex-1 md:flex-none px-4 py-2.5 bg-white/15 hover:bg-white/25 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 backdrop-blur-xs"
                      title="Sync with database"
                    >
                      <RotateCw className={`w-3.5 h-3.5 ${isLoadingSongs ? 'animate-spin' : ''}`} />
                      <span>Refresh</span>
                    </button>
                    <button
                      onClick={() => handleProtectedAction(() => setIsUploadOpen(true))}
                      className="flex-1 md:flex-none px-5 py-2.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Upload Song</span>
                    </button>
                  </div>
                </div>

                {/* Genre Selector */}
                <GenreCards
                  selectedGenre={selectedGenre}
                  onSelectGenre={handleSelectGenre}
                />

                {/* Main Songs List (All, New, Trending, Hot 100) */}
                <MusicColumns
                  newSongs={filteredNewSongs}
                  trendingSongs={filteredTrendingSongs}
                  hot100Songs={filteredHot100Songs}
                  currentSong={currentSong}
                  isPlaying={isPlaying}
                  onPlaySong={handlePlaySong}
                  onLikeSong={handleLikeSong}
                  onDownloadSong={handleDownloadSong}
                  onShareSong={(song) => setShareSong(song)}
                  onViewArtist={handleViewArtistByName}
                  onSelectGenre={(genre) => handleSelectGenre(genre)}
                  onDeleteSong={handleDeleteSong}
                  onOpenComments={(song) => handleOpenComments(song)}
                  onViewSongDetails={(song) => setSelectedSongDetails(song)}
                  downloadingSongId={downloadingSongId}
                  likedSongIds={likedSongIds}
                  currentUserId={currentUserId || undefined}
                  onOpenUpload={() => handleProtectedAction(() => setIsUploadOpen(true))}
                  isLoading={isLoadingSongs}
                />
              </div>
            ) : activeTab === 'videos' ? (
              <VideosLibrary
                videos={videos}
                isLoading={isLoadingVideos}
                error={videosError}
                searchQuery={searchQuery}
                onRefresh={() => syncVideosData(currentUserId)}
                onOpenUpload={() => handleProtectedAction(() => setIsVideoUploadOpen(true))}
                onSelectVideo={handleSelectVideo}
                onShareVideo={handleShareVideo}
                onLikeVideo={handleLikeVideo}
                onDeleteVideo={handleDeleteVideo}
                likedVideoIds={likedVideoIds}
                currentUserId={currentUserId}
                isAdmin={isUserAdminEmail(currentUser.email)}
              />
            ) : activeTab === 'artists' ? (
              /* Active Tab View: Artists Directory */
              <div className="bg-white rounded-2xl md:rounded-3xl p-5 md:p-6 shadow-xl border border-slate-100 space-y-5">
                {/* Header */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-pink-100 text-[#e91e63] flex items-center justify-center font-bold shadow-sm">
                      <Users className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="text-xl sm:text-2xl font-black text-[#032b69] tracking-tight">
                        Artists & Creators Directory
                      </h2>
                      <p className="text-xs text-slate-500 font-medium">
                        Search artists, stream authentic tracks, and download real music publicly
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        if (!currentUser.isLoggedIn) {
                          setAuthModal({ isOpen: true, mode: 'signup' });
                        } else {
                          setIsArtistSetupOpen(true);
                        }
                      }}
                      className="px-3.5 py-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{currentUser.role === 'artist' ? 'Edit Artist Profile' : 'Create Artist Profile 🎵'}</span>
                    </button>
                    <button
                      onClick={() => handleProtectedAction(() => setIsUploadOpen(true))}
                      className="px-3.5 py-2 bg-[#0072ce] hover:bg-blue-600 text-white font-bold text-xs rounded-xl shadow transition-all cursor-pointer"
                    >
                      Upload Music
                    </button>
                  </div>
                </div>

                {/* Artist Search Bar */}
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    value={artistSearchQuery}
                    onChange={(e) => setArtistSearchQuery(e.target.value)}
                    placeholder="Search artist by stage name or genre (e.g. King Saha, Afrobeat, Gospel, Akoogo)..."
                    className="w-full bg-slate-50 border border-slate-200 focus:border-[#0072ce] rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none transition-all shadow-inner font-medium"
                  />
                  {artistSearchQuery && (
                    <button
                      onClick={() => setArtistSearchQuery('')}
                      className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600 font-bold"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* Artist Count & Filter status */}
                <div className="flex items-center justify-between text-xs text-slate-500 px-1 font-medium">
                  <span>
                    Showing{' '}
                    <strong className="text-slate-800">
                      {
                        allDisplayedArtists.filter((a) => {
                          if (!effectiveArtistSearch) return true;
                          const q = effectiveArtistSearch.toLowerCase();
                          return a.name.toLowerCase().includes(q) || a.genre.toLowerCase().includes(q);
                        }).length
                      }
                    </strong>{' '}
                    artist(s) on Teso Melodies
                  </span>
                  {effectiveArtistSearch && (
                    <span className="text-blue-600 font-bold">Filtered by "{effectiveArtistSearch}"</span>
                  )}
                </div>

                {/* Artists Cards Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {allDisplayedArtists
                    .filter((artist) => {
                      if (!effectiveArtistSearch) return true;
                      const q = effectiveArtistSearch.toLowerCase();
                      return artist.name.toLowerCase().includes(q) || artist.genre.toLowerCase().includes(q);
                    })
                    .map((artist, idx) => {
                      const artistTracks = allSongs.filter(
                        (s) => s.artist.toLowerCase().trim() === artist.name.toLowerCase().trim()
                      );

                      return (
                        <div
                          key={`artist-grid-card-${artist.id}-${idx}`}
                          className="p-4 rounded-2xl bg-slate-50 hover:bg-blue-50/70 border border-slate-200/80 transition-all flex flex-col justify-between group shadow-sm hover:shadow-md"
                        >
                          <div className="flex items-start gap-3.5">
                            <a
                              href={getArtistSeoPath(artist.name)}
                              onClick={(e) => {
                                if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
                                e.preventDefault();
                                handleOpenArtist(artist);
                              }}
                              className="relative w-14 h-14 rounded-full overflow-hidden shrink-0 ring-2 ring-yellow-400 shadow-md bg-slate-200 cursor-pointer block"
                            >
                              <img
                                src={artist.avatar || HERO_ASSETS.announcement}
                                alt={artist.name}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                                referrerPolicy="no-referrer"
                              />
                            </a>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <a
                                  href={getArtistSeoPath(artist.name)}
                                  onClick={(e) => {
                                    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
                                    e.preventDefault();
                                    handleOpenArtist(artist);
                                  }}
                                  className="text-sm font-black text-slate-900 hover:text-[#0072ce] truncate cursor-pointer text-left transition-colors"
                                >
                                  {artist.name}
                                </a>
                                {artist.isRealArtist ? (
                                  <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[9px] font-bold">
                                    <Sparkles className="w-2.5 h-2.5" />
                                    <span>Real Artist</span>
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[9px] font-bold">
                                    <Check className="w-2.5 h-2.5" />
                                    <span>Featured</span>
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-blue-600 font-bold mt-0.5 truncate">{artist.genre}</p>
                              <div className="text-[11px] text-slate-500 font-medium mt-1 flex items-center gap-1.5 flex-wrap">
                                <span>{artistTracks.length || artist.totalSongs || 0} song(s)</span>
                                <span>•</span>
                                <span className="font-semibold text-slate-700">
                                  {artist.followers === 1
                                    ? '1 follower'
                                    : `${(artist.followers || 0).toLocaleString()} followers`}
                                </span>
                                <span>•</span>
                                <span className="text-red-600 font-bold flex items-center gap-0.5">
                                  <Heart className="w-2.5 h-2.5 fill-red-500 text-red-500" />
                                  {(artist.totalLikes !== undefined
                                    ? artist.totalLikes
                                    : artistTracks.reduce((acc, s) => acc + (s.likes || 0), 0)
                                  ).toLocaleString()} likes
                                </span>
                                <span>•</span>
                                <span className="text-emerald-700 font-bold flex items-center gap-0.5">
                                  <Download className="w-2.5 h-2.5 text-emerald-600" />
                                  {formatDownloadCount(
                                    artistTracks.reduce((acc, s) => acc + (s.downloadsCount || 0), 0)
                                  )}{' '}
                                  downloads
                                </span>
                              </div>
                            </div>
                          </div>

                          {artist.bio && (
                            <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                              {artist.bio}
                            </p>
                          )}

                          {/* Action Buttons: Discography & Download / Follow */}
                          <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-200/80">
                            <button
                              onClick={() => handleOpenArtist(artist)}
                              className="px-3 py-1.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow-sm transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1"
                            >
                              <Download className="w-3 h-3" />
                              <span>Discography</span>
                            </button>

                            <button
                              onClick={() => handleFollowArtist(artist.id)}
                              className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all shadow-sm active:scale-95 cursor-pointer flex items-center justify-center gap-1 ${
                                artist.isFollowed
                                  ? 'bg-slate-200 text-slate-800 hover:bg-slate-300'
                                  : 'bg-[#0072ce] hover:bg-blue-600 text-white'
                              }`}
                            >
                              <span>{artist.isFollowed ? 'Following' : 'Follow'}</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                </div>

                {/* Empty State */}
                {allDisplayedArtists.filter((artist) => {
                  if (!effectiveArtistSearch) return true;
                  const q = effectiveArtistSearch.toLowerCase();
                  return artist.name.toLowerCase().includes(q) || artist.genre.toLowerCase().includes(q);
                }).length === 0 && (
                  <div className="text-center py-12 px-4 rounded-2xl bg-slate-50 border border-slate-200">
                    <Users className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                    <h3 className="text-sm font-bold text-slate-800">No artists found</h3>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                      No artists match "{effectiveArtistSearch}". Try another name or clear filter.
                    </p>
                    <button
                      onClick={() => {
                        setArtistSearchQuery('');
                        setSearchQuery('');
                      }}
                      className="mt-3 px-4 py-1.5 bg-[#0072ce] text-white rounded-xl text-xs font-bold hover:bg-blue-600 cursor-pointer"
                    >
                      Show All Artists
                    </button>
                  </div>
                )}
              </div>
            ) : activeTab === 'news' ? (
              /* Active Tab View: News */
              <div className="bg-white rounded-2xl md:rounded-3xl p-5 md:p-6 shadow-xl border border-slate-100 space-y-4">
                <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
                  <div className="w-9 h-9 rounded-xl bg-red-100 text-red-600 flex items-center justify-center">
                    <Newspaper className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-xl sm:text-2xl font-black text-[#032b69]">Latest News & Announcements</h2>
                    <p className="text-xs text-slate-500">Stay updated with music releases, portal updates and community features</p>
                  </div>
                </div>

                <div className="space-y-3">
                  {announcements.length === 0 ? (
                    <div className="py-10 px-4 text-center rounded-2xl border border-slate-200 bg-slate-50">
                      <Newspaper className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                      <h3 className="text-sm font-bold text-slate-800">No published news articles yet</h3>
                      <p className="text-xs text-slate-500 mt-1">
                        Announcements and updates from Teso Melodies will appear here once published.
                      </p>
                    </div>
                  ) : (
                    announcements.map((ann, idx) => (
                      <div
                        key={`announcement-card-${ann.id}-${idx}`}
                        onClick={() => setSelectedAnnouncement(ann)}
                        className="p-4 rounded-2xl bg-slate-50 hover:bg-blue-50/70 border border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center gap-4 transition-all cursor-pointer group"
                      >
                        <img src={ann.thumbnail} alt={ann.title} className="w-full sm:w-24 h-24 sm:h-20 rounded-xl object-cover shrink-0 shadow-sm" referrerPolicy="no-referrer" />
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-600 uppercase tracking-wider">{ann.badge || 'News'}</span>
                            <span className="text-xs text-slate-400">{ann.date}</span>
                          </div>
                          <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">{ann.title}</h3>
                          <p className="text-xs text-slate-500 mt-1 line-clamp-2">{ann.description}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ) : activeTab === 'charts' ? (
              /* Active Tab View: Charts */
              <div className="space-y-5">
                <GenreCards
                  selectedGenre={selectedGenre}
                  onSelectGenre={handleSelectGenre}
                />
                <MusicColumns
                  newSongs={filteredNewSongs}
                  trendingSongs={filteredTrendingSongs}
                  hot100Songs={filteredHot100Songs}
                  currentSong={currentSong}
                  isPlaying={isPlaying}
                  onPlaySong={handlePlaySong}
                  onLikeSong={handleLikeSong}
                  onDownloadSong={handleDownloadSong}
                  onShareSong={(song) => setShareSong(song)}
                  onViewArtist={handleViewArtistByName}
                  onSelectGenre={(genre) => handleSelectGenre(genre)}
                  onDeleteSong={handleDeleteSong}
                  onOpenComments={(song) => handleOpenComments(song)}
                  onViewSongDetails={(song) => setSelectedSongDetails(song)}
                  downloadingSongId={downloadingSongId}
                  likedSongIds={likedSongIds}
                  currentUserId={currentUserId || undefined}
                  onOpenUpload={() => handleProtectedAction(() => setIsUploadOpen(true))}
                />
              </div>
            ) : activeTab === 'about' ? (
              /* Active Tab View: About */
              <div className="bg-white rounded-2xl md:rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-100 space-y-4 text-slate-700">
                <div className="flex items-center gap-2 text-2xl font-black text-[#032b69]">
                  <span>About</span>
                  <span className="text-[#FFCC00]">TESO MELODIES</span>
                </div>
                <div className="font-script text-3xl text-[#0072ce] font-bold">Music Unites Us</div>
                <p className="text-sm leading-relaxed">
                  Teso Melodies is East Africa's home for authentic sounds, bridging traditional instruments like the Akoogo with contemporary Teso Worship, Gospel, R&B, Afrobeat, Reggae, and Dancehall.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-100">
                    <h4 className="text-sm font-bold text-[#032b69] mb-1">100% Free For Fans</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">Listen to unlimited high-quality music and download offline tracks without paywalls, fees, or hidden subscriptions.</p>
                  </div>
                  <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-100">
                    <h4 className="text-sm font-bold text-amber-900 mb-1">Direct Creator Earnings</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">Artists and songwriters monetize their creativity through our automated Community Royalty Pool with local mobile money payouts.</p>
                  </div>
                </div>
              </div>
            ) : activeTab === 'privacy-policy' ? (
              /* Active Tab View: Privacy Policy (/privacy-policy) */
              <PrivacyPolicyPage
                onBackToHome={() => handleNavigate('home')}
                onNavigateToTerms={() => handleNavigate('terms-and-conditions')}
                currentUser={currentUser}
                onOpenAdminLegal={(docType: 'privacy' | 'terms') => setAdminLegalModal({ isOpen: true, docType })}
              />
            ) : activeTab === 'terms-and-conditions' ? (
              /* Active Tab View: Terms and Conditions (/terms-and-conditions) */
              <TermsAndConditionsPage
                onBackToHome={() => handleNavigate('home')}
                onNavigateToPrivacy={() => handleNavigate('privacy-policy')}
                currentUser={currentUser}
                onOpenAdminLegal={(docType: 'privacy' | 'terms') => setAdminLegalModal({ isOpen: true, docType })}
              />
            ) : (
              /* Default Home View */
              <>
                {/* A. Hero Section with Man Wearing Headphones & Sunset */}
                <HeroSection
                  currentUser={currentUser}
                  onOpenSignUp={() => setAuthModal({ isOpen: true, mode: 'signup' })}
                  onOpenLogin={() => setAuthModal({ isOpen: true, mode: 'signin' })}
                  onOpenUpload={() => handleProtectedAction(() => setIsUploadOpen(true))}
                  onOpenEarn={() => handleProtectedAction(() => setIsEarnOpen(true))}
                  onOpenAdvertise={() => setIsAdvertiseOpen(true)}
                  onOpenAnnouncements={() =>
                    announcements[0] ? setSelectedAnnouncement(announcements[0]) : handleNavigate('news')
                  }
                  onSupportArtists={() => {
                    setActiveTab('artists');
                    showToast('Support artists by following, streaming, and downloading!');
                  }}
                  onOpenArtistSetup={() => {
                    if (!currentUser.isLoggedIn) {
                      setAuthModal({ isOpen: true, mode: 'signup' });
                    } else {
                      setIsArtistSetupOpen(true);
                    }
                  }}
                />

                {/* B. Music Categories / Genres Section with Colorful Cards */}
                <GenreCards
                  selectedGenre={selectedGenre}
                  onSelectGenre={handleSelectGenre}
                />

                {/* C. Three-Column Layout: New Songs, Trending Songs, Hot 100 Songs */}
                <MusicColumns
                  newSongs={filteredNewSongs}
                  trendingSongs={filteredTrendingSongs}
                  hot100Songs={filteredHot100Songs}
                  currentSong={currentSong}
                  isPlaying={isPlaying}
                  onPlaySong={handlePlaySong}
                  onLikeSong={handleLikeSong}
                  onDownloadSong={handleDownloadSong}
                  onShareSong={(song) => setShareSong(song)}
                  onViewArtist={handleViewArtistByName}
                  onSelectGenre={(genre) => handleSelectGenre(genre)}
                  onDeleteSong={handleDeleteSong}
                  onOpenComments={(song) => handleOpenComments(song)}
                  onViewSongDetails={(song) => setSelectedSongDetails(song)}
                  downloadingSongId={downloadingSongId}
                  likedSongIds={likedSongIds}
                  currentUserId={currentUserId || undefined}
                  onOpenUpload={() => handleProtectedAction(() => setIsUploadOpen(true))}
                  isLoading={isLoadingSongs}
                />
              </>
            )}

          </div>

          {/* RIGHT SIDEBAR (Welcome Back, Announcements, Advertise Banner, Top Artists) - Hidden on legal & admin tabs */}
          {!isWideTab && (
            <div className="lg:col-span-4 xl:col-span-3">
              <Sidebar
                announcements={announcements}
                topArtist={topArtist}
                topArtists={allDisplayedArtists.slice(0, 5)}
                onFollowArtist={handleFollowArtist}
                onSelectArtist={handleOpenArtist}
                onSelectAnnouncement={(ann) => setSelectedAnnouncement(ann)}
                onOpenAdvertise={() => setIsAdvertiseOpen(true)}
                onOpenPostNews={() => setIsPostNewsOpen(true)}
                onOpenPublishLive={() => setIsPublishLiveOpen(true)}
                onOpenAdminDashboard={() => handleNavigate('admin')}
                onViewAllArtists={() => handleNavigate('artists')}
                currentUser={currentUser}
                currentUserId={currentUserId}
                onLogin={handleLogin}
                onOpenSignUp={() => {
                  const el = document.querySelector<HTMLInputElement>('input[placeholder="Email or Username"]');
                  if (el) el.focus();
                  showToast('Create your free Teso Melodies account!');
                }}
                onLogout={handleLogout}
                onUpdateAvatar={(newAvatarUrl) => {
                  setCurrentUser((prev) => ({ ...prev, avatar: newAvatarUrl }));
                  showToast('Profile photo updated successfully!');
                }}
                onOpenWallet={() => handleNavigate('wallet')}
                onOpenUpload={() => handleProtectedAction(() => setIsUploadOpen(true))}
                onOpenArtistSetup={() => {
                  if (!currentUser.isLoggedIn) {
                    setAuthModal({ isOpen: true, mode: 'signup' });
                  } else {
                    setIsArtistSetupOpen(true);
                  }
                }}
              />
            </div>
          )}

        </div>

      </main>

      {/* 3. Footer */}
      <Footer
        onNavigate={handleNavigate}
        showInstallApp={!pwa.isInstalled}
        onOpenInstallApp={pwa.openInstallModal}
      />

      {/* 4. Bottom Floating Audio Player (always mounted so <audio> exists in user gesture on first click) */}
      <AudioPlayer
        currentSong={currentSong}
        isPlaying={isPlaying}
        audioRef={audioRef}
        suppressPauseSyncRef={suppressPauseSyncRef}
        onPlaybackSync={(playing) => setIsPlaying(playing)}
        onPlaybackError={(msg) => showToast(msg)}
        onTogglePlay={toggleCurrentPlayback}
        onNext={handleNextSong}
        onPrev={handlePrevSong}
        onClose={handleClosePlayer}
        onLike={handleLikeSong}
        onDownload={handleDownloadSong}
        onOpenComments={(song) => handleOpenComments(song)}
        isLiked={currentSong ? likedSongIds.has(currentSong.id) : false}
        isDownloading={Boolean(currentSong && downloadingSongId === currentSong.id)}
      />

      {/* 5. Modals */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onUploadSuccess={handleUploadSuccess}
        currentUserId={currentUserId}
        currentUser={currentUser}
        onSwitchToVideoUpload={() => handleProtectedAction(() => setIsVideoUploadOpen(true))}
      />

      <VideoUploadModal
        isOpen={isVideoUploadOpen}
        onClose={() => setIsVideoUploadOpen(false)}
        onVideoCreated={handleVideoCreated}
        currentUserId={currentUserId}
        currentUser={currentUser}
      />

      <EarnModal
        isOpen={isEarnOpen}
        onClose={() => setIsEarnOpen(false)}
        isLoggedIn={currentUser.isLoggedIn}
        onOpenUpload={() => handleProtectedAction(() => setIsUploadOpen(true))}
        onOpenDashboard={() => handleNavigate('dashboard')}
        onOpenSignUp={() => setAuthModal({ isOpen: true, mode: 'signup' })}
      />

      <AdvertiseModal
        isOpen={isAdvertiseOpen}
        onClose={() => setIsAdvertiseOpen(false)}
        onSubmitAd={(brand) => {
          showToast(`Inquiry for "${brand}" received! Our advertising team will contact you shortly.`);
        }}
        onAdPublished={(newAd) => {
          setAnnouncements((prev) => [newAd, ...prev]);
          refreshPublishedNews();
          showToast(`Advertisement "${newAd.title}" published successfully!`);
        }}
        currentUserEmail={currentUser.email}
      />

      <PostNewsModal
        isOpen={isPostNewsOpen}
        onClose={() => setIsPostNewsOpen(false)}
        onNewsPublished={(newNews) => {
          setAnnouncements((prev) => [newNews, ...prev]);
          refreshPublishedNews();
          showToast(`News "${newNews.title}" published to Teso Melodies!`);
        }}
        currentUserEmail={currentUser.email}
      />

      <PublishLiveModal
        isOpen={isPublishLiveOpen}
        onClose={() => setIsPublishLiveOpen(false)}
        onAnnouncementPublished={(newLive) => {
          setAnnouncements((prev) => [newLive, ...prev]);
          refreshPublishedNews();
          showToast(`Announcement "${newLive.title}" broadcasted live!`);
        }}
        currentUserEmail={currentUser.email}
      />

      <AnnouncementModal
        announcement={selectedAnnouncement}
        onClose={() => setSelectedAnnouncement(null)}
      />

      <ArtistModal
        artist={selectedArtist}
        onClose={handleCloseArtist}
        onFollow={(id) => handleFollowArtist(id)}
        artistSongs={
          selectedArtist
            ? allSongs.filter(
                (s) =>
                  s.artist.toLowerCase() === selectedArtist.name.toLowerCase() ||
                  (selectedArtist.userId && s.userId === selectedArtist.userId)
              )
            : []
        }
        onPlaySong={handlePlaySong}
        onDownloadSong={handleDownloadSong}
        onLikeSong={handleLikeSong}
        likedSongIds={likedSongIds}
        downloadingSongId={downloadingSongId}
        onOpenComments={(song) => handleOpenComments(song)}
        onSelectGenre={(genre) => {
          setActiveTab('music');
          handleSelectGenre(genre);
        }}
        onPlaySongTitle={(songTitle) => {
          const found = allSongs.find((s) => s.title.toLowerCase() === songTitle.toLowerCase());
          if (found) {
            handlePlaySong(found);
            handleCloseArtist();
          } else {
            showToast(`Playing ${songTitle}`);
          }
        }}
      />

      <SongDetailsModal
        song={selectedSongDetails}
        isCurrentPlaying={Boolean(selectedSongDetails && currentSong?.id === selectedSongDetails.id && isPlaying)}
        isLiked={Boolean(selectedSongDetails && likedSongIds.has(selectedSongDetails.id))}
        isDownloading={Boolean(selectedSongDetails && downloadingSongId === selectedSongDetails.id)}
        onClose={() => setSelectedSongDetails(null)}
        onPlaySong={handlePlaySong}
        onDownloadSong={handleDownloadSong}
        onLikeSong={handleLikeSong}
        onShareSong={(song) => setShareSong(song)}
        onOpenComments={(song) => handleOpenComments(song)}
        onViewArtist={handleViewArtistByName}
        onSelectGenre={(genre) => {
          setActiveTab('music');
          handleSelectGenre(genre);
        }}
      />

      <ShareModal
        song={shareSong}
        video={shareVideo}
        onClose={() => {
          setShareSong(null);
          setShareVideo(null);
        }}
        onCopyLink={(url) => {
          navigator.clipboard?.writeText?.(url);
          showToast('Link copied to clipboard!');
        }}
      />

      {/* Professional HTML5 Video Player Modal */}
      <VideoPlayerModal
        video={selectedVideo}
        onClose={handleCloseVideo}
        onShare={handleShareVideo}
        onToggleLike={handleLikeVideo}
        isLiked={selectedVideo ? likedVideoIds.has(selectedVideo.id) : false}
        canDelete={Boolean(
          selectedVideo &&
            (isUserAdminEmail(currentUser.email) ||
              (currentUserId && selectedVideo.userId === currentUserId))
        )}
        onDeleteVideo={handleDeleteVideo}
      />

      {/* Artist Profile & Photo Setup Modal */}
      <ArtistProfileModal
        isOpen={isArtistSetupOpen}
        onClose={() => setIsArtistSetupOpen(false)}
        currentUser={currentUser}
        currentUserId={currentUserId}
        onProfileUpdated={(updated) => {
          setCurrentUser((prev) => ({
            ...prev,
            name: updated.stageName || prev.name || 'Artist',
            stageName: updated.stageName || prev.stageName,
            genre: updated.genre || prev.genre,
            bio: updated.bio || prev.bio,
            avatar: updated.avatar || prev.avatar,
            location: updated.location || prev.location,
            role: 'artist',
          }));
          fetchSongsFromSupabase().then((dbSongs) => {
            fetchArtistsFromSupabase(dbSongs).then((dbArtists) => {
              if (dbArtists && dbArtists.length > 0) setRealArtists(dbArtists);
            });
          });
          showToast('Artist profile & photo saved successfully!');
        }}
      />

      {/* Supabase Auth Modal */}
      <AuthModal
        isOpen={authModal.isOpen}
        initialMode={authModal.mode}
        onClose={() => setAuthModal((prev) => ({ ...prev, isOpen: false }))}
        onSuccess={(email, user) => {
          if (user) {
            const stage = user.user_metadata?.stage_name || user.user_metadata?.full_name;
            handleLogin(
              stage || user.email || email,
              user.email || email,
              user.user_metadata?.avatar_url || user.user_metadata?.picture,
              user.user_metadata?.role,
              stage,
              user.user_metadata?.genre,
              user.user_metadata?.bio,
              user.user_metadata?.location,
              user.id
            );
          } else {
            handleLogin(email);
          }
        }}
        onOpenLegal={(type) => {
          setAuthModal({ isOpen: false, mode: 'signin' });
          handleNavigate(type === 'privacy' ? 'privacy-policy' : 'terms-and-conditions');
        }}
      />

      {/* Admin Legal Pages Manager Modal (for tesomelodies@gmail.com) */}
      <AdminLegalModal
        isOpen={adminLegalModal.isOpen}
        initialDocType={adminLegalModal.docType}
        onClose={() => setAdminLegalModal({ isOpen: false, docType: 'privacy' })}
        onPublished={(docType: 'privacy' | 'terms') => {
          showToast(`Legal page for ${docType === 'privacy' ? 'Privacy Policy' : 'Terms & Conditions'} published successfully!`);
        }}
      />

      {/* Song Comments & Reviews Modal */}
      <SongCommentsModal
        song={selectedSongForComments}
        isOpen={Boolean(selectedSongForComments)}
        onClose={handleCloseComments}
        currentUser={currentUser}
        onOpenSignUp={() => setAuthModal({ isOpen: true, mode: 'signup' })}
      />

      {/* PWA Install Popup (Android native install + iPhone Safari instructions) & Offline Banner */}
      <PWAInstallPrompt
        isVisible={pwa.isVisible}
        isInstalled={pwa.isInstalled}
        isInstallable={pwa.isInstallable}
        isIOS={pwa.isIOS}
        isAndroid={pwa.isAndroid}
        isInstalling={pwa.isInstalling}
        onInstall={pwa.install}
        onMaybeLater={pwa.dismissMaybeLater}
        onClose={pwa.dismissClose}
        onInstalled={() => showToast('TESO MELODIES app installed!')}
      />
      <OfflineIndicator />

      {/* Toast Notification */}
      <Toast message={toastMessage} onClose={() => setToastMessage(null)} />

    </div>
  );
}
