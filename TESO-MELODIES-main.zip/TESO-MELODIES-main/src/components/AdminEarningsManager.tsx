import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Users,
  Wallet,
  ArrowDownToLine,
  Receipt,
  Settings,
  Search,
  ShieldCheck,
  ShieldAlert,
  Lock,
  CheckCircle2,
  XCircle,
  Ban,
  RotateCw,
  Loader2,
  Database,
  Eye,
  Heart,
  Download,
  Headphones,
  CreditCard,
  Banknote,
  TrendingUp,
  CalendarDays,
  History,
  X,
} from 'lucide-react';
import {
  AdminArtistEarningsRow,
  AdminEarningsOverview,
  AdminMonetizationHealth,
  ArtistWithdrawalRequest,
  DEFAULT_EARNING_SETTINGS,
  WithdrawalStatus,
  checkAdminMonetizationHealth,
  fetchAdminEarningsOverview,
  updateAdminEarningSettings,
  reviewAdminWithdrawal,
  toggleAdminArtistSuspension,
  formatUGX,
  getTransactionCategoryLabel,
} from '../services/earningsService';

export type AdminEarningsSectionTab =
  | 'artists'
  | 'earnings'
  | 'withdrawals'
  | 'rates'
  | 'transactions';

type AdminTransactionFilter =
  | 'all'
  | 'earnings'
  | 'withdrawals'
  | 'Pending'
  | 'Approved'
  | 'Paid'
  | 'Rejected';

interface AdminEarningsManagerProps {
  activeSection: AdminEarningsSectionTab;
  onToast: (msg: string) => void;
}

function formatDate(iso?: string | null): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('en-UG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

function badgeClass(status: string): string {
  switch (status) {
    case 'Paid':
    case 'Credited':
      return 'bg-emerald-100 text-emerald-800 border border-emerald-200';
    case 'Approved':
      return 'bg-blue-100 text-[#032b69] border border-blue-200';
    case 'Pending':
      return 'bg-amber-100 text-amber-900 border border-amber-200';
    case 'Rejected':
      return 'bg-red-100 text-red-700 border border-red-200';
    default:
      return 'bg-slate-100 text-slate-700 border border-slate-200';
  }
}

export const AdminEarningsManager: React.FC<AdminEarningsManagerProps> = ({
  activeSection,
  onToast,
}) => {
  const [overview, setOverview] = useState<AdminEarningsOverview | null>(null);
  const [backendHealth, setBackendHealth] = useState<AdminMonetizationHealth | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [migrationRequired, setMigrationRequired] = useState(false);
  const [schemaMismatch, setSchemaMismatch] = useState(false);
  const [diagnosticDetail, setDiagnosticDetail] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Artists filter & inspection
  const [artistSearch, setArtistSearch] = useState('');
  const [artistFilter, setArtistFilter] = useState<'all' | 'verified' | 'unverified' | 'suspended'>(
    'all'
  );
  const [expandedArtistId, setExpandedArtistId] = useState<string | null>(null);
  const [suspendTargetId, setSuspendTargetId] = useState<string | null>(null);
  const [suspendReason, setSuspendReason] = useState('');
  const [busyArtistId, setBusyArtistId] = useState<string | null>(null);

  // Earnings & Monthly Report tab state
  const [earningsSearch, setEarningsSearch] = useState('');
  const [inspectTransactionsArtist, setInspectTransactionsArtist] =
    useState<AdminArtistEarningsRow | null>(null);

  // Withdrawals filter & inline action modals
  const [withdrawalFilter, setWithdrawalFilter] = useState<'all' | WithdrawalStatus>('all');
  const [busyWithdrawalId, setBusyWithdrawalId] = useState<string | null>(null);
  const [paymentModalWithdrawal, setPaymentModalWithdrawal] =
    useState<ArtistWithdrawalRequest | null>(null);
  const [paymentReferenceInput, setPaymentReferenceInput] = useState('');
  const [paymentNoteInput, setPaymentNoteInput] = useState('');
  const [rejectModalWithdrawal, setRejectModalWithdrawal] =
    useState<ArtistWithdrawalRequest | null>(null);
  const [rejectReasonInput, setRejectReasonInput] = useState('');

  // Transactions & Audit Logs tab state
  const [txSubView, setTxSubView] = useState<'ledger' | 'audit'>('ledger');
  const [txSearch, setTxSearch] = useState('');
  const [txTypeFilter, setTxTypeFilter] = useState<AdminTransactionFilter>('all');

  // All 6 Royalty Rates + Min Withdrawal Form State
  const [downloadsRateUgx, setDownloadsRateUgx] = useState('5');
  const [downloadsPerUnit, setDownloadsPerUnit] = useState('1');
  const [streamsRateUgx, setStreamsRateUgx] = useState('10');
  const [streamsPerUnit, setStreamsPerUnit] = useState('25');
  const [likesRateUgx, setLikesRateUgx] = useState('18');
  const [likesPerUnit, setLikesPerUnit] = useState('30');
  const [followersRateUgx, setFollowersRateUgx] = useState('700');
  const [followersPerUnit, setFollowersPerUnit] = useState('100');
  const [minWithdrawalUgx, setMinWithdrawalUgx] = useState('15000');
  const [isSavingRates, setIsSavingRates] = useState(false);

  const loadOverview = useCallback(async () => {
    setIsLoading(true);
    setErrorMsg(null);
    setDiagnosticDetail(null);
    const [res, healthRes] = await Promise.all([
      fetchAdminEarningsOverview(),
      checkAdminMonetizationHealth(),
    ]);
    setBackendHealth(healthRes.health);

    if (res.migrationRequired) {
      setMigrationRequired(true);
      setSchemaMismatch(Boolean(res.schemaMismatch));
      setDiagnosticDetail(res.diagnosticDetail || null);
      setErrorMsg(res.error || null);
      setOverview(null);
    } else if (res.error || !res.data) {
      setMigrationRequired(false);
      setSchemaMismatch(false);
      setDiagnosticDetail(res.diagnosticDetail || null);
      setErrorMsg(res.error || 'Failed to load admin monetization overview.');
    } else {
      setMigrationRequired(false);
      setSchemaMismatch(false);
      setOverview(res.data);
      const s = res.data.settings || DEFAULT_EARNING_SETTINGS;
      setDownloadsRateUgx(String(s.downloads_rate_ugx ?? 5));
      setDownloadsPerUnit(String(s.downloads_per_unit ?? 1));
      setStreamsRateUgx(String(s.streams_rate_ugx ?? 10));
      setStreamsPerUnit(String(s.streams_per_unit ?? 25));
      setLikesRateUgx(String(s.likes_rate_ugx ?? 18));
      setLikesPerUnit(String(s.likes_per_unit ?? 30));
      setFollowersRateUgx(String(s.followers_rate_ugx ?? 700));
      setFollowersPerUnit(String(s.followers_per_unit ?? 100));
      setMinWithdrawalUgx(String(s.min_withdrawal_ugx ?? 15000));
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    loadOverview();
  }, [loadOverview]);

  const artists = overview?.artists || [];
  const withdrawals = overview?.withdrawals || [];
  const transactions = overview?.transactions || [];
  const auditLogs = overview?.audit_logs || [];
  const settings = overview?.settings || DEFAULT_EARNING_SETTINGS;

  const summaryStats = useMemo(() => {
    const verifiedCount = artists.filter((a) => a.earnings_verified).length;
    const unverifiedCount = artists.length - verifiedCount;
    const suspendedCount = artists.filter((a) => a.is_suspended).length;
    const totalEarned = artists.reduce((sum, a) => sum + Number(a.total_earnings_ugx || 0), 0);
    const totalPendingEarnings = artists.reduce(
      (sum, a) => sum + Number(a.pending_earnings_ugx || 0),
      0
    );
    const currentMonthEarned = artists.reduce(
      (sum, a) => sum + Number(a.monthly_earnings_ugx || 0),
      0
    );
    const previousMonthEarned = artists.reduce(
      (sum, a) => sum + Number(a.previous_month_earnings_ugx || 0),
      0
    );
    const totalLikes = artists.reduce((sum, a) => sum + Number(a.total_likes || 0), 0);
    const totalLikesUgx = artists.reduce((sum, a) => sum + Number(a.likes_earnings_ugx || 0), 0);
    const totalFollowers = artists.reduce((sum, a) => sum + Number(a.total_followers || 0), 0);
    const totalFollowersUgx = artists.reduce(
      (sum, a) => sum + Number(a.followers_earnings_ugx || 0),
      0
    );
    const totalDownloads = artists.reduce((sum, a) => sum + Number(a.total_downloads || 0), 0);
    const totalDownloadsUgx = artists.reduce(
      (sum, a) => sum + Number(a.downloads_earnings_ugx || 0),
      0
    );
    const totalStreams = artists.reduce((sum, a) => sum + Number(a.total_streams || 0), 0);
    const totalStreamsUgx = artists.reduce(
      (sum, a) => sum + Number(a.streams_earnings_ugx || 0),
      0
    );
    const monthlyLikes = artists.reduce((sum, a) => sum + Number(a.monthly_likes || 0), 0);
    const monthlyFollowers = artists.reduce((sum, a) => sum + Number(a.monthly_followers || 0), 0);
    const monthlyDownloads = artists.reduce((sum, a) => sum + Number(a.monthly_downloads || 0), 0);
    const monthlyStreams = artists.reduce((sum, a) => sum + Number(a.monthly_streams || 0), 0);

    const totalPaid = withdrawals
      .filter((w) => w.status === 'Paid')
      .reduce((sum, w) => sum + Number(w.amount_ugx || 0), 0);
    const pendingCount = withdrawals.filter(
      (w) => w.status === 'Pending' || w.status === 'Approved'
    ).length;
    const pendingAmount = withdrawals
      .filter((w) => w.status === 'Pending' || w.status === 'Approved')
      .reduce((sum, w) => sum + Number(w.amount_ugx || 0), 0);

    return {
      totalArtists: artists.length,
      verifiedCount,
      unverifiedCount,
      suspendedCount,
      totalEarned,
      totalPendingEarnings,
      currentMonthEarned,
      previousMonthEarned,
      totalLikes,
      totalLikesUgx,
      totalFollowers,
      totalFollowersUgx,
      totalDownloads,
      totalDownloadsUgx,
      totalStreams,
      totalStreamsUgx,
      monthlyLikes,
      monthlyFollowers,
      monthlyDownloads,
      monthlyStreams,
      totalPaid,
      pendingCount,
      pendingAmount,
    };
  }, [artists, withdrawals]);

  const filteredArtists = useMemo(() => {
    const q = artistSearch.trim().toLowerCase();
    return artists.filter((a) => {
      if (artistFilter === 'verified' && !a.earnings_verified) return false;
      if (artistFilter === 'unverified' && a.earnings_verified) return false;
      if (artistFilter === 'suspended' && !a.is_suspended) return false;
      if (!q) return true;
      return (
        a.artist_name.toLowerCase().includes(q) ||
        a.email.toLowerCase().includes(q) ||
        (a.payout_profile?.mobile_money_number || '').toLowerCase().includes(q)
      );
    });
  }, [artists, artistSearch, artistFilter]);

  const filteredEarningsArtists = useMemo(() => {
    const q = earningsSearch.trim().toLowerCase();
    return [...artists]
      .filter((a) => {
        if (!q) return true;
        return a.artist_name.toLowerCase().includes(q) || a.email.toLowerCase().includes(q);
      })
      .sort((a, b) => Number(b.total_earnings_ugx || 0) - Number(a.total_earnings_ugx || 0));
  }, [artists, earningsSearch]);

  const inspectedArtistTransactions = useMemo(() => {
    if (!inspectTransactionsArtist) return [];
    return transactions.filter((t) => t.user_id === inspectTransactionsArtist.user_id);
  }, [transactions, inspectTransactionsArtist]);

  const filteredWithdrawals = useMemo(() => {
    if (withdrawalFilter === 'all') return withdrawals;
    return withdrawals.filter((w) => w.status === withdrawalFilter);
  }, [withdrawals, withdrawalFilter]);

  const filteredTransactions = useMemo(() => {
    const q = txSearch.trim().toLowerCase();
    return transactions.filter((t) => {
      if (txTypeFilter === 'earnings' && t.direction !== 'credit') return false;
      if (
        txTypeFilter === 'withdrawals' &&
        t.transaction_type !== 'withdrawal' &&
        t.transaction_type !== 'payment'
      ) {
        return false;
      }
      if (
        (txTypeFilter === 'Pending' ||
          txTypeFilter === 'Approved' ||
          txTypeFilter === 'Paid' ||
          txTypeFilter === 'Rejected') &&
        t.status !== txTypeFilter
      ) {
        return false;
      }
      if (!q) return true;
      return (
        t.reference_code.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        getTransactionCategoryLabel(t).toLowerCase().includes(q) ||
        (t.artist_name || '').toLowerCase().includes(q) ||
        (t.artist_email || '').toLowerCase().includes(q) ||
        (t.payment_reference || '').toLowerCase().includes(q)
      );
    });
  }, [transactions, txSearch, txTypeFilter]);

  const handleApproveWithdrawal = async (w: ArtistWithdrawalRequest) => {
    setBusyWithdrawalId(w.id);
    const res = await reviewAdminWithdrawal({
      withdrawalId: w.id,
      action: 'approve',
    });
    setBusyWithdrawalId(null);

    if (!res.success) {
      onToast(res.error || 'Could not approve withdrawal.');
      return;
    }
    onToast(`Withdrawal ${w.reference_code} Approved. Record payment once transferred.`);
    await loadOverview();
  };

  const handleConfirmPaid = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentModalWithdrawal) return;
    if (paymentReferenceInput.trim().length < 3) {
      onToast('Enter the real Mobile Money payment confirmation reference.');
      return;
    }

    setBusyWithdrawalId(paymentModalWithdrawal.id);
    const res = await reviewAdminWithdrawal({
      withdrawalId: paymentModalWithdrawal.id,
      action: 'mark_paid',
      paymentReference: paymentReferenceInput,
      note: paymentNoteInput,
    });
    setBusyWithdrawalId(null);

    if (!res.success) {
      onToast(res.error || 'Could not record payment.');
      return;
    }

    onToast(`Recorded completed payment for ${paymentModalWithdrawal.reference_code} (Paid).`);
    setPaymentModalWithdrawal(null);
    setPaymentReferenceInput('');
    setPaymentNoteInput('');
    await loadOverview();
  };

  const handleConfirmReject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectModalWithdrawal) return;
    if (rejectReasonInput.trim().length < 3) {
      onToast('Please enter a clear reason for rejecting this withdrawal.');
      return;
    }

    setBusyWithdrawalId(rejectModalWithdrawal.id);
    const res = await reviewAdminWithdrawal({
      withdrawalId: rejectModalWithdrawal.id,
      action: 'reject',
      note: rejectReasonInput,
    });
    setBusyWithdrawalId(null);

    if (!res.success) {
      onToast(res.error || 'Could not reject withdrawal.');
      return;
    }

    onToast(
      `Withdrawal ${rejectModalWithdrawal.reference_code} Rejected. Funds restored to artist balance.`
    );
    setRejectModalWithdrawal(null);
    setRejectReasonInput('');
    await loadOverview();
  };

  const handleToggleSuspension = async (artist: AdminArtistEarningsRow, suspend: boolean) => {
    if (suspend && suspendReason.trim().length < 3) {
      onToast('Enter a reason before suspending suspicious earning activity.');
      return;
    }
    setBusyArtistId(artist.user_id);
    const res = await toggleAdminArtistSuspension(
      artist.user_id,
      suspend,
      suspend ? suspendReason : undefined
    );
    setBusyArtistId(null);

    if (!res.success) {
      onToast(res.error || 'Could not update suspension state.');
      return;
    }

    setSuspendTargetId(null);
    setSuspendReason('');
    onToast(
      suspend
        ? `Suspended earnings for ${artist.artist_name}.`
        : `Restored earnings access for ${artist.artist_name}.`
    );
    await loadOverview();
  };

  const handleSaveRates = async (e: React.FormEvent) => {
    e.preventDefault();
    const dRate = Number(downloadsRateUgx);
    const dUnit = Number(downloadsPerUnit);
    const sRate = Number(streamsRateUgx);
    const sUnit = Number(streamsPerUnit);
    const lRate = Number(likesRateUgx);
    const lUnit = Number(likesPerUnit);
    const fRate = Number(followersRateUgx);
    const fUnit = Number(followersPerUnit);
    const minW = Number(minWithdrawalUgx);

    const ratesValid = [dRate, sRate, lRate, fRate].every((v) => Number.isFinite(v) && v >= 0);
    const unitsValid = [dUnit, sUnit, lUnit, fUnit].every((v) => Number.isFinite(v) && v >= 1);

    if (!ratesValid) {
      onToast('All UGX royalty amounts must be 0 or greater.');
      return;
    }
    if (!unitsValid) {
      onToast('All milestone counts (likes, followers, downloads, streams) must be at least 1.');
      return;
    }
    if (!Number.isFinite(minW) || minW < 1000) {
      onToast('Minimum withdrawal must be at least 1,000 UGX.');
      return;
    }

    setIsSavingRates(true);
    const res = await updateAdminEarningSettings({
      downloadsRateUgx: dRate,
      downloadsPerUnit: dUnit,
      streamsRateUgx: sRate,
      streamsPerUnit: sUnit,
      likesRateUgx: lRate,
      likesPerUnit: lUnit,
      followersRateUgx: fRate,
      followersPerUnit: fUnit,
      minWithdrawalUgx: minW,
    });
    setIsSavingRates(false);

    if (!res.success) {
      onToast(res.error || 'Failed to update royalty settings.');
      return;
    }

    onToast('All royalty rates and withdrawal threshold saved!');
    await loadOverview();
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-2xl md:rounded-3xl p-10 shadow-xl border border-slate-100 text-center space-y-2">
        <Loader2 className="w-8 h-8 text-[#0072ce] animate-spin mx-auto" />
        <p className="text-sm font-black text-[#032b69]">
          Loading Artist Monetization Administration...
        </p>
      </div>
    );
  }

  if (migrationRequired) {
    return (
      <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border-2 border-amber-300 space-y-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
            <Database className="w-5 h-5" />
          </div>
          <div className="space-y-1.5 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-black uppercase tracking-wider">
                Admin Only • Setup Status
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-red-100 text-red-700 text-[10px] font-black uppercase tracking-wider">
                {schemaMismatch ? 'SQL Function Update Required' : 'Migration Not Yet Applied'}
              </span>
            </div>
            <h3 className="font-black text-base text-[#032b69]">
              {schemaMismatch
                ? 'Monetization SQL Update Required for Live Schema Compatibility'
                : 'Artist Monetization SQL Migration Pending'}
            </h3>
            <p className="text-xs text-slate-700 leading-relaxed">
              {errorMsg ||
                'Run supabase-artist-earnings-migration.sql in your Supabase SQL Editor to activate Artist Monetization.'}
            </p>
            {diagnosticDetail && (
              <div className="p-2.5 rounded-xl bg-slate-900 text-amber-300 font-mono text-[11px] overflow-x-auto">
                Supabase diagnostic: {diagnosticDetail}
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="font-black text-[#032b69]">How to Activate in Supabase (Safe &amp; Non-Destructive)</h4>
            <ol className="list-decimal list-inside space-y-1 text-slate-700 leading-relaxed">
              <li>Open your Supabase Dashboard &rarr; <strong>SQL Editor</strong>.</li>
              <li>Click <strong>New query</strong> and paste the full contents of <code>supabase-artist-earnings-migration.sql</code>.</li>
              <li>Click <strong>Run</strong> (safe to re-run; preserves all existing users, songs, likes, followers, and downloads).</li>
              <li>Return here and click <strong>Re-test Live Connection</strong>.</li>
            </ol>
          </div>

          <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 space-y-2">
            <h4 className="font-black text-[#032b69]">Gmail OTP Configuration Checklist (No SMS)</h4>
            <ul className="list-disc list-inside space-y-1 text-slate-700 leading-relaxed">
              <li><strong>Authentication &rarr; Providers &rarr; Email</strong>: Enabled (Phone/SMS disabled).</li>
              <li><strong>Authentication &rarr; Email Templates &rarr; Magic Link &amp; Confirm signup</strong>: Set Subject to <code>TESO MELODIES – Your Artist Verification Code</code> and include <code>{'{{ .Token }}'}</code> so every artist receives a genuine 6-digit OTP (no generic sign-in link).</li>
              <li><strong>Authentication &rarr; URL Configuration</strong>: Add <code>https://tesomelodies.com/**</code> to Redirect URLs.</li>
              <li><strong>Project Settings &rarr; Auth &rarr; SMTP</strong>: Configure Custom SMTP for reliable Gmail OTP delivery beyond default rate limits.</li>
            </ul>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          <button
            type="button"
            onClick={loadOverview}
            className="px-4 py-2 bg-[#032b69] hover:bg-[#0055d4] text-white font-black text-xs rounded-xl shadow cursor-pointer inline-flex items-center gap-1.5"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>Re-test Live Connection</span>
          </button>
          <span className="text-[11px] text-slate-500">
            This setup panel is strictly visible only to the administrator ({'tesomelodies@gmail.com'}).
          </span>
        </div>
      </div>
    );
  }

  if (errorMsg && !overview) {
    return (
      <div className="bg-white rounded-2xl p-6 shadow-xl border border-red-200 text-red-700 text-xs font-bold space-y-3">
        <p>{errorMsg}</p>
        <button
          type="button"
          onClick={loadOverview}
          className="px-3.5 py-1.5 bg-[#0072ce] text-white font-bold rounded-lg cursor-pointer"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Admin-Only Live Backend Verification Bar */}
      <div className="bg-white rounded-2xl px-4 py-3 shadow-sm border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <span
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-black ${
              backendHealth?.healthy !== false
                ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                : 'bg-amber-100 text-amber-900 border border-amber-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>
              {backendHealth?.healthy
                ? 'Supabase Monetization Backend: Active & Verified'
                : backendHealth && !backendHealth.healthy
                ? 'Backend Diagnostic Warning'
                : 'Supabase Monetization Connected'}
            </span>
          </span>
          <span className="text-slate-500">
            Gmail OTP Verification (Email Only) &bull; RLS Protected &bull; Min Withdrawal{' '}
            <strong className="text-[#032b69]">{formatUGX(settings.min_withdrawal_ugx)}</strong>
          </span>
        </div>
        {backendHealth?.metrics_error && (
          <span className="text-amber-800 font-bold">
            Diagnostic: {backendHealth.metrics_error}
          </span>
        )}
      </div>

      {/* Platform Overview Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        <div className="bg-white rounded-2xl p-4 shadow-md border border-slate-100">
          <span className="text-[11px] font-bold text-slate-500 block">Registered Artists</span>
          <div className="text-2xl font-black text-[#032b69] tabular-nums mt-1">
            {summaryStats.totalArtists}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">
            <strong className="text-emerald-700">{summaryStats.verifiedCount}</strong> verified
            &bull; <strong className="text-amber-700">{summaryStats.unverifiedCount}</strong>{' '}
            unverified
          </p>
        </div>

        <div className="bg-white rounded-2xl p-4 shadow-md border border-slate-100">
          <span className="text-[11px] font-bold text-slate-500 block">Total Artist Earnings</span>
          <div className="text-2xl font-black text-[#032b69] tabular-nums mt-1">
            {formatUGX(summaryStats.totalEarned)}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Pending: <strong>{formatUGX(summaryStats.totalPendingEarnings)}</strong>
          </p>
        </div>

        <div className="bg-white rounded-2xl p-4 shadow-md border border-slate-100">
          <span className="text-[11px] font-bold text-slate-500 block">Pending / Approved</span>
          <div className="text-2xl font-black text-amber-700 tabular-nums mt-1">
            {formatUGX(summaryStats.pendingAmount)}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">
            {summaryStats.pendingCount} withdrawal{' '}
            {summaryStats.pendingCount === 1 ? 'request' : 'requests'}
          </p>
        </div>

        <div className="bg-white rounded-2xl p-4 shadow-md border border-slate-100">
          <span className="text-[11px] font-bold text-slate-500 block">Total Paid Out</span>
          <div className="text-2xl font-black text-emerald-700 tabular-nums mt-1">
            {formatUGX(summaryStats.totalPaid)}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Confirmed MoMo payouts</p>
        </div>

        <div className="col-span-2 lg:col-span-1 bg-white rounded-2xl p-4 shadow-md border border-slate-100 flex flex-col justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 block">Suspended Accounts</span>
            <div className="text-2xl font-black text-red-600 tabular-nums mt-1">
              {summaryStats.suspendedCount}
            </div>
          </div>
          <button
            type="button"
            onClick={loadOverview}
            className="mt-2 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] rounded-lg inline-flex items-center justify-center gap-1 cursor-pointer"
          >
            <RotateCw className="w-3 h-3" />
            <span>Sync Live Data</span>
          </button>
        </div>
      </div>

      {/* ====================================================================
          SECTION 1: ARTISTS & VERIFICATION
         ==================================================================== */}
      {activeSection === 'artists' && (
        <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base sm:text-lg font-black text-[#032b69] flex items-center gap-2">
                <Users className="w-5 h-5 text-[#0072ce]" />
                <span>Artists &amp; Verification ({filteredArtists.length})</span>
              </h2>
              <p className="text-xs text-slate-500">
                View all, verified, and unverified artists, inspect private payout profiles, or
                suspend suspicious activity.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              {(
                [
                  { id: 'all', label: `All (${artists.length})` },
                  { id: 'verified', label: `Verified (${summaryStats.verifiedCount})` },
                  { id: 'unverified', label: `Unverified (${summaryStats.unverifiedCount})` },
                  { id: 'suspended', label: `Suspended (${summaryStats.suspendedCount})` },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setArtistFilter(f.id)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                    artistFilter === f.id
                      ? 'bg-[#032b69] text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
            <input
              type="text"
              value={artistSearch}
              onChange={(e) => setArtistSearch(e.target.value)}
              placeholder="Search artist by name, Gmail, or Mobile Money number..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
            />
          </div>

          {filteredArtists.length === 0 ? (
            <div className="py-10 text-center text-xs text-slate-500 rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50">
              No matching registered artist accounts found.
            </div>
          ) : (
            <div className="space-y-3">
              {filteredArtists.map((artist) => {
                const isExpanded = expandedArtistId === artist.user_id;
                const isSuspendingThis = suspendTargetId === artist.user_id;
                const isBusy = busyArtistId === artist.user_id;
                return (
                  <div
                    key={artist.user_id}
                    className={`rounded-2xl border p-4 transition-all ${
                      artist.is_suspended
                        ? 'bg-red-50/40 border-red-200'
                        : 'bg-slate-50/70 border-slate-200/80'
                    }`}
                  >
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-11 h-11 rounded-xl bg-[#032b69] text-[#FFCC00] font-black flex items-center justify-center overflow-hidden shrink-0">
                          {artist.avatar_url ? (
                            <img
                              src={artist.avatar_url}
                              alt={artist.artist_name}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            artist.artist_name.charAt(0).toUpperCase()
                          )}
                        </div>
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <h3 className="text-sm font-black text-slate-900 truncate">
                              {artist.artist_name}
                            </h3>
                            {artist.earnings_verified ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                                <ShieldCheck className="w-3 h-3" />
                                Verified
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-black">
                                <Lock className="w-3 h-3" />
                                Unverified
                              </span>
                            )}
                            {artist.is_suspended && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-[10px] font-black">
                                <ShieldAlert className="w-3 h-3" />
                                Suspended
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-500 truncate">
                            {artist.email} &bull; {artist.song_count} songs
                            {artist.earnings_verified_at
                              ? ` • Verified ${formatDate(artist.earnings_verified_at)}`
                              : ''}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs">
                        <div className="px-3 py-1.5 rounded-xl bg-white border border-slate-200">
                          <span className="text-[10px] font-bold text-slate-400 block">
                            Total Earned
                          </span>
                          <strong className="text-[#032b69] tabular-nums">
                            {formatUGX(artist.total_earnings_ugx)}
                          </strong>
                        </div>
                        <div className="px-3 py-1.5 rounded-xl bg-white border border-slate-200">
                          <span className="text-[10px] font-bold text-slate-400 block">
                            Available
                          </span>
                          <strong className="text-emerald-700 tabular-nums">
                            {formatUGX(artist.available_balance_ugx)}
                          </strong>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() =>
                              setExpandedArtistId(isExpanded ? null : artist.user_id)
                            }
                            className="px-3 py-1.5 bg-[#0072ce] hover:bg-blue-700 text-white font-bold text-xs rounded-xl cursor-pointer inline-flex items-center gap-1"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>{isExpanded ? 'Hide Details' : 'Inspect'}</span>
                          </button>

                          {artist.is_suspended ? (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => handleToggleSuspension(artist, false)}
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer disabled:opacity-50"
                            >
                              Restore
                            </button>
                          ) : (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => {
                                setSuspendTargetId(isSuspendingThis ? null : artist.user_id);
                                setSuspendReason('');
                              }}
                              className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-bold text-xs rounded-xl cursor-pointer inline-flex items-center gap-1 disabled:opacity-50"
                            >
                              <Ban className="w-3.5 h-3.5" />
                              <span>Suspend</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Inline Suspension Reason Form */}
                    {isSuspendingThis && (
                      <div className="mt-3 p-3 rounded-xl bg-red-50 border border-red-200 flex flex-col sm:flex-row gap-2">
                        <input
                          type="text"
                          value={suspendReason}
                          onChange={(e) => setSuspendReason(e.target.value)}
                          placeholder="Reason for suspending suspicious earning activity..."
                          className="flex-1 px-3 py-2 text-xs bg-white text-slate-900 border border-red-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-400"
                        />
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => handleToggleSuspension(artist, true)}
                            className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-lg cursor-pointer"
                          >
                            Confirm Suspend
                          </button>
                          <button
                            type="button"
                            onClick={() => setSuspendTargetId(null)}
                            className="px-3 py-2 bg-white text-slate-600 font-bold text-xs rounded-lg border border-slate-200 cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Expanded Artist Earnings & Payout Inspection */}
                    {isExpanded && (
                      <div className="mt-4 pt-4 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                        <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-2.5">
                          <h4 className="font-black text-[#032b69] flex items-center gap-1.5">
                            <Wallet className="w-3.5 h-3.5 text-[#0072ce]" />
                            <span>Individual Earnings Breakdown</span>
                          </h4>
                          <div className="grid grid-cols-2 gap-2">
                            <div className="p-2 rounded-lg bg-slate-50">
                              <span className="text-slate-500 flex items-center gap-1">
                                <Heart className="w-3 h-3 text-red-500" /> Likes (
                                {Number(artist.total_likes || 0).toLocaleString()})
                              </span>
                              <strong className="text-[#032b69]">
                                {formatUGX(artist.likes_earnings_ugx)}
                              </strong>
                            </div>
                            <div className="p-2 rounded-lg bg-slate-50">
                              <span className="text-slate-500 flex items-center gap-1">
                                <Users className="w-3 h-3 text-[#0072ce]" /> Followers (
                                {Number(artist.total_followers || 0).toLocaleString()})
                              </span>
                              <strong className="text-[#032b69]">
                                {formatUGX(artist.followers_earnings_ugx)}
                              </strong>
                            </div>
                            <div className="p-2 rounded-lg bg-slate-50">
                              <span className="text-slate-500 flex items-center gap-1">
                                <Download className="w-3 h-3 text-emerald-600" /> Downloads (
                                {Number(artist.total_downloads || 0).toLocaleString()})
                              </span>
                              <strong className="text-[#032b69]">
                                {formatUGX(artist.downloads_earnings_ugx)}
                              </strong>
                            </div>
                            <div className="p-2 rounded-lg bg-slate-50">
                              <span className="text-slate-500 flex items-center gap-1">
                                <Headphones className="w-3 h-3 text-indigo-600" /> Streams (
                                {Number(artist.total_streams || 0).toLocaleString()})
                              </span>
                              <strong className="text-[#032b69]">
                                {formatUGX(artist.streams_earnings_ugx)}
                              </strong>
                            </div>
                            <div className="p-2 rounded-lg bg-amber-50/70">
                              <span className="text-slate-500">Pending Earnings</span>
                              <strong className="text-amber-800 block">
                                {formatUGX(artist.pending_earnings_ugx)}
                              </strong>
                            </div>
                            <div className="p-2 rounded-lg bg-slate-50">
                              <span className="text-slate-500">Withdrawn / In Review</span>
                              <strong className="text-slate-900 block">
                                {formatUGX(artist.amount_withdrawn_ugx)} /{' '}
                                {formatUGX(artist.pending_withdrawals_ugx)}
                              </strong>
                            </div>
                          </div>
                          {artist.is_suspended && artist.suspended_reason && (
                            <p className="text-red-700 font-semibold pt-1">
                              Suspension Reason: {artist.suspended_reason}
                            </p>
                          )}
                        </div>

                        <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-2">
                          <h4 className="font-black text-[#032b69] flex items-center gap-1.5">
                            <CreditCard className="w-3.5 h-3.5 text-[#0072ce]" />
                            <span>Private Payout Profile</span>
                          </h4>
                          {artist.payout_profile ? (
                            <div className="space-y-1 text-slate-700">
                              <p>
                                <strong>Legal Name:</strong> {artist.payout_profile.full_legal_name}
                              </p>
                              <p>
                                <strong>Country:</strong> {artist.payout_profile.country}
                              </p>
                              <p>
                                <strong>Phone:</strong> {artist.payout_profile.phone_number}
                              </p>
                              <p>
                                <strong>Verified Gmail:</strong>{' '}
                                {artist.payout_profile.registered_gmail}
                              </p>
                              <p>
                                <strong>Mobile Money:</strong>{' '}
                                <span className="text-[#032b69] font-black">
                                  {artist.payout_profile.mobile_money_provider} (
                                  {artist.payout_profile.mobile_money_number})
                                </span>
                              </p>
                            </div>
                          ) : (
                            <p className="text-slate-500">
                              Artist has not submitted private payout information yet.
                            </p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ====================================================================
          SECTION 2: ARTIST EARNINGS & MONTHLY ROYALTY REPORTS
         ==================================================================== */}
      {activeSection === 'earnings' && (
        <div className="space-y-5">
          {/* Platform Royalty Breakdown by Engagement Pillar */}
          <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base sm:text-lg font-black text-[#032b69] flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-[#0072ce]" />
                  <span>Platform Royalty Totals &amp; Monthly Report</span>
                </h2>
                <p className="text-xs text-slate-500">
                  Real-time platform engagement totals, credited UGX royalties, and monthly royalty
                  reporting.
                </p>
              </div>
              <span className="text-[11px] font-black px-3 py-1 rounded-full bg-blue-50 text-[#032b69] border border-blue-200 self-start">
                All Verified UGX Royalties
              </span>
            </div>

            {/* 4 Pillar Totals */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
                <span className="text-xs font-bold text-slate-600 flex items-center gap-1.5">
                  <Heart className="w-3.5 h-3.5 text-red-500" />
                  Likes Royalties
                </span>
                <div className="text-xl font-black text-[#032b69] tabular-nums">
                  {formatUGX(summaryStats.totalLikesUgx)}
                </div>
                <p className="text-[11px] text-slate-500">
                  {summaryStats.totalLikes.toLocaleString()} total eligible likes
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
                <span className="text-xs font-bold text-slate-600 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-[#0072ce]" />
                  Followers Royalties
                </span>
                <div className="text-xl font-black text-[#032b69] tabular-nums">
                  {formatUGX(summaryStats.totalFollowersUgx)}
                </div>
                <p className="text-[11px] text-slate-500">
                  {summaryStats.totalFollowers.toLocaleString()} genuine followers
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
                <span className="text-xs font-bold text-slate-600 flex items-center gap-1.5">
                  <Download className="w-3.5 h-3.5 text-emerald-600" />
                  Download Royalties
                </span>
                <div className="text-xl font-black text-[#032b69] tabular-nums">
                  {formatUGX(summaryStats.totalDownloadsUgx)}
                </div>
                <p className="text-[11px] text-slate-500">
                  {summaryStats.totalDownloads.toLocaleString()} eligible downloads
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
                <span className="text-xs font-bold text-slate-600 flex items-center gap-1.5">
                  <Headphones className="w-3.5 h-3.5 text-indigo-600" />
                  Streaming Royalties
                </span>
                <div className="text-xl font-black text-[#032b69] tabular-nums">
                  {formatUGX(summaryStats.totalStreamsUgx)}
                </div>
                <p className="text-[11px] text-slate-500">
                  {summaryStats.totalStreams.toLocaleString()} eligible streams
                </p>
              </div>
            </div>

            {/* Monthly Royalty Report Strip */}
            <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200/80 space-y-3">
              <div className="flex items-center gap-2 text-xs font-black text-[#032b69]">
                <CalendarDays className="w-4 h-4 text-[#0072ce]" />
                <span>Monthly Royalty Report Summary</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                <div className="bg-white rounded-xl p-3 border border-blue-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    Current Month
                  </span>
                  <strong className="text-sm sm:text-base font-black text-[#032b69] tabular-nums">
                    {formatUGX(summaryStats.currentMonthEarned)}
                  </strong>
                </div>
                <div className="bg-white rounded-xl p-3 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    Previous Month
                  </span>
                  <strong className="text-sm sm:text-base font-black text-slate-800 tabular-nums">
                    {formatUGX(summaryStats.previousMonthEarned)}
                  </strong>
                </div>
                <div className="bg-white rounded-xl p-3 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    Month Likes
                  </span>
                  <strong className="text-sm sm:text-base font-black text-red-600 tabular-nums">
                    {summaryStats.monthlyLikes.toLocaleString()}
                  </strong>
                </div>
                <div className="bg-white rounded-xl p-3 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    Month Followers
                  </span>
                  <strong className="text-sm sm:text-base font-black text-[#0072ce] tabular-nums">
                    {summaryStats.monthlyFollowers.toLocaleString()}
                  </strong>
                </div>
                <div className="bg-white rounded-xl p-3 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    Month Downloads
                  </span>
                  <strong className="text-sm sm:text-base font-black text-emerald-700 tabular-nums">
                    {summaryStats.monthlyDownloads.toLocaleString()}
                  </strong>
                </div>
                <div className="bg-white rounded-xl p-3 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    Month Streams
                  </span>
                  <strong className="text-sm sm:text-base font-black text-indigo-700 tabular-nums">
                    {summaryStats.monthlyStreams.toLocaleString()}
                  </strong>
                </div>
              </div>
            </div>
          </div>

          {/* Individual Artist Royalties & Monthly Breakdown Table */}
          <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-black text-[#032b69]">
                  Individual Artist Earnings &amp; Monthly Performance (
                  {filteredEarningsArtists.length})
                </h3>
                <p className="text-xs text-slate-500">
                  Inspect each artist&apos;s likes, followers, downloads, streams, monthly earnings,
                  and individual transaction history.
                </p>
              </div>
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={earningsSearch}
                  onChange={(e) => setEarningsSearch(e.target.value)}
                  placeholder="Filter artist..."
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
                />
              </div>
            </div>

            {filteredEarningsArtists.length === 0 ? (
              <div className="py-10 text-center text-xs text-slate-500 rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50">
                No artist earnings records match your search.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-[11px] font-black text-slate-500 uppercase">
                      <th className="py-2.5 pr-3">Artist</th>
                      <th className="py-2.5 px-2">Likes</th>
                      <th className="py-2.5 px-2">Followers</th>
                      <th className="py-2.5 px-2">Downloads</th>
                      <th className="py-2.5 px-2">Streams</th>
                      <th className="py-2.5 px-2">This / Last Mo</th>
                      <th className="py-2.5 px-2">Total / Avail</th>
                      <th className="py-2.5 pl-2 text-right">Ledger</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredEarningsArtists.map((a) => (
                      <tr key={a.user_id} className="hover:bg-slate-50/80">
                        <td className="py-3 pr-3">
                          <div className="font-black text-slate-900">{a.artist_name}</div>
                          <div className="text-[11px] text-slate-500">{a.email}</div>
                        </td>
                        <td className="py-3 px-2 tabular-nums">
                          <div className="font-bold text-slate-900">
                            {Number(a.total_likes || 0).toLocaleString()}
                          </div>
                          <div className="text-[11px] text-[#032b69] font-bold">
                            {formatUGX(a.likes_earnings_ugx)}
                          </div>
                        </td>
                        <td className="py-3 px-2 tabular-nums">
                          <div className="font-bold text-slate-900">
                            {Number(a.total_followers || 0).toLocaleString()}
                          </div>
                          <div className="text-[11px] text-[#032b69] font-bold">
                            {formatUGX(a.followers_earnings_ugx)}
                          </div>
                        </td>
                        <td className="py-3 px-2 tabular-nums">
                          <div className="font-bold text-slate-900">
                            {Number(a.total_downloads || 0).toLocaleString()}
                          </div>
                          <div className="text-[11px] text-[#032b69] font-bold">
                            {formatUGX(a.downloads_earnings_ugx)}
                          </div>
                        </td>
                        <td className="py-3 px-2 tabular-nums">
                          <div className="font-bold text-slate-900">
                            {Number(a.total_streams || 0).toLocaleString()}
                          </div>
                          <div className="text-[11px] text-[#032b69] font-bold">
                            {formatUGX(a.streams_earnings_ugx)}
                          </div>
                        </td>
                        <td className="py-3 px-2 tabular-nums">
                          <div className="font-bold text-[#0072ce]">
                            {formatUGX(a.monthly_earnings_ugx)}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            Prev: {formatUGX(a.previous_month_earnings_ugx)}
                          </div>
                        </td>
                        <td className="py-3 px-2 tabular-nums">
                          <div className="font-black text-[#032b69]">
                            {formatUGX(a.total_earnings_ugx)}
                          </div>
                          <div className="text-[11px] text-emerald-700 font-bold">
                            Avail: {formatUGX(a.available_balance_ugx)}
                          </div>
                        </td>
                        <td className="py-3 pl-2 text-right">
                          <button
                            type="button"
                            onClick={() => setInspectTransactionsArtist(a)}
                            className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-[#032b69] font-bold text-[11px] rounded-lg cursor-pointer inline-flex items-center gap-1"
                          >
                            <Receipt className="w-3 h-3" />
                            <span>Transactions</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ====================================================================
          SECTION 3: WITHDRAWAL MANAGEMENT
         ==================================================================== */}
      {activeSection === 'withdrawals' && (
        <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base sm:text-lg font-black text-[#032b69] flex items-center gap-2">
                <ArrowDownToLine className="w-5 h-5 text-[#0072ce]" />
                <span>Withdrawal Management ({filteredWithdrawals.length})</span>
              </h2>
              <p className="text-xs text-slate-500">
                Review requests, view private payout details, approve payouts, reject with a reason,
                and mark Paid only after recording a real Mobile Money confirmation reference.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              {(['all', 'Pending', 'Approved', 'Paid', 'Rejected'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setWithdrawalFilter(st)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                    withdrawalFilter === st
                      ? 'bg-[#032b69] text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {st === 'all' ? 'All' : st}
                </button>
              ))}
            </div>
          </div>

          {filteredWithdrawals.length === 0 ? (
            <div className="py-10 text-center text-xs text-slate-500 rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50">
              No withdrawal requests in this status.
            </div>
          ) : (
            <div className="space-y-3">
              {filteredWithdrawals.map((w) => {
                const isBusy = busyWithdrawalId === w.id;
                return (
                  <div
                    key={w.id}
                    className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/80 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                  >
                    <div className="space-y-1.5 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${badgeClass(
                            w.status
                          )}`}
                        >
                          {w.status}
                        </span>
                        <span className="text-base font-black text-[#032b69] tabular-nums">
                          {formatUGX(w.amount_ugx)}
                        </span>
                        <span className="font-mono text-[11px] font-bold text-slate-500">
                          {w.reference_code}
                        </span>
                      </div>
                      <div className="text-xs text-slate-700 font-semibold">
                        Artist: <strong>{w.artist_name}</strong> ({w.registered_gmail})
                      </div>
                      <div className="text-xs text-slate-600">
                        Payout To: <strong>{w.payout_full_name}</strong> &bull;{' '}
                        <strong className="text-[#032b69]">{w.mobile_money_provider}</strong>:{' '}
                        <strong className="text-slate-900">{w.mobile_money_number}</strong> &bull;
                        Phone: {w.payout_phone} ({w.payout_country})
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Requested: {formatDate(w.created_at)}
                        {w.approved_at ? ` • Approved: ${formatDate(w.approved_at)}` : ''}
                        {w.paid_at ? ` • Paid: ${formatDate(w.paid_at)}` : ''}
                      </div>
                      {w.payment_reference && (
                        <p className="text-xs font-bold text-emerald-700">
                          Payment Confirmation Ref: {w.payment_reference}
                          {w.admin_note ? ` — ${w.admin_note}` : ''}
                        </p>
                      )}
                      {w.rejection_reason && (
                        <p className="text-xs font-semibold text-red-700">
                          Rejection Reason: {w.rejection_reason}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      {w.status === 'Pending' && (
                        <>
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => handleApproveWithdrawal(w)}
                            className="px-3.5 py-2 bg-[#0072ce] hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-sm cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-50"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Approve</span>
                          </button>
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => {
                              setRejectModalWithdrawal(w);
                              setRejectReasonInput('');
                            }}
                            className="px-3.5 py-2 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-bold text-xs rounded-xl cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-50"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </>
                      )}

                      {w.status === 'Approved' && (
                        <>
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => {
                              setPaymentModalWithdrawal(w);
                              setPaymentReferenceInput('');
                              setPaymentNoteInput('');
                            }}
                            className="px-3.5 py-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow-sm cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-50"
                          >
                            <Banknote className="w-4 h-4" />
                            <span>Record Payment (Paid)</span>
                          </button>
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => {
                              setRejectModalWithdrawal(w);
                              setRejectReasonInput('');
                            }}
                            className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-bold text-xs rounded-xl cursor-pointer"
                          >
                            Reject
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ====================================================================
          SECTION 4: ROYALTY SETTINGS (ALL 6 CONFIGURABLE RATES + MIN WITHDRAWAL)
         ==================================================================== */}
      {activeSection === 'rates' && (
        <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 max-w-3xl space-y-5">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-base sm:text-lg font-black text-[#032b69] flex items-center gap-2">
              <Settings className="w-5 h-5 text-[#0072ce]" />
              <span>Royalty &amp; Withdrawal Settings</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Configure UGX royalty rates for downloads, music streams, likes, and followers, plus
              the minimum withdrawal amount. Updated rates apply to future milestones only and never
              rewrite previously credited earnings.
            </p>
          </div>

          <form onSubmit={handleSaveRates} className="space-y-4">
            {/* Download Royalties */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#032b69] flex items-center gap-1.5">
                  <Download className="w-4 h-4 text-emerald-600" />
                  Download Royalties
                </span>
                <span className="text-[11px] font-bold text-slate-500">
                  Current: {formatUGX(settings.downloads_rate_ugx)} / {settings.downloads_per_unit}{' '}
                  {settings.downloads_per_unit === 1 ? 'download' : 'downloads'}
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Earning Amount per Download Milestone (UGX)
                  </label>
                  <input
                    type="number"
                    min={0}
                    step="0.5"
                    required
                    value={downloadsRateUgx}
                    onChange={(e) => setDownloadsRateUgx(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl font-black focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Number of Eligible Downloads Required
                  </label>
                  <input
                    type="number"
                    min={1}
                    step={1}
                    required
                    value={downloadsPerUnit}
                    onChange={(e) => setDownloadsPerUnit(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl font-black focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
                  />
                </div>
              </div>
            </div>

            {/* Streaming Royalties */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#032b69] flex items-center gap-1.5">
                  <Headphones className="w-4 h-4 text-indigo-600" />
                  Music Streaming Royalties
                </span>
                <span className="text-[11px] font-bold text-slate-500">
                  Current: {formatUGX(settings.streams_rate_ugx)} / {settings.streams_per_unit}{' '}
                  {settings.streams_per_unit === 1 ? 'stream' : 'streams'}
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Earning Amount per Stream Milestone (UGX)
                  </label>
                  <input
                    type="number"
                    min={0}
                    step="0.5"
                    required
                    value={streamsRateUgx}
                    onChange={(e) => setStreamsRateUgx(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl font-black focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Number of Eligible Streams Required
                  </label>
                  <input
                    type="number"
                    min={1}
                    step={1}
                    required
                    value={streamsPerUnit}
                    onChange={(e) => setStreamsPerUnit(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl font-black focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
                  />
                </div>
              </div>
            </div>

            {/* Likes Royalties */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#032b69] flex items-center gap-1.5">
                  <Heart className="w-4 h-4 text-red-500" />
                  Likes Royalties
                </span>
                <span className="text-[11px] font-bold text-slate-500">
                  Current: {formatUGX(settings.likes_rate_ugx)} / {settings.likes_per_unit} likes
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Earning Amount per Likes Milestone (UGX)
                  </label>
                  <input
                    type="number"
                    min={0}
                    step="0.5"
                    required
                    value={likesRateUgx}
                    onChange={(e) => setLikesRateUgx(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl font-black focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Number of Eligible Likes Required
                  </label>
                  <input
                    type="number"
                    min={1}
                    step={1}
                    required
                    value={likesPerUnit}
                    onChange={(e) => setLikesPerUnit(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl font-black focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
                  />
                </div>
              </div>
            </div>

            {/* Followers Royalties */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#032b69] flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-[#0072ce]" />
                  Followers Royalties
                </span>
                <span className="text-[11px] font-bold text-slate-500">
                  Current: {formatUGX(settings.followers_rate_ugx)} / {settings.followers_per_unit}{' '}
                  followers
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Earning Amount per Followers Milestone (UGX)
                  </label>
                  <input
                    type="number"
                    min={0}
                    step="1"
                    required
                    value={followersRateUgx}
                    onChange={(e) => setFollowersRateUgx(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl font-black focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Number of Genuine Followers Required
                  </label>
                  <input
                    type="number"
                    min={1}
                    step={1}
                    required
                    value={followersPerUnit}
                    onChange={(e) => setFollowersPerUnit(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl font-black focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
                  />
                </div>
              </div>
            </div>

            {/* Minimum Withdrawal Amount */}
            <div className="p-4 rounded-2xl bg-yellow-50/70 border border-yellow-200 space-y-2">
              <label className="block text-xs font-black text-[#032b69]">
                Minimum Withdrawal Amount (UGX)
              </label>
              <input
                type="number"
                min={1000}
                step={500}
                required
                value={minWithdrawalUgx}
                onChange={(e) => setMinWithdrawalUgx(e.target.value)}
                className="w-full sm:w-64 px-3.5 py-2.5 text-sm bg-white text-slate-900 border border-yellow-300 rounded-xl font-black focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
              />
              <p className="text-[11px] text-slate-600">
                Default is 15,000 UGX. Enforced strictly on the backend when artists submit
                withdrawals.
              </p>
            </div>

            <button
              type="submit"
              disabled={isSavingRates}
              className="px-5 py-2.5 bg-[#0072ce] hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow transition-all cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-60"
            >
              {isSavingRates ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <CheckCircle2 className="w-4 h-4" />
              )}
              <span>Save All Royalty &amp; Withdrawal Settings</span>
            </button>
          </form>
        </div>
      )}

      {/* ====================================================================
          SECTION 5: TRANSACTIONS & ADMIN AUDIT LOGS
         ==================================================================== */}
      {activeSection === 'transactions' && (
        <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base sm:text-lg font-black text-[#032b69] flex items-center gap-2">
                {txSubView === 'ledger' ? (
                  <Receipt className="w-5 h-5 text-[#0072ce]" />
                ) : (
                  <History className="w-5 h-5 text-[#0072ce]" />
                )}
                <span>
                  {txSubView === 'ledger'
                    ? `Platform Financial Ledger (${filteredTransactions.length})`
                    : `Admin Audit Logs (${auditLogs.length})`}
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                {txSubView === 'ledger'
                  ? 'Immutable record of all artist royalty credits, withdrawal requests, and confirmed Mobile Money payouts.'
                  : 'Complete audit trail of royalty rate changes, withdrawal approvals/payments/rejections, and account suspensions.'}
              </p>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setTxSubView('ledger')}
                className={`px-3 py-1.5 rounded-xl text-xs font-black cursor-pointer ${
                  txSubView === 'ledger'
                    ? 'bg-[#032b69] text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Financial Ledger
              </button>
              <button
                type="button"
                onClick={() => setTxSubView('audit')}
                className={`px-3 py-1.5 rounded-xl text-xs font-black cursor-pointer ${
                  txSubView === 'audit'
                    ? 'bg-[#032b69] text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Admin Audit Log ({auditLogs.length})
              </button>
            </div>
          </div>

          {txSubView === 'ledger' ? (
            <>
              <div className="flex flex-wrap items-center gap-1.5">
                {(
                  [
                    { id: 'all', label: 'All Transactions' },
                    { id: 'earnings', label: 'Earnings' },
                    { id: 'withdrawals', label: 'Withdrawals' },
                    { id: 'Pending', label: 'Pending' },
                    { id: 'Approved', label: 'Approved' },
                    { id: 'Paid', label: 'Paid' },
                    { id: 'Rejected', label: 'Rejected' },
                  ] as const
                ).map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setTxTypeFilter(t.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer ${
                      txTypeFilter === t.id
                        ? 'bg-[#0072ce] text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
                <input
                  type="text"
                  value={txSearch}
                  onChange={(e) => setTxSearch(e.target.value)}
                  placeholder="Search by artist, email, category, reference code, or MoMo payment ref..."
                  className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
                />
              </div>

              {filteredTransactions.length === 0 ? (
                <div className="py-10 text-center text-xs text-slate-500 rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50">
                  No earning or payment transactions match your filter.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {filteredTransactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="p-3.5 rounded-2xl bg-slate-50/80 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${badgeClass(
                              tx.status
                            )}`}
                          >
                            {tx.status}
                          </span>
                          <span className="px-2 py-0.5 rounded-full bg-blue-100 text-[#032b69] text-[10px] font-black">
                            {getTransactionCategoryLabel(tx)}
                          </span>
                          <span className="text-xs font-black text-slate-900">
                            {tx.artist_name || 'Artist'}
                          </span>
                          <span className="text-[11px] text-slate-500">{tx.artist_email}</span>
                          <span className="font-mono text-[11px] text-slate-400">
                            {tx.reference_code}
                          </span>
                        </div>
                        <p className="text-xs text-slate-700 font-medium">{tx.description}</p>
                        <div className="text-[11px] text-slate-400">
                          {formatDate(tx.created_at)}
                          {tx.payment_reference ? ` • Paid Ref: ${tx.payment_reference}` : ''}
                        </div>
                      </div>
                      <div className="sm:text-right shrink-0">
                        <span
                          className={`text-sm sm:text-base font-black tabular-nums ${
                            tx.direction === 'credit' ? 'text-emerald-700' : 'text-[#032b69]'
                          }`}
                        >
                          {tx.direction === 'credit' ? '+' : '-'}
                          {formatUGX(tx.amount_ugx)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          ) : auditLogs.length === 0 ? (
            <div className="py-10 text-center text-xs text-slate-500 rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50">
              No administrative actions have been recorded yet.
            </div>
          ) : (
            <div className="space-y-2.5">
              {auditLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full bg-[#032b69] text-[#FFCC00] text-[10px] font-black uppercase">
                        {log.action.replace(/_/g, ' ')}
                      </span>
                      <span className="text-xs font-bold text-slate-700">{log.admin_email}</span>
                    </div>
                    <span className="text-[11px] text-slate-400">{formatDate(log.created_at)}</span>
                  </div>
                  <p className="text-xs text-slate-800 font-semibold">{log.summary}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ====================================================================
          MODAL: INSPECT INDIVIDUAL ARTIST TRANSACTIONS
         ==================================================================== */}
      {inspectTransactionsArtist && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl md:rounded-3xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-black text-[#032b69]">
                  {inspectTransactionsArtist.artist_name} — Transaction Ledger
                </h3>
                <p className="text-xs text-slate-500">
                  {inspectTransactionsArtist.email} &bull; Total Earned:{' '}
                  <strong>{formatUGX(inspectTransactionsArtist.total_earnings_ugx)}</strong> &bull;
                  Available:{' '}
                  <strong className="text-emerald-700">
                    {formatUGX(inspectTransactionsArtist.available_balance_ugx)}
                  </strong>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setInspectTransactionsArtist(null)}
                className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-2.5">
              {inspectedArtistTransactions.length === 0 ? (
                <div className="py-10 text-center text-xs text-slate-500 rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50">
                  No transactions recorded for this artist yet.
                </div>
              ) : (
                inspectedArtistTransactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
                  >
                    <div className="space-y-0.5 min-w-0">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${badgeClass(
                            tx.status
                          )}`}
                        >
                          {tx.status}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-blue-100 text-[#032b69] text-[10px] font-black">
                          {getTransactionCategoryLabel(tx)}
                        </span>
                        <span className="font-mono text-[10px] text-slate-400">
                          {tx.reference_code}
                        </span>
                      </div>
                      <p className="text-xs font-semibold text-slate-800">{tx.description}</p>
                      <p className="text-[11px] text-slate-400">
                        {formatDate(tx.created_at)}
                        {tx.payment_reference ? ` • Ref: ${tx.payment_reference}` : ''}
                      </p>
                    </div>
                    <span
                      className={`text-sm font-black tabular-nums shrink-0 ${
                        tx.direction === 'credit' ? 'text-emerald-700' : 'text-[#032b69]'
                      }`}
                    >
                      {tx.direction === 'credit' ? '+' : '-'}
                      {formatUGX(tx.amount_ugx)}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================
          MODAL: RECORD ACTUAL MOBILE MONEY PAYMENT (MARKS AS PAID)
         ==================================================================== */}
      {paymentModalWithdrawal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleConfirmPaid}
            className="bg-white rounded-2xl md:rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4"
          >
            <div>
              <h3 className="text-base font-black text-[#032b69]">
                Confirm Completed Mobile Money Payment
              </h3>
              <p className="text-xs text-slate-600 mt-1">
                Only mark <strong>Paid</strong> after sending{' '}
                <strong className="text-[#032b69]">
                  {formatUGX(paymentModalWithdrawal.amount_ugx)}
                </strong>{' '}
                to <strong>{paymentModalWithdrawal.payout_full_name}</strong> via{' '}
                <strong>{paymentModalWithdrawal.mobile_money_provider}</strong> (
                {paymentModalWithdrawal.mobile_money_number}).
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Mobile Money Transaction Reference <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={paymentReferenceInput}
                onChange={(e) => setPaymentReferenceInput(e.target.value)}
                placeholder="e.g. MP260412.1422.A83920"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl font-bold focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Admin Note (Optional)
              </label>
              <input
                type="text"
                value={paymentNoteInput}
                onChange={(e) => setPaymentNoteInput(e.target.value)}
                placeholder="Optional internal note"
                className="w-full px-3.5 py-2 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setPaymentModalWithdrawal(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={busyWithdrawalId === paymentModalWithdrawal.id}
                className="px-4 py-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow cursor-pointer disabled:opacity-50"
              >
                Mark Paid &amp; Record Ref
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ====================================================================
          MODAL: REJECT WITHDRAWAL WITH REASON (REFUNDS BALANCE)
         ==================================================================== */}
      {rejectModalWithdrawal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleConfirmReject}
            className="bg-white rounded-2xl md:rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4"
          >
            <div>
              <h3 className="text-base font-black text-red-700">Reject Withdrawal Request</h3>
              <p className="text-xs text-slate-600 mt-1">
                Rejecting <strong>{rejectModalWithdrawal.reference_code}</strong> (
                {formatUGX(rejectModalWithdrawal.amount_ugx)}) automatically returns the reserved
                amount to the artist&apos;s available balance.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Rejection Reason <span className="text-red-500">*</span>
              </label>
              <textarea
                rows={3}
                required
                value={rejectReasonInput}
                onChange={(e) => setRejectReasonInput(e.target.value)}
                placeholder="Explain clearly why this withdrawal could not be processed..."
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-400"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setRejectModalWithdrawal(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={busyWithdrawalId === rejectModalWithdrawal.id}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow cursor-pointer disabled:opacity-50"
              >
                Confirm Rejection
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
