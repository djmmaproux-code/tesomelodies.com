import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import {
  X,
  Play,
  Pause,
  Volume2,
  Volume1,
  VolumeX,
  Sun,
  Maximize,
  Minimize,
  Heart,
  Share2,
  AlertCircle,
  RotateCw,
  RotateCcw,
  Settings,
  Trash2,
  Gauge,
  Check,
  Sparkles,
} from 'lucide-react';
import { VideoItem, VideoQualityKey } from '../types/music';
import { VIDEO_QUALITY_ORDER, formatVideoDuration } from '../services/videoService';

interface VideoPlayerModalProps {
  video: VideoItem | null;
  onClose: () => void;
  onShare: (video: VideoItem) => void;
  onToggleLike?: (videoId: string) => void;
  isLiked?: boolean;
  canDelete?: boolean;
  onDeleteVideo?: (video: VideoItem) => void;
}

const SPEED_OPTIONS = [0.5, 0.75, 1, 1.25, 1.5, 2] as const;
const LOWEST_FIRST_QUALITY_ORDER: VideoQualityKey[] = ['360p', '480p', '720p', '1080p'];

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({
  video,
  onClose,
  onShare,
  onToggleLike,
  isLiked = false,
  canDelete = false,
  onDeleteVideo,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const hideControlsTimerRef = useRef<number | null>(null);
  const hudTimerRef = useRef<number | null>(null);
  const lastGestureEndRef = useRef<number>(0);
  const pendingRestoreRef = useRef<{ time: number; shouldPlay: boolean; rate: number } | null>(null);

  const touchGestureRef = useRef<{
    active: boolean;
    moved: boolean;
    startX: number;
    startY: number;
    startBrightness: number;
    startVolume: number;
    mode: 'none' | 'brightness' | 'volume';
  }>({
    active: false,
    moved: false,
    startX: 0,
    startY: 0,
    startBrightness: 100,
    startVolume: 1,
    mode: 'none',
  });

  const [isPlaying, setIsPlaying] = useState(false);
  const [isBuffering, setIsBuffering] = useState(true);
  const [bufferingLabel, setBufferingLabel] = useState<string>('Preparing stream...');
  const [playbackError, setPlaybackError] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [bufferedPercent, setBufferedPercent] = useState(0);

  // Audio & Brightness controls
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [brightness, setBrightness] = useState(100); // percentage 30..140

  // Playback Speed, Quality & Fullscreen
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [settingsTab, setSettingsTab] = useState<'none' | 'speed' | 'quality'>('none');
  const [confirmDeleteArmed, setConfirmDeleteArmed] = useState(false);

  // Seek preview tooltip state
  const [hoverSeekTime, setHoverSeekTime] = useState<number | null>(null);
  const [hoverSeekPercent, setHoverSeekPercent] = useState<number>(0);

  // Transient HUD feedback badge (for brightness, volume, skip ±10s, quality switches)
  const [hudFeedback, setHudFeedback] = useState<{
    type: 'brightness' | 'volume' | 'seek-forward' | 'seek-back' | 'quality';
    label: string;
    percent?: number;
  } | null>(null);

  const showHud = useCallback(
    (feedback: {
      type: 'brightness' | 'volume' | 'seek-forward' | 'seek-back' | 'quality';
      label: string;
      percent?: number;
    }) => {
      setHudFeedback(feedback);
      if (hudTimerRef.current) window.clearTimeout(hudTimerRef.current);
      hudTimerRef.current = window.setTimeout(() => {
        setHudFeedback(null);
      }, 1150);
    },
    []
  );

  // Available quality URLs for active video
  const availableQualityMap = useMemo(() => {
    if (!video) return {} as Partial<Record<VideoQualityKey, string>>;
    const map: Partial<Record<VideoQualityKey, string>> = {};
    if (video.qualityUrls) {
      for (const q of VIDEO_QUALITY_ORDER) {
        if (video.qualityUrls[q]) map[q] = video.qualityUrls[q];
      }
    }
    if (Object.keys(map).length === 0 && video.videoUrl) {
      const defQ = video.defaultQuality || '720p';
      map[defQ] = video.videoUrl;
    }
    return map;
  }, [video]);

  // Auto-start selects the LOWEST available quality first (360p -> 480p -> 720p -> 1080p) to minimize buffering
  const lowestAvailableQuality = useMemo<VideoQualityKey>(() => {
    for (const q of LOWEST_FIRST_QUALITY_ORDER) {
      if (availableQualityMap[q]) return q;
    }
    return video?.defaultQuality || '360p';
  }, [availableQualityMap, video?.defaultQuality]);

  const [selectedQuality, setSelectedQuality] = useState<'Auto' | VideoQualityKey>('Auto');

  const effectiveStreamQuality: VideoQualityKey =
    selectedQuality === 'Auto' ? lowestAvailableQuality : selectedQuality;

  const activeSourceUrl = useMemo(() => {
    if (!video) return '';
    if (selectedQuality !== 'Auto' && availableQualityMap[selectedQuality]) {
      return availableQualityMap[selectedQuality]!;
    }
    return availableQualityMap[lowestAvailableQuality] || video.videoUrl;
  }, [video, selectedQuality, availableQualityMap, lowestAvailableQuality]);

  // Reset player cleanly when video changes
  useEffect(() => {
    if (!video) return;
    setIsPlaying(false);
    setIsBuffering(true);
    setBufferingLabel(`Starting stream in ${lowestAvailableQuality}...`);
    setPlaybackError(null);
    setCurrentTime(0);
    setDuration(video.durationSec || 0);
    setBufferedPercent(0);
    setPlaybackRate(1);
    setSelectedQuality('Auto');
    setSettingsTab('none');
    setControlsVisible(true);
    setConfirmDeleteArmed(false);
    setHudFeedback(null);
    pendingRestoreRef.current = null;
  }, [video?.id, lowestAvailableQuality]);

  // Cleanup timers & unlock screen orientation on unmount
  useEffect(() => {
    return () => {
      if (hideControlsTimerRef.current) window.clearTimeout(hideControlsTimerRef.current);
      if (hudTimerRef.current) window.clearTimeout(hudTimerRef.current);
      try {
        (screen.orientation as any)?.unlock?.();
      } catch {
        // ignore
      }
    };
  }, []);

  // Listen for fullscreen exit & auto-unlock orientation
  useEffect(() => {
    const handleFsChange = () => {
      const fsEl =
        document.fullscreenElement ||
        (document as any).webkitFullscreenElement ||
        (document as any).mozFullScreenElement;
      const nowFs = Boolean(fsEl);
      setIsFullscreen(nowFs);

      if (!nowFs) {
        try {
          (screen.orientation as any)?.unlock?.();
        } catch {
          // ignore
        }
      }
    };

    document.addEventListener('fullscreenchange', handleFsChange);
    document.addEventListener('webkitfullscreenchange', handleFsChange);
    document.addEventListener('mozfullscreenchange', handleFsChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFsChange);
      document.removeEventListener('webkitfullscreenchange', handleFsChange);
      document.removeEventListener('mozfullscreenchange', handleFsChange);
    };
  }, []);

  // Auto-hide timer for controls (smoothly fades out without pausing or interrupting)
  const resetHideTimer = useCallback(
    (forceShow = true) => {
      if (hideControlsTimerRef.current) {
        window.clearTimeout(hideControlsTimerRef.current);
        hideControlsTimerRef.current = null;
      }
      if (forceShow) {
        setControlsVisible(true);
      }
      if (isPlaying && settingsTab === 'none') {
        hideControlsTimerRef.current = window.setTimeout(() => {
          setControlsVisible(false);
        }, 3200);
      }
    },
    [isPlaying, settingsTab]
  );

  useEffect(() => {
    resetHideTimer(true);
    return () => {
      if (hideControlsTimerRef.current) window.clearTimeout(hideControlsTimerRef.current);
    };
  }, [isPlaying, settingsTab, resetHideTimer]);

  // Toggle visibility ONLY on video surface tap/click — NEVER pauses playback!
  const handleStageTap = useCallback(() => {
    if (Date.now() - lastGestureEndRef.current < 260) return;

    if (settingsTab !== 'none') {
      setSettingsTab('none');
      resetHideTimer(true);
      return;
    }

    if (!isPlaying) {
      setControlsVisible(true);
      return;
    }

    setControlsVisible((prev) => {
      const next = !prev;
      if (hideControlsTimerRef.current) {
        window.clearTimeout(hideControlsTimerRef.current);
        hideControlsTimerRef.current = null;
      }
      if (next) {
        hideControlsTimerRef.current = window.setTimeout(() => {
          setControlsVisible(false);
        }, 3200);
      }
      return next;
    });
  }, [isPlaying, settingsTab, resetHideTimer]);

  // Dedicated Play / Pause button action ONLY
  const handlePlayPauseButton = useCallback(
    (e?: React.MouseEvent | React.KeyboardEvent) => {
      if (e && 'stopPropagation' in e) e.stopPropagation();
      const el = videoRef.current;
      if (!el) return;
      setSettingsTab('none');

      if (el.paused || el.ended) {
        setPlaybackError(null);
        const p = el.play();
        if (p && typeof p.catch === 'function') {
          p.catch((err) => {
            if (err?.name === 'AbortError') return;
            if (err?.name === 'NotAllowedError') {
              setIsPlaying(false);
            }
          });
        }
      } else {
        el.pause();
      }
      resetHideTimer(true);
    },
    [resetHideTimer]
  );

  const handleSkipSeconds = useCallback(
    (deltaSec: number, e?: React.MouseEvent) => {
      e?.stopPropagation();
      const el = videoRef.current;
      if (!el) return;
      const totalDur = duration || el.duration || 0;
      const next = Math.max(0, Math.min(totalDur || Number.MAX_SAFE_INTEGER, (el.currentTime || 0) + deltaSec));
      el.currentTime = next;
      setCurrentTime(next);
      showHud({
        type: deltaSec >= 0 ? 'seek-forward' : 'seek-back',
        label: deltaSec >= 0 ? `+${deltaSec}s` : `${deltaSec}s`,
      });
      resetHideTimer(true);
    },
    [duration, showHud, resetHideTimer]
  );

  const toggleMute = useCallback(
    (e?: React.MouseEvent) => {
      e?.stopPropagation();
      const el = videoRef.current;
      if (!el) return;
      if (el.muted || el.volume === 0) {
        el.muted = false;
        const nextVol = volume > 0 ? volume : 0.8;
        el.volume = nextVol;
        setVolume(nextVol);
        setIsMuted(false);
        showHud({
          type: 'volume',
          label: `Volume ${Math.round(nextVol * 100)}%`,
          percent: Math.round(nextVol * 100),
        });
      } else {
        el.muted = true;
        setIsMuted(true);
        showHud({ type: 'volume', label: 'Muted', percent: 0 });
      }
      resetHideTimer(true);
    },
    [volume, showHud, resetHideTimer]
  );

  const handleVolumeChange = useCallback(
    (val: number) => {
      const el = videoRef.current;
      const clamped = Math.max(0, Math.min(1, val));
      if (el) {
        el.volume = clamped;
        el.muted = clamped === 0;
      }
      setVolume(clamped);
      setIsMuted(clamped === 0);
      showHud({
        type: 'volume',
        label: clamped === 0 ? 'Muted' : `Volume ${Math.round(clamped * 100)}%`,
        percent: Math.round(clamped * 100),
      });
      resetHideTimer(true);
    },
    [showHud, resetHideTimer]
  );

  const handleBrightnessChange = useCallback(
    (val: number) => {
      const clamped = Math.max(30, Math.min(140, Math.round(val)));
      setBrightness(clamped);
      showHud({
        type: 'brightness',
        label: `Brightness ${clamped}%`,
        percent: Math.round(((clamped - 30) / 110) * 100),
      });
      resetHideTimer(true);
    },
    [showHud, resetHideTimer]
  );

  const handleSeek = useCallback(
    (nextTime: number) => {
      const el = videoRef.current;
      if (!el) return;
      const totalDur = duration || el.duration || 0;
      const clamped = Math.max(0, Math.min(totalDur, nextTime));
      el.currentTime = clamped;
      setCurrentTime(clamped);
      resetHideTimer(true);
    },
    [duration, resetHideTimer]
  );

  const handleSpeedChange = useCallback(
    (speed: number) => {
      const el = videoRef.current;
      setPlaybackRate(speed);
      if (el) el.playbackRate = speed;
      setSettingsTab('none');
      resetHideTimer(true);
    },
    [resetHideTimer]
  );

  const handleQualityChange = useCallback(
    (nextQuality: 'Auto' | VideoQualityKey) => {
      if (nextQuality === selectedQuality) {
        setSettingsTab('none');
        return;
      }
      if (nextQuality !== 'Auto' && !availableQualityMap[nextQuality]) {
        return;
      }
      const el = videoRef.current;
      if (el) {
        pendingRestoreRef.current = {
          time: el.currentTime || 0,
          shouldPlay: !el.paused && !el.ended,
          rate: playbackRate,
        };
      }
      const resolvedTarget = nextQuality === 'Auto' ? lowestAvailableQuality : nextQuality;
      setIsBuffering(true);
      setBufferingLabel(`Switching to ${resolvedTarget}...`);
      setPlaybackError(null);
      setSelectedQuality(nextQuality);
      setSettingsTab('none');
      showHud({
        type: 'quality',
        label: nextQuality === 'Auto' ? `Auto (${lowestAvailableQuality})` : `${nextQuality} HD`,
      });
      resetHideTimer(true);
    },
    [selectedQuality, availableQualityMap, playbackRate, lowestAvailableQuality, showHud, resetHideTimer]
  );

  // Fullscreen toggle with automatic Landscape orientation lock on mobile/tablet browsers
  const toggleFullscreen = useCallback(
    async (e?: React.MouseEvent | React.KeyboardEvent) => {
      e?.stopPropagation();
      const container = containerRef.current;
      const el = videoRef.current as any;

      try {
        const fsEl =
          document.fullscreenElement ||
          (document as any).webkitFullscreenElement ||
          (document as any).mozFullScreenElement;

        if (fsEl) {
          try {
            (screen.orientation as any)?.unlock?.();
          } catch {
            // ignore
          }
          if (document.exitFullscreen) await document.exitFullscreen();
          else if ((document as any).webkitExitFullscreen) (document as any).webkitExitFullscreen();
          else if ((document as any).mozCancelFullScreen) (document as any).mozCancelFullScreen();
        } else if (container) {
          if (container.requestFullscreen) {
            await container.requestFullscreen();
          } else if ((container as any).webkitRequestFullscreen) {
            (container as any).webkitRequestFullscreen();
          } else if ((container as any).mozRequestFullScreen) {
            (container as any).mozRequestFullScreen();
          } else if (el?.webkitEnterFullscreen) {
            // iPhone Safari fallback uses native full-screen player which auto-rotates naturally
            el.webkitEnterFullscreen();
            return;
          }

          // Lock orientation to landscape on supported mobile/tablet browsers
          try {
            const orientationApi = screen.orientation as any;
            if (orientationApi && typeof orientationApi.lock === 'function') {
              await orientationApi.lock('landscape').catch(async () => {
                await orientationApi.lock('landscape-primary').catch(() => {});
              });
            }
          } catch {
            // Unsupported on desktop or iOS — safe no-op
          }
        }
      } catch {
        if (el?.webkitEnterFullscreen) {
          try {
            el.webkitEnterFullscreen();
          } catch {
            // ignore
          }
        }
      }
      resetHideTimer(true);
    },
    [resetHideTimer]
  );

  const handleRetryPlayback = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    const el = videoRef.current;
    if (!el) return;
    setPlaybackError(null);
    setIsBuffering(true);
    setBufferingLabel('Reconnecting stream...');
    el.load();
    el.play().catch(() => {});
  }, []);

  // Touch vertical-swipe gesture handling (Left half = Brightness, Right half = Volume)
  const handleStageTouchStart = useCallback(
    (e: React.TouchEvent<HTMLDivElement>) => {
      if (e.touches.length !== 1) return;
      const target = e.target as HTMLElement | null;
      if (target?.closest('[data-player-control="true"]')) {
        return;
      }
      const touch = e.touches[0];
      touchGestureRef.current = {
        active: true,
        moved: false,
        startX: touch.clientX,
        startY: touch.clientY,
        startBrightness: brightness,
        startVolume: isMuted ? 0 : volume,
        mode: 'none',
      };
    },
    [brightness, volume, isMuted]
  );

  const handleStageTouchMove = useCallback(
    (e: React.TouchEvent<HTMLDivElement>) => {
      const gesture = touchGestureRef.current;
      if (!gesture.active || e.touches.length !== 1) return;
      const stage = containerRef.current;
      if (!stage) return;

      const touch = e.touches[0];
      const dx = touch.clientX - gesture.startX;
      const dy = touch.clientY - gesture.startY;
      const rect = stage.getBoundingClientRect();

      if (gesture.mode === 'none') {
        if (Math.abs(dy) > 14 && Math.abs(dy) > Math.abs(dx) * 1.2) {
          const isLeftSide = gesture.startX - rect.left < rect.width * 0.5;
          gesture.mode = isLeftSide ? 'brightness' : 'volume';
          gesture.moved = true;
        } else {
          return;
        }
      }

      if (gesture.mode === 'brightness') {
        const deltaPercent = (-dy / Math.max(120, rect.height * 0.7)) * 110;
        const nextBright = Math.max(30, Math.min(140, Math.round(gesture.startBrightness + deltaPercent)));
        setBrightness(nextBright);
        showHud({
          type: 'brightness',
          label: `Brightness ${nextBright}%`,
          percent: Math.round(((nextBright - 30) / 110) * 100),
        });
      } else if (gesture.mode === 'volume') {
        const deltaVol = -dy / Math.max(120, rect.height * 0.7);
        const nextVol = Math.max(0, Math.min(1, gesture.startVolume + deltaVol));
        const el = videoRef.current;
        if (el) {
          el.volume = nextVol;
          el.muted = nextVol === 0;
        }
        setVolume(nextVol);
        setIsMuted(nextVol === 0);
        showHud({
          type: 'volume',
          label: nextVol === 0 ? 'Muted' : `Volume ${Math.round(nextVol * 100)}%`,
          percent: Math.round(nextVol * 100),
        });
      }
    },
    [showHud]
  );

  const handleStageTouchEnd = useCallback(() => {
    if (touchGestureRef.current.moved) {
      lastGestureEndRef.current = Date.now();
    }
    touchGestureRef.current.active = false;
    touchGestureRef.current.moved = false;
    touchGestureRef.current.mode = 'none';
  }, []);

  // Keyboard shortcuts on desktop
  useEffect(() => {
    if (!video) return;
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

      if (e.key === 'Escape' && !document.fullscreenElement) {
        onClose();
      } else if (e.key === ' ' || e.key.toLowerCase() === 'k') {
        e.preventDefault();
        handlePlayPauseButton();
      } else if (e.key.toLowerCase() === 'm') {
        toggleMute();
      } else if (e.key.toLowerCase() === 'f') {
        toggleFullscreen();
      } else if (e.key === 'ArrowRight') {
        handleSeek((videoRef.current?.currentTime || 0) + 10);
      } else if (e.key === 'ArrowLeft') {
        handleSeek((videoRef.current?.currentTime || 0) - 10);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        handleVolumeChange(volume + 0.1);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        handleVolumeChange(volume - 0.1);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    video,
    onClose,
    handlePlayPauseButton,
    toggleMute,
    toggleFullscreen,
    handleSeek,
    handleVolumeChange,
    volume,
  ]);

  if (!video) return null;

  const progressPercent = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;
  const activeQualityBadge =
    selectedQuality === 'Auto' ? `Auto (${lowestAvailableQuality})` : selectedQuality;

  const showControlsOverlay =
    controlsVisible || !isPlaying || settingsTab !== 'none' || Boolean(playbackError);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-1.5 sm:p-4 md:p-6 bg-black/90 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-4xl bg-slate-950 rounded-2xl sm:rounded-3xl border border-blue-400/25 overflow-hidden shadow-[0_25px_70px_rgba(0,0,0,0.85)] flex flex-col my-auto">
        {/* Video Cinema Stage */}
        <div
          ref={containerRef}
          onMouseMove={() => resetHideTimer(true)}
          onClick={handleStageTap}
          onTouchStart={handleStageTouchStart}
          onTouchMove={handleStageTouchMove}
          onTouchEnd={handleStageTouchEnd}
          className={`relative bg-black flex items-center justify-center overflow-hidden select-none ${
            isFullscreen ? 'w-screen h-screen rounded-none' : 'aspect-video w-full'
          }`}
        >
          {/* HTML5 Video Element (never sets crossOrigin so R2 & Supabase stream cleanly) */}
          <video
            ref={videoRef}
            key={`${video.id}-${activeSourceUrl}`}
            src={activeSourceUrl}
            poster={video.thumbnail}
            playsInline
            autoPlay
            preload="auto"
            style={{ filter: `brightness(${brightness / 100})` }}
            onLoadStart={() => {
              setIsBuffering(true);
              setBufferingLabel(`Loading ${effectiveStreamQuality} stream...`);
              setPlaybackError(null);
            }}
            onLoadedMetadata={(e) => {
              const el = e.currentTarget;
              if (Number.isFinite(el.duration) && el.duration > 0) {
                setDuration(el.duration);
              }
              el.playbackRate = playbackRate;
              el.muted = isMuted;
              el.volume = volume;

              if (pendingRestoreRef.current) {
                const { time, shouldPlay, rate } = pendingRestoreRef.current;
                pendingRestoreRef.current = null;
                el.playbackRate = rate;
                if (time > 0 && time < el.duration) {
                  el.currentTime = time;
                }
                if (shouldPlay) {
                  el.play().catch(() => {});
                }
              }
            }}
            onCanPlay={() => setIsBuffering(false)}
            onWaiting={() => {
              setIsBuffering(true);
              setBufferingLabel('Buffering...');
            }}
            onPlaying={() => {
              setIsBuffering(false);
              setIsPlaying(true);
              setPlaybackError(null);
            }}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onEnded={() => {
              setIsPlaying(false);
              setControlsVisible(true);
            }}
            onTimeUpdate={(e) => {
              const el = e.currentTarget;
              setCurrentTime(el.currentTime || 0);
              if (Number.isFinite(el.duration) && el.duration > 0) {
                setDuration(el.duration);
              }
              if (el.buffered.length > 0 && el.duration > 0) {
                const buffEnd = el.buffered.end(el.buffered.length - 1);
                setBufferedPercent(Math.min(100, (buffEnd / el.duration) * 100));
              }
            }}
            onProgress={(e) => {
              const el = e.currentTarget;
              if (el.buffered.length > 0 && el.duration > 0) {
                const buffEnd = el.buffered.end(el.buffered.length - 1);
                setBufferedPercent(Math.min(100, (buffEnd / el.duration) * 100));
              }
            }}
            onError={(e) => {
              const code = e.currentTarget.error?.code;
              setIsBuffering(false);
              setIsPlaying(false);
              setPlaybackError(
                `Unable to stream this video right now${code ? ` (error code ${code})` : ''}. Tap Retry or choose another quality.`
              );
            }}
            className="w-full h-full object-contain bg-black transition-[filter] duration-150"
          />

          {/* Top Bar Scrim: Title, Active Quality Tag, & Close */}
          <div
            data-player-control="true"
            onClick={(e) => e.stopPropagation()}
            className={`absolute top-0 inset-x-0 z-20 flex items-center justify-between gap-2 px-3 sm:px-5 pt-2.5 sm:pt-3.5 pb-6 bg-gradient-to-b from-black/85 via-black/45 to-transparent transition-all duration-300 ease-out ${
              showControlsOverlay
                ? 'opacity-100 translate-y-0'
                : 'opacity-0 -translate-y-2 pointer-events-none'
            }`}
          >
            <div className="min-w-0 flex items-center gap-2">
              <span className="shrink-0 px-2 py-0.5 rounded-md bg-[#FFCC00] text-slate-950 font-black text-[10px] uppercase tracking-wider">
                {effectiveStreamQuality}
              </span>
              <div className="min-w-0">
                <p className="text-xs sm:text-sm font-black text-white truncate drop-shadow">
                  {video.title}
                </p>
                <p className="text-[10px] sm:text-[11px] text-blue-200/90 font-medium truncate">
                  {video.artist} · {video.category}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {!isFullscreen && (
                <button
                  onClick={onClose}
                  className="w-9 h-9 rounded-full bg-black/65 hover:bg-black/90 border border-white/15 text-white flex items-center justify-center transition-colors cursor-pointer"
                  aria-label="Close Video Player"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Transient Live HUD Feedback (Swipe Brightness / Volume / Skip / Quality Switch) */}
          {hudFeedback && !playbackError && (
            <div className="pointer-events-none absolute top-14 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-slate-950/85 backdrop-blur-md border border-white/15 text-white shadow-2xl animate-in fade-in zoom-in-95 duration-150">
              {hudFeedback.type === 'brightness' && <Sun className="w-4 h-4 text-[#FFCC00]" />}
              {hudFeedback.type === 'volume' &&
                (hudFeedback.percent === 0 ? (
                  <VolumeX className="w-4 h-4 text-red-400" />
                ) : (
                  <Volume2 className="w-4 h-4 text-[#FFCC00]" />
                ))}
              {hudFeedback.type === 'seek-forward' && <RotateCw className="w-4 h-4 text-[#FFCC00]" />}
              {hudFeedback.type === 'seek-back' && <RotateCcw className="w-4 h-4 text-[#FFCC00]" />}
              {hudFeedback.type === 'quality' && <Sparkles className="w-4 h-4 text-[#FFCC00]" />}

              <span className="text-xs font-black tracking-tight tabular-nums whitespace-nowrap">
                {hudFeedback.label}
              </span>

              {typeof hudFeedback.percent === 'number' && (
                <div className="w-16 h-1.5 bg-white/20 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#FFCC00] rounded-full transition-all duration-100"
                    style={{ width: `${Math.max(0, Math.min(100, hudFeedback.percent))}%` }}
                  />
                </div>
              )}
            </div>
          )}

          {/* Smooth Buffering Animation / Playback Error / Dedicated Resume Play Button */}
          {playbackError ? (
            <div
              data-player-control="true"
              onClick={(e) => e.stopPropagation()}
              className="absolute inset-0 z-30 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-5 text-center"
            >
              <div className="w-12 h-12 rounded-2xl bg-red-500/20 border border-red-400/30 flex items-center justify-center mb-3">
                <AlertCircle className="w-6 h-6 text-red-400" />
              </div>
              <p className="text-xs sm:text-sm text-white font-semibold max-w-md mb-4">
                {playbackError}
              </p>
              <button
                onClick={handleRetryPlayback}
                className="px-4 py-2.5 rounded-xl bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-lg cursor-pointer"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>Retry Stream</span>
              </button>
            </div>
          ) : isBuffering ? (
            <div className="pointer-events-none absolute inset-0 z-10 flex flex-col items-center justify-center gap-2.5 bg-black/25">
              <div className="relative w-14 h-14 sm:w-16 sm:h-16 flex items-center justify-center">
                <span className="absolute inset-0 rounded-full border-2 border-[#FFCC00]/25" />
                <span className="absolute inset-0 rounded-full border-2 border-transparent border-t-[#FFCC00] border-r-[#FFCC00] animate-spin" />
                <span className="w-3 h-3 rounded-full bg-[#FFCC00] animate-pulse" />
              </div>
              <span className="px-3 py-1 rounded-full bg-black/70 backdrop-blur-sm text-[11px] font-bold text-white/95 border border-white/10">
                {bufferingLabel}
              </span>
            </div>
          ) : !isPlaying ? (
            <button
              data-player-control="true"
              onClick={handlePlayPauseButton}
              className="absolute z-10 w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#FFCC00] hover:bg-yellow-300 text-slate-950 flex items-center justify-center shadow-[0_0_35px_rgba(255,204,0,0.45)] transition-transform hover:scale-105 active:scale-95 cursor-pointer"
              aria-label="Play video"
            >
              <Play className="w-8 h-8 fill-current ml-1" />
            </button>
          ) : null}

          {/* Settings Popover (Quality & Playback Speed) */}
          {settingsTab !== 'none' && (
            <div
              data-player-control="true"
              onClick={(e) => e.stopPropagation()}
              className="absolute right-3 bottom-24 sm:bottom-24 z-30 w-60 bg-slate-950/95 backdrop-blur-xl border border-blue-400/30 rounded-2xl p-2.5 shadow-2xl text-white animate-in fade-in zoom-in-95 duration-150"
            >
              <div className="flex items-center gap-1 pb-2 mb-2 border-b border-white/10">
                <button
                  onClick={() => setSettingsTab('quality')}
                  className={`flex-1 py-1.5 text-[11px] font-bold rounded-lg cursor-pointer transition-colors ${
                    settingsTab === 'quality'
                      ? 'bg-[#0072ce] text-white'
                      : 'text-slate-300 hover:bg-white/10'
                  }`}
                >
                  Quality
                </button>
                <button
                  onClick={() => setSettingsTab('speed')}
                  className={`flex-1 py-1.5 text-[11px] font-bold rounded-lg cursor-pointer transition-colors ${
                    settingsTab === 'speed'
                      ? 'bg-[#0072ce] text-white'
                      : 'text-slate-300 hover:bg-white/10'
                  }`}
                >
                  Speed ({playbackRate}x)
                </button>
              </div>

              {settingsTab === 'quality' ? (
                <div className="space-y-1">
                  <button
                    onClick={() => handleQualityChange('Auto')}
                    className={`w-full px-2.5 py-1.5 rounded-lg text-left text-xs flex items-center justify-between cursor-pointer ${
                      selectedQuality === 'Auto'
                        ? 'bg-[#FFCC00] text-slate-950 font-black'
                        : 'hover:bg-white/10 text-slate-200 font-semibold'
                    }`}
                  >
                    <span className="flex items-center gap-1.5">
                      {selectedQuality === 'Auto' && <Check className="w-3.5 h-3.5" />}
                      <span>Auto (Data Saver)</span>
                    </span>
                    <span className="text-[10px] opacity-85">{lowestAvailableQuality}</span>
                  </button>

                  {LOWEST_FIRST_QUALITY_ORDER.map((q) => {
                    const isAvailable = Boolean(availableQualityMap[q]);
                    const isActive = selectedQuality === q;
                    return (
                      <button
                        key={q}
                        disabled={!isAvailable}
                        onClick={() => handleQualityChange(q)}
                        className={`w-full px-2.5 py-1.5 rounded-lg text-left text-xs flex items-center justify-between transition-colors ${
                          !isAvailable
                            ? 'opacity-40 cursor-not-allowed text-slate-400'
                            : isActive
                            ? 'bg-[#FFCC00] text-slate-950 font-black cursor-pointer'
                            : 'hover:bg-white/10 text-slate-200 font-semibold cursor-pointer'
                        }`}
                      >
                        <span className="flex items-center gap-1.5">
                          {isActive && <Check className="w-3.5 h-3.5" />}
                          <span>{q}</span>
                        </span>
                        <span className="text-[10px] opacity-85">
                          {isAvailable
                            ? q === '1080p'
                              ? 'Full HD'
                              : q === '720p'
                              ? 'HD'
                              : q === '480p'
                              ? 'Standard'
                              : 'Fast Load'
                            : 'Not uploaded'}
                        </span>
                      </button>
                    );
                  })}

                  <p className="text-[10px] text-slate-400 pt-1.5 px-1 border-t border-white/10">
                    Starts at lowest available quality to prevent buffering.
                  </p>
                </div>
              ) : (
                <div className="space-y-1">
                  {SPEED_OPTIONS.map((rate) => (
                    <button
                      key={rate}
                      onClick={() => handleSpeedChange(rate)}
                      className={`w-full px-2.5 py-1.5 rounded-lg text-left text-xs flex items-center justify-between cursor-pointer ${
                        playbackRate === rate
                          ? 'bg-[#FFCC00] text-slate-950 font-black'
                          : 'hover:bg-white/10 text-slate-200 font-semibold'
                      }`}
                    >
                      <span>{rate === 1 ? 'Normal (1x)' : `${rate}x`}</span>
                      {playbackRate === rate && <Check className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Bottom Modern Streaming Control Suite */}
          <div
            data-player-control="true"
            onClick={(e) => e.stopPropagation()}
            className={`absolute bottom-0 inset-x-0 z-20 bg-gradient-to-t from-black/95 via-black/80 to-transparent px-3 sm:px-5 pt-8 pb-2.5 sm:pb-3.5 transition-all duration-300 ease-out ${
              showControlsOverlay
                ? 'opacity-100 translate-y-0'
                : 'opacity-0 translate-y-3 pointer-events-none'
            }`}
          >
            {/* Interactive Progress / Seek Bar with Hover Timestamp */}
            <div
              className="relative flex items-center h-6 group/seek touch-none"
              onMouseMove={(e) => {
                if (!duration) return;
                const rect = e.currentTarget.getBoundingClientRect();
                const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                setHoverSeekPercent(pct * 100);
                setHoverSeekTime(pct * duration);
              }}
              onMouseLeave={() => setHoverSeekTime(null)}
            >
              {hoverSeekTime !== null && (
                <div
                  className="pointer-events-none absolute -top-7 -translate-x-1/2 px-2 py-0.5 rounded bg-slate-900/95 border border-white/15 text-[10px] font-bold text-[#FFCC00] tabular-nums shadow"
                  style={{ left: `${hoverSeekPercent}%` }}
                >
                  {formatVideoDuration(hoverSeekTime)}
                </div>
              )}

              <div className="w-full h-1.5 group-hover/seek:h-2.5 bg-white/25 rounded-full overflow-hidden relative transition-all duration-150">
                <div
                  className="absolute inset-y-0 left-0 bg-white/35 rounded-full transition-[width] duration-150"
                  style={{ width: `${bufferedPercent}%` }}
                />
                <div
                  className="absolute inset-y-0 left-0 bg-[#FFCC00] rounded-full"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              {/* Scrubber knob */}
              <div
                className="pointer-events-none absolute w-3.5 h-3.5 rounded-full bg-[#FFCC00] shadow-md -translate-x-1/2 scale-90 group-hover/seek:scale-110 transition-transform"
                style={{ left: `${progressPercent}%` }}
              />
              <input
                type="range"
                min={0}
                max={Math.max(1, duration)}
                step={0.1}
                value={currentTime}
                onChange={(e) => handleSeek(Number(e.target.value))}
                aria-label="Seek video position"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>

            {/* On-Screen Brightness & Volume Dual Slider Strip (Works on iPhone, Android, Tablet & Desktop) */}
            <div className="grid grid-cols-2 gap-2.5 sm:gap-4 py-1.5 px-2.5 mb-1.5 rounded-xl bg-white/10 backdrop-blur-md border border-white/10">
              {/* Volume Control */}
              <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
                <button
                  onClick={toggleMute}
                  className="w-7 h-7 rounded-lg hover:bg-white/15 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
                  aria-label={isMuted ? 'Unmute' : 'Mute'}
                  title={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted || volume === 0 ? (
                    <VolumeX className="w-4 h-4 text-red-400" />
                  ) : volume < 0.5 ? (
                    <Volume1 className="w-4 h-4 text-[#FFCC00]" />
                  ) : (
                    <Volume2 className="w-4 h-4 text-[#FFCC00]" />
                  )}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.02}
                  value={isMuted ? 0 : volume}
                  onChange={(e) => handleVolumeChange(Number(e.target.value))}
                  aria-label="Volume slider"
                  className="w-full h-1.5 accent-[#FFCC00] cursor-pointer"
                />
                <span className="inline-block text-[10px] font-bold text-white/85 tabular-nums w-8 text-right shrink-0">
                  {isMuted ? '0%' : `${Math.round(volume * 100)}%`}
                </span>
              </div>

              {/* Screen Brightness Control */}
              <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
                <button
                  onClick={() => handleBrightnessChange(100)}
                  className="w-7 h-7 rounded-lg hover:bg-white/15 text-[#FFCC00] flex items-center justify-center transition-colors cursor-pointer shrink-0"
                  aria-label="Reset screen brightness to 100%"
                  title="Tap to reset brightness (100%)"
                >
                  <Sun className="w-4 h-4" />
                </button>
                <input
                  type="range"
                  min={30}
                  max={140}
                  step={2}
                  value={brightness}
                  onChange={(e) => handleBrightnessChange(Number(e.target.value))}
                  aria-label="Screen brightness slider"
                  className="w-full h-1.5 accent-[#FFCC00] cursor-pointer"
                />
                <span className="inline-block text-[10px] font-bold text-white/85 tabular-nums w-8 text-right shrink-0">
                  {brightness}%
                </span>
              </div>
            </div>

            {/* Primary Action Row: Play/Pause, Skip ±10s, Timecode | Speed, Quality, Fullscreen */}
            <div className="flex items-center justify-between gap-1.5 sm:gap-2">
              <div className="flex items-center gap-1 sm:gap-2 min-w-0">
                {/* Dedicated Play / Pause Button (ONLY button that pauses playback) */}
                <button
                  onClick={handlePlayPauseButton}
                  className="w-10 h-10 rounded-xl bg-[#FFCC00] hover:bg-yellow-300 text-slate-950 flex items-center justify-center shadow transition-transform active:scale-95 cursor-pointer shrink-0"
                  aria-label={isPlaying ? 'Pause' : 'Play'}
                  title={isPlaying ? 'Pause' : 'Play'}
                >
                  {isPlaying ? (
                    <Pause className="w-5 h-5 fill-current" />
                  ) : (
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  )}
                </button>

                {/* Quick Skip Back / Forward 10s */}
                <button
                  onClick={(e) => handleSkipSeconds(-10, e)}
                  className="w-9 h-9 rounded-lg hover:bg-white/15 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
                  aria-label="Rewind 10 seconds"
                  title="-10s"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => handleSkipSeconds(10, e)}
                  className="w-9 h-9 rounded-lg hover:bg-white/15 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
                  aria-label="Forward 10 seconds"
                  title="+10s"
                >
                  <RotateCw className="w-4 h-4" />
                </button>

                {/* Timecode */}
                <span className="text-[11px] sm:text-xs font-bold text-white/95 tabular-nums whitespace-nowrap ml-0.5">
                  {formatVideoDuration(currentTime)}{' '}
                  <span className="text-white/50">/ {formatVideoDuration(duration)}</span>
                </span>
              </div>

              <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
                {/* Playback Speed Selector */}
                <button
                  onClick={() => setSettingsTab(settingsTab === 'speed' ? 'none' : 'speed')}
                  className={`px-2 sm:px-2.5 py-2 rounded-lg text-[11px] font-bold tabular-nums flex items-center gap-1 cursor-pointer whitespace-nowrap transition-colors ${
                    settingsTab === 'speed'
                      ? 'bg-[#0072ce] text-white'
                      : 'bg-white/10 hover:bg-white/20 text-white'
                  }`}
                  title="Playback speed"
                >
                  <Gauge className="w-3.5 h-3.5 text-[#FFCC00] hidden sm:inline" />
                  <span>{playbackRate}x</span>
                </button>

                {/* Quality Selector */}
                <button
                  onClick={() => setSettingsTab(settingsTab === 'quality' ? 'none' : 'quality')}
                  className={`px-2 sm:px-2.5 py-2 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap transition-colors ${
                    settingsTab === 'quality'
                      ? 'bg-[#0072ce] text-white'
                      : 'bg-white/10 hover:bg-white/20 text-white'
                  }`}
                  title="Video quality"
                >
                  <Settings className="w-3.5 h-3.5 text-[#FFCC00]" />
                  <span>{activeQualityBadge}</span>
                </button>

                {/* Landscape Auto-Rotate Fullscreen Toggle */}
                <button
                  onClick={toggleFullscreen}
                  className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
                  aria-label={isFullscreen ? 'Exit fullscreen' : 'Fullscreen Landscape'}
                  title={isFullscreen ? 'Exit fullscreen' : 'Landscape Fullscreen'}
                >
                  {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Video Details & Social Footer */}
        <div className="p-4 sm:p-5 bg-gradient-to-b from-[#032357] to-[#011438] text-white space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="min-w-0">
              <h3 className="text-base sm:text-lg font-black text-white leading-snug break-words">
                {video.title}
              </h3>
              <div className="flex flex-wrap items-center gap-2 text-xs text-blue-200 mt-1 tabular-nums">
                <span className="font-bold text-white">{video.artist}</span>
                <span aria-hidden="true">·</span>
                <span>{video.category}</span>
                <span aria-hidden="true">·</span>
                <span>{video.views}</span>
                <span aria-hidden="true">·</span>
                <span>{video.releaseDate}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              {onToggleLike && (
                <button
                  onClick={() => onToggleLike(video.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    isLiked ? 'bg-red-500 text-white' : 'bg-white/10 hover:bg-white/20 text-white'
                  }`}
                >
                  <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-current' : ''}`} />
                  <span className="tabular-nums">{video.likes || 0}</span>
                </button>
              )}

              <button
                onClick={() => onShare(video)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Share</span>
              </button>

              {canDelete && onDeleteVideo && (
                <button
                  onClick={() => {
                    if (!confirmDeleteArmed) {
                      setConfirmDeleteArmed(true);
                      window.setTimeout(() => setConfirmDeleteArmed(false), 3200);
                    } else {
                      setConfirmDeleteArmed(false);
                      onDeleteVideo(video);
                    }
                  }}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    confirmDeleteArmed
                      ? 'bg-red-600 text-white shadow'
                      : 'bg-red-600/30 hover:bg-red-600 text-red-100'
                  }`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>{confirmDeleteArmed ? 'Confirm Delete' : 'Delete'}</span>
                </button>
              )}
            </div>
          </div>

          {video.description && (
            <p className="text-xs text-blue-100/90 leading-relaxed bg-black/25 rounded-xl p-3 border border-white/10 whitespace-pre-line">
              {video.description}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
