import React, { useState, useEffect } from 'react';
import { FileText, ArrowLeft, Printer, Shield, Mail, MapPin, Phone, Lock, Calendar, Edit3, CheckCircle2, AlertTriangle } from 'lucide-react';
import { getTermsAndConditions, LegalDocument } from '../services/legalService';
import { isUserAdminEmail } from '../services/adminService';
import { UserProfile } from '../types/music';

interface TermsAndConditionsPageProps {
  onBackToHome: () => void;
  onNavigateToPrivacy: () => void;
  currentUser?: UserProfile;
  onOpenAdminLegal?: (docType: 'privacy' | 'terms') => void;
}

export const TermsAndConditionsPage: React.FC<TermsAndConditionsPageProps> = ({
  onBackToHome,
  onNavigateToPrivacy,
  currentUser,
  onOpenAdminLegal,
}) => {
  const [doc, setDoc] = useState<LegalDocument>(getTermsAndConditions());
  const [activeSection, setActiveSection] = useState<string>('acceptance');
  const isAdmin = isUserAdminEmail(currentUser?.email);

  useEffect(() => {
    setDoc(getTermsAndConditions());
    document.title = 'Terms & Conditions - TESO MELODIES.com | Official Terms of Service';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-in fade-in duration-200">
      
      {/* Top Breadcrumb & Action Header */}
      <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToHome}
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            title="Back to Home"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Back to Home</span>
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-black uppercase tracking-wider">
                Terms of Service
              </span>
              <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                Last Updated: {doc.lastUpdated}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-[#032b69] tracking-tight mt-0.5">
              TESO MELODIES Terms and Conditions
            </h1>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {isAdmin && onOpenAdminLegal && (
            <button
              onClick={() => onOpenAdminLegal('terms')}
              className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
              title="Edit Terms and Conditions as Admin"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Admin: Edit Terms</span>
            </button>
          )}

          <button
            onClick={onNavigateToPrivacy}
            className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-blue-50 text-[#0072ce] font-bold text-xs flex items-center gap-1.5 transition-all border border-blue-200/60 cursor-pointer"
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Privacy Policy</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            title="Print or Save PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Main Legal Content Container with Sidebar Table of Contents */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Table of Contents Sticky Sidebar */}
        <aside className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-2xl md:rounded-3xl p-5 shadow-xl border border-slate-100 sticky top-24">
            <div className="flex items-center gap-2 pb-3 mb-3 border-b border-slate-100">
              <FileText className="w-5 h-5 text-[#0072ce]" />
              <h3 className="text-sm font-black text-slate-900 tracking-tight">Table of Contents</h3>
            </div>
            
            <nav className="space-y-1 max-h-[60vh] overflow-y-auto pr-1 text-xs">
              {doc.sections.map((section) => {
                const isActive = activeSection === section.id;
                return (
                  <a
                    key={section.id}
                    href={`#${section.id}`}
                    onClick={() => setActiveSection(section.id)}
                    className={`block py-1.5 px-2.5 rounded-lg font-medium transition-colors ${
                      isActive
                        ? 'bg-blue-50 text-[#0072ce] font-bold'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <span className="truncate block">{section.title}</span>
                  </a>
                );
              })}
            </nav>

            {/* Quick summary box */}
            <div className="mt-4 pt-4 border-t border-slate-100 bg-amber-50/70 rounded-xl p-3 text-[11px] text-amber-950 leading-relaxed border border-amber-200/50">
              <p className="font-bold flex items-center gap-1 text-amber-900 mb-1">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                <span>Creator Rights Notice</span>
              </p>
              Artists retain 100% of their intellectual property ownership. Uploading content does not transfer copyright to TESO MELODIES.
            </div>
          </div>
        </aside>

        {/* Legal Text Document Content */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white rounded-2xl md:rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-100 text-slate-700 space-y-6 leading-relaxed">
            
            {/* Header Badge & Brand Info */}
            <div className="pb-4 border-b border-slate-100">
              <div className="text-xs text-slate-500 font-medium">
                Platform: <span className="text-[#032b69] font-bold">TESO MELODIES.com</span> • Tagline: <span className="font-script text-[#0072ce] font-bold text-sm">Teso Music, Our Pride ❤️</span>
              </div>
              <div className="text-xs text-slate-500 font-medium mt-1">
                Governing Jurisdiction: <span className="text-slate-800 font-bold">{doc.governingJurisdiction}</span> • Contact: <a href={`mailto:${doc.contactEmail}`} className="text-[#0072ce] font-bold underline">{doc.contactEmail}</a>
              </div>
            </div>

            {/* Sections */}
            {doc.sections.map((section) => (
              <section key={section.id} id={section.id} className="pt-2 scroll-mt-28">
                <h2 className="text-base sm:text-lg font-black text-[#032b69] pb-2 border-b border-slate-100/80 flex items-center gap-2">
                  <span>{section.title}</span>
                </h2>
                <div className="text-xs sm:text-sm text-slate-600 font-normal leading-relaxed whitespace-pre-line mt-3 space-y-2">
                  {section.content}
                </div>
              </section>
            ))}

            {/* Bottom Contact Verification Banner */}
            <div className="mt-8 pt-6 border-t border-slate-200/80 bg-slate-50 rounded-2xl p-5 text-xs text-slate-600 space-y-2">
              <h4 className="font-bold text-[#032b69] text-sm flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Binding Agreement – TESO MELODIES.com</span>
              </h4>
              <p>
                By using TESO MELODIES, you confirm that you have read, understood, and agreed to these Terms and Conditions. For copyright complaints, licensing, or official inquiries, please email <span className="font-bold text-[#032b69]">tesomelodies@gmail.com</span>.
              </p>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
