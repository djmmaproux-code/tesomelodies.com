import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Wallet,
  Heart,
  Users,
  Download,
  Headphones,
  TrendingUp,
  CheckCircle2,
  Lock,
  Mail,
  ShieldCheck,
  ShieldAlert,
  Clock,
  CreditCard,
  ArrowDownToLine,
  Receipt,
  RotateCw,
  Loader2,
  Megaphone,
  KeyRound,
  AlertTriangle,
  Send,
  CalendarDays,
  Hourglass,
  BadgeCheck,
} from 'lucide-react';
import { UserProfile } from '../types/music';
import {
  ArtistEarningsDashboardData,
  DEFAULT_EARNING_SETTINGS,
  MobileMoneyProvider,
  fetchArtistEarningsDashboard,
  sendArtistGmailVerification,
  verifyArtistGmailWithOtp,
  completeArtistGmailLinkVerification,
  updateArtistAccountEmailToGmail,
  saveArtistPayoutProfile,
  requestArtistWithdrawal,
  formatUGX,
  isGmailAddress,
  getTransactionCategoryLabel,
} from '../services/earningsService';

interface ArtistEarningsSectionProps {
  currentUser: UserProfile;
  currentUserId: string | null;
  onToast: (msg: string) => void;
  onVerificationChange?: (verified: boolean) => void;
  onOpenWallet?: () => void;
}

type EarningsSubTab = 'earnings' | 'transactions' | 'payout' | 'withdraw';
type TransactionFilter =
  | 'all'
  | 'earnings'
  | 'withdrawals'
  | 'Pending'
  | 'Approved'
  | 'Paid'
  | 'Rejected';

function formatDateTime(iso?: string | null): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('en-UG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

function statusBadgeClass(status: string): string {
  switch (status) {
    case 'Paid':
    case 'Credited':
      return 'bg-emerald-100 text-emerald-800 border border-emerald-200';
    case 'Approved':
      return 'bg-blue-100 text-[#032b69] border border-blue-200';
    case 'Pending':
      return 'bg-amber-100 text-amber-900 border border-amber-200';
    case 'Rejected':
      return 'bg-red-100 text-red-700 border border-red-200';
    default:
      return 'bg-slate-100 text-slate-700 border border-slate-200';
  }
}

function createIdempotencyKey(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `wdr-${crypto.randomUUID()}`;
  }
  return `wdr-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

export const ArtistEarningsSection: React.FC<ArtistEarningsSectionProps> = ({
  currentUser,
  currentUserId,
  onToast,
  onVerificationChange,
  onOpenWallet,
}) => {
  const [data, setData] = useState<ArtistEarningsDashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [serviceUnavailable, setServiceUnavailable] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [activeSubTab, setActiveSubTab] = useState<EarningsSubTab>('earnings');
  const [txFilter, setTxFilter] = useState<TransactionFilter>('all');

  // Gmail 6-digit OTP verification state
  const [isSendingVerification, setIsSendingVerification] = useState(false);
  const [verificationSentTo, setVerificationSentTo] = useState<string | null>(null);
  const [verificationNonce, setVerificationNonce] = useState<string | null>(null);
  const [resendCooldown, setResendCooldown] = useState(0);
  const [otpCode, setOtpCode] = useState('');
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [verifyFeedback, setVerifyFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  useEffect(() => {
    if (resendCooldown <= 0) return;
    const timer = window.setInterval(() => {
      setResendCooldown((prev) => (prev > 1 ? prev - 1 : 0));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [resendCooldown]);

  // Optional in-place Gmail update for existing artists registered with a non-Gmail email
  const [newGmailInput, setNewGmailInput] = useState('');
  const [isUpdatingEmail, setIsUpdatingEmail] = useState(false);

  // Payout info form state
  const [fullLegalName, setFullLegalName] = useState('');
  const [country, setCountry] = useState('Uganda');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [mobileMoneyProvider, setMobileMoneyProvider] =
    useState<MobileMoneyProvider>('MTN Mobile Money');
  const [mobileMoneyNumber, setMobileMoneyNumber] = useState('');
  const [isSavingPayout, setIsSavingPayout] = useState(false);
  const [payoutFeedback, setPayoutFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Withdrawal form state
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [isSubmittingWithdrawal, setIsSubmittingWithdrawal] = useState(false);
  const [withdrawFeedback, setWithdrawFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const hydratePayoutForm = useCallback((dash: ArtistEarningsDashboardData | null) => {
    if (!dash?.payout_profile) return;
    setFullLegalName(dash.payout_profile.full_legal_name || '');
    setCountry(dash.payout_profile.country || 'Uganda');
    setPhoneNumber(dash.payout_profile.phone_number || '');
    setMobileMoneyProvider(
      dash.payout_profile.mobile_money_provider === 'Airtel Money'
        ? 'Airtel Money'
        : 'MTN Mobile Money'
    );
    setMobileMoneyNumber(dash.payout_profile.mobile_money_number || '');
  }, []);

  const loadDashboard = useCallback(
    async (silent = false) => {
      if (!currentUser.isLoggedIn) {
        setIsLoading(false);
        return;
      }
      if (!silent) setIsLoading(true);
      setLoadError(null);
      const res = await fetchArtistEarningsDashboard();
      if (res.serviceUnavailable) {
        setServiceUnavailable(true);
        setLoadError(null);
        setData(null);
        onVerificationChange?.(false);
      } else if (res.error || !res.data) {
        setServiceUnavailable(false);
        setLoadError(res.error || 'Unable to load your earnings right now. Please try again.');
      } else {
        setServiceUnavailable(false);
        setData(res.data);
        hydratePayoutForm(res.data);
        onVerificationChange?.(Boolean(res.data.summary?.earnings_verified));
      }
      setIsLoading(false);
    },
    [currentUser.isLoggedIn, hydratePayoutForm, onVerificationChange]
  );

  // Initial load + handle Gmail verification link callback (?earnings_verify=1&nonce=...)
  useEffect(() => {
    if (!currentUser.isLoggedIn) return;
    let active = true;

    const runInit = async () => {
      try {
        const params = new URLSearchParams(window.location.search);
        if (params.get('earnings_verify') === '1') {
          const nonceFromUrl = params.get('nonce');
          const res = await completeArtistGmailLinkVerification(nonceFromUrl);
          if (!active) return;

          if (res.success) {
            setVerifyFeedback({
              type: 'success',
              text: `Your registered Gmail (${res.verifiedGmail || currentUser.email}) is verified! Your Artist Earnings Dashboard is now active.`,
            });
            onToast('Gmail verified! Artist Earnings Program activated.');
            onVerificationChange?.(true);
          } else if (res.error) {
            setVerifyFeedback({ type: 'error', text: res.error });
          }

          // Clean verification params from URL without reloading
          const cleanUrl = new URL(window.location.href);
          cleanUrl.searchParams.delete('earnings_verify');
          cleanUrl.searchParams.delete('nonce');
          window.history.replaceState({}, '', cleanUrl.pathname + cleanUrl.search);
        }
      } catch {
        // ignore URL parse errors
      }

      if (active) {
        await loadDashboard(false);
      }
    };

    runInit();
    return () => {
      active = false;
    };
  }, [
    currentUser.isLoggedIn,
    currentUserId,
    currentUser.email,
    loadDashboard,
    onToast,
    onVerificationChange,
  ]);

  const summary = data?.summary;
  const settings = data?.settings || DEFAULT_EARNING_SETTINGS;
  const payoutProfile = data?.payout_profile || null;
  const withdrawals = data?.withdrawals || [];
  const transactions = data?.transactions || [];

  const registeredEmail = (summary?.registered_email || currentUser.email || '')
    .trim()
    .toLowerCase();
  const emailIsGmail = summary ? summary.is_gmail : isGmailAddress(registeredEmail);
  const isVerified = Boolean(summary?.earnings_verified);
  const isSuspended = Boolean(summary?.is_suspended);

  const minWithdrawal = Number(settings.min_withdrawal_ugx || 15000);
  const availableBalance = Number(summary?.available_balance_ugx || 0);
  const pendingEarnings = Number(summary?.pending_earnings_ugx || 0);
  const canRequestWithdrawal =
    isVerified && !isSuspended && availableBalance >= minWithdrawal;
  const progressPercent = Math.min(
    100,
    Math.round((availableBalance / Math.max(1, minWithdrawal)) * 100)
  );

  const filteredTransactions = useMemo(() => {
    switch (txFilter) {
      case 'earnings':
        return transactions.filter((t) => t.direction === 'credit');
      case 'withdrawals':
        return transactions.filter(
          (t) => t.transaction_type === 'withdrawal' || t.transaction_type === 'payment'
        );
      case 'Pending':
      case 'Approved':
      case 'Paid':
      case 'Rejected':
        return transactions.filter((t) => t.status === txFilter);
      default:
        return transactions;
    }
  }, [transactions, txFilter]);

  const handleSendVerification = async () => {
    if (resendCooldown > 0) {
      setVerifyFeedback({
        type: 'error',
        text: `Please wait ${resendCooldown} seconds before requesting another 6-digit code. Check your Gmail inbox and Spam folder for your active code.`,
      });
      return;
    }

    setVerifyFeedback(null);
    setIsSendingVerification(true);
    const res = await sendArtistGmailVerification();
    setIsSendingVerification(false);

    if (res.alreadyVerified) {
      onToast('Your Gmail is already verified for Artist Earnings!');
      await loadDashboard(true);
      return;
    }

    if (!res.success) {
      if (res.cooldownSeconds && res.cooldownSeconds > 0) {
        setResendCooldown(res.cooldownSeconds);
      }
      setVerifyFeedback({
        type: 'error',
        text: res.error || 'Could not send the 6-digit verification code to your Gmail.',
      });
      onToast(res.error || 'Failed to send verification email.');
      return;
    }

    setVerificationSentTo(res.registeredEmail || registeredEmail);
    setVerificationNonce(res.nonce || null);
    setResendCooldown(res.cooldownSeconds || 60);
    setVerifyFeedback({
      type: 'success',
      text: `A 6-digit verification code has been sent to ${
        res.registeredEmail || registeredEmail
      }. Open Gmail (check Spam/Promotions if needed), copy the 6-digit code, paste it below, and click "Verify & Unlock".`,
    });
    onToast('6-digit verification code sent to your Gmail!');
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setVerifyFeedback(null);
    const cleanDigits = otpCode.replace(/\D/g, '');
    if (cleanDigits.length !== 6) {
      setVerifyFeedback({
        type: 'error',
        text: 'Please enter the exact 6-digit verification code sent to your Gmail inbox.',
      });
      return;
    }

    setIsVerifyingOtp(true);
    const res = await verifyArtistGmailWithOtp(
      verificationSentTo || registeredEmail,
      cleanDigits,
      verificationNonce
    );
    setIsVerifyingOtp(false);

    if (!res.success) {
      setVerifyFeedback({
        type: 'error',
        text: res.error || 'Verification code could not be confirmed.',
      });
      return;
    }

    setOtpCode('');
    setResendCooldown(0);
    setVerifyFeedback({
      type: 'success',
      text: `Gmail (${res.verifiedGmail || registeredEmail}) verified! Your Artist Earnings Dashboard is now unlocked.`,
    });
    onToast('Email verified! Your Artist Earnings Dashboard is now unlocked.');
    onVerificationChange?.(true);
    await loadDashboard(false);
  };

  const handleUpdateToGmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setVerifyFeedback(null);
    setIsUpdatingEmail(true);
    const res = await updateArtistAccountEmailToGmail(newGmailInput);
    setIsUpdatingEmail(false);

    if (!res.success) {
      setVerifyFeedback({
        type: 'error',
        text: res.error || 'Could not update your account email.',
      });
      return;
    }

    setVerifyFeedback({
      type: 'success',
      text: `Confirmation link sent to ${newGmailInput
        .trim()
        .toLowerCase()}. Confirm the email change in your inbox, then return here to complete Artist Earnings verification.`,
    });
    onToast('Check your new Gmail inbox to confirm your email update.');
  };

  const handleSavePayout = async (e: React.FormEvent) => {
    e.preventDefault();
    setPayoutFeedback(null);
    setIsSavingPayout(true);

    const res = await saveArtistPayoutProfile({
      fullLegalName,
      country,
      phoneNumber,
      mobileMoneyProvider,
      mobileMoneyNumber,
    });

    setIsSavingPayout(false);

    if (!res.success) {
      setPayoutFeedback({
        type: 'error',
        text: res.error || 'Could not save payout information.',
      });
      onToast(res.error || 'Failed to save payout details.');
      return;
    }

    setPayoutFeedback({
      type: 'success',
      text: 'Private payout information saved securely.',
    });
    onToast('Payout information saved!');
    await loadDashboard(true);
  };

  const handleRequestWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawFeedback(null);

    const parsedAmount = Number(String(withdrawAmount).replace(/[^0-9.]/g, ''));
    if (!Number.isFinite(parsedAmount) || parsedAmount < minWithdrawal) {
      setWithdrawFeedback({
        type: 'error',
        text: `Minimum withdrawal request is ${formatUGX(minWithdrawal)}.`,
      });
      return;
    }

    if (parsedAmount > availableBalance) {
      setWithdrawFeedback({
        type: 'error',
        text: `Amount cannot exceed your available balance (${formatUGX(availableBalance)}).`,
      });
      return;
    }

    if (!payoutProfile) {
      setWithdrawFeedback({
        type: 'error',
        text: 'Please complete and save your private Payout Information first.',
      });
      setActiveSubTab('payout');
      return;
    }

    setIsSubmittingWithdrawal(true);
    const idempotencyKey = createIdempotencyKey();
    const res = await requestArtistWithdrawal(parsedAmount, idempotencyKey);
    setIsSubmittingWithdrawal(false);

    if (!res.success) {
      setWithdrawFeedback({
        type: 'error',
        text: res.error || 'Could not submit withdrawal request.',
      });
      onToast(res.error || 'Withdrawal request failed.');
      return;
    }

    setWithdrawAmount('');
    setWithdrawFeedback({
      type: 'success',
      text: `Withdrawal request ${res.withdrawal?.reference_code || ''} for ${formatUGX(
        parsedAmount
      )} submitted with status Pending. An administrator will review and confirm payment.`,
    });
    onToast('Withdrawal request submitted (Pending admin review).');
    await loadDashboard(true);
  };

  if (!currentUser.isLoggedIn) {
    return null;
  }

  return (
    <div className="space-y-5">
      {/* Official Artist Monetization Announcement Banner (Exact Required Copy for Unverified Artists) */}
      {!isLoading && !serviceUnavailable && !isVerified && data && (
        <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border-2 border-[#FFCC00] relative overflow-hidden">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-[#FFCC00] text-[#032b69] flex items-center justify-center shrink-0 shadow-sm">
                <Megaphone className="w-5 h-5" />
              </div>
              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-[#032b69] text-[10px] font-black uppercase tracking-wider">
                    Official Announcement
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-black uppercase tracking-wider">
                    Verification Required
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-black text-[#032b69] leading-snug">
                  OFFICIAL TESO MELODIES ARTIST MONETIZATION PROGRAM
                </h3>
                <p className="text-xs sm:text-[13px] text-slate-700 leading-relaxed max-w-2xl">
                  We are introducing a new earning opportunity for our registered artists. Verify
                  your Gmail account to activate your Artist Earnings Dashboard, monitor your music
                  performance and start earning from eligible engagement.
                </p>
                <p className="text-xs font-black text-[#0072ce]">
                  Verify your account to unlock your earnings.
                </p>
              </div>
            </div>

            {emailIsGmail && (
              <button
                type="button"
                onClick={handleSendVerification}
                disabled={isSendingVerification || resendCooldown > 0}
                className="w-full md:w-auto px-4 py-2.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow transition-all cursor-pointer flex items-center justify-center gap-1.5 shrink-0 disabled:opacity-60"
              >
                {isSendingVerification ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Mail className="w-4 h-4" />
                )}
                <span>
                  {resendCooldown > 0
                    ? `Resend Code (${resendCooldown}s)`
                    : verificationSentTo
                    ? 'Resend Verification Email'
                    : 'Verify Email'}
                </span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Main Artist Earnings Card (Matches Existing White Teso Melodies Dashboard Card) */}
      <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 space-y-5">
        {/* Card Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-[#0072ce] flex items-center justify-center shrink-0">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-lg sm:text-xl font-black text-[#032b69] tracking-tight">
                  Artist Earnings Dashboard
                </h3>
                {!isLoading &&
                  !serviceUnavailable &&
                  data &&
                  (isVerified ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-black border border-emerald-200">
                      <BadgeCheck className="w-3.5 h-3.5" />
                      <span>Verified Artist • Gmail Confirmed</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[11px] font-black border border-amber-200">
                      <Lock className="w-3 h-3" />
                      <span>Earnings Locked — Verify Gmail</span>
                    </span>
                  ))}
                {isSuspended && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-red-100 text-red-700 text-[11px] font-black border border-red-200">
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>Earnings Suspended</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Monitor your verified UGX royalties from genuine likes, followers, downloads, and
                music streams.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
            {onOpenWallet && (
              <button
                type="button"
                onClick={onOpenWallet}
                className="px-3.5 py-1.5 bg-[#032b69] hover:bg-[#0055d4] text-[#FFCC00] font-black text-xs rounded-xl shadow-sm transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Wallet className="w-3.5 h-3.5" />
                <span>Artist Wallet</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => loadDashboard(false)}
              disabled={isLoading}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
            >
              <RotateCw
                className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#0072ce]' : ''}`}
              />
              <span>Refresh Earnings</span>
            </button>
          </div>
        </div>

        {/* Loading State */}
        {isLoading ? (
          <div className="py-10 text-center space-y-2">
            <Loader2 className="w-7 h-7 text-[#0072ce] animate-spin mx-auto" />
            <p className="text-xs font-bold text-slate-600">
              Loading your Artist Earnings Dashboard...
            </p>
          </div>
        ) : serviceUnavailable ? (
          <div className="p-5 rounded-2xl bg-blue-50/70 border border-blue-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#032b69] text-[#FFCC00] flex items-center justify-center shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div className="text-xs space-y-1">
                <p className="font-black text-sm text-[#032b69]">
                  Artist Earnings Program Syncing
                </p>
                <p className="text-slate-600 leading-relaxed max-w-xl">
                  Your Artist Earnings Dashboard is currently being updated. You can continue
                  uploading songs, editing your artist profile, and growing your likes, followers,
                  and downloads normally. Please check back shortly.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => loadDashboard(false)}
              className="self-start sm:self-auto px-4 py-2 bg-[#0072ce] hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition-all cursor-pointer shrink-0"
            >
              Check Again
            </button>
          </div>
        ) : loadError && !data ? (
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <p className="text-slate-700 text-xs font-semibold">{loadError}</p>
            <button
              type="button"
              onClick={() => loadDashboard(false)}
              className="self-start sm:self-auto px-3.5 py-1.5 bg-[#0072ce] hover:bg-blue-700 text-white font-bold text-xs rounded-xl cursor-pointer shrink-0"
            >
              Retry
            </button>
          </div>
        ) : !isVerified ? (
          /* ================================================================
             LOCKED VIEW: REAL GMAIL VERIFICATION (OTP CODE OR EMAIL LINK)
             ================================================================ */
          <div className="space-y-5">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              {/* Left: Real Gmail Verification Box */}
              <div className="lg:col-span-7 bg-slate-50 rounded-2xl p-5 border border-slate-200/80 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#032b69] text-[#FFCC00] flex items-center justify-center shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm sm:text-base font-black text-[#032b69]">
                      Gmail Verification Required to Unlock Earnings
                    </h4>
                    <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                      Registered account email:{' '}
                      <strong className="text-slate-900">{registeredEmail || 'Not set'}</strong>
                    </p>
                  </div>
                </div>

                {verifyFeedback && (
                  <div
                    className={`p-3 rounded-xl text-xs font-semibold leading-relaxed border ${
                      verifyFeedback.type === 'success'
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        : 'bg-red-50 border-red-200 text-red-700'
                    }`}
                  >
                    {verifyFeedback.text}
                  </div>
                )}

                {emailIsGmail ? (
                  <div className="space-y-4">
                    {/* Step 1: Send real 6-digit OTP verification code to registered Gmail */}
                    <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-2.5">
                      <div className="flex items-center gap-2 text-xs font-black text-[#032b69]">
                        <span className="w-5 h-5 rounded-full bg-[#0072ce] text-white flex items-center justify-center text-[11px]">
                          1
                        </span>
                        <span>Send 6-Digit Verification Code to Your Registered Gmail</span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        We will send a unique 6-digit TESO MELODIES verification code directly to{' '}
                        <strong>{registeredEmail}</strong>. Your existing artist profile, songs,
                        likes, followers, and downloads remain untouched with zero duplicate
                        accounts.
                      </p>
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={handleSendVerification}
                          disabled={isSendingVerification || resendCooldown > 0}
                          className="w-full sm:w-auto px-4 py-2.5 bg-[#0072ce] hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition-all cursor-pointer inline-flex items-center justify-center gap-1.5 disabled:opacity-60"
                        >
                          {isSendingVerification ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Send className="w-3.5 h-3.5" />
                          )}
                          <span>
                            {resendCooldown > 0
                              ? `Resend Verification Email (${resendCooldown}s)`
                              : verificationSentTo
                              ? 'Resend Verification Email'
                              : 'Verify Email'}
                          </span>
                        </button>
                        {verificationSentTo && (
                          <span className="text-[11px] font-semibold text-emerald-700">
                            Code sent to {verificationSentTo}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Step 2: Paste 6-digit OTP code from Gmail & Verify & Unlock */}
                    <form
                      onSubmit={handleVerifyOtp}
                      className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-3"
                    >
                      <div className="flex items-center gap-2 text-xs font-black text-[#032b69]">
                        <span className="w-5 h-5 rounded-full bg-[#FFCC00] text-slate-950 flex items-center justify-center text-[11px]">
                          2
                        </span>
                        <span>Copy &amp; Paste Your 6-Digit Verification Code from Gmail</span>
                      </div>
                      <div className="flex flex-col sm:flex-row gap-2">
                        <div className="relative flex-1">
                          <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                          <input
                            type="text"
                            inputMode="numeric"
                            autoComplete="one-time-code"
                            pattern="[0-9]*"
                            maxLength={6}
                            value={otpCode}
                            onChange={(e) =>
                              setOtpCode(e.target.value.replace(/\D/g, '').slice(0, 6))
                            }
                            placeholder="Enter 6-digit OTP code (e.g. 123456)"
                            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-bold tracking-[0.25em]"
                          />
                        </div>
                        <button
                          type="submit"
                          disabled={isVerifyingOtp || otpCode.replace(/\D/g, '').length !== 6}
                          className="px-4 py-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow transition-all cursor-pointer inline-flex items-center justify-center gap-1.5 disabled:opacity-50"
                        >
                          {isVerifyingOtp ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <CheckCircle2 className="w-4 h-4" />
                          )}
                          <span>Verify &amp; Unlock</span>
                        </button>
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Open your Gmail inbox for &ldquo;TESO MELODIES &ndash; Your Artist
                        Verification Code&rdquo;, copy the 6-digit code, and paste it above.
                      </p>
                    </form>
                  </div>
                ) : (
                  /* Non-Gmail existing account update helper (in-place, zero duplicates) */
                  <form
                    onSubmit={handleUpdateToGmail}
                    className="p-4 rounded-xl bg-white border border-amber-200 space-y-3"
                  >
                    <div className="flex items-start gap-2 text-xs text-amber-900">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <p className="leading-relaxed">
                        Your current email (<strong>{registeredEmail}</strong>) is not a Gmail
                        address. Update your existing account email in place to your personal{' '}
                        <strong>@gmail.com</strong> address to activate Artist Monetization without
                        creating a duplicate account.
                      </p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="email"
                        value={newGmailInput}
                        onChange={(e) => setNewGmailInput(e.target.value)}
                        placeholder="yourname@gmail.com"
                        required
                        className="flex-1 px-3.5 py-2 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold"
                      />
                      <button
                        type="submit"
                        disabled={isUpdatingEmail}
                        className="px-4 py-2 bg-[#0072ce] hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition-all cursor-pointer disabled:opacity-60"
                      >
                        {isUpdatingEmail ? 'Updating...' : 'Update to Gmail'}
                      </button>
                    </div>
                  </form>
                )}
              </div>

              {/* Right: Locked Preview & Current Royalty Rates */}
              <div className="lg:col-span-5 bg-blue-50/70 rounded-2xl p-5 border border-blue-200/70 flex flex-col justify-between space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-[#032b69] font-black text-sm">
                    <Lock className="w-4 h-4 text-[#0072ce]" />
                    <span>Official Royalty Rates (UGX)</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    You can keep uploading music, editing your profile, and growing your audience
                    normally. Once your Gmail is verified, your earnings dashboard unlocks with
                    automatic UGX royalties:
                  </p>
                  <div className="space-y-2 text-xs">
                    <div className="p-2.5 rounded-xl bg-white border border-blue-100 flex items-center justify-between">
                      <span className="font-bold text-slate-700 flex items-center gap-1.5">
                        <Heart className="w-3.5 h-3.5 text-red-500" />
                        Every {settings.likes_per_unit} eligible likes
                      </span>
                      <span className="font-black text-[#032b69]">
                        {formatUGX(settings.likes_rate_ugx)}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white border border-blue-100 flex items-center justify-between">
                      <span className="font-bold text-slate-700 flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-[#0072ce]" />
                        Every {settings.followers_per_unit} genuine followers
                      </span>
                      <span className="font-black text-[#032b69]">
                        {formatUGX(settings.followers_rate_ugx)}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white border border-blue-100 flex items-center justify-between">
                      <span className="font-bold text-slate-700 flex items-center gap-1.5">
                        <Download className="w-3.5 h-3.5 text-emerald-600" />
                        Every {settings.downloads_per_unit}{' '}
                        {settings.downloads_per_unit === 1
                          ? 'eligible download'
                          : 'eligible downloads'}
                      </span>
                      <span className="font-black text-[#032b69]">
                        {formatUGX(settings.downloads_rate_ugx)}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white border border-blue-100 flex items-center justify-between">
                      <span className="font-bold text-slate-700 flex items-center gap-1.5">
                        <Headphones className="w-3.5 h-3.5 text-indigo-600" />
                        Every {settings.streams_per_unit}{' '}
                        {settings.streams_per_unit === 1
                          ? 'eligible stream'
                          : 'eligible streams'}
                      </span>
                      <span className="font-black text-[#032b69]">
                        {formatUGX(settings.streams_rate_ugx)}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-200 flex items-center justify-between">
                      <span className="font-bold text-slate-800">Minimum withdrawal</span>
                      <span className="font-black text-[#032b69]">
                        {formatUGX(minWithdrawal)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* ================================================================
             UNLOCKED VERIFIED ARTIST EARNINGS DASHBOARD
             ================================================================ */
          <div className="space-y-5">
            {/* Suspension Notice (if admin flagged suspicious activity) */}
            {isSuspended && (
              <div className="p-4 rounded-2xl bg-red-50 border border-red-200 flex items-start gap-3 text-red-900">
                <ShieldAlert className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <p className="font-black text-sm">Earnings Activity Temporarily Suspended</p>
                  <p className="leading-relaxed">
                    {summary?.suspended_reason ||
                      'Suspicious engagement activity was detected on your account. New earning credits and withdrawals are paused pending administrator review.'}
                  </p>
                </div>
              </div>
            )}

            {/* Sub-Navigation Tabs (Blue & White Teso Melodies Style) */}
            <div className="flex flex-wrap items-center gap-2 pb-1">
              {(
                [
                  { id: 'earnings', label: 'EARNINGS', icon: TrendingUp },
                  {
                    id: 'transactions',
                    label: `TRANSACTIONS (${transactions.length})`,
                    icon: Receipt,
                  },
                  { id: 'payout', label: 'PAYOUT INFO', icon: CreditCard },
                  { id: 'withdraw', label: 'WITHDRAW', icon: ArrowDownToLine },
                ] as const
              ).map((tab) => {
                const Icon = tab.icon;
                const active = activeSubTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveSubTab(tab.id)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                      active
                        ? 'bg-[#032b69] text-white shadow-sm'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* --------------------------------------------------------------
                TAB 1: EARNINGS (ALL 12 CARDS + MONTHLY OVERVIEW)
               -------------------------------------------------------------- */}
            {activeSubTab === 'earnings' && summary && (
              <div className="space-y-5">
                {/* Highlight Balance Banner */}
                <div className="rounded-2xl bg-gradient-to-r from-[#032b69] via-[#0055d4] to-[#0072ce] p-5 text-white shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-blue-200">
                      Available Balance for Withdrawal
                    </span>
                    <div className="text-3xl sm:text-4xl font-black tracking-tight tabular-nums text-[#FFCC00]">
                      {formatUGX(availableBalance)}
                    </div>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-blue-100">
                      <span>
                        Total Earned:{' '}
                        <strong className="text-white">
                          {formatUGX(summary.total_earnings_ugx)}
                        </strong>
                      </span>
                      <span>
                        Pending Earnings:{' '}
                        <strong className="text-yellow-200">{formatUGX(pendingEarnings)}</strong>
                      </span>
                      <span>
                        Total Withdrawn:{' '}
                        <strong className="text-white">
                          {formatUGX(summary.amount_withdrawn_ugx)}
                        </strong>
                      </span>
                      {Number(summary.pending_withdrawals_ugx || 0) > 0 && (
                        <span>
                          Withdrawal In Review:{' '}
                          <strong className="text-yellow-300">
                            {formatUGX(summary.pending_withdrawals_ugx)}
                          </strong>
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col items-stretch sm:items-end gap-2 min-w-[215px]">
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('withdraw')}
                      disabled={isSuspended}
                      className="px-4 py-2.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
                    >
                      <ArrowDownToLine className="w-4 h-4" />
                      <span>
                        {canRequestWithdrawal
                          ? 'Request Withdrawal'
                          : `Min ${formatUGX(minWithdrawal)} to Withdraw`}
                      </span>
                    </button>
                    <div className="w-full space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-blue-100">
                        <span>Withdrawal threshold progress</span>
                        <span>{progressPercent}%</span>
                      </div>
                      <div className="h-1.5 w-full rounded-full bg-white/20 overflow-hidden">
                        <div
                          className="h-full bg-[#FFCC00] rounded-full transition-all"
                          style={{ width: `${progressPercent}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* All 12 Required Artist Earnings Cards (Matches Existing White/Slate Dashboard Design) */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                  {/* 1. Total Earnings (UGX) */}
                  <div className="bg-blue-50/70 rounded-2xl p-4 border border-blue-200/80 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-[#032b69]">Total Earnings</span>
                      <div className="w-8 h-8 rounded-lg bg-[#0072ce] text-white flex items-center justify-center">
                        <TrendingUp className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-[#032b69] tabular-nums">
                      {formatUGX(summary.total_earnings_ugx)}
                    </div>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      Lifetime credited royalties
                    </p>
                  </div>

                  {/* 2. Available Balance */}
                  <div className="bg-emerald-50/70 rounded-2xl p-4 border border-emerald-200/80 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-emerald-900">Available Balance</span>
                      <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                        <Wallet className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-emerald-800 tabular-nums">
                      {formatUGX(summary.available_balance_ugx)}
                    </div>
                    <p className="text-[11px] text-emerald-700 mt-0.5">
                      Ready to withdraw (min {formatUGX(minWithdrawal)})
                    </p>
                  </div>

                  {/* 3. Pending Earnings */}
                  <div className="bg-amber-50/70 rounded-2xl p-4 border border-amber-200/80 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-amber-950">Pending Earnings</span>
                      <div className="w-8 h-8 rounded-lg bg-[#FFCC00] text-[#032b69] flex items-center justify-center">
                        <Hourglass className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-amber-900 tabular-nums">
                      {formatUGX(pendingEarnings)}
                    </div>
                    <p className="text-[11px] text-amber-800 mt-0.5">
                      Accruing toward next milestone
                    </p>
                  </div>

                  {/* 4. Total Withdrawn */}
                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-600">Total Withdrawn</span>
                      <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-700 flex items-center justify-center">
                        <ArrowDownToLine className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-slate-900 tabular-nums">
                      {formatUGX(summary.amount_withdrawn_ugx)}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Confirmed Mobile Money payouts
                    </p>
                  </div>

                  {/* 5. Total Likes */}
                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-600">Total Likes</span>
                      <div className="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
                        <Heart className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-slate-900 tabular-nums">
                      {Number(summary.total_likes || 0).toLocaleString()}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Genuine eligible song likes
                    </p>
                  </div>

                  {/* 6. Likes Earnings */}
                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-600">Likes Earnings</span>
                      <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center">
                        <Wallet className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-[#032b69] tabular-nums">
                      {formatUGX(summary.likes_earnings_ugx)}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {formatUGX(settings.likes_rate_ugx)} / {settings.likes_per_unit} likes
                    </p>
                  </div>

                  {/* 7. Total Followers */}
                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-600">Total Followers</span>
                      <div className="w-8 h-8 rounded-lg bg-blue-100 text-[#0072ce] flex items-center justify-center">
                        <Users className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-slate-900 tabular-nums">
                      {Number(summary.total_followers || 0).toLocaleString()}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Genuine verified fan followers
                    </p>
                  </div>

                  {/* 8. Followers Earnings */}
                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-600">Followers Earnings</span>
                      <div className="w-8 h-8 rounded-lg bg-blue-100 text-[#0072ce] flex items-center justify-center">
                        <Wallet className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-[#032b69] tabular-nums">
                      {formatUGX(summary.followers_earnings_ugx)}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {formatUGX(settings.followers_rate_ugx)} / {settings.followers_per_unit}{' '}
                      followers
                    </p>
                  </div>

                  {/* 9. Total Downloads */}
                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-600">Total Downloads</span>
                      <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
                        <Download className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-slate-900 tabular-nums">
                      {Number(summary.total_downloads || 0).toLocaleString()}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Verified listener downloads
                    </p>
                  </div>

                  {/* 10. Download Earnings */}
                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-600">Download Earnings</span>
                      <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
                        <Wallet className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-[#032b69] tabular-nums">
                      {formatUGX(summary.downloads_earnings_ugx)}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {formatUGX(settings.downloads_rate_ugx)} / {settings.downloads_per_unit}{' '}
                      {settings.downloads_per_unit === 1 ? 'download' : 'downloads'}
                    </p>
                  </div>

                  {/* 11. Total Music Streams */}
                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-600">Total Music Streams</span>
                      <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
                        <Headphones className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-slate-900 tabular-nums">
                      {Number(summary.total_streams || 0).toLocaleString()}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Eligible genuine music plays
                    </p>
                  </div>

                  {/* 12. Streaming Earnings */}
                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/70 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-600">Streaming Earnings</span>
                      <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
                        <Wallet className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-[#032b69] tabular-nums">
                      {formatUGX(summary.streams_earnings_ugx)}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {formatUGX(settings.streams_rate_ugx)} / {settings.streams_per_unit}{' '}
                      {settings.streams_per_unit === 1 ? 'stream' : 'streams'}
                    </p>
                  </div>
                </div>

                {/* Monthly Overview (All 6 Monthly Metrics) */}
                <div className="rounded-2xl bg-slate-50 border border-slate-200/80 p-4 sm:p-5 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <CalendarDays className="w-4 h-4 text-[#0072ce]" />
                      <h4 className="text-sm font-black text-[#032b69]">
                        Monthly Earnings &amp; Engagement Overview
                      </h4>
                    </div>
                    <span className="text-[11px] font-bold text-slate-500">
                      Current Month vs Previous Month
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                    <div className="bg-white rounded-xl p-3 border border-blue-200/80">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide block">
                        Current Month
                      </span>
                      <div className="text-base font-black text-[#032b69] tabular-nums mt-0.5">
                        {formatUGX(summary.monthly_earnings_ugx)}
                      </div>
                    </div>
                    <div className="bg-white rounded-xl p-3 border border-slate-200">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide block">
                        Previous Month
                      </span>
                      <div className="text-base font-black text-slate-800 tabular-nums mt-0.5">
                        {formatUGX(summary.previous_month_earnings_ugx)}
                      </div>
                    </div>
                    <div className="bg-white rounded-xl p-3 border border-slate-200">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide block">
                        Monthly Likes
                      </span>
                      <div className="text-base font-black text-red-600 tabular-nums mt-0.5">
                        {Number(summary.monthly_likes || 0).toLocaleString()}
                      </div>
                    </div>
                    <div className="bg-white rounded-xl p-3 border border-slate-200">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide block">
                        Monthly Followers
                      </span>
                      <div className="text-base font-black text-[#0072ce] tabular-nums mt-0.5">
                        {Number(summary.monthly_followers || 0).toLocaleString()}
                      </div>
                    </div>
                    <div className="bg-white rounded-xl p-3 border border-slate-200">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide block">
                        Monthly Downloads
                      </span>
                      <div className="text-base font-black text-emerald-700 tabular-nums mt-0.5">
                        {Number(summary.monthly_downloads || 0).toLocaleString()}
                      </div>
                    </div>
                    <div className="bg-white rounded-xl p-3 border border-slate-200">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide block">
                        Monthly Streams
                      </span>
                      <div className="text-base font-black text-indigo-700 tabular-nums mt-0.5">
                        {Number(summary.monthly_streams || 0).toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* --------------------------------------------------------------
                TAB 2: EARNINGS TRANSACTION HISTORY (ALL 7 FILTERS)
               -------------------------------------------------------------- */}
            {activeSubTab === 'transactions' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h4 className="text-sm sm:text-base font-black text-[#032b69]">
                      Earnings &amp; Payment Transaction History
                    </h4>
                    <p className="text-xs text-slate-500">
                      Complete transparent ledger of your royalty credits, withdrawal requests, and
                      confirmed Mobile Money payments.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {(
                      [
                        { id: 'all', label: 'All Transactions' },
                        { id: 'earnings', label: 'Earnings' },
                        { id: 'withdrawals', label: 'Withdrawals' },
                        { id: 'Pending', label: 'Pending' },
                        { id: 'Approved', label: 'Approved' },
                        { id: 'Paid', label: 'Paid' },
                        { id: 'Rejected', label: 'Rejected' },
                      ] as const
                    ).map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setTxFilter(f.id)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                          txFilter === f.id
                            ? 'bg-[#032b69] text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                </div>

                {filteredTransactions.length === 0 ? (
                  <div className="py-10 px-4 text-center rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50 space-y-1.5">
                    <Receipt className="w-7 h-7 text-slate-400 mx-auto" />
                    <p className="text-sm font-bold text-slate-700">No transactions yet</p>
                    <p className="text-xs text-slate-500 max-w-md mx-auto">
                      Your royalty credits from eligible likes, followers, downloads, and streams,
                      as well as withdrawal requests and payouts, will appear here automatically.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {filteredTransactions.map((tx) => {
                      const category = getTransactionCategoryLabel(tx);
                      return (
                        <div
                          key={tx.id}
                          className="p-3.5 sm:p-4 rounded-2xl bg-slate-50/90 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div className="space-y-1 min-w-0">
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${statusBadgeClass(
                                  tx.status
                                )}`}
                              >
                                {tx.status}
                              </span>
                              <span className="px-2 py-0.5 rounded-full bg-blue-100 text-[#032b69] text-[10px] font-black">
                                {category}
                              </span>
                              <span className="font-mono text-[11px] font-bold text-slate-500">
                                {tx.reference_code}
                              </span>
                            </div>
                            <p className="text-xs sm:text-sm font-bold text-slate-900">
                              {tx.description}
                            </p>
                            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-500">
                              <span className="inline-flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {formatDateTime(tx.created_at)}
                              </span>
                              {tx.payment_reference && (
                                <span className="font-bold text-emerald-700">
                                  MoMo Confirmation Ref: {tx.payment_reference}
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="sm:text-right shrink-0">
                            <div
                              className={`text-base sm:text-lg font-black tabular-nums ${
                                tx.direction === 'credit' ? 'text-emerald-700' : 'text-[#032b69]'
                              }`}
                            >
                              {tx.direction === 'credit' ? '+' : '-'}
                              {formatUGX(tx.amount_ugx)}
                            </div>
                            <div className="text-[10px] font-bold uppercase text-slate-400">
                              {tx.direction === 'credit' ? 'Royalty Credit' : 'Payout Debit'}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* --------------------------------------------------------------
                TAB 3: PRIVATE PAYOUT INFORMATION
               -------------------------------------------------------------- */}
            {activeSubTab === 'payout' && (
              <div className="max-w-2xl space-y-4">
                <div className="p-3.5 rounded-2xl bg-blue-50 border border-blue-200/80 flex items-start gap-2.5 text-xs text-[#032b69]">
                  <ShieldCheck className="w-4 h-4 text-[#0072ce] shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong>Private &amp; Protected:</strong> Your payout details are strictly
                    private and visible only to you and the authorized Teso Melodies administrator
                    processing your withdrawals. They are never shown on your public artist profile.
                  </p>
                </div>

                {payoutFeedback && (
                  <div
                    className={`p-3 rounded-xl text-xs font-semibold border ${
                      payoutFeedback.type === 'success'
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        : 'bg-red-50 border-red-200 text-red-700'
                    }`}
                  >
                    {payoutFeedback.text}
                  </div>
                )}

                <form onSubmit={handleSavePayout} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Full Legal Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={fullLegalName}
                        onChange={(e) => setFullLegalName(e.target.value)}
                        placeholder="Exact name on your Mobile Money account"
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Country <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={country}
                        onChange={(e) => setCountry(e.target.value)}
                        placeholder="Uganda"
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Phone Number <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="tel"
                        required
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        placeholder="e.g. +256 772 000 000"
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold"
                      />
                      <p className="text-[11px] text-slate-500 mt-1">
                        Contact &amp; payout coordination only. Verification codes are sent strictly to Gmail.
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Registered Email Address (Verified Gmail)
                      </label>
                      <input
                        type="email"
                        readOnly
                        value={summary?.verified_gmail || registeredEmail}
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-100 text-slate-600 border border-slate-200 rounded-xl font-semibold cursor-not-allowed"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Mobile Money Provider <span className="text-red-500">*</span>
                      </label>
                      <select
                        value={mobileMoneyProvider}
                        onChange={(e) =>
                          setMobileMoneyProvider(e.target.value as MobileMoneyProvider)
                        }
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-bold cursor-pointer"
                      >
                        <option value="MTN Mobile Money">MTN Mobile Money</option>
                        <option value="Airtel Money">Airtel Money</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Mobile Money Payout Number <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="tel"
                        required
                        value={mobileMoneyNumber}
                        onChange={(e) => setMobileMoneyNumber(e.target.value)}
                        placeholder="e.g. 0772123456 or +256772123456"
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSavingPayout}
                    className="px-5 py-2.5 bg-[#0072ce] hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow transition-all cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-60"
                  >
                    {isSavingPayout ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4" />
                    )}
                    <span>{payoutProfile ? 'Update Payout Information' : 'Save Payout Information'}</span>
                  </button>
                </form>
              </div>
            )}

            {/* --------------------------------------------------------------
                TAB 4: WITHDRAWAL REQUEST & STATUS TRACKER
               -------------------------------------------------------------- */}
            {activeSubTab === 'withdraw' && (
              <div className="space-y-5">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
                  {/* Withdrawal Request Form */}
                  <div className="lg:col-span-6 bg-slate-50 rounded-2xl p-5 border border-slate-200/80 space-y-4">
                    <div>
                      <h4 className="text-sm sm:text-base font-black text-[#032b69]">
                        Request Mobile Money Withdrawal
                      </h4>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Minimum withdrawal amount is{' '}
                        <strong className="text-[#032b69]">{formatUGX(minWithdrawal)}</strong>.
                        Requests are verified and paid to your saved Mobile Money account.
                      </p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-white border border-slate-200 flex items-center justify-between">
                      <div>
                        <span className="text-[11px] font-bold text-slate-500 block">
                          Available Balance
                        </span>
                        <span className="text-xl font-black text-emerald-700 tabular-nums">
                          {formatUGX(availableBalance)}
                        </span>
                      </div>
                      {availableBalance >= minWithdrawal && (
                        <button
                          type="button"
                          onClick={() => setWithdrawAmount(String(Math.floor(availableBalance)))}
                          className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-[#032b69] text-[11px] font-black rounded-lg cursor-pointer"
                        >
                          Withdraw All
                        </button>
                      )}
                    </div>

                    {!payoutProfile ? (
                      <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-950 space-y-2">
                        <p className="font-bold">
                          Save your private Mobile Money payout details before requesting a
                          withdrawal.
                        </p>
                        <button
                          type="button"
                          onClick={() => setActiveSubTab('payout')}
                          className="px-3.5 py-2 bg-[#032b69] text-white font-bold text-xs rounded-xl cursor-pointer"
                        >
                          Go to Payout Info
                        </button>
                      </div>
                    ) : (
                      <div className="p-3 rounded-xl bg-white border border-slate-200 text-xs space-y-0.5">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-500">Payout Destination</span>
                          <button
                            type="button"
                            onClick={() => setActiveSubTab('payout')}
                            className="text-[#0072ce] font-bold hover:underline cursor-pointer"
                          >
                            Edit
                          </button>
                        </div>
                        <p className="font-black text-slate-900">{payoutProfile.full_legal_name}</p>
                        <p className="text-slate-600">
                          <strong>{payoutProfile.mobile_money_provider}</strong> &bull;{' '}
                          {payoutProfile.mobile_money_number} ({payoutProfile.country})
                        </p>
                      </div>
                    )}

                    {withdrawFeedback && (
                      <div
                        className={`p-3 rounded-xl text-xs font-semibold border ${
                          withdrawFeedback.type === 'success'
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                            : 'bg-red-50 border-red-200 text-red-700'
                        }`}
                      >
                        {withdrawFeedback.text}
                      </div>
                    )}

                    <form onSubmit={handleRequestWithdrawal} className="space-y-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Withdrawal Amount (UGX)
                        </label>
                        <input
                          type="number"
                          min={minWithdrawal}
                          max={Math.max(minWithdrawal, Math.floor(availableBalance))}
                          step={100}
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(e.target.value)}
                          placeholder={`Minimum ${minWithdrawal.toLocaleString()}`}
                          disabled={!canRequestWithdrawal || !payoutProfile}
                          className="w-full px-3.5 py-2.5 text-sm bg-white text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-black tabular-nums disabled:opacity-60"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={
                          isSubmittingWithdrawal || !canRequestWithdrawal || !payoutProfile
                        }
                        className="w-full py-2.5 px-4 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
                      >
                        {isSubmittingWithdrawal ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <ArrowDownToLine className="w-4 h-4" />
                        )}
                        <span>
                          {!canRequestWithdrawal
                            ? `Reach ${formatUGX(minWithdrawal)} Available Balance to Withdraw`
                            : 'Submit Withdrawal Request'}
                        </span>
                      </button>
                    </form>
                  </div>

                  {/* Withdrawal Requests History */}
                  <div className="lg:col-span-6 space-y-3">
                    <h4 className="text-sm sm:text-base font-black text-[#032b69]">
                      Your Withdrawal Requests ({withdrawals.length})
                    </h4>

                    {withdrawals.length === 0 ? (
                      <div className="py-10 px-4 text-center rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50 text-xs text-slate-500">
                        You have not submitted any withdrawal requests yet.
                      </div>
                    ) : (
                      <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                        {withdrawals.map((w) => (
                          <div
                            key={w.id}
                            className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1.5"
                          >
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-base font-black text-[#032b69] tabular-nums">
                                {formatUGX(w.amount_ugx)}
                              </span>
                              <span
                                className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${statusBadgeClass(
                                  w.status
                                )}`}
                              >
                                {w.status}
                              </span>
                            </div>
                            <div className="text-[11px] font-semibold text-slate-600">
                              {w.mobile_money_provider} ({w.mobile_money_number}) &bull;{' '}
                              <span className="font-mono text-slate-500">{w.reference_code}</span>
                            </div>
                            <div className="text-[11px] text-slate-400">
                              Requested: {formatDateTime(w.created_at)}
                              {w.paid_at ? ` • Paid: ${formatDateTime(w.paid_at)}` : ''}
                            </div>
                            {w.payment_reference && (
                              <p className="text-xs font-bold text-emerald-700">
                                MoMo Confirmation Ref: {w.payment_reference}
                              </p>
                            )}
                            {w.rejection_reason && (
                              <p className="text-xs font-semibold text-red-700">
                                Rejected: {w.rejection_reason} (Funds returned to balance)
                              </p>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
