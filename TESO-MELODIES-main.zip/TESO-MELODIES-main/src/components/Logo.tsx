import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'responsive';
  onClick?: () => void;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'responsive', onClick }) => {
  const isSm = size === 'sm';
  const isLg = size === 'lg';

  const svgClass = isSm
    ? 'w-7 h-6'
    : isLg
    ? 'w-12 h-10'
    : size === 'responsive'
    ? 'w-7 h-6 sm:w-9 sm:h-7 md:w-10 md:h-8'
    : 'w-10 h-8';

  const tesoClass = isSm
    ? 'text-base'
    : isLg
    ? 'text-3xl'
    : size === 'responsive'
    ? 'text-base sm:text-xl md:text-2xl'
    : 'text-2xl';

  const melodiesClass = isSm
    ? 'text-base'
    : isLg
    ? 'text-3xl'
    : size === 'responsive'
    ? 'text-base sm:text-xl md:text-2xl'
    : 'text-2xl';

  const dotComClass = isSm
    ? 'text-[10px]'
    : isLg
    ? 'text-sm'
    : size === 'responsive'
    ? 'text-[10px] sm:text-xs md:text-sm'
    : 'text-sm';

  return (
    <div 
      onClick={onClick} 
      className={`inline-flex items-center gap-1.5 sm:gap-2.5 cursor-pointer select-none group shrink-0 ${className}`}
    >
      {/* Soundwave equalizer bars + musical note mark */}
      <div className="relative flex items-center justify-center shrink-0">
        <svg
          viewBox="0 0 54 44"
          className={svgClass}
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Equalizer bars */}
          <rect x="2" y="18" width="3.5" height="10" rx="1.75" fill="#facc15" />
          <rect x="8" y="12" width="3.5" height="22" rx="1.75" fill="#facc15" />
          <rect x="14" y="6" width="3.5" height="34" rx="1.75" fill="#facc15" />
          
          {/* Musical double note icon in gold with gloss */}
          <path
            d="M26 9.5V28.5C26 31 23.5 33 20.5 33C17.5 33 15 31 15 28.5C15 26 17.5 24 20.5 24C21.8 24 23 24.4 23.9 25.1V12.5L39 8.5V25.5C39 28 36.5 30 33.5 30C30.5 30 28 28 28 25.5C28 23 30.5 21 33.5 21C34.8 21 36 21.4 36.9 22.1V9.5L26 9.5Z"
            fill="#FACC15"
            stroke="#CA8A04"
            strokeWidth="0.8"
          />
          {/* Right equalizer bars */}
          <rect x="42" y="10" width="3.5" height="26" rx="1.75" fill="#facc15" />
          <rect x="48" y="16" width="3.5" height="14" rx="1.75" fill="#facc15" />
        </svg>
      </div>

      {/* Typography: TESO (yellow) MELODIES.com (white) */}
      <div className="flex flex-col leading-none">
        <div className="flex items-baseline tracking-tight font-black">
          <span className={`text-[#FFCC00] uppercase font-black ${tesoClass}`}>
            TESO
          </span>
          <span className={`text-white uppercase font-extrabold ml-1 ${melodiesClass}`}>
            MELODIES
          </span>
          <span className={`text-white/90 font-bold ml-0.5 tracking-normal lowercase ${dotComClass}`}>
            .com
          </span>
        </div>
      </div>
    </div>
  );
};

