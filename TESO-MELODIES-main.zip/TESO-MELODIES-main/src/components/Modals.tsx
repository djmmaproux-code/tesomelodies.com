import React, { useState } from 'react';
import { X, Upload, Check, Copy, Share2, DollarSign, Megaphone, User, Play, Pause, Heart, Download, Video, Radio, Newspaper, ShieldCheck, ShieldAlert, Sparkles, Loader2, MessageCircle, Send, Music2, Clock } from 'lucide-react';
import { Song, Announcement, Artist, UserProfile, VideoItem } from '../types/music';
import { uploadAppFile } from '../services/storageService';
import { supabase } from '../supabaseClient';
import { HERO_ASSETS } from '../data/initialData';
import { publishNewsItem, publishLiveAnnouncement, publishAdvertisement, AUTHORIZED_ADMIN_EMAIL, isUserAdminEmail } from '../services/adminService';
import { formatDownloadCount } from '../services/musicService';
import { getSongSeoPath, getArtistSeoPath, getGenreSeoPath } from '../utils/seo';

// --- Toast Component ---
interface ToastProps {
  message: string | null;
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, onClose }) => {
  if (!message) return null;
  return (
    <div className="fixed bottom-20 right-6 z-50 bg-slate-900/95 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl border border-yellow-400/40 flex items-center gap-2.5 animate-in slide-in-from-bottom-3 duration-200">
      <Check className="w-4 h-4 text-[#FFCC00]" />
      <span>{message}</span>
      <button onClick={onClose} className="text-slate-400 hover:text-white ml-2">
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};

// --- Upload Audio Music Modal ---
interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: (newSong: Partial<Song>) => void;
  currentUserId?: string | null;
  currentUser?: UserProfile;
  onSwitchToVideoUpload?: () => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onUploadSuccess,
  currentUserId,
  currentUser,
  onSwitchToVideoUpload,
}) => {
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState(currentUser?.stageName || currentUser?.name || '');
  const [genre, setGenre] = useState(currentUser?.genre || 'Afrobeat');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedCoverFile, setSelectedCoverFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState('');
  const [coverFileName, setCoverFileName] = useState('');
  const [durationStr, setDurationStr] = useState('03:30');
  const [description, setDescription] = useState('');
  const [durationSec, setDurationSec] = useState(210);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploadStage, setUploadStage] = useState<string>('');

  React.useEffect(() => {
    if (isOpen && currentUser) {
      if (!artist) {
        setArtist(currentUser.stageName || currentUser.name || '');
      }
      if (currentUser.genre) {
        setGenre(currentUser.genre);
      }
    }
  }, [isOpen, currentUser]);

  const handleAudioSelect = (file: File) => {
    setSelectedFile(file);
    setFileName(file.name);
    setUploadError(null);
    try {
      const url = URL.createObjectURL(file);
      const audioObj = new Audio(url);
      audioObj.onloadedmetadata = () => {
        const dur = Math.round(audioObj.duration);
        if (dur && !isNaN(dur)) {
          setDurationSec(dur);
          const m = Math.floor(dur / 60);
          const s = dur % 60;
          setDurationStr(`${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`);
        }
        URL.revokeObjectURL(url);
      };
      audioObj.onerror = () => {
        URL.revokeObjectURL(url);
      };
    } catch {
      // fallback
    }
  };

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !artist.trim()) return;

    if (!selectedFile) {
      setUploadError('Please select an audio file (MP3, WAV, M4A, OGG) to upload.');
      return;
    }

    if (selectedFile.type.startsWith('video/') || /\.(mp4|webm|mov|mkv|m4v|ogv)$/i.test(selectedFile.name)) {
      setUploadError('Video files belong in the dedicated Videos section. Use "Upload Video" instead.');
      return;
    }

    const {
      data: { session },
    } = await supabase.auth.getSession();
    const activeUserId = session?.user?.id || currentUserId;

    if (!activeUserId) {
      setUploadError('You must be signed in to upload your music. Please sign in or create an account.');
      return;
    }

    setIsSubmitting(true);
    setUploadError(null);
    setUploadProgress(5);
    setUploadStage('Preparing upload...');

    try {
      const itemId = typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `song-${Date.now()}`;
      let audioUrl: string | undefined = undefined;
      let audioPath: string | undefined = undefined;
      let coverUrl: string | undefined = undefined;
      let coverPath: string | undefined = undefined;

      // 1. Upload audio file to Cloudflare R2
      const audioUpload = await uploadAppFile(activeUserId, 'tracks', itemId, selectedFile, (info) => {
        setUploadProgress(Math.min(85, Math.round(info.percent * 0.85)));
        setUploadStage(info.stage);
      });
      if (audioUpload.error || !audioUpload.publicUrl) {
        console.error('Storage upload error for audio track:', audioUpload.error);
        setUploadError(`Cloudflare R2 upload error: ${audioUpload.error || 'Failed to generate public audio URL'}`);
        setIsSubmitting(false);
        setUploadProgress(0);
        setUploadStage('');
        return;
      }

      audioUrl = audioUpload.publicUrl;
      audioPath = audioUpload.path;

      // 2. Upload cover artwork to Cloudflare R2 if provided
      if (selectedCoverFile) {
        setUploadProgress(88);
        setUploadStage('Uploading cover artwork to Cloudflare R2...');
        const coverUpload = await uploadAppFile(activeUserId, 'covers', itemId, selectedCoverFile);
        if (coverUpload.error || !coverUpload.publicUrl) {
          setUploadError(`Cover upload error: ${coverUpload.error || 'Failed to upload cover artwork'}`);
          setIsSubmitting(false);
          setUploadProgress(0);
          setUploadStage('');
          return;
        }
        coverUrl = coverUpload.publicUrl;
        coverPath = coverUpload.path;
      }

      setUploadProgress(95);
      setUploadStage('Publishing song to Teso Melodies...');

      await onUploadSuccess({
        id: itemId,
        title: title.trim(),
        artist: artist.trim(),
        genre,
        duration: durationStr || '03:30',
        durationSec: durationSec || 210,
        category: 'new',
        coverUrl: coverUrl || HERO_ASSETS.announcement,
        coverPath,
        audioUrl,
        audioPath,
        audioSize: audioUpload.fileSize,
        audioMimeType: audioUpload.contentType,
        storageProvider: 'cloudflare-r2',
        plays: 0,
        likes: 0,
        userId: activeUserId,
        isRealUpload: true,
      });

      setUploadProgress(100);
      setIsSubmitting(false);
      setTitle('');
      setSelectedFile(null);
      setSelectedCoverFile(null);
      setFileName('');
      setCoverFileName('');
      setDescription('');
      onClose();
    } catch (err: any) {
      setUploadError(err?.message || 'Upload failed');
      setIsSubmitting(false);
      setUploadProgress(0);
      setUploadStage('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#032b69] via-[#022153] to-[#011433] rounded-3xl p-6 shadow-2xl border border-blue-400/30 text-white max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-blue-200/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-[#FFCC00] flex items-center justify-center border border-blue-400/30 shadow-inner">
            <Upload className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white tracking-tight">Upload Music</h3>
            <p className="text-xs text-blue-200/80">Share your audio track with Teso and the world</p>
          </div>
        </div>

        {onSwitchToVideoUpload && (
          <div className="mb-3 flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-blue-950/60 border border-blue-400/25">
            <span className="text-[11px] text-blue-200/90 font-medium flex items-center gap-1.5">
              <Video className="w-3.5 h-3.5 text-[#FFCC00]" />
              Have a music video instead?
            </span>
            <button
              type="button"
              onClick={() => {
                onClose();
                onSwitchToVideoUpload();
              }}
              className="text-[11px] font-black text-[#FFCC00] hover:text-yellow-300 underline cursor-pointer"
            >
              Open Video Uploader
            </button>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-bold text-white mb-1">Track Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Teso Sunrise"
              required
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all shadow-inner"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">Artist Name</label>
            <input
              type="text"
              value={artist}
              onChange={(e) => setArtist(e.target.value)}
              placeholder="e.g. Master J"
              required
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all shadow-inner"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">Genre</label>
            <select
              value={genre}
              onChange={(e) => setGenre(e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all cursor-pointer shadow-inner"
            >
              <option value="teso worship" className="bg-[#032b69] text-white">teso worship</option>
              <option value="Gospel" className="bg-[#032b69] text-white">Gospel</option>
              <option value="Akoogo" className="bg-[#032b69] text-white">Akoogo</option>
              <option value="R&B" className="bg-[#032b69] text-white">R&B</option>
              <option value="Reggae" className="bg-[#032b69] text-white">Reggae</option>
              <option value="Rock" className="bg-[#032b69] text-white">Rock</option>
              <option value="Afrobeat" className="bg-[#032b69] text-white">Afrobeat</option>
              <option value="Country" className="bg-[#032b69] text-white">Country</option>
              <option value="Amapiano" className="bg-[#032b69] text-white">Amapiano</option>
              <option value="Jazz" className="bg-[#032b69] text-white">Jazz</option>
              <option value="Teso Dancehall" className="bg-[#032b69] text-white">Teso Dancehall</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">Audio Track File</label>
            <div className="border-2 border-dashed border-blue-400/40 hover:border-[#FFCC00] rounded-2xl p-4 text-center cursor-pointer bg-[#061e47]/70 hover:bg-[#061e47] transition-all">
              <input
                type="file"
                accept="audio/*,.mp3,.wav,.m4a,.ogg,.aac,.flac"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) {
                    handleAudioSelect(f);
                  }
                }}
                className="hidden"
                id="music-upload-input"
              />
              <label htmlFor="music-upload-input" className="cursor-pointer block">
                <Upload className="w-6 h-6 text-[#FFCC00] mx-auto mb-1.5" />
                <span className="text-xs font-semibold text-white block">
                  {fileName || 'Click to select MP3, WAV, M4A or OGG'}
                </span>
                <span className="text-[10px] text-blue-200/80 mt-0.5 block">
                  Audio songs catalog • 100% Free
                </span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Cover Artwork <span className="text-blue-200/70 font-normal">(Optional)</span>
            </label>
            <div className="border-2 border-dashed border-blue-400/40 hover:border-[#FFCC00] rounded-2xl p-3 text-center cursor-pointer bg-[#061e47]/70 hover:bg-[#061e47] transition-all">
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) {
                    setSelectedCoverFile(f);
                    setCoverFileName(f.name);
                  }
                }}
                className="hidden"
                id="cover-upload-input"
              />
              <label htmlFor="cover-upload-input" className="cursor-pointer block">
                <span className="text-xs font-semibold text-white block">
                  {coverFileName || 'Click to select artwork (JPG, PNG)'}
                </span>
                <span className="text-[10px] text-blue-200/80 mt-0.5 block">
                  Artwork stored permanently in Cloudflare R2
                </span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Song Description / Notes <span className="text-blue-200/70 font-normal">(Optional)</span>
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Tell listeners about this song, featured vocalists, instruments (e.g. Akoogo), or message..."
              rows={2}
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent resize-none transition-all shadow-inner"
            />
          </div>

          {isSubmitting && (
            <div className="space-y-1.5 bg-[#061e47]/90 border border-blue-400/30 p-3 rounded-xl">
              <div className="flex items-center justify-between text-[11px] font-bold text-blue-100">
                <span>{uploadStage || 'Uploading...'}</span>
                <span className="text-[#FFCC00]">{uploadProgress}%</span>
              </div>
              <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#FFCC00] transition-all duration-300"
                  style={{ width: `${Math.max(8, uploadProgress)}%` }}
                />
              </div>
            </div>
          )}

          {uploadError && (
            <p className="text-xs text-red-200 bg-red-950/80 border border-red-500/40 p-2.5 rounded-xl text-center font-medium">
              {uploadError}
            </p>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-2.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-yellow-500/20 transition-all active:scale-[0.98] cursor-pointer mt-2 disabled:opacity-60"
          >
            {isSubmitting ? (uploadStage || 'Uploading & Publishing...') : 'Upload & Publish Song'}
          </button>

          {/* Quick Contact & Music Promotion Links */}
          <div className="pt-2 border-t border-blue-400/20 text-center">
            <p className="text-[11px] text-blue-200/90 font-medium">
              Need Music Promotion on Radio or Online?
            </p>
            <div className="flex flex-wrap items-center justify-center gap-1.5 mt-1 text-[10px]">
              <a
                href="https://wa.me/256788900047"
                target="_blank"
                rel="noreferrer"
                className="px-2 py-0.5 rounded-lg bg-emerald-600/40 hover:bg-emerald-600 text-emerald-200 hover:text-white transition-colors border border-emerald-500/30"
              >
                WhatsApp Promotion: +256 788 900047
              </a>
              <a
                href="tel:0752848442"
                className="px-2 py-0.5 rounded-lg bg-red-600/30 hover:bg-red-600/50 text-red-200 hover:text-white transition-colors border border-red-500/30"
              >
                Airtel Show: 0752848442
              </a>
              <a
                href="tel:0788900047"
                className="px-2 py-0.5 rounded-lg bg-yellow-500/20 hover:bg-yellow-500/40 text-yellow-300 hover:text-white transition-colors border border-yellow-400/30"
              >
                MTN: 0788 900047
              </a>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

// --- Get Discovered & Earn Modal ---
interface EarnModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSignUp: () => void;
  isLoggedIn?: boolean;
  onOpenUpload?: () => void;
  onOpenDashboard?: () => void;
}

export const EarnModal: React.FC<EarnModalProps> = ({
  isOpen,
  onClose,
  onOpenSignUp,
  isLoggedIn,
  onOpenUpload,
  onOpenDashboard,
}) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-100">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 rounded-2xl bg-yellow-100 text-amber-700 flex items-center justify-center mb-3">
          <DollarSign className="w-6 h-6" />
        </div>

        <h3 className="text-2xl font-black text-[#032b69] tracking-tight mb-2">
          Get Discovered &amp; Earn on Teso Melodies
        </h3>

        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-4">
          Verified Teso Melodies artists earn real Ugandan Shillings (UGX) directly from genuine fan engagement. Verify your registered Gmail inside your Artist Dashboard to activate earnings.
        </p>

        <div className="space-y-2.5 mb-6 text-xs text-slate-700">
          <div className="p-3 bg-blue-50/80 rounded-xl border border-blue-100 flex items-center gap-3">
            <span className="w-6 h-6 rounded-full bg-[#0072ce] text-white font-bold flex items-center justify-center text-xs shrink-0">1</span>
            <div><strong>Verify Your Registered Gmail:</strong> Unlock your Artist Earnings Dashboard in seconds without creating a new account.</div>
          </div>
          <div className="p-3 bg-blue-50/80 rounded-xl border border-blue-100 flex items-center gap-3">
            <span className="w-6 h-6 rounded-full bg-[#0072ce] text-white font-bold flex items-center justify-center text-xs shrink-0">2</span>
            <div><strong>Genuine Fan Royalties:</strong> Earn <strong>18 UGX</strong> per 30 likes, <strong>700 UGX</strong> per 100 followers, plus eligible download earnings.</div>
          </div>
          <div className="p-3 bg-blue-50/80 rounded-xl border border-blue-100 flex items-center gap-3">
            <span className="w-6 h-6 rounded-full bg-[#0072ce] text-white font-bold flex items-center justify-center text-xs shrink-0">3</span>
            <div><strong>Mobile Money Payouts:</strong> Withdraw starting from <strong>15,000 UGX</strong> via MTN Mobile Money &amp; Airtel Money.</div>
          </div>
        </div>

        {isLoggedIn ? (
          <div className="flex flex-col sm:flex-row gap-2">
            <button
              onClick={() => {
                onClose();
                if (onOpenDashboard) onOpenDashboard();
              }}
              className="flex-1 py-3 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-sm rounded-xl shadow-md transition-all active:scale-[0.98] cursor-pointer"
            >
              Open Earnings Dashboard
            </button>
            <button
              onClick={() => {
                onClose();
                if (onOpenUpload) onOpenUpload();
              }}
              className="sm:w-auto px-4 py-3 bg-[#0072ce] hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow transition-all active:scale-[0.98] cursor-pointer"
            >
              Upload Music
            </button>
          </div>
        ) : (
          <button
            onClick={() => {
              onClose();
              onOpenSignUp();
            }}
            className="w-full py-3 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-sm rounded-xl shadow-md transition-all active:scale-[0.98] cursor-pointer"
          >
            Create Free Creator Account
          </button>
        )}
      </div>
    </div>
  );
};

// --- Advertise Your Brand Modal ---
interface AdvertiseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitAd: (company: string) => void;
  onAdPublished?: (newAnnouncement: Announcement) => void;
  currentUserEmail?: string | null;
}

export const AdvertiseModal: React.FC<AdvertiseModalProps> = ({
  isOpen,
  onClose,
  onSubmitAd,
  onAdPublished,
  currentUserEmail,
}) => {
  const [brand, setBrand] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [tagline, setTagline] = useState('');
  const [publishAsLiveAd, setPublishAsLiveAd] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const isAdmin = isUserAdminEmail(currentUserEmail);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // If publishing live advertisement onto portal
    if (publishAsLiveAd) {
      setSubmitted(true);
      const res = await publishAdvertisement({
        brandName: brand,
        tagline: tagline || 'Official Brand Advertisement on Teso Melodies',
        description: message,
        contactInfo: email,
      });

      if (!res.success || !res.announcement) {
        setErrorMsg(res.error || 'Failed to publish advertisement. Backend authorization check failed.');
        setSubmitted(false);
        return;
      }

      if (onAdPublished) {
        onAdPublished(res.announcement);
      }
      setSubmitted(false);
      onClose();
      return;
    }

    // Standard Inquiry submission
    setSubmitted(true);
    setTimeout(() => {
      onSubmitAd(brand || 'Your Brand');
      setSubmitted(false);
      onClose();
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#032b69] via-[#022153] to-[#011433] rounded-3xl p-6 shadow-2xl border border-blue-400/30 text-white max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-blue-200/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-[#FFCC00] flex items-center justify-center border border-purple-400/30 shadow-inner">
            <Megaphone className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white tracking-tight">Advertise on Teso Melodies</h3>
            <p className="text-xs text-blue-200/80">Reach thousands of engaged music lovers daily</p>
          </div>
        </div>

        {/* Admin Authorization Badge */}
        {isAdmin ? (
          <div className="mb-3 p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 flex items-center gap-2 text-xs text-emerald-200">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Authorized Administrator: <strong>{AUTHORIZED_ADMIN_EMAIL}</strong></span>
          </div>
        ) : null}

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-xs font-bold text-white mb-1">Company / Brand Name</label>
            <input
              type="text"
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              placeholder="e.g. Nile Telecom / Soroti Media Hub"
              required
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all shadow-inner font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">Contact Email / Phone</label>
            <input
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="brand@example.com or +256 788 900047"
              required
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all shadow-inner font-semibold"
            />
          </div>

          {isAdmin && (
            <div>
              <label className="block text-xs font-bold text-white mb-1">Ad Tagline / Subtitle (Optional)</label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                placeholder="e.g. Special Offer: 20% Off for Teso Melodies Listeners!"
                className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all shadow-inner font-semibold"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-white mb-1">Campaign Goal / Offer Details</label>
            <textarea
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell us about the product, billboard banner, or radio spot you want to place..."
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent resize-none font-medium transition-all shadow-inner"
            />
          </div>

          {isAdmin && (
            <div className="p-2.5 rounded-xl bg-blue-950/70 border border-blue-400/30 flex items-center gap-2">
              <input
                type="checkbox"
                id="publishAsLiveAd"
                checked={publishAsLiveAd}
                onChange={(e) => setPublishAsLiveAd(e.target.checked)}
                className="w-4 h-4 rounded text-[#FFCC00] focus:ring-[#FFCC00] cursor-pointer"
              />
              <label htmlFor="publishAsLiveAd" className="text-xs font-semibold text-blue-100 cursor-pointer">
                Publish live advertisement banner onto website immediately
              </label>
            </div>
          )}

          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-red-950/80 border border-red-500/40 text-xs text-red-200 text-center font-medium flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={submitted || !brand.trim()}
            className="w-full py-2.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-yellow-500/20 transition-all active:scale-[0.98] cursor-pointer disabled:opacity-60"
          >
            {submitted
              ? 'Processing...'
              : publishAsLiveAd
              ? 'Publish Official Advertisement'
              : 'Submit Advertising Request'}
          </button>
        </form>
      </div>
    </div>
  );
};

// --- Post News Modal (Authorized: tesomelodies@gmail.com) ---
export interface PostNewsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNewsPublished: (newAnnouncement: Announcement) => void;
  currentUserEmail?: string | null;
}

export const PostNewsModal: React.FC<PostNewsModalProps> = ({
  isOpen,
  onClose,
  onNewsPublished,
  currentUserEmail,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Portal News');
  const [description, setDescription] = useState('');
  const [fullContent, setFullContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  if (!isOpen) return null;

  const isAdmin = isUserAdminEmail(currentUserEmail);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    setIsSubmitting(true);
    setAuthError(null);

    // Call secure backend authorization service
    const result = await publishNewsItem({
      title,
      category,
      description,
      fullContent: fullContent || description,
      imageUrl: imageUrl || undefined,
      coverFile,
    });

    if (!result.success || !result.announcement) {
      setAuthError(result.error || `Permission Denied: Only ${AUTHORIZED_ADMIN_EMAIL} is authorized to post news.`);
      setIsSubmitting(false);
      return;
    }

    onNewsPublished(result.announcement);
    setTitle('');
    setDescription('');
    setFullContent('');
    setImageUrl('');
    setCoverFile(null);
    setIsSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#032b69] via-[#022153] to-[#011433] rounded-3xl p-6 shadow-2xl border border-blue-400/30 text-white max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-blue-200/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-[#FFCC00] flex items-center justify-center border border-blue-400/30 shadow-inner">
            <Newspaper className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white tracking-tight">Post News</h3>
            <p className="text-xs text-blue-200/80">Publish articles & updates to Teso Melodies</p>
          </div>
        </div>

        {/* Security & Authorization status */}
        {isAdmin ? (
          <div className="mb-3 p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 flex items-center gap-2 text-xs text-emerald-200">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Authorized: <strong>{AUTHORIZED_ADMIN_EMAIL}</strong></span>
          </div>
        ) : (
          <div className="mb-3 p-2.5 rounded-xl bg-amber-950/70 border border-amber-500/40 text-xs text-amber-200 flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Posting Permission Restriction</p>
              <p className="text-[11px] text-amber-300/90 mt-0.5">
                Only <strong>{AUTHORIZED_ADMIN_EMAIL}</strong> is authorized to create and publish news. Backend authorization is enforced on submit.
              </p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-xs font-bold text-white mb-1">
              News Headline <span className="text-yellow-400">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Teso Melodies Welcomes Soroti Music Festival"
              required
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all shadow-inner font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">Category / Tag</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all cursor-pointer shadow-inner font-semibold"
            >
              <option value="Portal News" className="bg-[#032b69] text-white">Portal News</option>
              <option value="Music News" className="bg-[#032b69] text-white">Music News</option>
              <option value="Artist Spotlight" className="bg-[#032b69] text-white">Artist Spotlight</option>
              <option value="Event" className="bg-[#032b69] text-white">Event & Festivals</option>
              <option value="Breaking News" className="bg-[#032b69] text-white">Breaking News</option>
              <option value="Announcement" className="bg-[#032b69] text-white">Announcement</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Short Summary <span className="text-yellow-400">*</span>
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief summary to show in sidebar and news cards..."
              required
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent resize-none font-medium transition-all shadow-inner"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Full Story / Article Content <span className="text-blue-200/70 font-normal">(Optional)</span>
            </label>
            <textarea
              rows={3}
              value={fullContent}
              onChange={(e) => setFullContent(e.target.value)}
              placeholder="Complete news story, quotes, and full details..."
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent resize-none font-medium transition-all shadow-inner"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Upload Cover Image or Paste URL <span className="text-blue-200/70 font-normal">(Optional)</span>
            </label>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => setCoverFile(e.target.files?.[0] || null)}
              className="block w-full text-xs text-blue-100 mb-2 cursor-pointer"
            />
            <input
              type="text"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="Or https://... (Leave blank for default header image)"
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all shadow-inner font-semibold"
            />
          </div>

          {authError && (
            <div className="p-2.5 rounded-xl bg-red-950/80 border border-red-500/40 text-xs text-red-200 text-center font-medium flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting || !title.trim()}
            className="w-full py-2.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-yellow-500/20 transition-all active:scale-[0.98] cursor-pointer disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Verifying Authorization & Publishing...</span>
              </>
            ) : (
              <span>Publish News to Teso Melodies</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

// --- Teso Melodies is Live! Modal (Authorized: tesomelodies@gmail.com) ---
export interface PublishLiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAnnouncementPublished: (newAnnouncement: Announcement) => void;
  currentUserEmail?: string | null;
}

export const PublishLiveModal: React.FC<PublishLiveModalProps> = ({
  isOpen,
  onClose,
  onAnnouncementPublished,
  currentUserEmail,
}) => {
  const [title, setTitle] = useState('Teso Melodies is Live!');
  const [tagline, setTagline] = useState('Welcome to Teso Melodies — stream, upload, share and earn!');
  const [details, setDetails] = useState(
    'Welcome to Teso Melodies — East Africa\'s premier free music and video streaming portal! We are proud to connect artists, fans, and producers from Teso, Uganda, Kenya, and across the globe. Stream unlimited songs, download for offline listening, discover emerging voices, and enjoy high-definition audio without subscriptions.'
  );
  const [badge, setBadge] = useState('Official Live');
  const [imageUrl, setImageUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  if (!isOpen) return null;

  const isAdmin = isUserAdminEmail(currentUserEmail);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !tagline.trim()) return;

    setIsSubmitting(true);
    setAuthError(null);

    // Call secure backend authorization service
    const result = await publishLiveAnnouncement({
      title,
      tagline,
      details: details || tagline,
      badge,
      imageUrl: imageUrl || undefined,
    });

    if (!result.success || !result.announcement) {
      setAuthError(result.error || `Permission Denied: Only ${AUTHORIZED_ADMIN_EMAIL} is authorized to publish announcements.`);
      setIsSubmitting(false);
      return;
    }

    onAnnouncementPublished(result.announcement);
    setIsSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#032b69] via-[#022153] to-[#011433] rounded-3xl p-6 shadow-2xl border border-blue-400/30 text-white max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-blue-200/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-10 h-10 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center border border-red-400/30 shadow-inner">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white tracking-tight">Teso Melodies is Live!</h3>
            <p className="text-xs text-blue-200/80">Broadcast platform status & live announcements</p>
          </div>
        </div>

        {/* Security & Authorization status */}
        {isAdmin ? (
          <div className="mb-3 p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 flex items-center gap-2 text-xs text-emerald-200">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Authorized Administrator: <strong>{AUTHORIZED_ADMIN_EMAIL}</strong></span>
          </div>
        ) : (
          <div className="mb-3 p-2.5 rounded-xl bg-amber-950/70 border border-amber-500/40 text-xs text-amber-200 flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Posting Permission Restriction</p>
              <p className="text-[11px] text-amber-300/90 mt-0.5">
                Only <strong>{AUTHORIZED_ADMIN_EMAIL}</strong> is authorized to publish official live announcements. Backend authorization is enforced on submit.
              </p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Live Announcement Title <span className="text-yellow-400">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Teso Melodies is Live!"
              required
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all shadow-inner font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">Badge / Status</label>
            <select
              value={badge}
              onChange={(e) => setBadge(e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all cursor-pointer shadow-inner font-semibold"
            >
              <option value="Official Live" className="bg-[#032b69] text-white">Official Live</option>
              <option value="Now Streaming" className="bg-[#032b69] text-white">Now Streaming</option>
              <option value="Radio Broadcast" className="bg-[#032b69] text-white">Radio Broadcast</option>
              <option value="Special Release" className="bg-[#032b69] text-white">Special Release</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Tagline / Broadcast Subtitle <span className="text-yellow-400">*</span>
            </label>
            <textarea
              rows={2}
              value={tagline}
              onChange={(e) => setTagline(e.target.value)}
              placeholder="Brief tagline shown under headline..."
              required
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent resize-none font-medium transition-all shadow-inner"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Full Announcement Content
            </label>
            <textarea
              rows={3}
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              placeholder="Full details of the announcement..."
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent resize-none font-medium transition-all shadow-inner"
            />
          </div>

          {authError && (
            <div className="p-2.5 rounded-xl bg-red-950/80 border border-red-500/40 text-xs text-red-200 text-center font-medium flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting || !title.trim()}
            className="w-full py-2.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-yellow-500/20 transition-all active:scale-[0.98] cursor-pointer disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Verifying Authorization & Broadcasting...</span>
              </>
            ) : (
              <span>Broadcast "Teso Melodies is Live!" Announcement</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

// --- Announcement Details Modal ---
interface AnnouncementModalProps {
  announcement: Announcement | null;
  onClose: () => void;
}

export const AnnouncementModal: React.FC<AnnouncementModalProps> = ({ announcement, onClose }) => {
  if (!announcement) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-100">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-full h-44 rounded-2xl overflow-hidden mb-4 shadow-sm bg-slate-100">
          <img
            src={announcement.thumbnail}
            alt={announcement.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>

        <div className="flex items-center justify-between text-xs text-slate-400 font-bold mb-2">
          <span className="px-2.5 py-1 rounded-md bg-blue-50 text-[#0072ce]">{announcement.badge || 'News'}</span>
          <span>{announcement.date}</span>
        </div>

        <h3 className="text-xl font-black text-[#032b69] leading-snug mb-3">
          {announcement.title}
        </h3>

        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
          {announcement.fullContent || announcement.description}
        </p>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-[#0072ce] hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-all"
        >
          Close Announcement
        </button>
      </div>
    </div>
  );
};

// --- Artist Profile Modal ---
interface ArtistModalProps {
  artist: Artist | null;
  artistSongs?: Song[];
  onClose: () => void;
  onFollow: (id: string) => void;
  onPlaySong?: (song: Song) => void;
  onDownloadSong?: (song: Song) => void;
  onLikeSong?: (songId: string) => void;
  likedSongIds?: Set<string>;
  downloadingSongId?: string | null;
  onPlaySongTitle?: (title: string) => void;
  onOpenComments?: (song: Song) => void;
  onSelectGenre?: (genre: string) => void;
}

export const ArtistModal: React.FC<ArtistModalProps> = ({
  artist,
  artistSongs = [],
  onClose,
  onFollow,
  onPlaySong,
  onDownloadSong,
  onLikeSong,
  likedSongIds = new Set(),
  downloadingSongId = null,
  onPlaySongTitle,
  onOpenComments,
  onSelectGenre,
}) => {
  if (!artist) return null;

  const realTotalLikes =
    artist.totalLikes !== undefined
      ? artist.totalLikes
      : artistSongs.reduce((sum, s) => sum + (s.likes || 0), 0);

  const realTotalDownloads =
    artistSongs.length > 0
      ? artistSongs.reduce((sum, s) => sum + (s.downloadsCount || 0), 0)
      : artist.totalDownloads || 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-4 mb-4">
          <div className="w-20 h-20 rounded-full overflow-hidden shrink-0 ring-4 ring-yellow-400 shadow-md bg-slate-100">
            <img
              src={artist.avatar}
              alt={artist.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-black text-slate-900">{artist.name}</h3>
              <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[10px] font-black uppercase tracking-wider">
                Artist
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-1.5 mt-1 text-xs">
              <a
                href={getGenreSeoPath(artist.genre || 'Teso Music')}
                onClick={(e) => {
                  if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
                  if (onSelectGenre && artist.genre) {
                    e.preventDefault();
                    onClose();
                    onSelectGenre(artist.genre);
                  }
                }}
                className="font-semibold text-slate-600 hover:text-[#0072ce] hover:underline"
              >
                {artist.genre}
              </a>
              <span className="text-slate-300">•</span>
              <span className="font-bold text-slate-700">
                {artist.followers === 1
                  ? '1 follower'
                  : `${(artist.followers || 0).toLocaleString()} followers`}
              </span>
              <span className="text-slate-300">•</span>
              <span className="font-bold text-red-600 flex items-center gap-1">
                <Heart className="w-3.5 h-3.5 fill-red-500 text-red-500" />
                {realTotalLikes.toLocaleString()} likes
              </span>
              <span className="text-slate-300">•</span>
              <span className="font-bold text-emerald-700 flex items-center gap-1">
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                {realTotalDownloads.toLocaleString()} {realTotalDownloads === 1 ? 'download' : 'downloads'}
              </span>
            </div>
            <p className="text-[11px] text-[#0072ce] font-bold mt-0.5">{artist.monthlyListeners || `${realTotalLikes} likes`}</p>
          </div>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed mb-4 bg-slate-50 p-3 rounded-2xl border border-slate-100">
          {artist.bio}
        </p>

        {/* Real Uploaded Songs or Top Tracks */}
        <div className="mb-5">
          <div className="flex items-center justify-between mb-2.5">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <span>Discography & Tracks</span>
              {artistSongs.length > 0 && (
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-black px-1.5 py-0.5 rounded-md">
                  {artistSongs.length} Available
                </span>
              )}
            </h4>
            <span className="text-[10px] text-slate-400 font-semibold">Free MP3 Downloads</span>
          </div>

          {artistSongs && artistSongs.length > 0 ? (
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {artistSongs.map((song, sIdx) => {
                const isLiked = likedSongIds.has(song.id);
                return (
                    <div
                      key={`artist-modal-song-${song.id}-${sIdx}`}
                      className="flex items-center justify-between gap-2 p-2 rounded-2xl bg-slate-50 hover:bg-blue-50/70 border border-slate-200/60 transition-colors group"
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0 bg-slate-200 shadow-xs">
                          <img
                            src={song.coverUrl}
                            alt={song.title}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="min-w-0 flex-1 pr-1 py-0.5">
                          <h5 className="text-xs font-bold text-slate-900 leading-snug break-words">
                            <a
                              href={getSongSeoPath(song.id)}
                              onClick={(e) => {
                                if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
                                if (onPlaySong) {
                                  e.preventDefault();
                                  onPlaySong(song);
                                }
                              }}
                              className="hover:text-[#0072ce] transition-colors"
                            >
                              {song.title}
                            </a>
                          </h5>
                          <p className="text-[10px] text-slate-500 font-medium leading-snug break-words mt-0.5">
                            {song.artist ? `${song.artist} • ` : ''}{song.genre} • {song.duration}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 self-center">
                      {onPlaySong && (
                        <button
                          onClick={() => onPlaySong(song)}
                          className="w-8 h-8 rounded-full bg-[#0072ce] hover:bg-[#005fb8] text-white flex items-center justify-center shadow-xs cursor-pointer transition-transform active:scale-90"
                          title="Play Song"
                        >
                          <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                        </button>
                      )}

                      {onOpenComments && (
                        <button
                          onClick={() => onOpenComments(song)}
                          className="p-1.5 text-slate-400 hover:text-[#0072ce] rounded-lg hover:bg-blue-50 transition-colors cursor-pointer"
                          title="Reviews & Comments"
                        >
                          <MessageCircle className="w-4 h-4 text-[#0072ce]" />
                        </button>
                      )}

                      {onDownloadSong && (
                        <button
                          onClick={() => onDownloadSong(song)}
                          disabled={downloadingSongId === song.id}
                          className="inline-flex items-center gap-1 px-2 py-1 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer disabled:opacity-60"
                          title={`Download Song (MP3) • ${(song.downloadsCount || 0).toLocaleString()} downloads`}
                        >
                          {downloadingSongId === song.id ? (
                            <Loader2 className="w-3.5 h-3.5 text-emerald-600 animate-spin" />
                          ) : (
                            <Download className="w-3.5 h-3.5 text-emerald-600" />
                          )}
                          <span className="text-[11px] font-bold tabular-nums">
                            {formatDownloadCount(song.downloadsCount || 0)}
                          </span>
                        </button>
                      )}

                      {onLikeSong && (
                        <button
                          onClick={() => onLikeSong(song.id)}
                          className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg hover:bg-red-50 transition-colors cursor-pointer"
                          title={isLiked ? 'Unlike' : 'Like'}
                        >
                          <Heart className={`w-4 h-4 ${isLiked ? 'fill-red-500 text-red-500' : ''}`} />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (artist.topTracks && artist.topTracks.length > 0) ? (
            <div className="space-y-1.5">
              {artist.topTracks.map((trk, i) => (
                <div
                  key={`top-track-${trk}-${i}`}
                  onClick={() => onPlaySongTitle?.(trk)}
                  className="flex items-center justify-between p-2 rounded-xl bg-slate-50 hover:bg-blue-50 transition-colors cursor-pointer group"
                >
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 group-hover:text-blue-600">
                    <span className="text-slate-400 font-normal w-4">{i + 1}</span>
                    <span>{trk}</span>
                  </div>
                  <Play className="w-3.5 h-3.5 text-blue-600" />
                </div>
              ))}
            </div>
          ) : (
            <div className="py-6 text-center bg-slate-50 rounded-2xl border border-slate-100 p-4">
              <p className="text-xs font-bold text-slate-700">No tracks uploaded yet</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Stay tuned as {artist.name} uploads fresh music to Teso Melodies!</p>
            </div>
          )}
        </div>

        <button
          onClick={() => onFollow(artist.id)}
          className={`w-full py-2.5 rounded-xl font-bold text-xs transition-all shadow-sm cursor-pointer ${
            artist.isFollowed
              ? 'bg-slate-100 text-slate-800 border border-slate-200'
              : 'bg-[#FFCC00] text-slate-950 hover:bg-yellow-400'
          }`}
        >
          {artist.isFollowed ? 'Following Artist' : 'Follow ' + artist.name}
        </button>
      </div>
    </div>
  );
};

// --- Share Modal (Songs & Videos with Crawler-Compatible Individual URLs) ---
interface ShareModalProps {
  song?: Song | null;
  video?: VideoItem | null;
  onClose: () => void;
  onCopyLink: (shareUrl: string) => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ song, video, onClose, onCopyLink }) => {
  const [copied, setCopied] = useState(false);

  const activeItem = song || video;
  if (!activeItem) return null;

  const isVideo = Boolean(video && !song);
  const origin =
    typeof window !== 'undefined' ? window.location.origin : 'https://tesomelodies.com';
  const shareUrl = isVideo
    ? `${origin}/video/${encodeURIComponent(video!.id)}`
    : `${origin}/song/${encodeURIComponent(song!.id)}`;

  const itemTitle = activeItem.title;
  const itemArtist = activeItem.artist;
  const itemCategory = isVideo ? video!.category : song!.genre;
  const itemArtwork = isVideo ? video!.thumbnail : song!.coverUrl;
  const shareText = isVideo
    ? `Watch "${itemTitle}" by ${itemArtist} on TESO MELODIES:`
    : `Listen to "${itemTitle}" by ${itemArtist} on TESO MELODIES:`;

  const whatsappHref = `https://wa.me/?text=${encodeURIComponent(`${shareText}\n${shareUrl}`)}`;
  const facebookHref = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
  const telegramHref = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`;
  const twitterHref = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
  const messengerHref = `fb-messenger://share/?link=${encodeURIComponent(shareUrl)}`;

  const handleCopy = () => {
    setCopied(true);
    onCopyLink(shareUrl);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNativeShare = async () => {
    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      try {
        await navigator.share({
          title: `${itemTitle} — ${itemArtist} | TESO MELODIES`,
          text: shareText,
          url: shareUrl,
        });
      } catch {
        // user cancelled native share dialog
      }
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-md bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-100 text-center">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          aria-label="Close Share Modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Preview Card */}
        <div className="flex items-center gap-3 text-left p-3 rounded-2xl bg-slate-50 border border-slate-200/80 mb-4 pr-8">
          <img
            src={itemArtwork || HERO_ASSETS.announcement}
            alt={itemTitle}
            className="w-16 h-16 rounded-xl object-cover bg-slate-200 shrink-0 shadow-sm"
            referrerPolicy="no-referrer"
          />
          <div className="min-w-0 flex-1">
            <span className="inline-block text-[10px] font-black uppercase tracking-wider text-[#0072ce] mb-0.5">
              {isVideo ? 'Share Video' : 'Share Song'} · {itemCategory}
            </span>
            <h3 className="text-sm font-black text-slate-900 leading-snug line-clamp-1">{itemTitle}</h3>
            <p className="text-xs text-slate-500 font-semibold line-clamp-1">{itemArtist}</p>
            {!isVideo && song && (
              <div className="flex flex-wrap items-center gap-2 mt-1.5 text-[11px] font-bold">
                <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-md tabular-nums">
                  <Download className="w-3 h-3 text-emerald-600" />
                  {(song.downloadsCount || 0).toLocaleString()} {(song.downloadsCount || 0) === 1 ? 'download' : 'downloads'}
                </span>
                <span className="inline-flex items-center gap-1 text-red-600 bg-red-50 px-1.5 py-0.5 rounded-md tabular-nums">
                  <Heart className="w-3 h-3 fill-red-500 text-red-500" />
                  {(song.likes || 0).toLocaleString()}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Direct Share Link */}
        <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-xl border border-slate-200 mb-4">
          <input
            type="text"
            readOnly
            value={shareUrl}
            onFocus={(e) => e.currentTarget.select()}
            aria-label="Share URL"
            className="w-full bg-transparent text-xs text-slate-700 font-medium focus:outline-none select-all px-1"
          />
          <button
            onClick={handleCopy}
            className="px-3 py-1.5 bg-[#0072ce] hover:bg-blue-700 text-white text-xs font-bold rounded-lg shrink-0 flex items-center gap-1 transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        {/* Social Platform Share Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-3">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#1ebe5d] text-white text-xs font-bold shadow-xs transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>WhatsApp</span>
          </a>

          <a
            href={facebookHref}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-[#1877F2] hover:bg-[#1466d2] text-white text-xs font-bold shadow-xs transition-colors"
          >
            <Share2 className="w-4 h-4" />
            <span>Facebook</span>
          </a>

          <a
            href={telegramHref}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-[#229ED9] hover:bg-[#1c8bc0] text-white text-xs font-bold shadow-xs transition-colors"
          >
            <Send className="w-4 h-4" />
            <span>Telegram</span>
          </a>

          <a
            href={messengerHref}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-[#0084FF] hover:bg-[#0073e0] text-white text-xs font-bold shadow-xs transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Messenger</span>
          </a>

          <a
            href={twitterHref}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-xs transition-colors"
          >
            <Share2 className="w-4 h-4" />
            <span>X / Twitter</span>
          </a>

          {typeof navigator !== 'undefined' && typeof navigator.share === 'function' ? (
            <button
              type="button"
              onClick={handleNativeShare}
              className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 text-xs font-black shadow-xs transition-colors cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
              <span>More Apps</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors cursor-pointer"
            >
              <Copy className="w-4 h-4" />
              <span>Copy Link</span>
            </button>
          )}
        </div>

        <p className="text-[11px] text-slate-400">
          Links include full cover artwork preview on WhatsApp, Facebook & Telegram!
        </p>
      </div>
    </div>
  );
};

// --- Song Details & Public Stats Modal ---
interface SongDetailsModalProps {
  song: Song | null;
  isCurrentPlaying?: boolean;
  isLiked?: boolean;
  isDownloading?: boolean;
  onClose: () => void;
  onPlaySong: (song: Song) => void;
  onDownloadSong: (song: Song) => void;
  onLikeSong: (songId: string) => void;
  onShareSong: (song: Song) => void;
  onOpenComments?: (song: Song) => void;
  onViewArtist: (artistName: string) => void;
  onSelectGenre?: (genre: string) => void;
}

export const SongDetailsModal: React.FC<SongDetailsModalProps> = ({
  song,
  isCurrentPlaying = false,
  isLiked = false,
  isDownloading = false,
  onClose,
  onPlaySong,
  onDownloadSong,
  onLikeSong,
  onShareSong,
  onOpenComments,
  onViewArtist,
  onSelectGenre,
}) => {
  if (!song) return null;

  const downloads = Math.max(0, song.downloadsCount || 0);
  const likes = Math.max(0, song.likes || 0);
  const plays = Math.max(0, song.plays || 0);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-md bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          aria-label="Close Song Details"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Artwork + Core Info */}
        <div className="flex items-start gap-4 pr-8 mb-5">
          <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden shrink-0 shadow-md border border-slate-100 bg-slate-100">
            <img
              src={song.coverUrl || HERO_ASSETS.announcement}
              alt={song.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = HERO_ASSETS.announcement;
              }}
            />
          </div>
          <div className="min-w-0 flex-1">
            <a
              href={getGenreSeoPath(song.genre || 'Afrobeat')}
              onClick={(e) => {
                if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
                if (onSelectGenre) {
                  e.preventDefault();
                  onClose();
                  onSelectGenre(song.genre || 'Afrobeat');
                }
              }}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-50 text-[#0072ce] hover:bg-blue-100 text-[10px] font-black uppercase tracking-wider mb-1 transition-colors"
            >
              <Music2 className="w-3 h-3" />
              {song.genre || 'Afrobeat'}
            </a>
            <h3 className="text-base sm:text-lg font-black text-slate-900 leading-snug break-words">
              <a
                href={getSongSeoPath(song.id)}
                onClick={(e) => {
                  if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
                  e.preventDefault();
                  onPlaySong(song);
                }}
                className="hover:text-[#0072ce] transition-colors"
              >
                {song.title}
              </a>
            </h3>
            <a
              href={getArtistSeoPath(song.artist)}
              onClick={(e) => {
                if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
                e.preventDefault();
                onClose();
                onViewArtist(song.artist);
              }}
              className="inline-block text-xs sm:text-sm text-[#0072ce] hover:underline font-bold mt-0.5 cursor-pointer text-left"
            >
              {song.artist}
            </a>
            <div className="flex flex-wrap items-center gap-2 mt-1.5 text-[11px] text-slate-500 font-medium">
              {song.duration && (
                <span className="inline-flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  {song.duration}
                </span>
              )}
              {song.createdAt && (
                <>
                  <span>•</span>
                  <span>Released {new Date(song.createdAt).toLocaleDateString()}</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Live Public Statistics Grid */}
        <div className="grid grid-cols-3 gap-2.5 mb-5">
          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200/70 text-center">
            <div className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-emerald-600 text-white mb-1 shadow-xs">
              <Download className="w-3.5 h-3.5" />
            </div>
            <div className="text-base sm:text-lg font-black text-emerald-900 tabular-nums leading-tight">
              {downloads.toLocaleString()}
            </div>
            <div className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider">
              {downloads === 1 ? 'Download' : 'Downloads'}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-red-50 border border-red-100 text-center">
            <div className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-red-500 text-white mb-1 shadow-xs">
              <Heart className="w-3.5 h-3.5 fill-current" />
            </div>
            <div className="text-base sm:text-lg font-black text-slate-900 tabular-nums leading-tight">
              {likes.toLocaleString()}
            </div>
            <div className="text-[10px] font-bold text-red-600 uppercase tracking-wider">
              {likes === 1 ? 'Like' : 'Likes'}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-blue-50 border border-blue-100 text-center">
            <div className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-[#0072ce] text-white mb-1 shadow-xs">
              <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
            </div>
            <div className="text-base sm:text-lg font-black text-slate-900 tabular-nums leading-tight">
              {plays.toLocaleString()}
            </div>
            <div className="text-[10px] font-bold text-[#0072ce] uppercase tracking-wider">
              {plays === 1 ? 'Play' : 'Plays'}
            </div>
          </div>
        </div>

        {song.description && (
          <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 border border-slate-100 rounded-2xl p-3 mb-5">
            {song.description}
          </p>
        )}

        {/* Primary Action Buttons */}
        <div className="grid grid-cols-2 gap-2.5 mb-2.5">
          <button
            type="button"
            onClick={() => onPlaySong(song)}
            className="py-2.5 px-3 bg-[#0072ce] hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            {isCurrentPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>Pause Song</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Play Song</span>
              </>
            )}
          </button>

          <button
            type="button"
            disabled={isDownloading}
            onClick={() => onDownloadSong(song)}
            className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-65"
          >
            {isDownloading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Downloading...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Download MP3 ({formatDownloadCount(downloads)})</span>
              </>
            )}
          </button>
        </div>

        {/* Secondary Engagement Actions */}
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => onLikeSong(song.id)}
            className={`py-2 px-2.5 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              isLiked
                ? 'bg-red-50 border-red-200 text-red-600'
                : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-red-500 text-red-500' : ''}`} />
            <span>{isLiked ? 'Liked' : 'Like'}</span>
          </button>

          {onOpenComments && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenComments(song);
              }}
              className="py-2 px-2.5 rounded-xl text-xs font-bold bg-slate-50 hover:bg-blue-50 border border-slate-200 text-slate-700 hover:text-[#0072ce] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>Comments</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              onClose();
              onShareSong(song);
            }}
            className="py-2 px-2.5 rounded-xl text-xs font-bold bg-slate-50 hover:bg-indigo-50 border border-slate-200 text-slate-700 hover:text-indigo-700 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Share</span>
          </button>
        </div>
      </div>
    </div>
  );
};


