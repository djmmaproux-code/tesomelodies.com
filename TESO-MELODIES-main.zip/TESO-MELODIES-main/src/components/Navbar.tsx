import React, { useState } from 'react';
import { Logo } from './Logo';
import { Search, Home, Menu, X, Music, Video, Users, Newspaper, BarChart2, Info, LogOut, LayoutDashboard, Wallet, ShieldCheck, Download } from 'lucide-react';
import { UserProfile } from '../types/music';
import { isUserAdminEmail } from '../services/adminService';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onOpenLogin: () => void;
  onOpenSignUp: () => void;
  currentUser: UserProfile;
  onLogout: () => void;
  showInstallApp?: boolean;
  onOpenInstallApp?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  searchQuery,
  setSearchQuery,
  onOpenLogin,
  onOpenSignUp,
  currentUser,
  onLogout,
  showInstallApp = false,
  onOpenInstallApp,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isAdmin = Boolean(currentUser.isLoggedIn && isUserAdminEmail(currentUser.email));

  const baseNavLinks = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'music', label: 'Music', icon: Music },
    { id: 'videos', label: 'Videos', icon: Video },
    { id: 'artists', label: 'Artists', icon: Users },
    { id: 'news', label: 'News', icon: Newspaper },
    { id: 'charts', label: 'Charts', icon: BarChart2 },
    { id: 'about', label: 'About', icon: Info },
  ];

  const navLinks = currentUser.isLoggedIn
    ? [
        { id: 'home', label: 'Home', icon: Home },
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'wallet', label: 'Artist Wallet', icon: Wallet },
        ...(isAdmin ? [{ id: 'admin', label: 'Admin Panel', icon: ShieldCheck }] : []),
        { id: 'music', label: 'Music', icon: Music },
        { id: 'videos', label: 'Videos', icon: Video },
        { id: 'artists', label: 'Artists', icon: Users },
        { id: 'news', label: 'News', icon: Newspaper },
        { id: 'charts', label: 'Charts', icon: BarChart2 },
        { id: 'about', label: 'About', icon: Info },
      ]
    : baseNavLinks;

  const handleNavClick = (tabId: string) => {
    setActiveTab(tabId);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="w-full bg-[#034ea2] border-b border-blue-400/25 sticky top-0 z-40 shadow-lg select-none">
      <div className="max-w-[1520px] mx-auto px-3 sm:px-4 lg:px-6 h-[64px] sm:h-[72px] flex items-center justify-between gap-2 sm:gap-4 lg:gap-6">
        
        {/* Left: Responsive Logo */}
        <div className="shrink-0 flex items-center">
          <Logo onClick={() => handleNavClick('home')} size="responsive" />
        </div>

        {/* Center-Left: Search Bar (Desktop / Tablet) */}
        <div className="hidden md:flex flex-1 max-w-[320px] xl:max-w-[400px] relative items-center">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for songs, artists, videos..."
            className="w-full bg-blue-900/50 border border-white/20 text-white placeholder-blue-200/70 text-xs sm:text-sm rounded-full pl-4 sm:pl-5 pr-10 sm:pr-11 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all shadow-inner"
          />
          <button 
            type="button"
            className="absolute right-1.5 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-blue-600/70 hover:bg-blue-500 flex items-center justify-center text-white transition-colors cursor-pointer"
            title="Search"
          >
            <Search className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
          </button>
        </div>

        {/* Center: Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
          {navLinks.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`flex items-center gap-1.5 px-3 xl:px-3.5 py-1.5 text-xs xl:text-sm font-semibold rounded-full transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#0072ce] text-white shadow-sm ring-1 ring-cyan-300/40'
                    : 'text-white/90 hover:text-white hover:bg-white/10'
                }`}
              >
                {Icon && <Icon className="w-3.5 h-3.5" />}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right: Auth Buttons & Hamburger Menu (Exact arrangement from screenshot on mobile) */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
          {currentUser.isLoggedIn ? (
            /* Authenticated User Menu: Replaces login & signup completely */
            <div className="flex items-center gap-1.5 sm:gap-2.5">
              <div className="flex items-center gap-1.5 bg-blue-900/70 border border-blue-400/40 rounded-full py-1 px-2.5 sm:px-3 shadow-inner">
                <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-[#FFCC00] text-slate-950 font-black flex items-center justify-center text-xs shadow-sm shrink-0">
                  {currentUser.name[0]?.toUpperCase() || 'U'}
                </div>
                <span className="text-white text-xs font-bold max-w-[85px] sm:max-w-[130px] truncate">
                  {currentUser.name}
                </span>
              </div>
              <button
                onClick={onLogout}
                className="inline-flex items-center gap-1 px-2.5 sm:px-3 py-1 sm:py-1.5 text-xs font-bold text-blue-100 hover:text-white bg-white/10 hover:bg-white/20 rounded-full border border-white/25 transition-all cursor-pointer whitespace-nowrap"
                title="Log Out of Teso Melodies"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          ) : (
            /* Guest Visitors: Reproduce Mobile Header with Login & Sign Up */
            <>
              {/* Login button (purple outlined glass pill) */}
              <button
                onClick={onOpenLogin}
                className="px-2.5 sm:px-4 py-1 sm:py-1.5 text-xs sm:text-sm font-bold text-white bg-[#5e17eb]/35 hover:bg-[#5e17eb]/60 border border-pink-400/50 rounded-full transition-all shadow-sm hover:shadow active:scale-95 cursor-pointer whitespace-nowrap"
              >
                Login
              </button>

              {/* Sign Up button (bold bright yellow solid pill) */}
              <button
                onClick={onOpenSignUp}
                className="px-2.5 sm:px-4 py-1 sm:py-1.5 text-xs sm:text-sm font-black text-slate-950 bg-[#FFCC00] hover:bg-yellow-400 rounded-full transition-all shadow-md hover:shadow-lg active:scale-95 cursor-pointer whitespace-nowrap"
              >
                Sign Up
              </button>
            </>
          )}

          {/* Mobile hamburger menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 sm:p-2 text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5 sm:w-6 sm:h-6" /> : <Menu className="w-5 h-5 sm:w-6 sm:h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#023373] border-t border-blue-400/20 px-4 py-4 space-y-3 shadow-2xl animate-in slide-in-from-top-2 duration-200">
          
          {/* User profile card inside drawer if logged in */}
          {currentUser.isLoggedIn ? (
            <div className="p-3 bg-blue-900/60 rounded-2xl border border-blue-400/30 flex items-center justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-9 h-9 rounded-full bg-[#FFCC00] text-slate-950 font-black flex items-center justify-center text-sm shrink-0">
                  {currentUser.name[0]?.toUpperCase() || 'U'}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white truncate">{currentUser.name}</div>
                  <div className="text-[10px] text-cyan-200 truncate">{currentUser.email}</div>
                </div>
              </div>
              <button
                onClick={() => {
                  onLogout();
                  setMobileMenuOpen(false);
                }}
                className="px-3 py-1 text-xs font-bold text-red-200 bg-red-950/60 hover:bg-red-900/80 rounded-xl border border-red-500/40"
              >
                Sign Out
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2 pb-1">
              <button
                onClick={() => {
                  onOpenLogin();
                  setMobileMenuOpen(false);
                }}
                className="flex-1 py-2 text-xs font-bold text-white bg-[#5e17eb]/50 border border-pink-400/50 rounded-xl text-center"
              >
                Login to Account
              </button>
              <button
                onClick={() => {
                  onOpenSignUp();
                  setMobileMenuOpen(false);
                }}
                className="flex-1 py-2 text-xs font-black text-slate-950 bg-[#FFCC00] rounded-xl text-center shadow-md"
              >
                Sign Up Free
              </button>
            </div>
          )}

          {/* Mobile search bar */}
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search songs, artists, videos..."
              className="w-full bg-blue-950/70 border border-white/20 text-white placeholder-blue-200 text-xs sm:text-sm rounded-xl pl-4 pr-10 py-2.5 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
            <Search className="w-4 h-4 text-white/70 absolute right-3.5 top-3" />
          </div>

          {/* Navigation Links Grid */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            {navLinks.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-2 px-3 py-2.5 text-xs font-semibold rounded-xl text-left transition-all ${
                    isActive
                      ? 'bg-[#FFCC00] text-slate-950 font-black shadow-md'
                      : 'text-blue-100 hover:text-white hover:bg-white/10 bg-blue-900/40'
                  }`}
                >
                  {Icon && <Icon className="w-4 h-4" />}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Permanent subtle Install App option (hidden when already installed) */}
          {showInstallApp && onOpenInstallApp && (
            <div className="pt-2 border-t border-blue-400/20">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenInstallApp();
                }}
                className="w-full flex items-center justify-center gap-2 px-3 py-2.5 text-xs font-bold rounded-xl text-[#FFCC00] bg-blue-950/70 hover:bg-blue-900/80 border border-[#FFCC00]/35 transition-all cursor-pointer"
              >
                <Download className="w-4 h-4 shrink-0" />
                <span>Install App</span>
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};

