import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Heart,
  Download,
  X,
  Repeat,
  Shuffle,
  MessageCircle,
  Loader2,
} from 'lucide-react';
import { Song } from '../types/music';
import { audioEngine } from '../utils/audioEngine';
import { formatDownloadCount } from '../services/musicService';

interface AudioPlayerProps {
  currentSong: Song | null;
  isPlaying: boolean;
  audioRef: React.RefObject<HTMLAudioElement | null>;
  suppressPauseSyncRef: React.MutableRefObject<boolean>;
  onPlaybackSync: (playing: boolean) => void;
  onPlaybackError?: (message: string) => void;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  onClose: () => void;
  onLike: (songId: string) => void;
  onDownload: (song: Song) => void;
  onOpenComments?: (song: Song) => void;
  isLiked: boolean;
  isDownloading?: boolean;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({
  currentSong,
  isPlaying,
  audioRef,
  suppressPauseSyncRef,
  onPlaybackSync,
  onPlaybackError,
  onTogglePlay,
  onNext,
  onPrev,
  onClose,
  onLike,
  onDownload,
  onOpenComments,
  isLiked,
  isDownloading = false,
}) => {
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [isLooping, setIsLooping] = useState(false);
  const [isBuffering, setIsBuffering] = useState(false);

  const isSeekingRef = useRef(false);
  const pendingSeekValueRef = useRef<number | null>(null);
  const isPlayingRef = useRef(isPlaying);
  isPlayingRef.current = isPlaying;

  const hasRealAudio = Boolean(currentSong?.audioUrl);

  // Sync audio element volume when volume/mute or track changes
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted, currentSong?.id, audioRef]);

  // Reset UI timer and duration state when track changes (never force audio.currentTime = 0 here)
  useEffect(() => {
    setCurrentTime(0);
    setDuration(currentSong?.durationSec || 0);
    setIsBuffering(Boolean(currentSong?.audioUrl && isPlayingRef.current));
    isSeekingRef.current = false;
    pendingSeekValueRef.current = null;
  }, [currentSong?.id]);

  // Handle synthetic audioEngine ONLY when no real audio file is attached
  useEffect(() => {
    if (hasRealAudio || !currentSong) {
      audioEngine.pause();
      return;
    }

    if (isPlaying) {
      audioEngine.playTone(currentSong.audioToneFreq || 440, currentTime, (t) => {
        setCurrentTime(() => {
          if (t >= currentSong.durationSec) {
            if (isLooping) {
              audioEngine.seek(0);
              return 0;
            }
            onNext();
            return 0;
          }
          return t;
        });
      });
    } else {
      audioEngine.pause();
    }

    return () => {
      audioEngine.pause();
    };
  }, [currentSong?.id, isPlaying, isLooping, hasRealAudio]);

  // Commit seek safely when user finishes dragging slider
  const commitSeek = (targetSec: number) => {
    const audio = audioRef.current;
    if (hasRealAudio && audio) {
      const maxDur =
        Number.isFinite(audio.duration) && audio.duration > 0
          ? audio.duration
          : duration || currentSong?.durationSec || 0;
      const clamped = Math.max(0, maxDur > 0 ? Math.min(targetSec, maxDur) : targetSec);
      const shouldKeepPlaying = isPlayingRef.current || !audio.paused;

      setCurrentTime(clamped);
      try {
        if (audio.readyState >= 1) {
          audio.currentTime = clamped;
        } else {
          const onMeta = () => {
            audio.currentTime = clamped;
            audio.removeEventListener('loadedmetadata', onMeta);
          };
          audio.addEventListener('loadedmetadata', onMeta);
        }
        if (shouldKeepPlaying && audio.paused) {
          audio.play().catch(() => {});
        }
      } catch (err) {
        console.warn('Seek error:', err);
      }
    } else {
      setCurrentTime(targetSec);
      audioEngine.seek(targetSec);
    }
  };

  // Global release listener so dragging outside the range input still commits seek
  useEffect(() => {
    const handleGlobalRelease = () => {
      if (isSeekingRef.current) {
        isSeekingRef.current = false;
        const target = pendingSeekValueRef.current;
        pendingSeekValueRef.current = null;
        if (target !== null) {
          commitSeek(target);
        }
      }
    };
    window.addEventListener('pointerup', handleGlobalRelease);
    window.addEventListener('touchend', handleGlobalRelease);
    return () => {
      window.removeEventListener('pointerup', handleGlobalRelease);
      window.removeEventListener('touchend', handleGlobalRelease);
    };
  }, [hasRealAudio, duration, currentSong?.durationSec]);

  const formatTime = (secs: number) => {
    if (!Number.isFinite(secs) || secs < 0) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    pendingSeekValueRef.current = val;
    setCurrentTime(val);
    if (!isSeekingRef.current) {
      commitSeek(val);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setVolume(val);
    setIsMuted(val === 0);
    if (hasRealAudio && audioRef.current) {
      audioRef.current.volume = val;
    } else {
      audioEngine.setVolume(val);
    }
  };

  const toggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      const newVol = volume || 0.8;
      if (hasRealAudio && audioRef.current) {
        audioRef.current.volume = newVol;
      } else {
        audioEngine.setVolume(newVol);
      }
    } else {
      setIsMuted(true);
      if (hasRealAudio && audioRef.current) {
        audioRef.current.volume = 0;
      } else {
        audioEngine.setVolume(0);
      }
    }
  };

  const effectiveDuration =
    Number.isFinite(duration) && duration > 0
      ? duration
      : currentSong?.durationSec || 200;
  const sliderValue = Math.min(effectiveDuration, Math.max(0, currentTime));

  return (
    <>
      {/* Always-mounted persistent HTML5 audio element so play() runs synchronously inside user gestures */}
      <audio
        ref={audioRef}
        preload="auto"
        loop={isLooping}
        onLoadStart={() => {
          if (currentSong?.audioUrl && isPlayingRef.current) {
            setIsBuffering(true);
          }
        }}
        onLoadedMetadata={() => {
          const audio = audioRef.current;
          if (audio && Number.isFinite(audio.duration) && audio.duration > 0) {
            setDuration(audio.duration);
          }
        }}
        onDurationChange={() => {
          const audio = audioRef.current;
          if (audio && Number.isFinite(audio.duration) && audio.duration > 0) {
            setDuration(audio.duration);
          }
        }}
        onCanPlay={() => {
          setIsBuffering(false);
        }}
        onPlay={() => {
          suppressPauseSyncRef.current = false;
          if (currentSong?.audioUrl) {
            onPlaybackSync(true);
          }
        }}
        onPlaying={() => {
          suppressPauseSyncRef.current = false;
          setIsBuffering(false);
          if (currentSong?.audioUrl) {
            onPlaybackSync(true);
          }
        }}
        onWaiting={() => {
          if (currentSong?.audioUrl && isPlayingRef.current) {
            setIsBuffering(true);
          }
        }}
        onPause={() => {
          setIsBuffering(false);
          const audio = audioRef.current;
          if (
            !suppressPauseSyncRef.current &&
            audio &&
            audio.paused &&
            !audio.ended &&
            currentSong?.audioUrl
          ) {
            onPlaybackSync(false);
          }
        }}
        onTimeUpdate={() => {
          const audio = audioRef.current;
          if (audio && !isSeekingRef.current) {
            const t = audio.currentTime;
            if (Number.isFinite(t)) {
              setCurrentTime(t);
              if (t > 0) {
                setIsBuffering(false);
              }
            }
          }
        }}
        onSeeked={() => {
          const audio = audioRef.current;
          if (audio && !isSeekingRef.current) {
            if (Number.isFinite(audio.currentTime)) {
              setCurrentTime(audio.currentTime);
            }
            setIsBuffering(false);
            if (isPlayingRef.current && audio.paused && !audio.ended) {
              audio.play().catch(() => {});
            }
          }
        }}
        onEnded={() => {
          setIsBuffering(false);
          if (!isLooping) {
            onNext();
          }
        }}
        onError={(e) => {
          if (!currentSong?.audioUrl) return;
          suppressPauseSyncRef.current = false;
          setIsBuffering(false);
          onPlaybackSync(false);
          const err = e.currentTarget.error;
          const code = err?.code;
          const reasonMap: Record<number, string> = {
            1: 'aborted',
            2: 'network',
            3: 'decode',
            4: 'src not supported',
          };
          const reason = code ? `${code}: ${reasonMap[code] || 'unknown'}` : 'unknown';
          console.error('HTMLAudioElement playback error:', {
            code,
            message: err?.message,
            src: currentSong.audioUrl,
          });
          onPlaybackError?.(`Unable to stream this track right now (Error code ${reason}).`);
        }}
      />

      {currentSong && (
        <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#021b44]/95 backdrop-blur-xl border-t border-blue-400/30 text-white shadow-2xl py-2.5 px-4 sm:px-6 transition-all duration-300">
          <div className="max-w-[1520px] mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
            {/* Left: Track Information */}
            <div className="flex items-center gap-2.5 sm:gap-3 w-full md:w-1/4 min-w-0">
              <div className="relative w-10 h-10 sm:w-12 sm:h-12 rounded-xl overflow-hidden shrink-0 shadow-md ring-2 ring-yellow-400/40">
                <img
                  src={currentSong.coverUrl}
                  alt={currentSong.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src =
                      'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80';
                  }}
                />
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="text-xs sm:text-sm font-bold text-white truncate leading-tight">
                  {currentSong.title}
                </h4>
                <p className="text-[11px] sm:text-xs text-blue-200/80 truncate font-medium">
                  {currentSong.artist}
                </p>
              </div>
              {/* Action buttons */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => onLike(currentSong.id)}
                  className="p-1 sm:p-1.5 text-blue-300 hover:text-red-400 transition-colors cursor-pointer"
                  title={isLiked ? 'Unlike' : 'Like'}
                >
                  <Heart className={`w-4 h-4 ${isLiked ? 'fill-red-500 text-red-500' : ''}`} />
                </button>
                {onOpenComments && (
                  <button
                    onClick={() => onOpenComments(currentSong)}
                    className="p-1 sm:p-1.5 text-blue-300 hover:text-[#FFCC00] transition-colors cursor-pointer"
                    title="Reviews & Comments"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => onDownload(currentSong)}
                  disabled={isDownloading}
                  className="inline-flex items-center gap-1 px-1.5 py-1 sm:px-2 sm:py-1 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 hover:text-emerald-200 transition-colors cursor-pointer disabled:opacity-60"
                  title={`Download MP3 • ${(currentSong.downloadsCount || 0).toLocaleString()} ${(currentSong.downloadsCount || 0) === 1 ? 'download' : 'downloads'}`}
                >
                  {isDownloading ? (
                    <Loader2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 animate-spin" />
                  ) : (
                    <Download className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  )}
                  <span className="text-[10px] sm:text-[11px] font-bold tabular-nums">
                    {formatDownloadCount(currentSong.downloadsCount || 0)}
                  </span>
                </button>
                {/* Mobile close button */}
                <button
                  onClick={onClose}
                  className="md:hidden p-1 text-blue-300 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer ml-1"
                  title="Close Player"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Center: Playback Controls & Progress Bar */}
            <div className="flex flex-col items-center gap-1.5 w-full md:w-2/4">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setIsLooping(!isLooping)}
                  className={`p-1.5 rounded-full transition-colors cursor-pointer ${
                    isLooping ? 'text-yellow-400' : 'text-blue-300 hover:text-white'
                  }`}
                  title="Repeat Track"
                >
                  <Repeat className="w-4 h-4" />
                </button>

                <button
                  onClick={onPrev}
                  className="p-1.5 text-blue-200 hover:text-white transition-colors cursor-pointer"
                  title="Previous"
                >
                  <SkipBack className="w-4 h-4" />
                </button>

                <button
                  onClick={onTogglePlay}
                  className="w-10 h-10 rounded-full bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 flex items-center justify-center shadow-lg transition-transform active:scale-95 cursor-pointer font-bold"
                  title={isPlaying ? 'Pause' : 'Play'}
                >
                  {isBuffering && isPlaying ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : isPlaying ? (
                    <Pause className="w-5 h-5 fill-current" />
                  ) : (
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  )}
                </button>

                <button
                  onClick={onNext}
                  className="p-1.5 text-blue-200 hover:text-white transition-colors cursor-pointer"
                  title="Next"
                >
                  <SkipForward className="w-4 h-4" />
                </button>

                <button
                  onClick={onNext}
                  className="p-1.5 text-blue-300 hover:text-white transition-colors cursor-pointer"
                  title="Shuffle"
                >
                  <Shuffle className="w-4 h-4" />
                </button>
              </div>

              {/* Scrub bar */}
              <div className="w-full flex items-center gap-3 text-xs font-semibold text-blue-200 tabular-nums">
                <span className="w-10 text-right">{formatTime(sliderValue)}</span>
                <div className="relative flex-1 flex items-center">
                  <input
                    type="range"
                    min="0"
                    max={effectiveDuration}
                    step="0.5"
                    value={sliderValue}
                    onPointerDown={() => {
                      isSeekingRef.current = true;
                    }}
                    onTouchStart={() => {
                      isSeekingRef.current = true;
                    }}
                    onChange={handleSeekChange}
                    onPointerUp={() => {
                      if (isSeekingRef.current) {
                        isSeekingRef.current = false;
                        const target = pendingSeekValueRef.current;
                        pendingSeekValueRef.current = null;
                        if (target !== null) {
                          commitSeek(target);
                        }
                      }
                    }}
                    onTouchEnd={() => {
                      if (isSeekingRef.current) {
                        isSeekingRef.current = false;
                        const target = pendingSeekValueRef.current;
                        pendingSeekValueRef.current = null;
                        if (target !== null) {
                          commitSeek(target);
                        }
                      }
                    }}
                    className="w-full h-1.5 bg-blue-900/80 rounded-lg appearance-none cursor-pointer accent-[#FFCC00]"
                  />
                </div>
                <span className="w-10 text-left">
                  {duration ? formatTime(duration) : currentSong.duration}
                </span>
              </div>
            </div>

            {/* Right: Volume & Close */}
            <div className="hidden md:flex items-center justify-end gap-3 w-1/4">
              <button
                onClick={toggleMute}
                className="text-blue-200 hover:text-white transition-colors cursor-pointer"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-4 h-4" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-20 h-1.5 bg-blue-900/80 rounded-lg appearance-none cursor-pointer accent-[#FFCC00]"
              />
              <button
                onClick={onClose}
                className="p-1 text-blue-300 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer ml-2"
                title="Close Player"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
