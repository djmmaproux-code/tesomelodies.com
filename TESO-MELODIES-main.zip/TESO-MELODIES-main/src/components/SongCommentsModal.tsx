import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Star,
  Heart,
  MessageCircle,
  CornerDownRight,
  Send,
  Loader2,
  Trash2,
  Edit2,
  Check,
  AlertCircle,
  ThumbsUp,
  Share2,
  Sparkles,
  Music,
  User,
} from 'lucide-react';
import { Song, UserProfile } from '../types/music';
import {
  fetchSongComments,
  addSongComment,
  editSongComment,
  deleteSongComment,
  toggleLikeComment,
  SongComment,
} from '../services/commentsService';
import { getOrCreateVisitorId } from '../services/musicService';
import { realtime } from '../services/realtimeService';

interface SongCommentsModalProps {
  song: Song | null;
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onOpenSignUp?: () => void;
}

const QUICK_APPRECIATIONS = [
  '🔥 This song is amazing. Keep making great music!',
  '👏 Big respect to the artist!',
  '❤️ I really enjoyed this song.',
  '🎵 The beat is great. I love this song.',
  '⭐ 10/10 production and vocals!',
  '✨ Pure authentic Teso melodies!',
];

export const SongCommentsModal: React.FC<SongCommentsModalProps> = ({
  song,
  isOpen,
  onClose,
  currentUser,
  onOpenSignUp,
}) => {
  const [comments, setComments] = useState<SongComment[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Form states
  const [commentText, setCommentText] = useState('');
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [visitorName, setVisitorName] = useState('');

  // Reply & Edit states
  const [replyingTo, setReplyingTo] = useState<SongComment | null>(null);
  const [replyText, setReplyText] = useState('');
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [editRating, setEditRating] = useState<number>(5);

  // Sorting
  const [sortBy, setSortBy] = useState<'newest' | 'most_liked' | 'highest_rated'>('newest');

  const visitorId = useMemo(() => getOrCreateVisitorId(), []);

  // Load comments whenever modal opens or song changes
  useEffect(() => {
    if (!isOpen || !song) return;

    let isMounted = true;
    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    setReplyingTo(null);
    setEditingCommentId(null);

    fetchSongComments(song.id)
      .then((data) => {
        if (isMounted) {
          setComments(data);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          console.error('Error fetching comments:', err);
          setLoading(false);
        }
      });

    const unsubscribeRealtime = realtime.onComment((evt) => {
      if (!isMounted || !song || String(evt.songId) !== String(song.id)) return;
      if (evt.action === 'create' && evt.comment) {
        setComments((prev) => {
          if (prev.some((c) => c.id === evt.comment.id)) return prev;
          return [evt.comment, ...prev];
        });
      } else if (evt.action === 'delete' && evt.commentId) {
        setComments((prev) =>
          prev.filter((c) => c.id !== evt.commentId && c.replyToId !== evt.commentId)
        );
      } else if (evt.action === 'like' && evt.commentId && evt.comment) {
        setComments((prev) =>
          prev.map((c) =>
            c.id === evt.commentId
              ? { ...c, likes: evt.comment.likes, likedBy: evt.comment.likedBy }
              : c
          )
        );
      } else if (evt.action === 'update' && evt.comment) {
        setComments((prev) =>
          prev.map((c) => (c.id === evt.comment.id ? { ...c, ...evt.comment } : c))
        );
      }
    });

    return () => {
      isMounted = false;
      unsubscribeRealtime();
    };
  }, [isOpen, song?.id]);

  // Compute rating and comment summary
  const summary = useMemo(() => {
    const total = comments.length;
    const rated = comments.filter((c) => c.rating > 0);
    const avg =
      rated.length > 0
        ? Number((rated.reduce((acc, c) => acc + c.rating, 0) / rated.length).toFixed(1))
        : 5.0;
    return {
      total,
      ratedCount: rated.length,
      average: avg,
    };
  }, [comments]);

  // Sort comments
  const sortedComments = useMemo(() => {
    const list = [...comments];
    if (sortBy === 'most_liked') {
      return list.sort((a, b) => (b.likes || 0) - (a.likes || 0) || new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
    if (sortBy === 'highest_rated') {
      return list.sort((a, b) => (b.rating || 0) - (a.rating || 0) || new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
    // 'newest' default
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [comments, sortBy]);

  // Organize nested replies
  const topLevelComments = useMemo(() => {
    return sortedComments.filter((c) => !c.replyToId);
  }, [sortedComments]);

  const getRepliesFor = (commentId: string) => {
    return sortedComments.filter((c) => c.replyToId === commentId);
  };

  if (!isOpen || !song) return null;

  // Handle comment submit
  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!commentText.trim()) {
      setErrorMsg('Please write a message to encourage the artist.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await addSongComment({
        songId: song.id,
        songTitle: song.title,
        artistName: song.artist,
        content: commentText.trim(),
        rating: rating,
        user: currentUser,
        visitorName: visitorName.trim() || undefined,
      });

      if (res.success && res.comment) {
        setComments((prev) => [res.comment!, ...prev]);
        setCommentText('');
        setSuccessMsg('Your review and appreciation have been posted! Thank you for supporting the artist.');
        setTimeout(() => setSuccessMsg(null), 4500);
      } else {
        setErrorMsg(res.error || 'Failed to post comment. Please try again.');
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Unexpected error submitting comment.');
    } finally {
      setSubmitting(false);
    }
  };

  // Handle reply submit
  const handleSubmitReply = async (parentComment: SongComment) => {
    if (!replyText.trim()) return;

    setSubmitting(true);
    try {
      const res = await addSongComment({
        songId: song.id,
        songTitle: song.title,
        artistName: song.artist,
        content: replyText.trim(),
        rating: 0,
        user: currentUser,
        visitorName: visitorName.trim() || undefined,
        replyToId: parentComment.id,
        replyToUserName: parentComment.userName,
      });

      if (res.success && res.comment) {
        setComments((prev) => [res.comment!, ...prev]);
        setReplyText('');
        setReplyingTo(null);
        setSuccessMsg(`Reply to ${parentComment.userName} posted!`);
        setTimeout(() => setSuccessMsg(null), 3500);
      }
    } finally {
      setSubmitting(false);
    }
  };

  // Handle like comment
  const handleLikeComment = async (commentId: string) => {
    const res = await toggleLikeComment(commentId, song.id, visitorId);
    if (res.success) {
      setComments((prev) =>
        prev.map((c) => {
          if (c.id === commentId) {
            const likedBy = Array.isArray(c.likedBy) ? [...c.likedBy] : [];
            const updatedLikedBy = res.isLiked
              ? [...likedBy, visitorId]
              : likedBy.filter((id) => id !== visitorId);
            return { ...c, likes: res.likes, likedBy: updatedLikedBy };
          }
          return c;
        })
      );
    }
  };

  // Handle save edit
  const handleSaveEdit = async (commentId: string) => {
    if (!editText.trim()) return;

    const res = await editSongComment({
      commentId,
      songId: song.id,
      content: editText.trim(),
      rating: editRating,
      user: currentUser,
    });

    if (res.success && res.comment) {
      setComments((prev) => prev.map((c) => (c.id === commentId ? res.comment! : c)));
      setEditingCommentId(null);
      setSuccessMsg('Comment updated successfully.');
      setTimeout(() => setSuccessMsg(null), 3000);
    } else {
      setErrorMsg(res.error || 'Failed to edit comment.');
    }
  };

  // Handle delete comment
  const handleDeleteComment = async (commentId: string) => {
    if (!window.confirm('Delete this comment permanently?')) return;

    const res = await deleteSongComment(commentId, song.id, currentUser);
    if (res.success) {
      setComments((prev) => prev.filter((c) => c.id !== commentId && c.replyToId !== commentId));
      setSuccessMsg('Comment deleted.');
      setTimeout(() => setSuccessMsg(null), 3000);
    } else {
      setErrorMsg(res.error || 'Failed to delete comment.');
    }
  };

  const getRatingDescription = (stars: number) => {
    switch (stars) {
      case 5:
        return 'Masterpiece! ⭐⭐⭐⭐⭐';
      case 4:
        return 'Great track! ⭐⭐⭐⭐';
      case 3:
        return 'Good vibes ⭐⭐⭐';
      case 2:
        return 'Fair ⭐⭐';
      case 1:
        return 'Needs work ⭐';
      default:
        return 'Rate this song';
    }
  };

  const formatDate = (isoString: string) => {
    try {
      const d = new Date(isoString);
      const now = new Date();
      const diffMs = now.getTime() - d.getTime();
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffMins < 1) return 'Just now';
      if (diffMins < 60) return `${diffMins}m ago`;
      if (diffHours < 24) return `${diffHours}h ago`;
      if (diffDays === 1) return 'Yesterday';
      if (diffDays < 7) return `${diffDays}d ago`;
      return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
      return 'Recently';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="bg-white text-slate-900 w-full max-w-2xl max-h-[92vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 1. Modal Header */}
        <div className="bg-gradient-to-r from-[#032b69] to-[#0055d4] p-4 sm:p-5 text-white flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-13 h-13 sm:w-15 sm:h-15 rounded-2xl overflow-hidden bg-slate-800 shrink-0 shadow-md border border-white/20">
              <img
                src={song.coverUrl}
                alt={song.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-yellow-400/20 text-yellow-300 text-[10px] font-bold border border-yellow-400/30">
                  Reviews & Appreciation
                </span>
                <span className="text-white/60 text-xs hidden sm:inline">• {song.genre}</span>
              </div>
              <h3 className="text-base sm:text-lg font-black tracking-tight text-white truncate mt-0.5">
                {song.title}
              </h3>
              <p className="text-xs text-blue-100 font-medium truncate">
                by <strong className="text-white font-bold">{song.artist}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors shrink-0 cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 2. Rating & Review Summary Banner */}
        <div className="bg-blue-50/70 border-b border-blue-100 px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 text-amber-500 font-black text-sm sm:text-base">
              <Star className="w-4 h-4 sm:w-5 sm:h-5 fill-amber-400 text-amber-400" />
              <span>{summary.total > 0 ? summary.average : '5.0'}</span>
            </div>
            <span className="text-slate-400">/ 5.0</span>
            <span className="text-slate-600 font-medium">
              ({summary.total} {summary.total === 1 ? 'review' : 'reviews & comments'})
            </span>
          </div>

          <div className="flex items-center gap-1">
            <span className="text-slate-500 font-medium mr-1">Sort:</span>
            <button
              onClick={() => setSortBy('newest')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                sortBy === 'newest'
                  ? 'bg-[#0072ce] text-white shadow-xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700'
              }`}
            >
              Newest
            </button>
            <button
              onClick={() => setSortBy('most_liked')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                sortBy === 'most_liked'
                  ? 'bg-[#0072ce] text-white shadow-xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700'
              }`}
            >
              Top Liked
            </button>
            <button
              onClick={() => setSortBy('highest_rated')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                sortBy === 'highest_rated'
                  ? 'bg-[#0072ce] text-white shadow-xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700'
              }`}
            >
              Highest Rated
            </button>
          </div>
        </div>

        {/* 3. Scrollable Comments Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* Success / Error alerts */}
          {successMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-2xl flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-2xl flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Quick Encouragement Prompts */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-[#0072ce]" />
              <span>Tap to write quick appreciation</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {QUICK_APPRECIATIONS.map((prompt, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setCommentText(prompt)}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-blue-50 hover:text-[#0072ce] hover:border-blue-200 border border-slate-200/60 rounded-xl text-xs font-medium text-slate-700 transition-all text-left cursor-pointer active:scale-95"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>

          {/* Comment & Rating Submission Box (Guests are prompted to sign in, members submit directly to Supabase) */}
          {!currentUser.isLoggedIn ? (
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50/70 border border-blue-200/80 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#0072ce] text-white flex items-center justify-center shrink-0 shadow-xs">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="text-xs sm:text-sm font-bold text-slate-900">
                    Want to review or appreciate "{song.title}"?
                  </h5>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Sign in or create a free account to rate, leave comments, and reply to listeners.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onOpenSignUp?.()}
                className="px-4 py-2 bg-[#0072ce] hover:bg-[#005fb8] text-white font-bold text-xs rounded-xl shadow-xs transition-transform active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
              >
                Sign In / Join
              </button>
            </div>
          ) : (
            <form
              onSubmit={handleSubmitComment}
              className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-200/70">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-[#0055d4] to-yellow-400 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                    {currentUser.avatar ? (
                      <img
                        src={currentUser.avatar}
                        alt={currentUser.name}
                        className="w-full h-full object-cover rounded-full"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      (currentUser.stageName || currentUser.name || 'U').charAt(0).toUpperCase()
                    )}
                  </div>
                  <span className="text-xs font-bold text-slate-800">
                    Reviewing as{' '}
                    <span className="text-[#0072ce]">
                      {currentUser.stageName || currentUser.name}
                    </span>
                  </span>
                </div>

                {/* Interactive 5-Star Rating Selector */}
                <div className="flex items-center gap-1.5 self-start sm:self-auto">
                  <span className="text-[11px] font-bold text-slate-500">Your Rating:</span>
                  <div className="flex items-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((starVal) => {
                      const isFilled =
                        hoverRating !== null ? starVal <= hoverRating : starVal <= rating;
                      return (
                        <button
                          key={starVal}
                          type="button"
                          onMouseEnter={() => setHoverRating(starVal)}
                          onMouseLeave={() => setHoverRating(null)}
                          onClick={() => setRating(starVal)}
                          className="p-0.5 text-amber-400 hover:scale-115 transition-transform cursor-pointer"
                          title={`${starVal} Star${starVal > 1 ? 's' : ''}`}
                        >
                          <Star
                            className={`w-4 h-4 sm:w-5 sm:h-5 ${
                              isFilled ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                            }`}
                          />
                        </button>
                      );
                    })}
                  </div>
                  <span className="text-[10px] text-slate-500 font-semibold hidden md:inline ml-1">
                    {getRatingDescription(hoverRating || rating)}
                  </span>
                </div>
              </div>

              {/* Comment Textarea */}
              <div>
                <textarea
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder={`What do you think of "${song.title}"? Share your appreciation, favorite lyrics, or thoughts with the artist...`}
                  rows={3}
                  className="w-full bg-white border border-slate-200 rounded-xl p-3 text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0072ce] focus:border-transparent transition-all resize-none"
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-slate-400">
                  {commentText.length} characters • Authentic artist encouragement
                </span>
                <button
                  type="submit"
                  disabled={submitting || !commentText.trim()}
                  className="px-4 py-2 bg-[#0072ce] hover:bg-[#005fb8] disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Posting...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Submit Review</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* Comments List Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h4 className="text-sm font-black text-[#032b69] flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#0072ce]" />
                <span>Comments & Reviews ({comments.length})</span>
              </h4>
              <span className="text-xs text-slate-400 font-medium">Real Listener Feedback</span>
            </div>

            {loading ? (
              <div className="py-12 flex flex-col items-center justify-center gap-2 text-slate-400">
                <Loader2 className="w-6 h-6 animate-spin text-[#0072ce]" />
                <span className="text-xs font-medium">Loading reviews...</span>
              </div>
            ) : topLevelComments.length === 0 ? (
              <div className="py-12 px-4 text-center rounded-2xl bg-slate-50 border border-dashed border-slate-200 flex flex-col items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-blue-50 text-[#0072ce] flex items-center justify-center mb-2 shadow-xs">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <h5 className="text-sm font-bold text-slate-800">No reviews yet</h5>
                <p className="text-xs text-slate-500 mt-1 max-w-sm">
                  Be the very first listener to review <strong className="text-slate-700">"{song.title}"</strong> and show your appreciation to <strong className="text-slate-700">{song.artist}</strong>!
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {topLevelComments.map((comment) => {
                  const isAuthor =
                    (currentUser.isLoggedIn && (currentUser.id === comment.userId || currentUser.email === comment.userEmail)) ||
                    (!comment.userId && !comment.userEmail);
                  const isAdmin = currentUser.email?.toLowerCase() === 'tesomelodies@gmail.com';
                  const canManage = isAuthor || isAdmin;
                  const isCommentLiked = comment.likedBy?.includes(visitorId);
                  const isEditing = editingCommentId === comment.id;
                  const replies = getRepliesFor(comment.id);

                  return (
                    <div
                      key={comment.id}
                      className="p-3.5 sm:p-4 rounded-2xl bg-white border border-slate-100 shadow-xs hover:border-slate-200 transition-all space-y-2.5"
                    >
                      {/* Comment Header: Author, Rating, Date, Manage Actions */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#0055d4] to-yellow-400 text-white flex items-center justify-center font-bold text-xs shadow-xs shrink-0">
                            {comment.userAvatar ? (
                              <img
                                src={comment.userAvatar}
                                alt={comment.userName}
                                className="w-full h-full object-cover rounded-full"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              comment.userName.charAt(0).toUpperCase()
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-xs font-bold text-slate-900">
                                {comment.userName}
                              </span>
                              {comment.userEmail?.toLowerCase() === 'tesomelodies@gmail.com' && (
                                <span className="px-1.5 py-0.2 bg-blue-100 text-[#0072ce] text-[9px] font-black rounded-md">
                                  Official
                                </span>
                              )}
                              <span className="text-slate-300">•</span>
                              <span className="text-[11px] text-slate-400">
                                {formatDate(comment.createdAt)}
                              </span>
                            </div>

                            {/* Star Rating Badge */}
                            {comment.rating > 0 && (
                              <div className="flex items-center gap-1 mt-0.5">
                                <div className="flex items-center">
                                  {[1, 2, 3, 4, 5].map((s) => (
                                    <Star
                                      key={s}
                                      className={`w-3 h-3 ${
                                        s <= comment.rating
                                          ? 'fill-amber-400 text-amber-400'
                                          : 'text-slate-200'
                                      }`}
                                    />
                                  ))}
                                </div>
                                <span className="text-[10px] text-amber-600 font-bold">
                                  {comment.rating}.0
                                </span>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Edit / Delete actions for author or admin */}
                        {canManage && (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                setEditingCommentId(comment.id);
                                setEditText(comment.content);
                                setEditRating(comment.rating || 5);
                              }}
                              className="p-1 text-slate-400 hover:text-[#0072ce] rounded-md hover:bg-slate-50 transition-colors cursor-pointer"
                              title="Edit comment"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteComment(comment.id)}
                              className="p-1 text-slate-400 hover:text-red-600 rounded-md hover:bg-red-50 transition-colors cursor-pointer"
                              title="Delete comment"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Comment Body or Inline Editor */}
                      {isEditing ? (
                        <div className="space-y-2 pt-1">
                          <textarea
                            value={editText}
                            onChange={(e) => setEditText(e.target.value)}
                            rows={2}
                            className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1">
                              <span className="text-[11px] text-slate-500 font-bold">Rating:</span>
                              {[1, 2, 3, 4, 5].map((s) => (
                                <button
                                  key={s}
                                  type="button"
                                  onClick={() => setEditRating(s)}
                                  className="text-amber-400 cursor-pointer"
                                >
                                  <Star
                                    className={`w-3.5 h-3.5 ${
                                      s <= editRating ? 'fill-amber-400' : 'text-slate-200'
                                    }`}
                                  />
                                </button>
                              ))}
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => setEditingCommentId(null)}
                                className="px-2.5 py-1 text-xs text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                              >
                                Cancel
                              </button>
                              <button
                                onClick={() => handleSaveEdit(comment.id)}
                                className="px-3 py-1 bg-[#0072ce] text-white text-xs font-bold rounded-lg cursor-pointer"
                              >
                                Save Changes
                              </button>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <p className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                          {comment.content}
                        </p>
                      )}

                      {/* Footer Actions: Like, Reply */}
                      <div className="flex items-center justify-between pt-1 text-xs text-slate-500 border-t border-slate-50">
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => handleLikeComment(comment.id)}
                            className={`flex items-center gap-1 py-1 px-2 rounded-lg font-bold text-xs transition-colors cursor-pointer ${
                              isCommentLiked
                                ? 'text-red-600 bg-red-50 hover:bg-red-100'
                                : 'text-slate-500 hover:text-red-500 hover:bg-slate-50'
                            }`}
                            title="Appreciate this review"
                          >
                            <Heart
                              className={`w-3.5 h-3.5 ${
                                isCommentLiked ? 'fill-red-500 text-red-500' : 'text-slate-400'
                              }`}
                            />
                            <span>{comment.likes || 0}</span>
                          </button>

                          <button
                            onClick={() => {
                              if (!currentUser.isLoggedIn) {
                                setErrorMsg('Please sign in or create an account to reply to comments.');
                                onOpenSignUp?.();
                                return;
                              }
                              setReplyingTo(replyingTo?.id === comment.id ? null : comment);
                              setReplyText('');
                            }}
                            className="flex items-center gap-1 py-1 px-2 text-slate-500 hover:text-[#0072ce] hover:bg-blue-50 rounded-lg transition-colors cursor-pointer font-medium text-xs"
                          >
                            <CornerDownRight className="w-3.5 h-3.5" />
                            <span>Reply</span>
                          </button>
                        </div>

                        {/* Reply count badge */}
                        {replies.length > 0 && (
                          <span className="text-[10px] font-bold text-[#0072ce] bg-blue-50 px-2 py-0.5 rounded-full">
                            {replies.length} {replies.length === 1 ? 'reply' : 'replies'}
                          </span>
                        )}
                      </div>

                      {/* Inline Reply Input Box */}
                      {replyingTo?.id === comment.id && (
                        <div className="mt-2 pl-4 border-l-2 border-blue-400 space-y-2 pt-1 animate-in fade-in">
                          <div className="flex items-center justify-between text-xs text-slate-600 font-medium">
                            <span>
                              Replying to <strong className="text-[#0072ce]">{comment.userName}</strong>
                            </span>
                            <button
                              onClick={() => setReplyingTo(null)}
                              className="text-slate-400 hover:text-slate-600 cursor-pointer"
                            >
                              Cancel
                            </button>
                          </div>
                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              value={replyText}
                              onChange={(e) => setReplyText(e.target.value)}
                              placeholder={`Reply to ${comment.userName}...`}
                              className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  handleSubmitReply(comment);
                                }
                              }}
                            />
                            <button
                              type="button"
                              onClick={() => handleSubmitReply(comment)}
                              disabled={submitting || !replyText.trim()}
                              className="px-3 py-1.5 bg-[#0072ce] text-white rounded-xl text-xs font-bold hover:bg-[#005fb8] disabled:bg-slate-200 cursor-pointer flex items-center gap-1"
                            >
                              <Send className="w-3 h-3" />
                              <span>Reply</span>
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Nested Replies */}
                      {replies.length > 0 && (
                        <div className="mt-3 pl-4 sm:pl-6 border-l-2 border-blue-100 space-y-2.5">
                          {replies.map((reply) => {
                            const isReplyLiked = reply.likedBy?.includes(visitorId);
                            const canManageReply =
                              (currentUser.isLoggedIn && (currentUser.id === reply.userId || currentUser.email === reply.userEmail)) ||
                              isAdmin;

                            return (
                              <div
                                key={reply.id}
                                className="bg-slate-50/80 p-2.5 sm:p-3 rounded-xl border border-slate-100 space-y-1.5"
                              >
                                <div className="flex items-center justify-between gap-2">
                                  <div className="flex items-center gap-2">
                                    <div className="w-6 h-6 rounded-full bg-[#0072ce] text-white flex items-center justify-center font-bold text-[10px]">
                                      {reply.userName.charAt(0).toUpperCase()}
                                    </div>
                                    <span className="text-xs font-bold text-slate-800">
                                      {reply.userName}
                                    </span>
                                    <span className="text-slate-300">•</span>
                                    <span className="text-[10px] text-slate-400">
                                      {formatDate(reply.createdAt)}
                                    </span>
                                  </div>

                                  {canManageReply && (
                                    <button
                                      onClick={() => handleDeleteComment(reply.id)}
                                      className="p-1 text-slate-400 hover:text-red-600 rounded transition-colors cursor-pointer"
                                      title="Delete reply"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </button>
                                  )}
                                </div>

                                <p className="text-xs text-slate-700 leading-relaxed">
                                  {reply.content}
                                </p>

                                <div className="flex items-center gap-2 pt-0.5 text-[11px] text-slate-400">
                                  <button
                                    onClick={() => handleLikeComment(reply.id)}
                                    className={`flex items-center gap-1 py-0.5 px-1.5 rounded cursor-pointer ${
                                      isReplyLiked ? 'text-red-500 font-bold' : 'hover:text-red-500'
                                    }`}
                                  >
                                    <Heart
                                      className={`w-3 h-3 ${isReplyLiked ? 'fill-red-500' : ''}`}
                                    />
                                    <span>{reply.likes || 0}</span>
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* 4. Modal Footer */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <div className="flex items-center gap-1.5 text-slate-600">
            <Music className="w-3.5 h-3.5 text-[#0072ce]" />
            <span className="font-medium">Teso Melodies Community • Music Unites Us ❤️</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
