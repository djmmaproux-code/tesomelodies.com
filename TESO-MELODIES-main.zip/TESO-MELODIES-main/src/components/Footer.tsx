import React from 'react';
import { Logo } from './Logo';
import { Heart, Download } from 'lucide-react';

interface FooterProps {
  onNavigate?: (tab: string) => void;
  showInstallApp?: boolean;
  onOpenInstallApp?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  showInstallApp = false,
  onOpenInstallApp,
}) => {
  return (
    <footer className="w-full bg-[#051838] border-t border-blue-500/20 text-white mt-12 py-7">
      <div className="max-w-[1520px] mx-auto px-4 lg:px-6">
        
        {/* Main Footer Row */}
        <div className="flex flex-col xl:flex-row items-center justify-between gap-6 pb-4">
          
          {/* Left: Logo */}
          <div className="shrink-0 cursor-pointer" onClick={() => onNavigate?.('home')}>
            <Logo size="md" />
          </div>

          {/* Center-Left: Main Navigation Links */}
          <nav aria-label="Footer Navigation" className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-xs md:text-sm font-semibold text-blue-100/90">
            <a
              href="/music"
              onClick={(e) => {
                if (!e.metaKey && !e.ctrlKey && !e.shiftKey) {
                  e.preventDefault();
                  onNavigate?.('music');
                }
              }}
              className="hover:text-yellow-300 transition-colors cursor-pointer"
            >
              Music
            </a>
            <span className="text-blue-400">•</span>
            <a
              href="/genre/teso-music"
              onClick={(e) => {
                if (!e.metaKey && !e.ctrlKey && !e.shiftKey) {
                  e.preventDefault();
                  onNavigate?.('genre:teso-music');
                }
              }}
              className="hover:text-yellow-300 transition-colors cursor-pointer"
            >
              Teso Music
            </a>
            <span className="text-blue-400">•</span>
            <a
              href="/genre/teso-gospel-music"
              onClick={(e) => {
                if (!e.metaKey && !e.ctrlKey && !e.shiftKey) {
                  e.preventDefault();
                  onNavigate?.('genre:teso-gospel-music');
                }
              }}
              className="hover:text-yellow-300 transition-colors cursor-pointer"
            >
              Teso Gospel
            </a>
            <span className="text-blue-400">•</span>
            <a
              href="/videos"
              onClick={(e) => {
                if (!e.metaKey && !e.ctrlKey && !e.shiftKey) {
                  e.preventDefault();
                  onNavigate?.('videos');
                }
              }}
              className="hover:text-yellow-300 transition-colors cursor-pointer"
            >
              Videos
            </a>
            <span className="text-blue-400">•</span>
            <a
              href="/artists"
              onClick={(e) => {
                if (!e.metaKey && !e.ctrlKey && !e.shiftKey) {
                  e.preventDefault();
                  onNavigate?.('artists');
                }
              }}
              className="hover:text-yellow-300 transition-colors cursor-pointer"
            >
              Artists
            </a>
            <span className="text-blue-400">•</span>
            <a
              href="/news"
              onClick={(e) => {
                if (!e.metaKey && !e.ctrlKey && !e.shiftKey) {
                  e.preventDefault();
                  onNavigate?.('news');
                }
              }}
              className="hover:text-yellow-300 transition-colors cursor-pointer"
            >
              News
            </a>
            <span className="text-blue-400">•</span>
            <a
              href="/about"
              onClick={(e) => {
                if (!e.metaKey && !e.ctrlKey && !e.shiftKey) {
                  e.preventDefault();
                  onNavigate?.('about');
                }
              }}
              className="hover:text-yellow-300 transition-colors cursor-pointer"
            >
              About
            </a>
            <span className="text-blue-400">•</span>
            <a href="tel:0788900047" className="hover:text-yellow-300 transition-colors cursor-pointer">Contact</a>
          </nav>

          {/* Center: Social Icons */}
          <div className="flex flex-wrap items-center justify-center gap-2.5">
            {/* WhatsApp - Message Music Promotion */}
            <a
              href="https://wa.me/256788900047"
              target="_blank"
              rel="noreferrer"
              className="w-8 h-8 rounded-full bg-emerald-600 hover:bg-emerald-500 flex items-center justify-center text-white transition-all hover:scale-110 shadow-sm"
              title="Message Music Promotion on WhatsApp"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
              </svg>
            </a>

            {/* Facebook */}
            <a
              href="https://www.facebook.com/tesomelodies?mibextid=rS40aB7S9Ucbxw6v"
              target="_blank"
              rel="noreferrer"
              className="w-8 h-8 rounded-full bg-blue-600/40 hover:bg-blue-600 flex items-center justify-center text-white transition-all hover:scale-110 shadow-sm"
              title="Facebook @tesomelodies"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
            </a>

            {/* YouTube */}
            <a
              href="https://www.youtube.com/@TESOMELODIES"
              target="_blank"
              rel="noreferrer"
              className="w-8 h-8 rounded-full bg-red-600/40 hover:bg-red-600 flex items-center justify-center text-white transition-all hover:scale-110 shadow-sm"
              title="YouTube @TESOMELODIES"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
              </svg>
            </a>

            {/* TikTok */}
            <a
              href="https://www.tiktok.com/@tesomelodies?_r=1&_t=ZS-9BD66jZ3EBx"
              target="_blank"
              rel="noreferrer"
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-black flex items-center justify-center text-white transition-all hover:scale-110 shadow-sm"
              title="TikTok @tesomelodies"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
              </svg>
            </a>

            {/* Telegram */}
            <a
              href="https://t.me/tesomelodies"
              target="_blank"
              rel="noreferrer"
              className="w-8 h-8 rounded-full bg-sky-500/40 hover:bg-sky-500 flex items-center justify-center text-white transition-all hover:scale-110 shadow-sm"
              title="Telegram t.me/tesomelodies"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
              </svg>
            </a>
          </div>

          {/* Right-Middle: Legal Links */}
          <div className="flex flex-wrap items-center justify-center gap-x-2 text-xs text-blue-200/80 font-medium">
            <a
              href="/terms-and-conditions"
              onClick={(e) => {
                e.preventDefault();
                onNavigate?.('terms-and-conditions');
                window.history.pushState({}, '', '/terms-and-conditions');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-yellow-300 transition-colors cursor-pointer"
            >
              Terms of Service
            </a>
            <span>|</span>
            <a
              href="/privacy-policy"
              onClick={(e) => {
                e.preventDefault();
                onNavigate?.('privacy-policy');
                window.history.pushState({}, '', '/privacy-policy');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-yellow-300 transition-colors cursor-pointer"
            >
              Privacy Policy
            </a>
            <span>|</span>
            <button
              onClick={() => {
                onNavigate?.('about');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Support
            </button>
            <span>|</span>
            <button
              onClick={() => {
                onNavigate?.('artists');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Grow Together
            </button>
            {showInstallApp && onOpenInstallApp && (
              <>
                <span>|</span>
                <button
                  type="button"
                  onClick={onOpenInstallApp}
                  className="inline-flex items-center gap-1 text-[#FFCC00] hover:text-yellow-200 transition-colors cursor-pointer font-semibold"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Install App</span>
                </button>
              </>
            )}
          </div>

          {/* Far Right: Cursive slogan */}
          <div className="font-script text-2xl md:text-3xl text-pink-300 font-bold flex items-center gap-2 select-none">
            <span>Teso Music, Our Pride</span>
            <Heart className="w-5 h-5 text-red-500 fill-red-500 animate-pulse" />
          </div>

        </div>

        {/* Music Promotion & Contact Information Bar */}
        <div className="my-3 py-3 px-4 rounded-2xl bg-gradient-to-r from-blue-900/60 via-[#0a2f6b]/70 to-blue-900/60 border border-blue-400/25 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
            <span className="font-extrabold text-[#FFCC00] uppercase tracking-wider text-[11px]">Music Promotion & Bookings:</span>
          </div>

          <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-blue-100">
            <a
              href="https://wa.me/256788900047"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600/80 hover:bg-emerald-600 text-white font-semibold transition-colors"
            >
              <span>WhatsApp:</span>
              <span className="underline font-bold">+256 788 900047</span>
            </a>

            <a
              href="tel:0752848442"
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-red-600/30 hover:bg-red-600/50 text-red-200 hover:text-white font-semibold transition-colors border border-red-500/30"
            >
              <span className="font-bold text-red-300">Airtel (Show & Calls):</span>
              <span>0752848442</span>
            </a>

            <a
              href="tel:0788900047"
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-yellow-500/20 hover:bg-yellow-500/40 text-yellow-300 hover:text-white font-semibold transition-colors border border-yellow-400/30"
            >
              <span className="font-bold text-yellow-400">MTN:</span>
              <span>0788 900047</span>
            </a>

            <a
              href="https://t.me/tesomelodies"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-600/30 hover:bg-sky-600/50 text-sky-200 hover:text-white font-semibold transition-colors border border-sky-400/30"
            >
              <span>Telegram:</span>
              <span className="underline">t.me/tesomelodies</span>
            </a>
          </div>
        </div>

        {/* Quiet copyright sub-bar */}
        <div className="pt-3 border-t border-white/10 text-center text-[11px] text-blue-300/60 font-medium">
          © {new Date().getFullYear()} TESO MELODIES (TesoMelodies.com). All rights reserved. Music Unites Us.
        </div>

      </div>
    </footer>
  );
};
