import React, { useState } from 'react';
import { X, ShieldCheck, FileText, Save, RotateCcw, Eye, Sparkles, Loader2, Check, AlertCircle } from 'lucide-react';
import { getPrivacyPolicy, getTermsAndConditions, saveLegalDocument, resetLegalDocumentToDefault, LegalDocument } from '../services/legalService';
import { AUTHORIZED_ADMIN_EMAIL } from '../services/adminService';

interface AdminLegalModalProps {
  isOpen: boolean;
  initialDocType?: 'privacy' | 'terms';
  onClose: () => void;
  onPublished?: (docType: 'privacy' | 'terms') => void;
}

export const AdminLegalModal: React.FC<AdminLegalModalProps> = ({
  isOpen,
  initialDocType = 'privacy',
  onClose,
  onPublished,
}) => {
  const [docType, setDocType] = useState<'privacy' | 'terms'>(initialDocType);
  const [document, setDocument] = useState<LegalDocument>(
    initialDocType === 'privacy' ? getPrivacyPolicy() : getTermsAndConditions()
  );
  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState(false);

  // Sync when docType changes
  React.useEffect(() => {
    setDocType(initialDocType);
    setDocument(initialDocType === 'privacy' ? getPrivacyPolicy() : getTermsAndConditions());
    setErrorMsg(null);
    setSuccessMsg(null);
  }, [initialDocType, isOpen]);

  if (!isOpen) return null;

  const handleSwitchTab = (type: 'privacy' | 'terms') => {
    setDocType(type);
    setDocument(type === 'privacy' ? getPrivacyPolicy() : getTermsAndConditions());
    setErrorMsg(null);
    setSuccessMsg(null);
  };

  const handleSectionContentChange = (index: number, newContent: string) => {
    setDocument((prev) => {
      const updated = [...prev.sections];
      updated[index] = { ...updated[index], content: newContent };
      return { ...prev, sections: updated };
    });
  };

  const handleSectionTitleChange = (index: number, newTitle: string) => {
    setDocument((prev) => {
      const updated = [...prev.sections];
      updated[index] = { ...updated[index], title: newTitle };
      return { ...prev, sections: updated };
    });
  };

  const handleSave = async () => {
    setIsSaving(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    const result = await saveLegalDocument(docType, document);
    setIsSaving(false);

    if (result.success) {
      setSuccessMsg(`Successfully published changes to ${document.title}!`);
      onPublished?.(docType);
      setTimeout(() => setSuccessMsg(null), 4000);
    } else {
      setErrorMsg(result.error || 'Failed to publish legal document.');
    }
  };

  const handleReset = async () => {
    if (!window.confirm(`Reset ${document.title} to the official verified default content?`)) {
      return;
    }
    setIsSaving(true);
    await resetLegalDocumentToDefault(docType);
    setDocument(docType === 'privacy' ? getPrivacyPolicy() : getTermsAndConditions());
    setIsSaving(false);
    setSuccessMsg(`Restored official default version for ${document.title}.`);
    onPublished?.(docType);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-gradient-to-b from-[#032b69] via-[#022153] to-[#011433] rounded-3xl p-5 sm:p-7 shadow-2xl border border-blue-400/30 text-white max-h-[92vh] flex flex-col">
        
        {/* Modal Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-blue-200/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4 shrink-0">
          <div className="w-11 h-11 rounded-2xl bg-blue-500/20 text-[#FFCC00] flex items-center justify-center font-bold shadow-inner border border-blue-400/30">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white flex items-center gap-1.5 tracking-tight">
              <span>Admin: Legal Pages Management</span>
              <Sparkles className="w-4 h-4 text-yellow-400" />
            </h3>
            <p className="text-xs text-blue-200/80">
              Authorized Administrator: <span className="text-yellow-300 font-bold">{AUTHORIZED_ADMIN_EMAIL}</span>
            </p>
          </div>
        </div>

        {/* Document Switcher & Preview Toggle */}
        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-blue-400/20 shrink-0">
          <div className="flex items-center gap-1.5 p-1 bg-blue-950/80 rounded-xl border border-blue-400/30">
            <button
              onClick={() => handleSwitchTab('privacy')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                docType === 'privacy'
                  ? 'bg-[#FFCC00] text-slate-950 shadow-sm'
                  : 'text-blue-200 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Privacy Policy</span>
            </button>
            <button
              onClick={() => handleSwitchTab('terms')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                docType === 'terms'
                  ? 'bg-[#FFCC00] text-slate-950 shadow-sm'
                  : 'text-blue-200 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Terms & Conditions</span>
            </button>
            <button
              onClick={() => {
                setDocType('supabase' as any);
                setPreviewMode(false);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                (docType as any) === 'supabase'
                  ? 'bg-[#FFCC00] text-slate-950 shadow-sm'
                  : 'text-blue-200 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>Supabase Database & SQL</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setPreviewMode(!previewMode)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 cursor-pointer ${
                previewMode
                  ? 'bg-yellow-400 text-slate-950 border-yellow-300 font-black'
                  : 'bg-blue-800/50 hover:bg-blue-800/70 text-blue-100 border-blue-400/40'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>{previewMode ? 'Edit Mode' : 'Preview Mode'}</span>
            </button>
            <button
              type="button"
              onClick={handleReset}
              disabled={isSaving}
              className="px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-600 transition-all cursor-pointer flex items-center gap-1.5"
              title="Reset to official default"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset Default</span>
            </button>
          </div>
        </div>

        {/* Feedback messages */}
        {successMsg && (
          <div className="mb-3 p-3 rounded-xl bg-emerald-950/80 border border-emerald-400/50 text-emerald-200 text-xs font-semibold flex items-center gap-2 shrink-0">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}
        {errorMsg && (
          <div className="mb-3 p-3 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs font-semibold flex items-center gap-2 shrink-0">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Modal Body: Editor or Preview */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-4">
          
          {/* Metadata Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-2xl bg-blue-900/40 border border-blue-400/25">
            <div>
              <label className="block text-[11px] font-bold text-blue-200 uppercase tracking-wider mb-1">
                Last Modified Date
              </label>
              <input
                type="text"
                value={document.lastUpdated}
                onChange={(e) => setDocument({ ...document, lastUpdated: e.target.value })}
                disabled={previewMode}
                className="w-full bg-[#032b69] border border-blue-400/40 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-yellow-400 font-semibold"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-blue-200 uppercase tracking-wider mb-1">
                Governing Jurisdiction
              </label>
              <input
                type="text"
                value={document.governingJurisdiction}
                onChange={(e) => setDocument({ ...document, governingJurisdiction: e.target.value })}
                disabled={previewMode}
                className="w-full bg-[#032b69] border border-blue-400/40 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-yellow-400 font-semibold"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-blue-200 uppercase tracking-wider mb-1">
                Contact Email
              </label>
              <input
                type="email"
                value={document.contactEmail}
                onChange={(e) => setDocument({ ...document, contactEmail: e.target.value })}
                disabled={previewMode}
                className="w-full bg-[#032b69] border border-blue-400/40 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-yellow-400 font-semibold"
              />
            </div>
          </div>

          {(docType as any) === 'supabase' ? (
            /* Supabase Database Architecture & SQL Migration */
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-blue-900/50 border border-blue-400/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                    <h4 className="text-sm font-bold text-white">Supabase Cloud Database Connection</h4>
                  </div>
                  <span className="text-[11px] font-mono text-yellow-300 bg-yellow-400/10 px-2 py-0.5 rounded-lg border border-yellow-400/30">
                    csguerwyvykvzlnikwbf
                  </span>
                </div>
                <p className="text-xs text-blue-100 leading-relaxed">
                  Teso Melodies connects directly to your Supabase project. The <code className="text-yellow-300">artist_follows</code> table is active for public follower counts and verified user follow/unfollow actions. To ensure <code className="text-yellow-300">song_comments</code> and social reviews persist across all devices without limits, run the verified SQL migration below in your Supabase SQL editor.
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs">
                  <div className="p-2.5 rounded-xl bg-blue-950/70 border border-blue-400/20">
                    <span className="text-[10px] text-blue-300 uppercase font-bold block">songs</span>
                    <span className="text-emerald-400 font-bold text-xs">Active (35 Tracks)</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-blue-950/70 border border-blue-400/20">
                    <span className="text-[10px] text-blue-300 uppercase font-bold block">artist_follows</span>
                    <span className="text-emerald-400 font-bold text-xs">Active (Public/Auth)</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-blue-950/70 border border-blue-400/20">
                    <span className="text-[10px] text-blue-300 uppercase font-bold block">profiles</span>
                    <span className="text-emerald-400 font-bold text-xs">Active</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-blue-950/70 border border-blue-400/20">
                    <span className="text-[10px] text-blue-300 uppercase font-bold block">song_comments</span>
                    <span className="text-yellow-300 font-bold text-xs">Ready to Run</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-blue-400/20">
                  <span className="text-xs text-blue-200">
                    Click below to copy the full idempotent SQL migration script:
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const sql = `-- TESO MELODIES - SONG COMMENTS & SOCIAL SCHEMA
CREATE TABLE IF NOT EXISTS public.song_comments (
  id TEXT PRIMARY KEY,
  song_id TEXT NOT NULL,
  song_title TEXT,
  artist_name TEXT,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  user_email TEXT,
  user_name TEXT NOT NULL,
  user_avatar TEXT,
  content TEXT NOT NULL,
  rating INTEGER DEFAULT 5,
  likes INTEGER DEFAULT 0 NOT NULL,
  liked_by JSONB DEFAULT '[]'::jsonb,
  reply_to_id TEXT,
  reply_to_user_name TEXT,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.song_comments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view song comments" ON public.song_comments;
CREATE POLICY "Public can view song comments" ON public.song_comments FOR SELECT USING (true);

DROP POLICY IF EXISTS "Anyone can insert song comments" ON public.song_comments;
CREATE POLICY "Anyone can insert song comments" ON public.song_comments FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Anyone can update their own comment" ON public.song_comments;
CREATE POLICY "Anyone can update their own comment" ON public.song_comments FOR UPDATE USING (true);

DROP POLICY IF EXISTS "Public can view artist followers" ON public.artist_follows;
CREATE POLICY "Public can view artist followers" ON public.artist_follows FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can manage artist follows" ON public.artist_follows;
CREATE POLICY "Users can manage artist follows" ON public.artist_follows FOR ALL USING (true);

-- STORAGE BUCKETS & RLS RULES (100MB LIMIT, PUBLIC STREAMING, AUTHENTICATED UPLOAD)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('songs', 'songs', true, 104857600, NULL)
ON CONFLICT (id) DO UPDATE SET public = true, file_size_limit = 104857600, allowed_mime_types = NULL;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('app-files', 'app-files', true, 104857600, NULL)
ON CONFLICT (id) DO UPDATE SET public = true, file_size_limit = 104857600, allowed_mime_types = NULL;

DROP POLICY IF EXISTS "Public can view and stream audio files" ON storage.objects;
CREATE POLICY "Public can view and stream audio files" ON storage.objects
  FOR SELECT USING (bucket_id IN ('songs', 'app-files'));

DROP POLICY IF EXISTS "Authenticated users can upload audio files" ON storage.objects;
CREATE POLICY "Authenticated users can upload audio files" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id IN ('songs', 'app-files') AND auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can update their own storage files" ON storage.objects;
CREATE POLICY "Users can update their own storage files" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id IN ('songs', 'app-files') AND auth.uid()::text = (storage.foldername(name))[1]);

DROP POLICY IF EXISTS "Users can delete their own storage files" ON storage.objects;
CREATE POLICY "Users can delete their own storage files" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id IN ('songs', 'app-files') AND auth.uid()::text = (storage.foldername(name))[1]);`;
                      navigator.clipboard.writeText(sql);
                      setSuccessMsg('SQL Migration copied to clipboard! Paste it into Supabase Dashboard -> SQL Editor and click Run.');
                      setTimeout(() => setSuccessMsg(null), 5000);
                    }}
                    className="px-4 py-2 rounded-xl bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs transition-all shadow-md active:scale-95 cursor-pointer flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4 text-slate-950" />
                    <span>Copy SQL Migration</span>
                  </button>
                </div>
              </div>
            </div>
          ) : previewMode ? (
            /* Live Preview Layout */
            <div className="bg-white rounded-2xl p-6 text-slate-800 space-y-5 shadow-inner">
              <div className="border-b border-slate-200 pb-3">
                <span className="text-xs font-bold text-[#0072ce] uppercase tracking-wider">Preview Mode</span>
                <h2 className="text-xl font-black text-[#032b69] mt-0.5">{document.title}</h2>
                <p className="text-xs text-slate-500">Last Updated: {document.lastUpdated} • Jurisdiction: {document.governingJurisdiction}</p>
              </div>

              {document.sections.map((section) => (
                <div key={section.id} className="space-y-1.5">
                  <h3 className="text-sm font-bold text-[#032b69]">{section.title}</h3>
                  <div className="text-xs text-slate-600 leading-relaxed whitespace-pre-line bg-slate-50 p-3 rounded-xl border border-slate-100">
                    {section.content}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* Section By Section Editor */
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-yellow-300 uppercase tracking-wider">
                  Document Sections ({document.sections.length} total)
                </span>
                <span className="text-[11px] text-blue-200/70">
                  Edit section headings and clause text
                </span>
              </div>

              {document.sections.map((section, idx) => (
                <div
                  key={section.id}
                  className="p-3.5 rounded-2xl bg-blue-900/30 border border-blue-400/20 space-y-2"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-500/30 text-yellow-300 font-bold text-[10px] flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <input
                      type="text"
                      value={section.title}
                      onChange={(e) => handleSectionTitleChange(idx, e.target.value)}
                      className="w-full bg-[#022153] border border-blue-400/40 rounded-lg px-3 py-1.5 text-xs text-white font-bold focus:outline-none focus:border-yellow-400"
                    />
                  </div>

                  <textarea
                    rows={4}
                    value={section.content}
                    onChange={(e) => handleSectionContentChange(idx, e.target.value)}
                    className="w-full bg-[#02183c] border border-blue-400/30 rounded-xl p-3 text-xs text-blue-100 focus:outline-none focus:border-yellow-400 font-normal leading-relaxed resize-y"
                  />
                </div>
              ))}
            </div>
          )}

        </div>

        {/* Modal Footer Actions */}
        <div className="pt-4 mt-3 border-t border-blue-400/20 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-blue-200/70">
            Publishing updates the public legal pages across <span className="text-white font-semibold">TESO MELODIES.com</span>.
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-blue-200 hover:text-white bg-white/10 hover:bg-white/15 transition-all cursor-pointer"
            >
              Close
            </button>
            {(docType as any) !== 'supabase' && (
              <button
                type="button"
                onClick={handleSave}
                disabled={isSaving}
                className="px-5 py-2 rounded-xl text-xs font-black bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 transition-all shadow-md active:scale-95 cursor-pointer flex items-center gap-1.5 disabled:opacity-60"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Publishing...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Publish Changes</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
