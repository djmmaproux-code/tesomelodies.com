import React, { useState, useEffect, useMemo } from 'react';
import {
  Play,
  Pause,
  MoreVertical,
  Flame,
  Crown,
  Music2,
  Heart,
  Download,
  Share2,
  User,
  Trash2,
  MessageCircle,
  Star,
  Sparkles,
  Loader2,
  Info,
} from 'lucide-react';
import { Song } from '../types/music';
import { HERO_ASSETS } from '../data/initialData';
import { getAllSongReviewSummaries, onCommentsUpdated } from '../services/commentsService';
import { formatDownloadCount } from '../services/musicService';
import { getSongSeoPath, getArtistSeoPath, getGenreSeoPath } from '../utils/seo';

interface MusicColumnsProps {
  newSongs: Song[];
  trendingSongs: Song[];
  hot100Songs: Song[];
  currentSong: Song | null;
  isPlaying: boolean;
  onPlaySong: (song: Song) => void;
  onLikeSong: (songId: string) => void;
  onDownloadSong: (song: Song) => void;
  onShareSong: (song: Song) => void;
  onViewArtist: (artistName: string) => void;
  onSelectGenre?: (genreName: string) => void;
  onDeleteSong?: (songId: string) => void;
  onOpenComments?: (song: Song) => void;
  onViewSongDetails?: (song: Song) => void;
  downloadingSongId?: string | null;
  likedSongIds: Set<string>;
  currentUserId?: string;
  onOpenUpload?: () => void;
  isLoading?: boolean;
}

export const MusicColumns: React.FC<MusicColumnsProps> = ({
  newSongs,
  trendingSongs,
  hot100Songs,
  currentSong,
  isPlaying,
  onPlaySong,
  onLikeSong,
  onDownloadSong,
  onShareSong,
  onViewArtist,
  onSelectGenre,
  onDeleteSong,
  onOpenComments,
  onViewSongDetails,
  downloadingSongId = null,
  likedSongIds,
  currentUserId,
  onOpenUpload,
  isLoading = false,
}) => {
  const [activeCategory, setActiveCategory] = useState<'new' | 'trending' | 'hot100' | 'all'>('new');
  const [activeMenuSongId, setActiveMenuSongId] = useState<string | null>(null);
  const [reviewSummaries, setReviewSummaries] = useState<Record<string, { totalComments: number; averageRating: number }>>({});
  const [showAllRows, setShowAllRows] = useState(false);

  // Subscribe to real-time comments updates to keep comment counts live
  useEffect(() => {
    setReviewSummaries(getAllSongReviewSummaries());
    const unsubscribe = onCommentsUpdated(() => {
      setReviewSummaries(getAllSongReviewSummaries());
    });
    return unsubscribe;
  }, []);

  // Compute all unique songs
  const allUniqueSongs = useMemo(() => {
    const map = new Map<string, Song>();
    newSongs.forEach((s) => map.set(s.id, s));
    trendingSongs.forEach((s) => map.set(s.id, s));
    hot100Songs.forEach((s) => map.set(s.id, s));
    return Array.from(map.values());
  }, [newSongs, trendingSongs, hot100Songs]);

  // Determine current active songs list
  const activeSongs = useMemo(() => {
    if (activeCategory === 'new') return newSongs;
    if (activeCategory === 'trending') return trendingSongs;
    if (activeCategory === 'hot100') return hot100Songs;
    return allUniqueSongs;
  }, [activeCategory, newSongs, trendingSongs, hot100Songs, allUniqueSongs]);

  // Limit display unless "View All" is toggled
  const displayedSongs = showAllRows ? activeSongs : activeSongs.slice(0, 15);

  const getCategoryDetails = () => {
    switch (activeCategory) {
      case 'new':
        return {
          title: 'New Songs',
          icon: Music2,
          color: 'text-red-500',
          bg: 'bg-red-50',
          emptyText: 'No new songs uploaded yet.',
        };
      case 'trending':
        return {
          title: 'Trending Songs',
          icon: Flame,
          color: 'text-orange-500',
          bg: 'bg-orange-50',
          emptyText: 'No trending songs yet. Like tracks to get them trending!',
        };
      case 'hot100':
        return {
          title: 'Hot 100 Songs',
          icon: Crown,
          color: 'text-amber-500',
          bg: 'bg-amber-50',
          emptyText: 'Hot 100 chart is ready for your tracks.',
        };
      case 'all':
        return {
          title: 'All Released Songs',
          icon: Music2,
          color: 'text-[#0072ce]',
          bg: 'bg-blue-50',
          emptyText: 'No released music yet.',
        };
    }
  };

  const currentCategoryDetails = getCategoryDetails();

  // Render individual song row matching the reference screenshot on desktop and optimized for mobile
  const renderSongRow = (song: Song, index: number) => {
    const isCurrent = currentSong?.id === song.id;
    const isTrackPlaying = isCurrent && isPlaying;
    const isLiked = likedSongIds.has(song.id);
    const isMenuOpen = activeMenuSongId === song.id;
    const isDownloading = downloadingSongId === song.id;
    const downloadCount = Math.max(0, song.downloadsCount || 0);
    const stats = reviewSummaries[song.id] || { totalComments: 0, averageRating: 0 };

    return (
      <div
        key={`song-row-${song.id}-${activeCategory}-${index}`}
        className={`group relative flex items-center justify-between gap-1.5 sm:gap-4 py-2 sm:py-3.5 px-1 sm:px-4 rounded-xl sm:rounded-2xl transition-all duration-150 border-b border-slate-100/90 last:border-b-0 hover:bg-blue-50/60 ${
          isCurrent ? 'bg-blue-50/90 ring-1 ring-blue-200' : 'bg-transparent'
        }`}
      >
        {/* Left Side: Square Artwork (56px mobile [55-65px], 86px desktop) + Circular Blue Play Button + FULL Song Title & Artist */}
        <div className="flex items-center gap-2 sm:gap-4 min-w-0 flex-1">
          {/* 1. Square Album Artwork: 56px on mobile (55-65px), 80px sm, 86px md */}
          <div className="relative w-[56px] h-[56px] sm:w-[80px] sm:h-[80px] md:w-[86px] md:h-[86px] rounded-xl sm:rounded-2xl overflow-hidden shrink-0 shadow-xs bg-slate-200 border border-slate-100">
            <img
              src={song.coverUrl || HERO_ASSETS.announcement}
              alt={song.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = HERO_ASSETS.announcement;
              }}
            />
            {/* Hot 100 rank tag overlay if applicable */}
            {activeCategory === 'hot100' && (
              <div className="absolute top-1 left-1 w-4.5 h-4.5 sm:w-5 sm:h-5 rounded-md bg-yellow-400 text-slate-950 font-black text-[9px] sm:text-[10px] flex items-center justify-center shadow-xs">
                {song.rank || index + 1}
              </div>
            )}
          </div>

          {/* 2. Circular Blue Play Button beside artwork */}
          <button
            onClick={() => onPlaySong(song)}
            className={`w-[34px] h-[34px] sm:w-11 sm:h-11 md:w-12 md:h-12 rounded-full flex items-center justify-center shrink-0 transition-all duration-150 shadow-xs cursor-pointer active:scale-90 ${
              isTrackPlaying
                ? 'bg-yellow-400 text-slate-950 ring-2 ring-yellow-300 ring-offset-2 animate-pulse'
                : 'bg-[#0072ce] hover:bg-[#005fb8] text-white hover:scale-105'
            }`}
            title={isTrackPlaying ? 'Pause song' : 'Play song'}
          >
            {isTrackPlaying ? (
              <Pause className="w-3.5 h-3.5 sm:w-5 sm:h-5 fill-current" />
            ) : (
              <Play className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 fill-current ml-0.5" />
            )}
          </button>

          {/* 3. Song Title (FULL title, clearly visible, natural multi-line wrapping) + Artist Name underneath */}
          <div className="min-w-0 flex-1 pr-1">
            <h4
              className={`text-[13px] sm:text-base font-bold transition-colors leading-tight sm:leading-snug break-words hyphens-auto ${
                isCurrent ? 'text-[#0072ce]' : 'text-slate-900 hover:text-[#0072ce]'
              }`}
            >
              <a
                href={getSongSeoPath(song.id)}
                onClick={(e) => {
                  if (!e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) {
                    e.preventDefault();
                    onPlaySong(song);
                  }
                }}
                className="cursor-pointer hover:text-[#0072ce] transition-colors"
              >
                {song.title}
              </a>
            </h4>

            <div className="flex flex-wrap items-center gap-1 sm:gap-2 mt-0.5">
              <a
                href={getArtistSeoPath(song.artist)}
                onClick={(e) => {
                  if (!e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) {
                    e.preventDefault();
                    onViewArtist(song.artist);
                  }
                }}
                className="text-[11px] sm:text-sm text-slate-500 font-medium cursor-pointer hover:underline hover:text-slate-800 break-words"
              >
                {song.artist}
              </a>

              <span className="text-slate-300 text-[10px]">•</span>

              {/* Genre badge */}
              <a
                href={getGenreSeoPath(song.genre || 'Afrobeat')}
                onClick={(e) => {
                  if (onSelectGenre && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) {
                    e.preventDefault();
                    onSelectGenre(song.genre || 'Afrobeat');
                  }
                }}
                className="px-1.5 py-0.5 bg-blue-50 text-[#0072ce] text-[10px] font-bold rounded hover:bg-blue-100 transition-colors"
              >
                {song.genre || 'Afrobeat'}
              </a>

              {/* Duration badge */}
              {song.duration && (
                <>
                  <span className="text-slate-300 text-[10px] hidden xs:inline">•</span>
                  <span className="text-[10px] sm:text-xs text-slate-400 font-medium tabular-nums hidden xs:inline">
                    {song.duration}
                  </span>
                </>
              )}

              {/* Star Rating Indicator */}
              {stats.averageRating > 0 && (
                <div
                  onClick={() => onOpenComments && onOpenComments(song)}
                  className="hidden xs:inline-flex items-center gap-1 text-[10px] sm:text-[11px] text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded-md font-bold cursor-pointer hover:bg-amber-100 transition-colors"
                  title={`${stats.averageRating} Stars from reviews`}
                >
                  <Star className="w-2.5 h-2.5 sm:w-3 sm:h-3 fill-amber-400 text-amber-400" />
                  <span>{stats.averageRating}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Side Action Controls: Like + Comments + Download + Three-dot Menu */}
        <div className="flex items-center gap-1 sm:gap-2.5 md:gap-3 shrink-0">
          {/* Like Button with Count */}
          <button
            onClick={() => onLikeSong(song.id)}
            className={`transition-all cursor-pointer flex items-center gap-0.5 sm:gap-1.5 p-1 sm:px-2.5 sm:py-1 rounded-lg text-xs font-bold active:scale-90 ${
              isLiked
                ? 'text-red-600 bg-red-50/60 hover:bg-red-50'
                : 'text-slate-400 hover:text-red-500 hover:bg-red-50/60'
            }`}
            title={isLiked ? 'Unlike song' : 'Like song'}
          >
            <Heart
              className={`w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 transition-transform ${
                isLiked ? 'fill-red-500 text-red-500' : 'text-slate-400'
              }`}
            />
            <span className={`tabular-nums text-[11px] sm:text-xs ${isLiked ? 'font-bold text-red-600' : 'text-slate-500'}`}>
              {song.likes || 0}
            </span>
          </button>

          {/* Comments & Reviews Button with Count */}
          {onOpenComments && (
            <button
              onClick={() => onOpenComments(song)}
              className="flex items-center gap-0.5 sm:gap-1.5 p-1 sm:px-2.5 sm:py-1.5 rounded-lg text-slate-500 hover:text-[#0072ce] hover:bg-blue-50 transition-colors cursor-pointer text-xs font-semibold"
              title="Open Comments & Reviews"
            >
              <MessageCircle className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 text-slate-400 hover:text-[#0072ce]" />
              <span className="tabular-nums text-slate-600 text-[11px] sm:text-xs">{stats.totalComments}</span>
            </button>
          )}

          {/* Green Download Button (Free MP3) with Live Public Download Count */}
          <button
            onClick={() => onDownloadSong(song)}
            disabled={isDownloading}
            className={`flex items-center gap-0.5 sm:gap-1.5 p-1 sm:px-2.5 sm:py-1.5 rounded-lg sm:rounded-xl text-xs font-bold transition-all cursor-pointer active:scale-90 disabled:opacity-70 ${
              isDownloading
                ? 'bg-emerald-100 text-emerald-800'
                : 'text-emerald-700 bg-emerald-50/70 hover:bg-emerald-100/90 hover:text-emerald-800'
            }`}
            title={
              isDownloading
                ? `Downloading "${song.title}"...`
                : `Download Free MP3 • ${downloadCount.toLocaleString()} ${downloadCount === 1 ? 'download' : 'downloads'}`
            }
          >
            {isDownloading ? (
              <Loader2 className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 text-emerald-600 animate-spin" />
            ) : (
              <Download className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 text-emerald-600" />
            )}
            <span className="tabular-nums text-[11px] sm:text-xs font-bold text-emerald-700">
              {formatDownloadCount(downloadCount)}
            </span>
          </button>

          {/* Three-dot options menu */}
          <div className="relative">
            <button
              onClick={() => setActiveMenuSongId(isMenuOpen ? null : song.id)}
              className="p-1 sm:p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              title="More Song Options"
            >
              <MoreVertical className="w-3.5 h-3.5 sm:w-5 sm:h-5" />
            </button>

            {/* Dropdown Menu */}
            {isMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setActiveMenuSongId(null)}
                />
                <div className="absolute right-0 top-8 w-52 bg-white rounded-2xl shadow-2xl border border-slate-100 py-1.5 z-50 text-xs font-semibold text-slate-700 divide-y divide-slate-100 animate-in fade-in zoom-in-95 duration-100">
                  <div className="py-1">
                    <button
                      onClick={() => {
                        onPlaySong(song);
                        setActiveMenuSongId(null);
                      }}
                      className="w-full px-3.5 py-2 text-left hover:bg-blue-50 flex items-center gap-2.5 text-[#0072ce] cursor-pointer"
                    >
                      <Play className="w-4 h-4" />
                      <span>{isTrackPlaying ? 'Pause Track' : 'Play Track'}</span>
                    </button>
                    <button
                      onClick={() => {
                        onLikeSong(song.id);
                        setActiveMenuSongId(null);
                      }}
                      className="w-full px-3.5 py-2 text-left hover:bg-blue-50 flex items-center gap-2.5 cursor-pointer"
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          isLiked ? 'fill-red-500 text-red-500' : 'text-slate-400'
                        }`}
                      />
                      <span>{isLiked ? 'Unlike Song' : 'Like Song'}</span>
                    </button>
                  </div>

                  <div className="py-1">
                    {onOpenComments && (
                      <button
                        onClick={() => {
                          onOpenComments(song);
                          setActiveMenuSongId(null);
                        }}
                        className="w-full px-3.5 py-2 text-left hover:bg-blue-50 flex items-center gap-2.5 text-[#032b69] cursor-pointer"
                      >
                        <MessageCircle className="w-4 h-4 text-[#0072ce]" />
                        <span>Comments & Reviews ({stats.totalComments})</span>
                      </button>
                    )}
                    <button
                      onClick={() => {
                        onDownloadSong(song);
                        setActiveMenuSongId(null);
                      }}
                      className="w-full px-3.5 py-2 text-left hover:bg-blue-50 flex items-center justify-between gap-2 text-emerald-700 cursor-pointer"
                    >
                      <span className="flex items-center gap-2.5">
                        <Download className="w-4 h-4 text-emerald-600" />
                        <span>Download Free MP3</span>
                      </span>
                      <span className="text-[10px] font-black px-1.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 tabular-nums">
                        {formatDownloadCount(downloadCount)}
                      </span>
                    </button>
                    {onViewSongDetails && (
                      <button
                        onClick={() => {
                          onViewSongDetails(song);
                          setActiveMenuSongId(null);
                        }}
                        className="w-full px-3.5 py-2 text-left hover:bg-blue-50 flex items-center gap-2.5 text-[#032b69] cursor-pointer"
                      >
                        <Info className="w-4 h-4 text-[#0072ce]" />
                        <span>Song Details & Stats</span>
                      </button>
                    )}
                    <button
                      onClick={() => {
                        onShareSong(song);
                        setActiveMenuSongId(null);
                      }}
                      className="w-full px-3.5 py-2 text-left hover:bg-blue-50 flex items-center gap-2.5 cursor-pointer"
                    >
                      <Share2 className="w-4 h-4 text-indigo-600" />
                      <span>Share Track</span>
                    </button>
                    <button
                      onClick={() => {
                        onViewArtist(song.artist);
                        setActiveMenuSongId(null);
                      }}
                      className="w-full px-3.5 py-2 text-left hover:bg-blue-50 flex items-center gap-2.5 cursor-pointer"
                    >
                      <User className="w-4 h-4 text-slate-500" />
                      <span>View Artist Profile</span>
                    </button>
                    {onDeleteSong && (song.userId === currentUserId || !song.userId) && (
                      <button
                        onClick={() => {
                          onDeleteSong(song.id);
                          setActiveMenuSongId(null);
                        }}
                        className="w-full px-3.5 py-2 text-left hover:bg-red-50 flex items-center gap-2.5 text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span>Delete Track</span>
                      </button>
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full space-y-4 max-w-full overflow-hidden">
      {/* Main Full-Width Horizontal Songs Card */}
      <div className="bg-white rounded-2xl md:rounded-3xl p-2.5 sm:p-6 shadow-xl border border-slate-100 overflow-hidden">
        {/* Card Header matching reference screenshot: Icon + Title on left, View All on right */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 sm:gap-3 mb-3 sm:mb-4 pb-2.5 sm:pb-3 border-b border-slate-100">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 w-full sm:w-auto">
            <div className="flex items-center justify-between sm:justify-start w-full sm:w-auto">
              {/* Header Icon + Title */}
              <div className="flex items-center gap-2 mr-2">
                <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl ${currentCategoryDetails.bg} flex items-center justify-center ${currentCategoryDetails.color} shadow-xs`}>
                  <currentCategoryDetails.icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                <h3 className="text-base sm:text-xl font-black text-[#032b69] tracking-tight">
                  {currentCategoryDetails.title}
                </h3>
              </div>

              {/* View All on mobile header top right */}
              <button
                onClick={() => setShowAllRows(!showAllRows)}
                className="sm:hidden text-xs font-bold text-[#E53935] hover:text-red-700 flex items-center gap-1 group cursor-pointer transition-colors"
              >
                <span>{showAllRows ? 'Show Less' : 'View All'}</span>
                <span className="group-hover:translate-x-0.5 transition-transform">→</span>
              </button>
            </div>

            {/* Category Navigation Pills with smooth horizontal swipe on small screens */}
            <div className="flex items-center gap-1 bg-slate-100/90 p-1 rounded-xl overflow-x-auto max-w-full no-scrollbar">
              <button
                onClick={() => setActiveCategory('new')}
                className={`px-2.5 py-1 rounded-lg text-[11px] sm:text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  activeCategory === 'new'
                    ? 'bg-white text-[#032b69] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                New ({newSongs.length})
              </button>
              <button
                onClick={() => setActiveCategory('trending')}
                className={`px-2.5 py-1 rounded-lg text-[11px] sm:text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  activeCategory === 'trending'
                    ? 'bg-white text-[#032b69] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Trending ({trendingSongs.length})
              </button>
              <button
                onClick={() => setActiveCategory('hot100')}
                className={`px-2.5 py-1 rounded-lg text-[11px] sm:text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  activeCategory === 'hot100'
                    ? 'bg-white text-[#032b69] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Hot 100 ({hot100Songs.length})
              </button>
              <button
                onClick={() => setActiveCategory('all')}
                className={`px-2.5 py-1 rounded-lg text-[11px] sm:text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  activeCategory === 'all'
                    ? 'bg-white text-[#032b69] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All Songs ({allUniqueSongs.length})
              </button>
            </div>
          </div>

          {/* Right Header: View All → in red text for tablet/desktop */}
          <div className="hidden sm:flex items-center gap-2 shrink-0">
            <button
              onClick={() => setShowAllRows(!showAllRows)}
              className="text-xs sm:text-sm font-bold text-[#E53935] hover:text-red-700 flex items-center gap-1 group cursor-pointer transition-colors"
            >
              <span>{showAllRows ? 'Show Less' : `View All (${activeSongs.length})`}</span>
              <span className="group-hover:translate-x-0.5 transition-transform">→</span>
            </button>
          </div>
        </div>

        {/* Horizontal Songs List */}
        <div className="divide-y-0">
          {isLoading ? (
            <div className="space-y-3 py-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 animate-pulse">
                  <div className="w-[56px] h-[56px] sm:w-[80px] sm:h-[80px] rounded-xl bg-slate-200" />
                  <div className="w-10 h-10 rounded-full bg-slate-200 shrink-0" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-slate-200 rounded w-2/3" />
                    <div className="h-3 bg-slate-200 rounded w-1/3" />
                  </div>
                  <div className="w-20 h-8 bg-slate-200 rounded-lg hidden sm:block" />
                </div>
              ))}
            </div>
          ) : displayedSongs.length === 0 ? (
            <div className="py-12 px-4 text-center flex flex-col items-center justify-center">
              <div className="w-12 h-12 rounded-full bg-blue-50 text-[#0072ce] flex items-center justify-center mb-2 shadow-xs">
                <Music2 className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-slate-800">{currentCategoryDetails.emptyText}</p>
              <p className="text-xs text-slate-400 mt-1">Be the next artist to release music on Teso Melodies!</p>
              {onOpenUpload && (
                <button
                  onClick={onOpenUpload}
                  className="mt-4 px-4 py-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer"
                >
                  Upload New Song
                </button>
              )}
            </div>
          ) : (
            <>
              {displayedSongs.map((song, index) => renderSongRow(song, index))}
              {!showAllRows && activeSongs.length > displayedSongs.length && (
                <div className="pt-3 text-center">
                  <button
                    onClick={() => setShowAllRows(true)}
                    className="w-full sm:w-auto px-6 py-2.5 bg-blue-50 hover:bg-blue-100 text-[#0072ce] font-bold text-xs rounded-xl border border-blue-200/60 transition-all cursor-pointer inline-flex items-center justify-center gap-1.5"
                  >
                    <span>View all {activeSongs.length} songs in {currentCategoryDetails.title}</span>
                    <span>→</span>
                  </button>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer info: Total tracks count */}
        {!isLoading && displayedSongs.length > 0 && (
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>
              Showing {displayedSongs.length} of {activeSongs.length} songs
            </span>
            <span className="text-[#0072ce] font-semibold">100% Free Streaming & MP3 Downloads</span>
          </div>
        )}
      </div>
    </div>
  );
};
