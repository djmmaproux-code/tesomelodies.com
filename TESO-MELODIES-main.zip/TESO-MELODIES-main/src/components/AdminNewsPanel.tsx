import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Newspaper,
  ShieldCheck,
  ShieldAlert,
  ArrowLeft,
  Plus,
  Edit3,
  Trash2,
  Eye,
  EyeOff,
  Search,
  CheckCircle2,
  Database,
  Loader2,
  RotateCw,
  Archive,
  Image as ImageIcon,
  X,
  Users,
  TrendingUp,
  ArrowDownToLine,
  Receipt,
  Settings,
} from 'lucide-react';
import { UserProfile } from '../types/music';
import { HERO_ASSETS } from '../data/initialData';
import { AdminEarningsManager, AdminEarningsSectionTab } from './AdminEarningsManager';
import {
  AUTHORIZED_ADMIN_EMAIL,
  verifyAdminAuthorization,
} from '../services/adminService';
import {
  NewsArticle,
  NewsStatus,
  fetchAllNewsForAdmin,
  createNewsArticle,
  updateNewsArticle,
  deleteNewsArticle,
  formatNewsDate,
} from '../services/newsService';

interface AdminNewsPanelProps {
  currentUser: UserProfile;
  onBackToSite: () => void;
  onToast: (msg: string) => void;
  onNewsChanged: () => void;
}

const NEWS_CATEGORIES = [
  'Portal News',
  'Music News',
  'Artist Spotlight',
  'Event & Festivals',
  'Breaking News',
  'Official Live',
  'Announcement',
  'Advertisement',
];

export const AdminNewsPanel: React.FC<AdminNewsPanelProps> = ({
  currentUser,
  onBackToSite,
  onToast,
  onNewsChanged,
}) => {
  const [authChecking, setAuthChecking] = useState(true);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [tableMissing, setTableMissing] = useState(false);

  const [adminSection, setAdminSection] = useState<'news' | AdminEarningsSectionTab>('news');
  const [statusFilter, setStatusFilter] = useState<'all' | NewsStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Editor form state (handles both Create and Edit)
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Portal News');
  const [badge, setBadge] = useState('');
  const [description, setDescription] = useState('');
  const [fullContent, setFullContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [status, setStatus] = useState<NewsStatus>('published');
  const [isSaving, setIsSaving] = useState(false);
  const [busyArticleId, setBusyArticleId] = useState<string | null>(null);

  const resetForm = () => {
    setEditingId(null);
    setTitle('');
    setCategory('Portal News');
    setBadge('');
    setDescription('');
    setFullContent('');
    setImageUrl('');
    setCoverFile(null);
    setStatus('published');
  };

  const loadArticles = useCallback(async () => {
    setIsLoading(true);
    const res = await fetchAllNewsForAdmin();
    setTableMissing(Boolean(res.tableMissing));
    if (res.error && !res.tableMissing) {
      onToast(res.error);
    }
    setArticles(res.articles || []);
    setIsLoading(false);
  }, [onToast]);

  useEffect(() => {
    let active = true;
    const verifyAndLoad = async () => {
      setAuthChecking(true);
      const auth = await verifyAdminAuthorization();
      if (!active) return;

      setIsAuthorized(auth.authorized);
      setAuthError(auth.error || null);
      setAuthChecking(false);

      if (auth.authorized) {
        await loadArticles();
      }
    };
    verifyAndLoad();
    return () => {
      active = false;
    };
  }, [currentUser.email, currentUser.isLoggedIn, loadArticles]);

  const handleStartEdit = (article: NewsArticle) => {
    setEditingId(article.id);
    setTitle(article.title);
    setCategory(article.category || 'Portal News');
    setBadge(article.badge || '');
    setDescription(article.description);
    setFullContent(article.fullContent || article.description);
    setImageUrl(article.imageUrl === HERO_ASSETS.announcement ? '' : article.imageUrl);
    setCoverFile(null);
    setStatus(article.status);
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSubmit = async (e: React.FormEvent, overrideStatus?: NewsStatus) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      onToast('Please enter both a headline and a short summary.');
      return;
    }

    const targetStatus = overrideStatus || status;
    const cleanBadge = badge.trim() || category || 'News';

    setIsSaving(true);
    try {
      if (editingId) {
        const res = await updateNewsArticle(editingId, {
          title,
          category,
          badge: cleanBadge,
          description,
          fullContent: fullContent || description,
          imageUrl,
          coverFile,
          status: targetStatus,
        });
        if (!res.success || !res.article) {
          onToast(res.error || 'Failed to update news article.');
          return;
        }
        setArticles((prev) => prev.map((a) => (a.id === editingId ? res.article! : a)));
        onNewsChanged();
        onToast(`Updated "${res.article.title}" (${res.article.status}).`);
        resetForm();
      } else {
        const res = await createNewsArticle({
          title,
          category,
          badge: cleanBadge,
          description,
          fullContent: fullContent || description,
          imageUrl: imageUrl || HERO_ASSETS.announcement,
          coverFile,
          status: targetStatus,
        });
        if (res.tableMissing) {
          setTableMissing(true);
        }
        if (!res.success || !res.article) {
          onToast(res.error || 'Failed to save news article.');
          return;
        }
        setArticles((prev) => [res.article!, ...prev]);
        onNewsChanged();
        onToast(
          targetStatus === 'published'
            ? `Published "${res.article.title}" to Teso Melodies!`
            : `Saved "${res.article.title}" as draft.`
        );
        resetForm();
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleStatus = async (article: NewsArticle, nextStatus: NewsStatus) => {
    setBusyArticleId(article.id);
    const res = await updateNewsArticle(article.id, { status: nextStatus });
    setBusyArticleId(null);

    if (!res.success || !res.article) {
      onToast(res.error || 'Could not update article status.');
      return;
    }
    setArticles((prev) => prev.map((a) => (a.id === article.id ? res.article! : a)));
    onNewsChanged();
    onToast(
      nextStatus === 'published'
        ? `"${article.title}" is now published on the website.`
        : `"${article.title}" moved to ${nextStatus}.`
    );
  };

  const handleDelete = async (article: NewsArticle) => {
    if (!window.confirm(`Permanently delete "${article.title}"? This cannot be undone.`)) {
      return;
    }
    setBusyArticleId(article.id);
    const res = await deleteNewsArticle(article.id);
    setBusyArticleId(null);

    if (!res.success) {
      onToast(res.error || 'Failed to delete news article.');
      return;
    }
    setArticles((prev) => prev.filter((a) => a.id !== article.id));
    if (editingId === article.id) {
      resetForm();
    }
    onNewsChanged();
    onToast(`Deleted "${article.title}".`);
  };

  const filteredArticles = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return articles.filter((a) => {
      if (statusFilter !== 'all' && a.status !== statusFilter) return false;
      if (!q) return true;
      return (
        a.title.toLowerCase().includes(q) ||
        a.description.toLowerCase().includes(q) ||
        a.category.toLowerCase().includes(q)
      );
    });
  }, [articles, statusFilter, searchQuery]);

  const counts = useMemo(() => {
    return {
      all: articles.length,
      published: articles.filter((a) => a.status === 'published').length,
      draft: articles.filter((a) => a.status === 'draft').length,
      archived: articles.filter((a) => a.status === 'archived').length,
    };
  }, [articles]);

  if (authChecking) {
    return (
      <div className="bg-white rounded-2xl md:rounded-3xl p-10 shadow-xl border border-slate-100 text-center space-y-3">
        <Loader2 className="w-8 h-8 text-[#0072ce] animate-spin mx-auto" />
        <h2 className="text-lg font-black text-[#032b69]">Verifying Administrator Access...</h2>
        <p className="text-xs text-slate-500">Checking Supabase authentication for {AUTHORIZED_ADMIN_EMAIL}</p>
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="bg-white rounded-2xl md:rounded-3xl p-8 sm:p-10 shadow-xl border border-red-200 text-center space-y-4 max-w-xl mx-auto">
        <div className="w-14 h-14 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center mx-auto">
          <ShieldAlert className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-black text-slate-900">Restricted Admin News Panel</h2>
        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
          {authError ||
            `Access denied. Only ${AUTHORIZED_ADMIN_EMAIL} is authorized to post, edit, publish, or delete news.`}
        </p>
        <button
          onClick={onBackToSite}
          className="px-5 py-2.5 bg-[#032b69] hover:bg-[#0055d4] text-white font-bold text-xs rounded-xl shadow transition-all cursor-pointer inline-flex items-center gap-1.5"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Teso Melodies</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Header Bar */}
      <div className="bg-gradient-to-r from-[#032b69] via-[#0055d4] to-[#0072ce] rounded-2xl md:rounded-3xl p-5 sm:p-6 text-white shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 text-[11px] font-bold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
              <span>Private Admin Dashboard • {AUTHORIZED_ADMIN_EMAIL}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
              <Newspaper className="w-6 h-6 text-[#FFCC00]" />
              <span>Teso Melodies Admin Dashboard</span>
            </h1>
            <p className="text-xs text-blue-100">
              Manage official news, artist verification, UGX royalties, monthly reports, royalty settings, Mobile Money withdrawals, and audit logs.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            {adminSection === 'news' && (
              <button
                onClick={loadArticles}
                disabled={isLoading}
                className="px-3.5 py-2 bg-white/15 hover:bg-white/25 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5 disabled:opacity-60"
              >
                <RotateCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            )}
            <button
              onClick={onBackToSite}
              className="px-4 py-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow transition-all cursor-pointer flex items-center gap-1.5"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Site</span>
            </button>
          </div>
        </div>

        {/* Extended Admin Section Tabs (Preserves Existing News Manager + Adds Full Monetization Admin) */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-white/15">
          {(
            [
              { id: 'news', label: 'News Manager', icon: Newspaper },
              { id: 'artists', label: 'Artists & Verification', icon: Users },
              { id: 'earnings', label: 'Artist Earnings', icon: TrendingUp },
              { id: 'withdrawals', label: 'Withdrawals', icon: ArrowDownToLine },
              { id: 'rates', label: 'Royalty Settings', icon: Settings },
              { id: 'transactions', label: 'Transactions', icon: Receipt },
            ] as const
          ).map((tab) => {
            const Icon = tab.icon;
            const active = adminSection === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setAdminSection(tab.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer inline-flex items-center gap-1.5 ${
                  active
                    ? 'bg-[#FFCC00] text-slate-950 shadow-md'
                    : 'bg-white/10 hover:bg-white/20 text-white border border-white/15'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {adminSection !== 'news' ? (
        <AdminEarningsManager activeSection={adminSection} onToast={onToast} />
      ) : (
      <>
      {/* Missing SQL Migration Notice */}
      {tableMissing && (
        <div className="bg-amber-50 border border-amber-300 rounded-2xl p-4 flex items-start gap-3 text-amber-950 shadow-sm">
          <Database className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-xs space-y-1">
            <p className="font-black text-sm">Setup Required: Create public.news in Supabase</p>
            <p className="text-amber-900 leading-relaxed">
              The <code>public.news</code> table has not been created yet in your Supabase project. Run{' '}
              <code>supabase-news-likes-migration.sql</code> in the Supabase SQL Editor, then click Refresh.
            </p>
          </div>
        </div>
      )}

      {/* Two-Column Grid: Editor + News Articles List */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left: Create / Edit News Form */}
        <div className="lg:col-span-5 bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#0072ce] flex items-center justify-center">
                {editingId ? <Edit3 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              </div>
              <h2 className="text-base font-black text-[#032b69]">
                {editingId ? 'Edit News Article' : 'Create News Article'}
              </h2>
            </div>
            {editingId && (
              <button
                type="button"
                onClick={resetForm}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
                <span>Cancel Edit</span>
              </button>
            )}
          </div>

          <form onSubmit={(e) => handleSubmit(e)} className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Headline <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Teso Melodies Music Awards 2026"
                required
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold cursor-pointer"
                >
                  {NEWS_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Badge Label</label>
                <input
                  type="text"
                  value={badge}
                  onChange={(e) => setBadge(e.target.value)}
                  placeholder={category || 'News'}
                  className="w-full px-3 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Short Summary <span className="text-red-500">*</span>
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Brief summary shown in Latest Announcements & news cards..."
                required
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] resize-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Full Story Content</label>
              <textarea
                rows={4}
                value={fullContent}
                onChange={(e) => setFullContent(e.target.value)}
                placeholder="Complete article text shown when visitors click to read more..."
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] resize-y"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-[#0072ce]" />
                <span>Cover Image (Upload or URL)</span>
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => setCoverFile(e.target.files?.[0] || null)}
                className="block w-full text-xs text-slate-600 mb-2 cursor-pointer"
              />
              <input
                type="text"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="Or paste image URL (optional)"
                className="w-full px-3.5 py-2 text-xs bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Publish Status</label>
              <div className="grid grid-cols-3 gap-1.5 bg-slate-100 p-1 rounded-xl">
                {(['published', 'draft', 'archived'] as NewsStatus[]).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setStatus(st)}
                    className={`py-1.5 text-xs font-bold rounded-lg capitalize transition-all cursor-pointer ${
                      status === st
                        ? st === 'published'
                          ? 'bg-emerald-600 text-white shadow-sm'
                          : st === 'draft'
                          ? 'bg-amber-500 text-slate-950 shadow-sm'
                          : 'bg-slate-700 text-white shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <button
                type="submit"
                disabled={isSaving}
                className="flex-1 py-2.5 px-4 bg-[#0072ce] hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow transition-all cursor-pointer disabled:opacity-60 flex items-center justify-center gap-1.5"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : editingId ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Save Changes</span>
                  </>
                ) : (
                  <>
                    <Newspaper className="w-4 h-4" />
                    <span>{status === 'published' ? 'Publish News' : 'Save Draft'}</span>
                  </>
                )}
              </button>

              {!editingId && status !== 'draft' && (
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={(e) => handleSubmit(e, 'draft')}
                  className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer disabled:opacity-60"
                >
                  Save as Draft
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Right: Existing News List */}
        <div className="lg:col-span-7 bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base sm:text-lg font-black text-[#032b69]">
                All News Articles ({articles.length})
              </h2>
              <p className="text-[11px] text-slate-500">
                Only articles marked <strong>Published</strong> are visible publicly on the site.
              </p>
            </div>

            {/* Status filter tabs */}
            <div className="flex flex-wrap items-center gap-1.5">
              {(
                [
                  { id: 'all', label: `All (${counts.all})` },
                  { id: 'published', label: `Published (${counts.published})` },
                  { id: 'draft', label: `Drafts (${counts.draft})` },
                  { id: 'archived', label: `Archived (${counts.archived})` },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setStatusFilter(tab.id)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    statusFilter === tab.id
                      ? 'bg-[#032b69] text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Search input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search news by title, summary, or category..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce]"
            />
          </div>

          {isLoading ? (
            <div className="py-12 text-center space-y-2">
              <Loader2 className="w-7 h-7 text-[#0072ce] animate-spin mx-auto" />
              <p className="text-xs text-slate-500 font-medium">Loading news articles from Supabase...</p>
            </div>
          ) : filteredArticles.length === 0 ? (
            <div className="py-12 px-4 text-center rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50">
              <Newspaper className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-slate-800">No news articles found</h3>
              <p className="text-xs text-slate-500 mt-1">
                {articles.length === 0
                  ? 'Use the form on the left to publish your first official news story.'
                  : 'Try adjusting your search query or status filter.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredArticles.map((article) => {
                const isBusy = busyArticleId === article.id;
                const isEditingThis = editingId === article.id;
                return (
                  <div
                    key={article.id}
                    className={`p-3.5 rounded-2xl border transition-all flex flex-col sm:flex-row gap-3.5 ${
                      isEditingThis
                        ? 'bg-blue-50/70 border-blue-300 shadow-sm'
                        : 'bg-slate-50/70 border-slate-200/80 hover:bg-slate-50'
                    }`}
                  >
                    <img
                      src={article.imageUrl || HERO_ASSETS.announcement}
                      alt={article.title}
                      className="w-full sm:w-20 h-28 sm:h-20 rounded-xl object-cover shrink-0 bg-slate-200"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = HERO_ASSETS.announcement;
                      }}
                    />

                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                            article.status === 'published'
                              ? 'bg-emerald-100 text-emerald-700'
                              : article.status === 'draft'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-200 text-slate-700'
                          }`}
                        >
                          {article.status}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-blue-100 text-[#032b69] text-[10px] font-bold">
                          {article.badge || article.category}
                        </span>
                        <span className="text-[11px] text-slate-400 font-medium">
                          {formatNewsDate(article.publishedAt || article.createdAt)}
                        </span>
                      </div>

                      <h3 className="text-sm font-black text-slate-900 leading-snug break-words">
                        {article.title}
                      </h3>
                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {article.description}
                      </p>

                      {/* Action Buttons */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-1.5">
                        <button
                          onClick={() => handleStartEdit(article)}
                          disabled={isBusy}
                          className="px-2.5 py-1 bg-white hover:bg-blue-50 text-[#032b69] border border-slate-200 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>

                        {article.status !== 'published' ? (
                          <button
                            onClick={() => handleToggleStatus(article, 'published')}
                            disabled={isBusy}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50"
                          >
                            <Eye className="w-3 h-3" />
                            <span>Publish</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleToggleStatus(article, 'draft')}
                            disabled={isBusy}
                            className="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50"
                          >
                            <EyeOff className="w-3 h-3" />
                            <span>Unpublish</span>
                          </button>
                        )}

                        {article.status !== 'archived' && (
                          <button
                            onClick={() => handleToggleStatus(article, 'archived')}
                            disabled={isBusy}
                            className="px-2.5 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50"
                          >
                            <Archive className="w-3 h-3" />
                            <span>Archive</span>
                          </button>
                        )}

                        <button
                          onClick={() => handleDelete(article)}
                          disabled={isBusy}
                          className="px-2.5 py-1 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
      </>
      )}
    </div>
  );
};
