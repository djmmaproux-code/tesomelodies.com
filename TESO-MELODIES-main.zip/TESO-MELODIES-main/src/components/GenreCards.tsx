import React from 'react';
import { Mic, Heart, Music, Flame } from 'lucide-react';
import { INITIAL_GENRES } from '../data/initialData';
import { getGenreSeoPath } from '../utils/seo';

interface GenreCardsProps {
  selectedGenre: string | null;
  onSelectGenre: (genreName: string | null) => void;
}

export const GenreCards: React.FC<GenreCardsProps> = ({
  selectedGenre,
  onSelectGenre,
}) => {
  // SVG Icon Renderer for genre icons matching the reference cards
  const renderGenreIcon = (icon: string) => {
    switch (icon) {
      case 'cross':
        return (
          <svg viewBox="0 0 24 24" className="w-5 h-5 sm:w-6 sm:h-6 fill-white">
            <path d="M10 2H14V8H20V12H14V22H10V12H4V8H10V2Z" />
          </svg>
        );
      case 'music':
        return <Music className="w-5 h-5 sm:w-6 sm:h-6 text-white stroke-[2.2]" />;
      case 'heart':
        return <Heart className="w-5 h-5 sm:w-6 sm:h-6 text-white fill-white" />;
      case 'palm':
        return (
          <svg viewBox="0 0 24 24" className="w-5 h-5 sm:w-6 sm:h-6 fill-none stroke-white stroke-[2]">
            <path d="M13 8C13 8 16 7 19 9" />
            <path d="M13 10C13 10 17 11 18 14" />
            <path d="M11 8C11 8 8 7 5 9" />
            <path d="M11 10C11 10 7 11 6 14" />
            <path d="M12 5V21" />
          </svg>
        );
      case 'guitar':
        return (
          <svg viewBox="0 0 24 24" className="w-5 h-5 sm:w-6 sm:h-6 fill-white">
            <path d="M19.59 4.41C18.81 3.63 17.55 3.63 16.77 4.41L14.7 6.48L17.52 9.3L19.59 7.23C20.37 6.45 20.37 5.19 19.59 4.41ZM13.29 7.89L5.59 15.59C5.21 15.97 5 16.48 5 17.02V19H6.98C7.52 19 8.03 18.79 8.41 18.41L16.11 10.71L13.29 7.89Z" />
          </svg>
        );
      case 'africa':
        return (
          <svg viewBox="0 0 24 24" className="w-5 h-5 sm:w-6 sm:h-6 fill-white">
            <path d="M6 4C7 3 13 3 17 5C18 7 19 10 18 12C17 14 15 15 15 17C15 19 13 22 11 22C10 21 9 17 9 15C9 14 8 12 7 11C6 10 5 7 6 4Z" />
          </svg>
        );
      case 'hat':
        return (
          <svg viewBox="0 0 24 24" className="w-5 h-5 sm:w-6 sm:h-6 fill-white">
            <path d="M12 4C8 4 6 7 6 9C4 9 2 11 2 13C2 14.5 4 16 8 16H16C20 16 22 14.5 22 13C22 11 20 9 18 9C18 7 16 4 12 4ZM9 10C9 8.5 10.3 7 12 7C13.7 7 15 8.5 15 10H9Z" />
          </svg>
        );
      case 'soundwave':
        return (
          <svg viewBox="0 0 24 24" className="w-5 h-5 sm:w-6 sm:h-6 fill-white">
            <rect x="2" y="9" width="2" height="6" rx="1" />
            <rect x="6" y="5" width="2" height="14" rx="1" />
            <rect x="10" y="2" width="2" height="20" rx="1" />
            <rect x="14" y="6" width="2" height="12" rx="1" />
            <rect x="18" y="8" width="2" height="8" rx="1" />
            <rect x="22" y="11" width="2" height="2" rx="1" />
          </svg>
        );
      case 'saxophone':
        return (
          <svg viewBox="0 0 24 24" className="w-5 h-5 sm:w-6 sm:h-6 fill-white">
            <path d="M17 3H19V7H17V3ZM15 7H13V15C13 17.2 11.2 19 9 19C6.8 19 5 17.2 5 15C5 12.8 6.8 11 9 11V9C5.7 9 3 11.7 3 15C3 18.3 5.7 21 9 21C12.3 21 15 18.3 15 15V9H17V7H15Z" />
          </svg>
        );
      case 'flame':
        return <Flame className="w-5 h-5 sm:w-6 sm:h-6 text-white fill-white" />;
      default:
        return <Mic className="w-5 h-5 sm:w-6 sm:h-6 text-white stroke-[2.2]" />;
    }
  };

  return (
    <div className="w-full bg-white rounded-2xl md:rounded-3xl p-4 sm:p-5 shadow-xl border border-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3.5">
        <div>
          <h2 className="text-lg sm:text-2xl font-black text-[#032b69] tracking-tight">
            Music Categories / Genres
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Explore your favorite music genres
          </p>
        </div>

        <button
          onClick={() => onSelectGenre(null)}
          className="text-xs sm:text-sm font-bold text-[#E53935] hover:text-red-700 flex items-center gap-1 transition-colors group cursor-pointer"
        >
          <span>{selectedGenre ? 'Show All Genres' : 'View All Genres'}</span>
          <span className="group-hover:translate-x-0.5 transition-transform">→</span>
        </button>
      </div>

      {/* Genre Grid matching the exact 11 categories:
          teso worship, Gospel, Akoogo, R&B, Reggae, Rock, Afrobeat, Country, Amapiano, Jazz, Teso Dancehall */}
      <div className="grid grid-cols-2 min-[420px]:grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-11 gap-2 sm:gap-2.5">
        {INITIAL_GENRES.map((genre) => {
          const isSelected = selectedGenre?.toLowerCase() === genre.name.toLowerCase();
          return (
            <a
              key={genre.id}
              href={getGenreSeoPath(genre.name)}
              onClick={(e) => {
                if (!e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) {
                  e.preventDefault();
                  onSelectGenre(isSelected ? null : genre.name);
                }
              }}
              className={`flex flex-col items-center justify-center p-2.5 sm:p-3 rounded-xl md:rounded-2xl transition-all group cursor-pointer shadow-sm hover:shadow-md hover:-translate-y-0.5 ${
                genre.color
              } ${isSelected ? 'ring-4 ring-yellow-400 scale-[1.03] shadow-md' : 'hover:opacity-95'}`}
            >
              <div className="mb-1.5 transition-transform group-hover:scale-110">
                {renderGenreIcon(genre.icon)}
              </div>
              <span className="text-[11px] font-bold text-white text-center leading-tight line-clamp-1 w-full px-0.5">
                {genre.name}
              </span>
            </a>
          );
        })}
      </div>
    </div>
  );
};

