import React, { useState, useEffect } from 'react';
import { X, Upload, Video, Image as ImageIcon, Check, SlidersHorizontal, ChevronDown, ChevronUp, Loader2 } from 'lucide-react';
import { UserProfile, VideoItem, VideoQualityKey } from '../types/music';
import { uploadAppFile } from '../services/storageService';
import { supabase } from '../supabaseClient';
import {
  VIDEO_CATEGORIES,
  VIDEO_QUALITY_ORDER,
  extractVideoMetadata,
  createVideoInSupabase,
} from '../services/videoService';

interface VideoUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVideoCreated: (video: VideoItem) => void;
  currentUserId?: string | null;
  currentUser?: UserProfile;
}

export const VideoUploadModal: React.FC<VideoUploadModalProps> = ({
  isOpen,
  onClose,
  onVideoCreated,
  currentUserId,
  currentUser,
}) => {
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState(currentUser?.stageName || currentUser?.name || '');
  const [category, setCategory] = useState<string>('Music Video');
  const [description, setDescription] = useState('');

  const [primaryVideoFile, setPrimaryVideoFile] = useState<File | null>(null);
  const [primaryQuality, setPrimaryQuality] = useState<VideoQualityKey>('720p');
  const [durationStr, setDurationStr] = useState('00:00');
  const [durationSec, setDurationSec] = useState(0);
  const [detectedResolutionText, setDetectedResolutionText] = useState<string>('');

  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [thumbnailPreviewUrl, setThumbnailPreviewUrl] = useState<string | null>(null);
  const [autoThumbFile, setAutoThumbFile] = useState<File | null>(null);
  const [autoThumbPreviewUrl, setAutoThumbPreviewUrl] = useState<string | null>(null);
  const [isInspectingVideo, setIsInspectingVideo] = useState(false);

  const [showExtraQualities, setShowExtraQualities] = useState(false);
  const [extraQualityFiles, setExtraQualityFiles] = useState<Partial<Record<VideoQualityKey, File>>>({});

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStage, setUploadStage] = useState('');

  useEffect(() => {
    if (isOpen && currentUser) {
      if (!artist) {
        setArtist(currentUser.stageName || currentUser.name || '');
      }
    }
  }, [isOpen, currentUser, artist]);

  // Cleanup object URLs on close/unmount
  useEffect(() => {
    return () => {
      if (thumbnailPreviewUrl) URL.revokeObjectURL(thumbnailPreviewUrl);
      if (autoThumbPreviewUrl) URL.revokeObjectURL(autoThumbPreviewUrl);
    };
  }, [thumbnailPreviewUrl, autoThumbPreviewUrl]);

  if (!isOpen) return null;

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setCategory('Music Video');
    setPrimaryVideoFile(null);
    setPrimaryQuality('720p');
    setDurationStr('00:00');
    setDurationSec(0);
    setDetectedResolutionText('');
    if (thumbnailPreviewUrl) URL.revokeObjectURL(thumbnailPreviewUrl);
    if (autoThumbPreviewUrl) URL.revokeObjectURL(autoThumbPreviewUrl);
    setThumbnailFile(null);
    setThumbnailPreviewUrl(null);
    setAutoThumbFile(null);
    setAutoThumbPreviewUrl(null);
    setExtraQualityFiles({});
    setShowExtraQualities(false);
    setUploadError(null);
    setUploadProgress(0);
    setUploadStage('');
  };

  const handlePrimaryVideoSelect = async (file: File) => {
    setPrimaryVideoFile(file);
    setUploadError(null);
    setIsInspectingVideo(true);

    if (autoThumbPreviewUrl) {
      URL.revokeObjectURL(autoThumbPreviewUrl);
      setAutoThumbPreviewUrl(null);
    }

    try {
      const meta = await extractVideoMetadata(file);
      if (meta.durationSec > 0) {
        setDurationSec(meta.durationSec);
        setDurationStr(meta.durationStr);
      }
      setPrimaryQuality(meta.detectedQuality);
      if (meta.width && meta.height) {
        setDetectedResolutionText(`${meta.width}x${meta.height} (${meta.detectedQuality})`);
      }
      if (meta.autoThumbnailFile && meta.autoThumbnailPreviewUrl) {
        setAutoThumbFile(meta.autoThumbnailFile);
        setAutoThumbPreviewUrl(meta.autoThumbnailPreviewUrl);
      }
    } catch {
      // ignore metadata inspection fallback
    } finally {
      setIsInspectingVideo(false);
    }
  };

  const handleThumbnailSelect = (file: File) => {
    if (thumbnailPreviewUrl) URL.revokeObjectURL(thumbnailPreviewUrl);
    setThumbnailFile(file);
    setThumbnailPreviewUrl(URL.createObjectURL(file));
  };

  const handleExtraQualitySelect = (quality: VideoQualityKey, file: File | null) => {
    setExtraQualityFiles((prev) => {
      const next = { ...prev };
      if (file) next[quality] = file;
      else delete next[quality];
      return next;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !artist.trim()) {
      setUploadError('Please enter both a video title and artist name.');
      return;
    }
    if (!primaryVideoFile) {
      setUploadError('Please select a video file (MP4, WebM, or MOV) to upload.');
      return;
    }

    const {
      data: { session },
    } = await supabase.auth.getSession();
    const activeUserId = session?.user?.id || currentUserId;

    if (!activeUserId) {
      setUploadError('You must be signed in to upload videos. Please sign in first.');
      return;
    }

    setIsSubmitting(true);
    setUploadError(null);
    setUploadProgress(5);
    setUploadStage('Preparing video upload...');

    try {
      const videoId =
        typeof crypto !== 'undefined' && crypto.randomUUID
          ? crypto.randomUUID()
          : `vid-${Date.now()}`;

      // Count total uploads to scale progress smoothly
      const extraEntries = Object.entries(extraQualityFiles).filter(
        ([q, f]) => q !== primaryQuality && Boolean(f)
      ) as [VideoQualityKey, File][];

      // 1. Upload Primary Video File
      const primaryRes = await uploadAppFile(
        activeUserId,
        'videos',
        videoId,
        primaryVideoFile,
        (info) => {
          const ceiling = extraEntries.length > 0 ? 60 : 82;
          setUploadProgress(Math.min(ceiling, Math.max(8, Math.round(info.percent * (ceiling / 100)))));
          setUploadStage(info.stage);
        }
      );

      if (primaryRes.error || !primaryRes.publicUrl) {
        setUploadError(`Video upload error: ${primaryRes.error || 'Failed to get public video URL'}`);
        setIsSubmitting(false);
        setUploadProgress(0);
        setUploadStage('');
        return;
      }

      const qualityUrls: Partial<Record<VideoQualityKey, string>> = {
        [primaryQuality]: primaryRes.publicUrl,
      };

      // 2. Upload Optional Extra Quality Streams (360p/480p/720p/1080p)
      for (let i = 0; i < extraEntries.length; i++) {
        const [q, qFile] = extraEntries[i];
        setUploadStage(`Uploading ${q} quality version (${i + 1}/${extraEntries.length})...`);
        const qRes = await uploadAppFile(activeUserId, 'videos', videoId, qFile, (info) => {
          const basePct = 60 + Math.round(((i + info.percent / 100) / extraEntries.length) * 22);
          setUploadProgress(Math.min(84, basePct));
        });
        if (!qRes.error && qRes.publicUrl) {
          qualityUrls[q] = qRes.publicUrl;
        }
      }

      // 3. Upload Thumbnail (Custom selected OR auto-captured frame from video) to Cloudflare R2
      let thumbnailUrl: string | undefined;
      let thumbnailPath: string | undefined;
      const thumbToUpload = thumbnailFile || autoThumbFile;
      if (thumbToUpload) {
        setUploadProgress(88);
        setUploadStage('Uploading video thumbnail to Cloudflare R2...');
        const thumbRes = await uploadAppFile(activeUserId, 'thumbnails', videoId, thumbToUpload);
        if (thumbRes.error && thumbnailFile) {
          setUploadError(`Thumbnail upload error: ${thumbRes.error}`);
          setIsSubmitting(false);
          setUploadProgress(0);
          setUploadStage('');
          return;
        }
        if (!thumbRes.error && thumbRes.publicUrl) {
          thumbnailUrl = thumbRes.publicUrl;
          thumbnailPath = thumbRes.path;
        }
      }

      // 4. Save Video Record in Supabase
      setUploadProgress(94);
      setUploadStage('Publishing video to Teso Melodies...');
      const { video: createdVideo, error: dbError } = await createVideoInSupabase(
        {
          id: videoId,
          title: title.trim(),
          artist: artist.trim(),
          description: description.trim(),
          category,
          genre: category,
          thumbnailUrl,
          thumbnailPath,
          videoUrl: primaryRes.publicUrl,
          videoPath: primaryRes.path,
          fileSize: primaryRes.fileSize,
          mimeType: primaryRes.contentType,
          qualityUrls,
          defaultQuality: primaryQuality,
          duration: durationStr || '00:00',
          durationSec,
        },
        activeUserId
      );

      if (dbError || !createdVideo) {
        setUploadError(`Database save error: ${dbError || 'Could not save video record.'}`);
        setIsSubmitting(false);
        setUploadProgress(0);
        setUploadStage('');
        return;
      }

      setUploadProgress(100);
      setUploadStage('Video published!');
      onVideoCreated(createdVideo);
      resetForm();
      setIsSubmitting(false);
      onClose();
    } catch (err: any) {
      setUploadError(err?.message || 'Unexpected error while uploading video.');
      setIsSubmitting(false);
      setUploadProgress(0);
      setUploadStage('');
    }
  };

  const activePreviewUrl = thumbnailPreviewUrl || autoThumbPreviewUrl;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#032b69] via-[#022153] to-[#011433] rounded-3xl p-6 shadow-2xl border border-blue-400/30 text-white max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          disabled={isSubmitting}
          className="absolute right-4 top-4 p-1.5 rounded-full text-blue-200/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer disabled:opacity-40"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-10 h-10 rounded-xl bg-red-500/20 text-[#FFCC00] flex items-center justify-center border border-red-400/30 shadow-inner">
            <Video className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white tracking-tight">Upload Official Video</h3>
            <p className="text-xs text-blue-200/80">Publish music videos strictly to the Videos library</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-white mb-1">Video Title *</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Teso Praise (Official Video)"
                required
                className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent shadow-inner"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-white mb-1">Artist / Creator Name *</label>
              <input
                type="text"
                value={artist}
                onChange={(e) => setArtist(e.target.value)}
                placeholder="e.g. Master J"
                required
                className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent shadow-inner"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-white mb-1">Category *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] cursor-pointer shadow-inner"
              >
                {VIDEO_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat} className="bg-[#032b69] text-white">
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-white mb-1">Primary Quality</label>
              <select
                value={primaryQuality}
                onChange={(e) => setPrimaryQuality(e.target.value as VideoQualityKey)}
                className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] cursor-pointer shadow-inner"
              >
                {VIDEO_QUALITY_ORDER.map((q) => (
                  <option key={q} value={q} className="bg-[#032b69] text-white">
                    {q} {q === '1080p' ? '(Full HD)' : q === '720p' ? '(HD)' : '(SD)'}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Primary Video File */}
          <div>
            <label className="block text-xs font-bold text-white mb-1">Video File (MP4, WebM, MOV) *</label>
            <div className="border-2 border-dashed border-blue-400/40 hover:border-[#FFCC00] rounded-2xl p-4 text-center bg-[#061e47]/70 hover:bg-[#061e47] transition-all">
              <input
                type="file"
                accept="video/mp4,video/webm,video/quicktime,video/x-matroska,video/*,.mp4,.webm,.mov,.mkv"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handlePrimaryVideoSelect(f);
                }}
                className="hidden"
                id="video-primary-input"
              />
              <label htmlFor="video-primary-input" className="cursor-pointer block">
                <Upload className="w-6 h-6 text-[#FFCC00] mx-auto mb-1.5" />
                <span className="text-xs font-semibold text-white block truncate px-2">
                  {primaryVideoFile ? primaryVideoFile.name : 'Click to choose MP4, WebM or MOV video'}
                </span>
                <span className="text-[11px] text-blue-200/80 mt-1 block">
                  {isInspectingVideo
                    ? 'Inspecting video duration & resolution...'
                    : primaryVideoFile
                    ? `${(primaryVideoFile.size / (1024 * 1024)).toFixed(1)} MB${
                        durationStr !== '00:00' ? ` · ${durationStr}` : ''
                      }${detectedResolutionText ? ` · ${detectedResolutionText}` : ''}`
                    : 'Supports up to 500 MB HD video files'}
                </span>
              </label>
            </div>
          </div>

          {/* Thumbnail Upload + Preview */}
          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Video Thumbnail <span className="text-blue-200/70 font-normal">(Optional — auto-captured from video if blank)</span>
            </label>
            <div className="flex items-center gap-3">
              <div className="w-28 aspect-video rounded-xl overflow-hidden bg-[#061e47] border border-blue-400/30 shrink-0 flex items-center justify-center">
                {activePreviewUrl ? (
                  <img
                    src={activePreviewUrl}
                    alt="Thumbnail preview"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <ImageIcon className="w-5 h-5 text-blue-300/60" />
                )}
              </div>

              <div className="flex-1 border-2 border-dashed border-blue-400/40 hover:border-[#FFCC00] rounded-2xl p-3 text-center bg-[#061e47]/70 hover:bg-[#061e47] transition-all">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handleThumbnailSelect(f);
                  }}
                  className="hidden"
                  id="video-thumb-input"
                />
                <label htmlFor="video-thumb-input" className="cursor-pointer block">
                  <span className="text-xs font-semibold text-white block truncate">
                    {thumbnailFile
                      ? thumbnailFile.name
                      : autoThumbFile
                      ? 'Auto-captured frame ready (click to replace)'
                      : 'Choose custom thumbnail (JPG, PNG, WebP)'}
                  </span>
                  <span className="text-[10px] text-blue-200/75 mt-0.5 block">
                    Recommended 16:9 widescreen image
                  </span>
                </label>
              </div>
            </div>
          </div>

          {/* Optional Multi-Quality Video Versions */}
          <div className="rounded-2xl bg-[#061e47]/60 border border-blue-400/25 overflow-hidden">
            <button
              type="button"
              onClick={() => setShowExtraQualities(!showExtraQualities)}
              className="w-full px-3.5 py-2.5 flex items-center justify-between text-xs font-bold text-blue-100 hover:text-white cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <SlidersHorizontal className="w-3.5 h-3.5 text-[#FFCC00]" />
                <span>Additional Quality Versions (360p / 480p / 720p / 1080p)</span>
              </span>
              {showExtraQualities ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showExtraQualities && (
              <div className="px-3.5 pb-3.5 pt-1 grid grid-cols-2 gap-2 border-t border-blue-400/20">
                {VIDEO_QUALITY_ORDER.map((q) => {
                  const isPrimary = q === primaryQuality;
                  const chosen = extraQualityFiles[q];
                  return (
                    <div
                      key={q}
                      className={`p-2 rounded-xl border text-[11px] ${
                        isPrimary
                          ? 'bg-blue-900/50 border-[#FFCC00]/60 text-yellow-200'
                          : 'bg-[#041638] border-blue-400/20 text-blue-100'
                      }`}
                    >
                      <div className="flex items-center justify-between font-bold mb-1">
                        <span>{q}</span>
                        {isPrimary && <span className="text-[10px] text-[#FFCC00]">Primary</span>}
                      </div>
                      {isPrimary ? (
                        <span className="text-[10px] text-blue-200/80 block truncate">
                          {primaryVideoFile ? primaryVideoFile.name : 'Set via main file above'}
                        </span>
                      ) : (
                        <label className="cursor-pointer block">
                          <input
                            type="file"
                            accept="video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov"
                            onChange={(e) => handleExtraQualitySelect(q, e.target.files?.[0] || null)}
                            className="hidden"
                          />
                          <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-cyan-300 hover:text-white truncate max-w-full">
                            {chosen ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-400 shrink-0" />
                                <span className="truncate">{chosen.name}</span>
                              </>
                            ) : (
                              '+ Attach file (optional)'
                            )}
                          </span>
                        </label>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Description <span className="text-blue-200/70 font-normal">(Optional)</span>
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Tell viewers about this music video, director, recording location, or story..."
              rows={2}
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] resize-none shadow-inner"
            />
          </div>

          {isSubmitting && (
            <div className="space-y-1.5 bg-[#061e47]/90 border border-blue-400/30 p-3 rounded-xl">
              <div className="flex items-center justify-between text-[11px] font-bold text-blue-100">
                <span className="truncate pr-2">{uploadStage || 'Uploading video...'}</span>
                <span className="text-[#FFCC00] tabular-nums shrink-0">{uploadProgress}%</span>
              </div>
              <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#FFCC00] transition-all duration-300"
                  style={{ width: `${Math.max(8, uploadProgress)}%` }}
                />
              </div>
            </div>
          )}

          {uploadError && (
            <p className="text-xs text-red-200 bg-red-950/80 border border-red-500/40 p-2.5 rounded-xl text-center font-medium">
              {uploadError}
            </p>
          )}

          <button
            type="submit"
            disabled={isSubmitting || isInspectingVideo}
            className="w-full py-2.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-yellow-500/20 transition-all active:scale-[0.98] cursor-pointer disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{uploadStage || 'Uploading Video...'}</span>
              </>
            ) : (
              <span>Upload & Publish Video</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
