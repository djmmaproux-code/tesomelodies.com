import React, { useState } from 'react';
import { X, Camera, Music, Sparkles, Check, Loader2 } from 'lucide-react';
import { UserProfile } from '../types/music';
import { uploadAppFile } from '../services/storageService';
import { saveArtistProfileInSupabase } from '../services/musicService';

interface ArtistProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  currentUserId?: string | null;
  onProfileUpdated: (updatedUser: Partial<UserProfile>) => void;
}

export const ArtistProfileModal: React.FC<ArtistProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  currentUserId,
  onProfileUpdated,
}) => {
  const [stageName, setStageName] = useState(currentUser.stageName || currentUser.name || '');
  const [genre, setGenre] = useState(currentUser.genre || 'Afrobeat');
  const [location, setLocation] = useState(currentUser.location || 'Teso, Uganda');
  const [bio, setBio] = useState(currentUser.bio || '');
  const [selectedPhoto, setSelectedPhoto] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string>(currentUser.avatar || '');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedPhoto(file);
      setPhotoPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stageName.trim()) {
      setErrorMsg('Please enter your Stage / Artist Name.');
      return;
    }
    if (!currentUserId) {
      setErrorMsg('You must be logged in to create an artist profile.');
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);

    try {
      let avatarUrl = currentUser.avatar;

      // 1. Upload artist photo to Cloudflare R2 if selected
      if (selectedPhoto) {
        const photoUpload = await uploadAppFile(
          currentUserId,
          'avatars',
          'artist-profile',
          selectedPhoto
        );
        const uploadedUrl = photoUpload.publicUrl || photoUpload.signedUrl;
        if (photoUpload.error || !uploadedUrl) {
          setErrorMsg(photoUpload.error || 'Failed to upload artist profile picture to Cloudflare R2.');
          setIsLoading(false);
          return;
        }
        avatarUrl = uploadedUrl;
      }

      // 2. Save artist profile to Supabase artists table
      const res = await saveArtistProfileInSupabase(currentUserId, {
        stageName: stageName.trim(),
        genre,
        bio: bio.trim() || undefined,
        location: location.trim() || 'Teso, Uganda',
        avatarUrl,
      });

      if (!res.success && res.error) {
        // If the error was about the missing bio column in profiles schema cache, ignore it since bio is optional
        if (!res.error.includes("'bio'") && !res.error.includes('schema cache')) {
          setErrorMsg(res.error);
          setIsLoading(false);
          return;
        }
      }

      // 3. Update in-memory user profile
      onProfileUpdated({
        role: 'artist',
        name: stageName.trim(),
        stageName: stageName.trim(),
        genre,
        location: location.trim() || 'Teso, Uganda',
        bio: bio.trim() || undefined,
        avatar: avatarUrl,
      });

      setIsLoading(false);
      onClose();
    } catch (err: any) {
      if (err?.message && (err.message.includes("'bio'") || err.message.includes('schema cache'))) {
        // bio is optional, proceed with success
        onProfileUpdated({
          role: 'artist',
          name: stageName.trim(),
          stageName: stageName.trim(),
          genre,
          location: location.trim() || 'Teso, Uganda',
          bio: bio.trim() || undefined,
        });
        setIsLoading(false);
        onClose();
        return;
      }
      setErrorMsg(err?.message || 'Failed to update artist profile');
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#032b69] via-[#022153] to-[#011433] rounded-3xl p-6 shadow-2xl border border-blue-400/30 text-white max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-blue-200/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-11 h-11 rounded-2xl bg-blue-500/20 text-[#FFCC00] flex items-center justify-center font-bold shadow-inner border border-blue-400/30">
            <Music className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white flex items-center gap-1.5 tracking-tight">
              <span>Artist Account Setup</span>
              <Sparkles className="w-4 h-4 text-yellow-400" />
            </h3>
            <p className="text-xs text-blue-200/80">Publish music, build your fanbase, and get discovered</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Artist Photo Upload */}
          <div className="text-center pb-2">
            <div className="relative w-24 h-24 mx-auto group">
              <div className="w-24 h-24 rounded-full overflow-hidden ring-4 ring-yellow-400/60 shadow-xl bg-[#061e47] mx-auto border border-blue-400/30">
                {photoPreview ? (
                  <img
                    src={photoPreview}
                    alt="Artist Profile"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-blue-300">
                    <Camera className="w-7 h-7 mb-1 text-yellow-400" />
                    <span className="text-[10px] font-bold text-white">Add Photo</span>
                  </div>
                )}
              </div>
              <label
                htmlFor="artist-photo-upload"
                className="absolute bottom-0 right-0 p-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 rounded-full shadow-lg cursor-pointer transition-transform active:scale-90"
                title="Upload Artist Photo"
              >
                <Camera className="w-4 h-4" />
                <input
                  type="file"
                  id="artist-photo-upload"
                  accept="image/*"
                  onChange={handlePhotoSelect}
                  className="hidden"
                />
              </label>
            </div>
            <p className="text-[11px] text-blue-200/80 mt-2 font-medium">
              Upload your official stage / press photo (JPG, PNG)
            </p>
          </div>

          {/* Stage Name */}
          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Artist / Stage Name <span className="text-yellow-400">*</span>
            </label>
            <input
              type="text"
              value={stageName}
              onChange={(e) => setStageName(e.target.value)}
              placeholder="e.g. Master J, King Saha, Queen Flo"
              required
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all shadow-inner font-semibold"
            />
          </div>

          {/* Primary Genre */}
          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Primary Music Genre
            </label>
            <select
              value={genre}
              onChange={(e) => setGenre(e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all cursor-pointer shadow-inner font-semibold"
            >
              <option value="teso worship" className="bg-[#032b69] text-white">teso worship</option>
              <option value="Gospel" className="bg-[#032b69] text-white">Gospel</option>
              <option value="Akoogo" className="bg-[#032b69] text-white">Akoogo</option>
              <option value="R&B" className="bg-[#032b69] text-white">R&B</option>
              <option value="Reggae" className="bg-[#032b69] text-white">Reggae</option>
              <option value="Rock" className="bg-[#032b69] text-white">Rock</option>
              <option value="Afrobeat" className="bg-[#032b69] text-white">Afrobeat</option>
              <option value="Country" className="bg-[#032b69] text-white">Country</option>
              <option value="Amapiano" className="bg-[#032b69] text-white">Amapiano</option>
              <option value="Jazz" className="bg-[#032b69] text-white">Jazz</option>
              <option value="Teso Dancehall" className="bg-[#032b69] text-white">Teso Dancehall</option>
            </select>
          </div>

          {/* Location / Hometown */}
          <div>
            <label className="block text-xs font-bold text-white mb-1">
              Location / Hometown
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Soroti, Teso, Uganda"
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent transition-all shadow-inner font-semibold"
            />
          </div>

          {/* Artist Bio (Optional) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-white">
                Artist Bio / Description
              </label>
              <span className="text-[11px] font-semibold text-blue-200/70">Optional</span>
            </div>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell listeners and fans about your music journey, hometown, and style (optional)..."
              rows={3}
              className="w-full px-3.5 py-2.5 text-xs bg-[#061e47] text-white placeholder:text-blue-200/50 border border-blue-400/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFCC00] focus:border-transparent resize-none font-medium transition-all shadow-inner"
            />
          </div>

          {errorMsg && (
            <p className="text-xs text-red-200 bg-red-950/80 border border-red-500/40 p-2.5 rounded-xl text-center font-medium">
              {errorMsg}
            </p>
          )}

          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading || !stageName.trim()}
              className="w-full py-3 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-yellow-500/20 transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Saving Artist Profile...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Save & Activate Artist Account</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
