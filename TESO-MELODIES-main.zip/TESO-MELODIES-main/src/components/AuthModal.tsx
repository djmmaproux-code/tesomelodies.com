import React, { useState } from 'react';
import { X, User, Lock, Eye, EyeOff } from 'lucide-react';
import { supabase } from '../supabaseClient';
import { initiateRealGoogleLogin } from '../utils/googleAuth';

interface AuthModalProps {
  isOpen: boolean;
  initialMode?: 'signin' | 'signup';
  onClose: () => void;
  onSuccess: (email: string, user?: any) => void;
  onOpenLegal?: (docType: 'privacy' | 'terms') => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode = 'signin',
  onClose,
  onSuccess,
  onOpenLegal,
}) => {
  const [isSignUp, setIsSignUp] = useState(initialMode === 'signup');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [accountType, setAccountType] = useState<'fan' | 'artist'>('fan');
  const [stageName, setStageName] = useState('');
  const [genre, setGenre] = useState('Afrobeat');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Sync mode and query parameters
  React.useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get('registered') === 'true') {
        const emailParam = params.get('email');
        if (emailParam) {
          setEmail(emailParam);
        }
        setSuccessMessage('Your account has been created. Please check your email and verify your address before logging in.');
        setIsSignUp(false);
        return;
      }
    } catch {
      // ignore
    }

    setIsSignUp(initialMode === 'signup');
    setAuthError(null);
    setSuccessMessage(null);
  }, [initialMode, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) return;

    setAuthError(null);
    setSuccessMessage(null);

    if (isSignUp && !agreedToTerms) {
      setAuthError('You must read and agree to the Terms and Conditions and Privacy Policy to register.');
      return;
    }

    setIsLoading(true);

    try {
      if (isSignUp) {
        const finalDisplayName = accountType === 'artist' && stageName.trim() ? stageName.trim() : email.trim().split('@')[0];
        const { error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            data: {
              full_name: finalDisplayName,
              role: accountType,
              stage_name: accountType === 'artist' ? finalDisplayName : undefined,
              genre: accountType === 'artist' ? genre : undefined,
            },
          },
        });

        if (error) {
          setAuthError(error.message);
          setIsLoading(false);
          return;
        }

        // After successful signup:
        // - Do NOT auto-login.
        // - Redirect / switch the user to the Sign In page/view.
        // - Keep / pre-fill the email they just used for signup.
        const registeredEmail = email.trim();
        setPassword('');
        setIsSignUp(false);
        setSuccessMessage('Your account has been created. Please check your email and verify your address before logging in.');

        // Pass email to Sign In using query parameter
        try {
          const newUrl = new URL(window.location.href);
          newUrl.searchParams.set('registered', 'true');
          newUrl.searchParams.set('email', registeredEmail);
          window.history.replaceState({}, '', newUrl.toString());
        } catch {
          // ignore
        }
      } else {
        // 2) For Sign In: Use supabase.auth.signInWithPassword({ email, password })
        const { data, error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });

        if (error) {
          setAuthError(error.message);
          setIsLoading(false);
          return;
        }

        // Only complete login when a real session exists after login:
        if (data?.session) {
          onSuccess(data?.user?.email || email.trim(), data?.user);
          onClose();
        } else {
          setAuthError('Check your email and confirm your account before logging in.');
          setIsLoading(false);
        }
      }
    } catch (err: any) {
      setAuthError(err?.message || 'Authentication failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setAuthError(null);
    setSuccessMessage(null);

    if (isSignUp && !agreedToTerms) {
      setAuthError('Please agree to the Terms and Conditions and Privacy Policy before continuing with Google.');
      return;
    }

    await initiateRealGoogleLogin(setIsLoading, {
      onSuccess: (user) => {
        onSuccess(user.email, user);
        onClose();
      },
      onError: (errMsg) => {
        setAuthError(errMsg);
      },
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm rounded-3xl p-6 shadow-2xl border border-blue-400/30 bg-gradient-to-b from-[#0066d6] via-[#024ea2] to-[#1a237e] text-white">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-blue-200 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-2xl font-black tracking-tight mb-1 text-white">
          {isSignUp ? 'Create Account' : 'Welcome Back!'}
        </h3>
        <p className="text-xs text-blue-100/80 mb-3 font-medium">
          {isSignUp
            ? 'Join Teso Melodies to stream or upload music.'
            : 'Log in to your account or create a new one.'}
        </p>

        {/* 2) On the Sign In page: Show clear success message ABOVE the form */}
        {successMessage && !isSignUp && (
          <div className="mb-3.5 p-3 rounded-xl bg-emerald-950/70 border border-emerald-400/50 text-emerald-200 text-xs font-semibold leading-relaxed text-center animate-in fade-in duration-200 shadow-sm">
            {successMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          {/* Account Role Selector during Sign Up */}
          {isSignUp && (
            <div className="p-1 bg-black/25 rounded-xl flex items-center gap-1 border border-white/15 mb-2">
              <button
                type="button"
                onClick={() => setAccountType('fan')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  accountType === 'fan'
                    ? 'bg-[#FFCC00] text-slate-950 shadow-sm'
                    : 'text-blue-200 hover:text-white'
                }`}
              >
                🎧 Listener / Fan
              </button>
              <button
                type="button"
                onClick={() => setAccountType('artist')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  accountType === 'artist'
                    ? 'bg-[#FFCC00] text-slate-950 shadow-sm'
                    : 'text-blue-200 hover:text-white'
                }`}
              >
                🎵 Artist / Musician
              </button>
            </div>
          )}

          {/* Artist Stage Name and Genre if Artist is chosen */}
          {isSignUp && accountType === 'artist' && (
            <>
              <div>
                <input
                  type="text"
                  value={stageName}
                  onChange={(e) => setStageName(e.target.value)}
                  placeholder="Stage Name / Musician Name (e.g. Master J)"
                  required
                  className="w-full bg-[#4a148c]/50 hover:bg-[#4a148c]/70 focus:bg-[#4a148c]/80 border border-purple-400/30 focus:border-yellow-400 rounded-xl px-4 py-2.5 text-xs text-white placeholder-purple-200/60 focus:outline-none transition-all shadow-inner font-semibold"
                />
              </div>
              <div>
                <select
                  value={genre}
                  onChange={(e) => setGenre(e.target.value)}
                  className="w-full bg-[#4a148c]/80 border border-purple-400/30 focus:border-yellow-400 rounded-xl px-3 py-2 text-xs text-white focus:outline-none transition-all"
                >
                  <option value="teso worship">teso worship</option>
                  <option value="Gospel">Gospel</option>
                  <option value="Akoogo">Akoogo</option>
                  <option value="R&B">R&B</option>
                  <option value="Reggae">Reggae</option>
                  <option value="Rock">Rock</option>
                  <option value="Afrobeat">Afrobeat</option>
                  <option value="Country">Country</option>
                  <option value="Amapiano">Amapiano</option>
                  <option value="Jazz">Jazz</option>
                  <option value="Teso Dancehall">Teso Dancehall</option>
                </select>
              </div>
            </>
          )}
          {/* Email Input */}
          <div className="relative">
            <User className="w-4 h-4 text-purple-300 absolute left-4 top-3.5" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              required
              className="w-full bg-[#4a148c]/50 hover:bg-[#4a148c]/70 focus:bg-[#4a148c]/80 border border-purple-400/30 focus:border-yellow-400 rounded-xl pl-11 pr-4 py-2.5 text-xs text-white placeholder-purple-200/60 focus:outline-none transition-all shadow-inner"
            />
          </div>

          {/* Password Input */}
          <div className="relative">
            <Lock className="w-4 h-4 text-purple-300 absolute left-4 top-3.5" />
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              required
              className="w-full bg-[#4a148c]/50 hover:bg-[#4a148c]/70 focus:bg-[#4a148c]/80 border border-purple-400/30 focus:border-yellow-400 rounded-xl pl-11 pr-11 py-2.5 text-xs text-white placeholder-purple-200/60 focus:outline-none transition-all shadow-inner"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3.5 top-3.5 text-purple-300 hover:text-white transition-colors cursor-pointer"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {/* Required Terms & Privacy Policy Checkbox for Registration */}
          {isSignUp && (
            <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-black/25 border border-white/15 text-xs text-blue-100/90 leading-snug">
              <input
                type="checkbox"
                id="auth-agree-terms"
                checked={agreedToTerms}
                onChange={(e) => setAgreedToTerms(e.target.checked)}
                required
                className="mt-0.5 rounded border-purple-400 text-yellow-400 focus:ring-yellow-400 cursor-pointer w-4 h-4 shrink-0 accent-[#FFCC00]"
              />
              <label htmlFor="auth-agree-terms" className="cursor-pointer select-none text-[11px] leading-tight text-blue-100">
                I have read and agree to the{' '}
                <a
                  href="/terms-and-conditions"
                  onClick={(e) => {
                    e.preventDefault();
                    onClose();
                    onOpenLegal?.('terms');
                  }}
                  className="text-yellow-300 hover:text-white font-bold underline cursor-pointer"
                >
                  Terms and Conditions
                </a>{' '}
                and{' '}
                <a
                  href="/privacy-policy"
                  onClick={(e) => {
                    e.preventDefault();
                    onClose();
                    onOpenLegal?.('privacy');
                  }}
                  className="text-yellow-300 hover:text-white font-bold underline cursor-pointer"
                >
                  Privacy Policy
                </a>
                .
              </label>
            </div>
          )}

          {/* 4) Simple error handling under form */}
          {authError && (
            <p className="text-xs text-red-200 bg-red-900/60 border border-red-500/50 rounded-lg p-2 text-center font-medium animate-in fade-in duration-150">
              {authError}
            </p>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading || (isSignUp && !agreedToTerms)}
            className="w-full py-2.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-sm rounded-xl shadow-lg transition-all active:scale-[0.98] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading
              ? isSignUp
                ? 'Signing Up...'
                : 'Logging In...'
              : isSignUp
              ? 'Sign Up'
              : 'Login'}
          </button>

          {/* Toggle link */}
          <div className="text-center text-xs text-blue-100 font-medium pt-1">
            <span>{isSignUp ? 'Already have an account? ' : "Don't have an account? "}</span>
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp);
                setAuthError(null);
                setSuccessMessage(null);
              }}
              className="text-yellow-300 hover:text-yellow-200 font-bold underline cursor-pointer"
            >
              {isSignUp ? 'Sign In' : 'Sign Up'}
            </button>
          </div>

          {/* Divider */}
          <div className="flex items-center gap-3 my-2">
            <div className="h-px bg-white/20 flex-1" />
            <span className="text-[10px] text-blue-200 font-bold uppercase tracking-widest">
              OR
            </span>
            <div className="h-px bg-white/20 flex-1" />
          </div>

          {/* Social Sign Up / Login with Google */}
          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={isLoading}
            className="w-full py-2 px-3 bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-70"
          >
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
              />
            </svg>
            <span>{isSignUp ? 'Sign up with Google' : 'Continue with Google'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
