import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  Wallet,
  ArrowLeft,
  ArrowDownToLine,
  Receipt,
  TrendingUp,
  Hourglass,
  RotateCw,
  Loader2,
  ShieldCheck,
  ShieldAlert,
  BadgeCheck,
  Lock,
  Clock,
  CreditCard,
  CheckCircle2,
  Heart,
  Users,
  Download,
  Headphones,
  X,
} from 'lucide-react';
import { UserProfile } from '../types/music';
import {
  ArtistEarningsDashboardData,
  DEFAULT_EARNING_SETTINGS,
  MobileMoneyProvider,
  fetchArtistEarningsDashboard,
  subscribeToArtistWalletChanges,
  saveArtistPayoutProfile,
  requestArtistWithdrawal,
  formatUGX,
  getTransactionCategoryLabel,
} from '../services/earningsService';

interface ArtistWalletPageProps {
  currentUser: UserProfile;
  currentUserId: string | null;
  onBackToDashboard: () => void;
  onToast: (msg: string) => void;
  onVerificationChange?: (verified: boolean) => void;
}

type WalletTxFilter =
  | 'all'
  | 'earnings'
  | 'withdrawals'
  | 'Pending'
  | 'Approved'
  | 'Paid'
  | 'Rejected';

function formatDateTime(iso?: string | null): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('en-UG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

function statusBadgeClass(status: string): string {
  switch (status) {
    case 'Paid':
    case 'Credited':
      return 'bg-emerald-100 text-emerald-800 border border-emerald-200';
    case 'Approved':
      return 'bg-blue-100 text-[#032b69] border border-blue-200';
    case 'Pending':
      return 'bg-amber-100 text-amber-900 border border-amber-200';
    case 'Rejected':
      return 'bg-red-100 text-red-700 border border-red-200';
    default:
      return 'bg-slate-100 text-slate-700 border border-slate-200';
  }
}

function createIdempotencyKey(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `wdr-${crypto.randomUUID()}`;
  }
  return `wdr-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

export const ArtistWalletPage: React.FC<ArtistWalletPageProps> = ({
  currentUser,
  currentUserId,
  onBackToDashboard,
  onToast,
  onVerificationChange,
}) => {
  const [data, setData] = useState<ArtistEarningsDashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [serviceUnavailable, setServiceUnavailable] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [txFilter, setTxFilter] = useState<WalletTxFilter>('all');
  const [showWithdrawPanel, setShowWithdrawPanel] = useState(false);
  const [showPayoutForm, setShowPayoutForm] = useState(false);

  // Payout info form state
  const [fullLegalName, setFullLegalName] = useState('');
  const [country, setCountry] = useState('Uganda');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [mobileMoneyProvider, setMobileMoneyProvider] =
    useState<MobileMoneyProvider>('MTN Mobile Money');
  const [mobileMoneyNumber, setMobileMoneyNumber] = useState('');
  const [isSavingPayout, setIsSavingPayout] = useState(false);
  const [payoutFeedback, setPayoutFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Withdrawal form state
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [isSubmittingWithdrawal, setIsSubmittingWithdrawal] = useState(false);
  const [withdrawFeedback, setWithdrawFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const withdrawSectionRef = useRef<HTMLDivElement | null>(null);
  const transactionsSectionRef = useRef<HTMLDivElement | null>(null);

  const hydratePayoutForm = useCallback((walletData: ArtistEarningsDashboardData | null) => {
    if (!walletData?.payout_profile) return;
    setFullLegalName(walletData.payout_profile.full_legal_name || '');
    setCountry(walletData.payout_profile.country || 'Uganda');
    setPhoneNumber(walletData.payout_profile.phone_number || '');
    setMobileMoneyProvider(
      walletData.payout_profile.mobile_money_provider === 'Airtel Money'
        ? 'Airtel Money'
        : 'MTN Mobile Money'
    );
    setMobileMoneyNumber(walletData.payout_profile.mobile_money_number || '');
  }, []);

  const loadWallet = useCallback(
    async (silent = false) => {
      if (!currentUser.isLoggedIn) {
        setIsLoading(false);
        return;
      }
      if (!silent) setIsLoading(true);
      setLoadError(null);

      const res = await fetchArtistEarningsDashboard();
      if (res.serviceUnavailable) {
        setServiceUnavailable(true);
        setLoadError(null);
        setData(null);
      } else if (res.error || !res.data) {
        setServiceUnavailable(false);
        setLoadError(res.error || 'Unable to load your Artist Wallet right now. Please try again.');
      } else {
        setServiceUnavailable(false);
        setData(res.data);
        hydratePayoutForm(res.data);
        onVerificationChange?.(Boolean(res.data.summary?.earnings_verified));
      }

      setIsLoading(false);
    },
    [currentUser.isLoggedIn, hydratePayoutForm, onVerificationChange]
  );

  // Initial load & account-change refresh
  useEffect(() => {
    if (!currentUser.isLoggedIn) return;
    loadWallet(false);
  }, [currentUser.isLoggedIn, currentUserId, loadWallet]);

  // Real-time Supabase updates for this artist's wallet
  useEffect(() => {
    const uid = currentUserId || currentUser.id;
    if (!currentUser.isLoggedIn || !uid) return;
    return subscribeToArtistWalletChanges(uid, () => {
      loadWallet(true);
    });
  }, [currentUser.isLoggedIn, currentUserId, currentUser.id, loadWallet]);

  const summary = data?.summary;
  const settings = data?.settings || DEFAULT_EARNING_SETTINGS;
  const payoutProfile = data?.payout_profile || null;
  const withdrawals = data?.withdrawals || [];
  const transactions = data?.transactions || [];

  const isVerified = Boolean(summary?.earnings_verified);
  const isSuspended = Boolean(summary?.is_suspended);
  const minWithdrawal = Number(settings.min_withdrawal_ugx || 15000);
  const availableBalance = Number(summary?.available_balance_ugx || 0);
  const totalEarnings = Number(summary?.total_earnings_ugx || 0);
  const pendingEarnings = Number(summary?.pending_earnings_ugx || 0);
  const totalWithdrawals = Number(summary?.amount_withdrawn_ugx || 0);
  const pendingWithdrawals = Number(summary?.pending_withdrawals_ugx || 0);

  const canRequestWithdrawal =
    isVerified && !isSuspended && availableBalance >= minWithdrawal;
  const progressPercent = Math.min(
    100,
    Math.round((availableBalance / Math.max(1, minWithdrawal)) * 100)
  );

  const filteredTransactions = useMemo(() => {
    switch (txFilter) {
      case 'earnings':
        return transactions.filter((t) => t.direction === 'credit');
      case 'withdrawals':
        return transactions.filter(
          (t) => t.transaction_type === 'withdrawal' || t.transaction_type === 'payment'
        );
      case 'Pending':
      case 'Approved':
      case 'Paid':
      case 'Rejected':
        return transactions.filter((t) => t.status === txFilter);
      default:
        return transactions;
    }
  }, [transactions, txFilter]);

  const handleOpenWithdrawalPanel = () => {
    setShowWithdrawPanel(true);
    if (!payoutProfile && isVerified) {
      setShowPayoutForm(true);
    }
    window.setTimeout(() => {
      withdrawSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
  };

  const handleViewTransactions = () => {
    setTxFilter('all');
    transactionsSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const handleSavePayout = async (e: React.FormEvent) => {
    e.preventDefault();
    setPayoutFeedback(null);
    setIsSavingPayout(true);

    const res = await saveArtistPayoutProfile({
      fullLegalName,
      country,
      phoneNumber,
      mobileMoneyProvider,
      mobileMoneyNumber,
    });

    setIsSavingPayout(false);

    if (!res.success) {
      setPayoutFeedback({
        type: 'error',
        text: res.error || 'Could not save payout details right now.',
      });
      onToast(res.error || 'Failed to save payout details.');
      return;
    }

    setPayoutFeedback({
      type: 'success',
      text: 'Your Mobile Money payout details have been saved securely.',
    });
    setShowPayoutForm(false);
    onToast('Payout details saved!');
    await loadWallet(true);
  };

  const handleRequestWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawFeedback(null);

    if (!isVerified) {
      setWithdrawFeedback({
        type: 'error',
        text: 'Verify your registered Gmail account on your Artist Dashboard before requesting a withdrawal.',
      });
      return;
    }

    const parsedAmount = Number(String(withdrawAmount).replace(/[^0-9.]/g, ''));
    if (!Number.isFinite(parsedAmount) || parsedAmount < minWithdrawal) {
      setWithdrawFeedback({
        type: 'error',
        text: `Minimum withdrawal request is ${formatUGX(minWithdrawal)}.`,
      });
      return;
    }

    if (parsedAmount > availableBalance) {
      setWithdrawFeedback({
        type: 'error',
        text: `Requested amount cannot exceed your available balance (${formatUGX(availableBalance)}).`,
      });
      return;
    }

    if (!payoutProfile) {
      setShowPayoutForm(true);
      setWithdrawFeedback({
        type: 'error',
        text: 'Please save your Mobile Money payout details first.',
      });
      return;
    }

    setIsSubmittingWithdrawal(true);
    const idempotencyKey = createIdempotencyKey();
    const res = await requestArtistWithdrawal(parsedAmount, idempotencyKey);
    setIsSubmittingWithdrawal(false);

    if (!res.success) {
      setWithdrawFeedback({
        type: 'error',
        text: res.error || 'Could not submit withdrawal request.',
      });
      onToast(res.error || 'Withdrawal request failed.');
      return;
    }

    setWithdrawAmount('');
    setWithdrawFeedback({
      type: 'success',
      text: `Withdrawal request ${res.withdrawal?.reference_code || ''} for ${formatUGX(
        parsedAmount
      )} has been submitted and is Pending review.`,
    });
    onToast('Withdrawal request submitted!');
    await loadWallet(true);
  };

  if (!currentUser.isLoggedIn) {
    return null;
  }

  return (
    <div className="space-y-5">
      {/* Top Bar: Back to Dashboard + Refresh */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBackToDashboard}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold border border-white/20 transition-all cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Artist Dashboard</span>
        </button>

        <button
          type="button"
          onClick={() => loadWallet(false)}
          disabled={isLoading}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-100 text-[#032b69] text-xs font-black shadow-sm transition-all cursor-pointer disabled:opacity-60"
        >
          <RotateCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#0072ce]' : ''}`} />
          <span>Refresh Wallet</span>
        </button>
      </div>

      {/* Main Dedicated Artist Wallet Hero Header */}
      <div className="rounded-2xl md:rounded-3xl bg-gradient-to-br from-[#02183d] via-[#032b69] to-[#0055d4] p-5 sm:p-7 text-white shadow-2xl border border-blue-400/30 relative overflow-hidden">
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-[#FFCC00]/10 blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2.5">
              <div className="w-11 h-11 rounded-2xl bg-[#FFCC00] text-[#032b69] flex items-center justify-center shadow-lg shrink-0">
                <Wallet className="w-6 h-6" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-black uppercase tracking-widest text-[#FFCC00]">
                    ARTIST WALLET
                  </span>
                  {!isLoading &&
                    data &&
                    (isVerified ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-200 text-[10px] font-bold border border-emerald-400/40">
                        <BadgeCheck className="w-3 h-3" />
                        <span>Verified Artist</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#FFCC00]/20 text-yellow-200 text-[10px] font-bold border border-[#FFCC00]/40">
                        <Lock className="w-3 h-3" />
                        <span>Gmail Verification Pending</span>
                      </span>
                    ))}
                </div>
                <h2 className="text-lg sm:text-xl font-black tracking-tight text-white">
                  {currentUser.stageName || currentUser.name || 'Artist Account'}
                </h2>
              </div>
            </div>

            <div className="pt-1">
              <div className="text-xs font-bold uppercase tracking-wider text-blue-200">
                Available Balance (UGX)
              </div>
              <div className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight tabular-nums text-[#FFCC00] mt-1">
                {isLoading ? (
                  <span className="inline-flex items-center gap-2 text-2xl text-blue-100">
                    <Loader2 className="w-6 h-6 animate-spin text-[#FFCC00]" />
                    <span>Loading balance...</span>
                  </span>
                ) : (
                  formatUGX(availableBalance)
                )}
              </div>
              <p className="text-[11px] sm:text-xs text-blue-100/90 mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1">
                <span className="inline-flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#FFCC00]" />
                  <span>Live balance synced from verified engagement</span>
                </span>
                {currentUser.email && (
                  <span className="text-blue-200/80">• {currentUser.email}</span>
                )}
              </p>
            </div>
          </div>

          {/* Primary Wallet Actions + Threshold Progress */}
          <div className="flex flex-col gap-3 lg:min-w-[270px]">
            <div className="flex flex-col sm:flex-row lg:flex-col gap-2.5">
              <button
                type="button"
                onClick={handleOpenWithdrawalPanel}
                disabled={isLoading || isSuspended}
                className="flex-1 px-5 py-3 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs sm:text-sm rounded-xl shadow-lg transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <ArrowDownToLine className="w-4 h-4" />
                <span>Request Withdrawal</span>
              </button>

              <button
                type="button"
                onClick={handleViewTransactions}
                disabled={isLoading}
                className="flex-1 px-5 py-2.5 bg-white/15 hover:bg-white/25 text-white font-bold text-xs sm:text-sm rounded-xl border border-white/25 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Receipt className="w-4 h-4 text-[#FFCC00]" />
                <span>View Transactions</span>
              </button>
            </div>

            {!isLoading && data && (
              <div className="bg-blue-950/50 border border-blue-400/25 rounded-xl p-3 space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-bold text-blue-100">
                  <span>Min. withdrawal ({formatUGX(minWithdrawal)})</span>
                  <span className="text-[#FFCC00]">{progressPercent}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-white/15 overflow-hidden">
                  <div
                    className="h-full bg-[#FFCC00] rounded-full transition-all duration-300"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Status / Error States (Zero technical DB or SQL messages) */}
      {serviceUnavailable && !isLoading && (
        <div className="bg-white rounded-2xl p-5 shadow-xl border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#032b69] text-[#FFCC00] flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div className="text-xs space-y-1">
              <p className="font-black text-sm text-[#032b69]">Artist Wallet Syncing</p>
              <p className="text-slate-600 leading-relaxed">
                Your wallet summary is temporarily refreshing. Your songs, engagement, and earned
                royalties remain safely recorded.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => loadWallet(false)}
            className="self-start sm:self-auto px-4 py-2 bg-[#0072ce] hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow cursor-pointer shrink-0"
          >
            Try Again
          </button>
        </div>
      )}

      {loadError && !data && !isLoading && (
        <div className="bg-white rounded-2xl p-5 shadow-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <p className="text-xs font-semibold text-slate-700">{loadError}</p>
          <button
            type="button"
            onClick={() => loadWallet(false)}
            className="self-start sm:self-auto px-4 py-2 bg-[#0072ce] hover:bg-blue-700 text-white font-bold text-xs rounded-xl cursor-pointer shrink-0"
          >
            Retry
          </button>
        </div>
      )}

      {/* Unverified Gmail Notice */}
      {!isLoading && data && !isVerified && (
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xl border-2 border-[#FFCC00] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FFCC00] text-[#032b69] flex items-center justify-center shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <div className="text-xs space-y-1">
              <h3 className="text-sm font-black text-[#032b69]">
                Verify Your Gmail to Activate Automatic Wallet Credits &amp; Withdrawals
              </h3>
              <p className="text-slate-600 leading-relaxed">
                Complete your 6-digit Gmail OTP verification in your Artist Dashboard to start
                crediting eligible royalties into your Artist Wallet and unlock Mobile Money
                withdrawals.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onBackToDashboard}
            className="self-start sm:self-auto px-4 py-2.5 bg-[#032b69] hover:bg-[#0055d4] text-white font-black text-xs rounded-xl shadow cursor-pointer shrink-0"
          >
            Verify Gmail in Dashboard
          </button>
        </div>
      )}

      {/* Suspension Warning (if applicable) */}
      {isSuspended && (
        <div className="bg-red-50 rounded-2xl p-4 border border-red-200 flex items-start gap-3 text-red-900">
          <ShieldAlert className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div className="text-xs space-y-1">
            <p className="font-black text-sm">Wallet Withdrawals Temporarily Suspended</p>
            <p className="leading-relaxed">
              {summary?.suspended_reason ||
                'Your monetization account is currently under administrator review.'}
            </p>
          </div>
        </div>
      )}

      {/* 4 Core Wallet Financial Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* 1. Available Balance */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xl border border-slate-100 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-2 mb-3">
            <span className="text-xs font-bold text-slate-600">Available Balance</span>
            <div className="w-9 h-9 rounded-xl bg-[#032b69] text-[#FFCC00] flex items-center justify-center shrink-0">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-black text-[#032b69] tabular-nums">
              {formatUGX(availableBalance)}
            </div>
            <p className="text-[11px] text-emerald-700 font-semibold mt-1">
              Ready for withdrawal
            </p>
          </div>
        </div>

        {/* 2. Total Earnings */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xl border border-slate-100 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-2 mb-3">
            <span className="text-xs font-bold text-slate-600">Total Earnings</span>
            <div className="w-9 h-9 rounded-xl bg-blue-100 text-[#0072ce] flex items-center justify-center shrink-0">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-black text-slate-900 tabular-nums">
              {formatUGX(totalEarnings)}
            </div>
            <p className="text-[11px] text-slate-500 font-medium mt-1">
              Lifetime credited royalties
            </p>
          </div>
        </div>

        {/* 3. Pending Earnings */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xl border border-slate-100 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-2 mb-3">
            <span className="text-xs font-bold text-slate-600">Pending Earnings</span>
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
              <Hourglass className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-black text-amber-900 tabular-nums">
              {formatUGX(pendingEarnings)}
            </div>
            <p className="text-[11px] text-slate-500 font-medium mt-1">
              {pendingWithdrawals > 0
                ? `Plus ${formatUGX(pendingWithdrawals)} withdrawal in review`
                : 'Accruing toward next milestone'}
            </p>
          </div>
        </div>

        {/* 4. Total Withdrawals */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xl border border-slate-100 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-2 mb-3">
            <span className="text-xs font-bold text-slate-600">Total Withdrawals</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <ArrowDownToLine className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-black text-slate-900 tabular-nums">
              {formatUGX(totalWithdrawals)}
            </div>
            <p className="text-[11px] text-slate-500 font-medium mt-1">
              {withdrawals.length === 1
                ? '1 withdrawal request'
                : `${withdrawals.length} withdrawal requests`}
            </p>
          </div>
        </div>
      </div>

      {/* Compact Monetized Engagement Sources Breakdown */}
      {summary && (
        <div className="bg-white rounded-2xl md:rounded-3xl p-4 sm:p-5 shadow-xl border border-slate-100">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <h3 className="text-sm sm:text-base font-black text-[#032b69]">
              Credited Earnings Breakdown
            </h3>
            <span className="text-[11px] font-semibold text-slate-500">
              Calculated automatically from eligible fan activity
            </span>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[11px] font-bold text-slate-500 flex items-center gap-1">
                  <Heart className="w-3.5 h-3.5 text-red-500 shrink-0" />
                  <span>Likes ({Number(summary.total_likes || 0).toLocaleString()})</span>
                </div>
                <div className="text-sm sm:text-base font-black text-[#032b69] tabular-nums mt-0.5">
                  {formatUGX(summary.likes_earnings_ugx)}
                </div>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[11px] font-bold text-slate-500 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-[#0072ce] shrink-0" />
                  <span>Followers ({Number(summary.total_followers || 0).toLocaleString()})</span>
                </div>
                <div className="text-sm sm:text-base font-black text-[#032b69] tabular-nums mt-0.5">
                  {formatUGX(summary.followers_earnings_ugx)}
                </div>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[11px] font-bold text-slate-500 flex items-center gap-1">
                  <Download className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Downloads ({Number(summary.total_downloads || 0).toLocaleString()})</span>
                </div>
                <div className="text-sm sm:text-base font-black text-[#032b69] tabular-nums mt-0.5">
                  {formatUGX(summary.downloads_earnings_ugx)}
                </div>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[11px] font-bold text-slate-500 flex items-center gap-1">
                  <Headphones className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                  <span>Streams ({Number(summary.total_streams || 0).toLocaleString()})</span>
                </div>
                <div className="text-sm sm:text-base font-black text-[#032b69] tabular-nums mt-0.5">
                  {formatUGX(summary.streams_earnings_ugx)}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Request Withdrawal Panel (Opens when clicking Request Withdrawal) */}
      {showWithdrawPanel && (
        <div
          ref={withdrawSectionRef}
          className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border-2 border-[#0072ce]/30 space-y-5"
        >
          <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[#FFCC00] text-[#032b69] flex items-center justify-center shrink-0">
                <ArrowDownToLine className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-[#032b69]">
                  Request Mobile Money Withdrawal
                </h3>
                <p className="text-xs text-slate-500">
                  Minimum withdrawal is {formatUGX(minWithdrawal)} via MTN Mobile Money or Airtel
                  Money.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowWithdrawPanel(false)}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label="Close Withdrawal Panel"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left: Withdrawal Form + Payout Destination */}
            <div className="lg:col-span-6 space-y-4">
              {!isVerified ? (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-950 space-y-2.5">
                  <p className="font-bold">
                    Verify your registered Gmail account first to save payout details and submit
                    withdrawals.
                  </p>
                  <button
                    type="button"
                    onClick={onBackToDashboard}
                    className="px-4 py-2 bg-[#032b69] text-white font-bold text-xs rounded-xl cursor-pointer"
                  >
                    Go to Gmail Verification
                  </button>
                </div>
              ) : (
                <>
                  {/* Payout Destination Summary or Form */}
                  {payoutProfile && !showPayoutForm ? (
                    <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-500 flex items-center gap-1.5">
                          <CreditCard className="w-3.5 h-3.5 text-[#0072ce]" />
                          <span>Payout Destination</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => setShowPayoutForm(true)}
                          className="text-[#0072ce] font-bold hover:underline cursor-pointer"
                        >
                          Edit Details
                        </button>
                      </div>
                      <p className="font-black text-slate-900">{payoutProfile.full_legal_name}</p>
                      <p className="text-slate-600">
                        <strong>{payoutProfile.mobile_money_provider}</strong> &bull;{' '}
                        {payoutProfile.mobile_money_number} ({payoutProfile.country})
                      </p>
                    </div>
                  ) : (
                    <form
                      onSubmit={handleSavePayout}
                      className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200 space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-[#032b69]">
                          Mobile Money Payout Details (Private)
                        </span>
                        {payoutProfile && (
                          <button
                            type="button"
                            onClick={() => setShowPayoutForm(false)}
                            className="text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                          >
                            Cancel
                          </button>
                        )}
                      </div>

                      {payoutFeedback && (
                        <div
                          className={`p-2.5 rounded-xl text-xs font-semibold border ${
                            payoutFeedback.type === 'success'
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                              : 'bg-red-50 border-red-200 text-red-700'
                          }`}
                        >
                          {payoutFeedback.text}
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <input
                          type="text"
                          required
                          value={fullLegalName}
                          onChange={(e) => setFullLegalName(e.target.value)}
                          placeholder="Full Legal Name"
                          className="w-full px-3 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold"
                        />
                        <input
                          type="text"
                          required
                          value={country}
                          onChange={(e) => setCountry(e.target.value)}
                          placeholder="Country (Uganda)"
                          className="w-full px-3 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold"
                        />
                        <input
                          type="tel"
                          required
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          placeholder="Contact Phone (+256...)"
                          className="w-full px-3 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold"
                        />
                        <select
                          value={mobileMoneyProvider}
                          onChange={(e) =>
                            setMobileMoneyProvider(e.target.value as MobileMoneyProvider)
                          }
                          className="w-full px-3 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-bold"
                        >
                          <option value="MTN Mobile Money">MTN Mobile Money</option>
                          <option value="Airtel Money">Airtel Money</option>
                        </select>
                      </div>

                      <input
                        type="tel"
                        required
                        value={mobileMoneyNumber}
                        onChange={(e) => setMobileMoneyNumber(e.target.value)}
                        placeholder="Mobile Money Payout Number (e.g. 0772123456)"
                        className="w-full px-3 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-semibold"
                      />

                      <button
                        type="submit"
                        disabled={isSavingPayout}
                        className="px-4 py-2 bg-[#0072ce] hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-60"
                      >
                        {isSavingPayout ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        )}
                        <span>Save Payout Details</span>
                      </button>
                    </form>
                  )}

                  {withdrawFeedback && (
                    <div
                      className={`p-3 rounded-xl text-xs font-semibold border ${
                        withdrawFeedback.type === 'success'
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                          : 'bg-red-50 border-red-200 text-red-700'
                      }`}
                    >
                      {withdrawFeedback.text}
                    </div>
                  )}

                  <form onSubmit={handleRequestWithdrawal} className="space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <label className="font-bold text-slate-700">Withdrawal Amount (UGX)</label>
                      {availableBalance >= minWithdrawal && (
                        <button
                          type="button"
                          onClick={() => setWithdrawAmount(String(Math.floor(availableBalance)))}
                          className="text-[#0072ce] font-black hover:underline cursor-pointer"
                        >
                          Use Full Balance ({formatUGX(availableBalance)})
                        </button>
                      )}
                    </div>
                    <input
                      type="number"
                      min={minWithdrawal}
                      max={Math.max(minWithdrawal, Math.floor(availableBalance))}
                      step={100}
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      placeholder={`Minimum ${minWithdrawal.toLocaleString()} UGX`}
                      disabled={!canRequestWithdrawal || !payoutProfile}
                      className="w-full px-3.5 py-2.5 text-sm bg-slate-50 text-slate-900 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0072ce] font-black tabular-nums disabled:opacity-60"
                    />

                    <button
                      type="submit"
                      disabled={
                        isSubmittingWithdrawal || !canRequestWithdrawal || !payoutProfile
                      }
                      className="w-full py-2.5 px-4 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
                    >
                      {isSubmittingWithdrawal ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <ArrowDownToLine className="w-4 h-4" />
                      )}
                      <span>
                        {!canRequestWithdrawal
                          ? `Reach ${formatUGX(minWithdrawal)} Available Balance to Withdraw`
                          : 'Submit Withdrawal Request'}
                      </span>
                    </button>
                  </form>
                </>
              )}
            </div>

            {/* Right: Recent Withdrawal Requests */}
            <div className="lg:col-span-6 space-y-3">
              <h4 className="text-sm font-black text-[#032b69]">
                Your Withdrawal Requests ({withdrawals.length})
              </h4>
              {withdrawals.length === 0 ? (
                <div className="py-8 px-4 text-center rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50 text-xs text-slate-500">
                  No withdrawal requests submitted yet.
                </div>
              ) : (
                <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
                  {withdrawals.map((w) => (
                    <div
                      key={w.id}
                      className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm sm:text-base font-black text-[#032b69] tabular-nums">
                          {formatUGX(w.amount_ugx)}
                        </span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${statusBadgeClass(
                            w.status
                          )}`}
                        >
                          {w.status}
                        </span>
                      </div>
                      <div className="text-[11px] font-semibold text-slate-600">
                        {w.mobile_money_provider} ({w.mobile_money_number}) &bull;{' '}
                        <span className="font-mono text-slate-500">{w.reference_code}</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {formatDateTime(w.created_at)}
                        {w.paid_at ? ` • Paid ${formatDateTime(w.paid_at)}` : ''}
                      </div>
                      {w.payment_reference && (
                        <p className="text-xs font-bold text-emerald-700">
                          MoMo Ref: {w.payment_reference}
                        </p>
                      )}
                      {w.rejection_reason && (
                        <p className="text-xs font-semibold text-red-700">
                          Rejected: {w.rejection_reason}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Transaction History Section */}
      <div
        ref={transactionsSectionRef}
        className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 space-y-4"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-100 text-[#0072ce] flex items-center justify-center shrink-0">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-[#032b69]">
                Transaction History
              </h3>
              <p className="text-xs text-slate-500">
                Verified record of all royalty credits, withdrawal requests, and completed payouts.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'earnings', label: 'Earnings' },
                { id: 'withdrawals', label: 'Withdrawals' },
                { id: 'Pending', label: 'Pending' },
                { id: 'Approved', label: 'Approved' },
                { id: 'Paid', label: 'Paid' },
                { id: 'Rejected', label: 'Rejected' },
              ] as const
            ).map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setTxFilter(f.id)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                  txFilter === f.id
                    ? 'bg-[#032b69] text-white shadow-sm'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="py-10 text-center space-y-2">
            <Loader2 className="w-6 h-6 text-[#0072ce] animate-spin mx-auto" />
            <p className="text-xs font-bold text-slate-500">Loading wallet transactions...</p>
          </div>
        ) : filteredTransactions.length === 0 ? (
          <div className="py-12 px-4 text-center rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50 space-y-2">
            <Receipt className="w-8 h-8 text-slate-400 mx-auto" />
            <p className="text-sm font-black text-slate-700">No wallet transactions yet</p>
            <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
              When your songs earn verified royalties from eligible likes, followers, downloads, or
              streams — or when you request a withdrawal — every transaction will appear here with
              its date and description.
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {filteredTransactions.map((tx) => {
              const category = getTransactionCategoryLabel(tx);
              const isCredit = tx.direction === 'credit';
              return (
                <div
                  key={tx.id}
                  className="p-3.5 sm:p-4 rounded-2xl bg-slate-50/90 hover:bg-blue-50/40 border border-slate-200/80 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${statusBadgeClass(
                          tx.status
                        )}`}
                      >
                        {tx.status}
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-blue-100 text-[#032b69] text-[10px] font-black">
                        {category}
                      </span>
                      <span className="font-mono text-[11px] font-bold text-slate-500">
                        {tx.reference_code}
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm font-bold text-slate-900">
                      {tx.description}
                    </p>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-500">
                      <span className="inline-flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatDateTime(tx.created_at)}
                      </span>
                      {tx.payment_reference && (
                        <span className="font-bold text-emerald-700">
                          MoMo Ref: {tx.payment_reference}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="sm:text-right shrink-0">
                    <div
                      className={`text-base sm:text-lg font-black tabular-nums ${
                        isCredit ? 'text-emerald-700' : 'text-[#032b69]'
                      }`}
                    >
                      {isCredit ? '+' : '-'}
                      {formatUGX(tx.amount_ugx)}
                    </div>
                    <div className="text-[10px] font-bold uppercase text-slate-400">
                      {isCredit ? 'Wallet Credit' : 'Withdrawal Debit'}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
