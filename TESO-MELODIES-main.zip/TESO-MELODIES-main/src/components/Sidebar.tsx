import React, { useState } from 'react';
import { User, Lock, Eye, EyeOff, Megaphone, Users, Check, Camera, Sparkles, Upload, Newspaper, Radio, ShieldCheck, Wallet } from 'lucide-react';
import { Announcement, Artist, UserProfile } from '../types/music';
import { HERO_ASSETS } from '../data/initialData';
import { supabase } from '../supabaseClient';
import { initiateRealGoogleLogin } from '../utils/googleAuth';
import { uploadAppFile } from '../services/storageService';
import { isUserAdminEmail } from '../services/adminService';
import { getArtistSeoPath } from '../utils/seo';

interface SidebarProps {
  announcements: Announcement[];
  topArtist?: Artist | null;
  topArtists?: Artist[];
  onFollowArtist: (artistId: string) => void;
  onSelectArtist?: (artist: Artist) => void;
  onSelectAnnouncement: (announcement: Announcement) => void;
  onOpenAdvertise: () => void;
  onOpenPostNews?: () => void;
  onOpenPublishLive?: () => void;
  onOpenAdminDashboard?: () => void;
  onViewAllArtists?: () => void;
  currentUser: UserProfile;
  currentUserId?: string | null;
  onLogin: (
    identifier: string,
    userEmail?: string,
    avatarUrl?: string,
    role?: 'fan' | 'artist',
    stageName?: string,
    genre?: string,
    bio?: string,
    location?: string,
    userId?: string
  ) => void;
  onOpenSignUp: () => void;
  onLogout: () => void;
  onUpdateAvatar?: (avatarUrl: string) => void;
  onOpenWallet?: () => void;
  onOpenUpload?: () => void;
  onOpenArtistSetup?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  announcements,
  topArtist,
  topArtists,
  onFollowArtist,
  onSelectArtist,
  onSelectAnnouncement,
  onOpenAdvertise,
  onOpenPostNews,
  onOpenPublishLive,
  onOpenAdminDashboard,
  onViewAllArtists,
  currentUser,
  currentUserId,
  onLogin,
  onOpenSignUp,
  onLogout,
  onUpdateAvatar,
  onOpenWallet,
  onOpenUpload,
  onOpenArtistSetup,
}) => {
  const isAdmin = Boolean(currentUser.isLoggedIn && isUserAdminEmail(currentUser.email));
  const [isSignUp, setIsSignUp] = useState(false);
  const [accountType, setAccountType] = useState<'fan' | 'artist'>('fan');
  const [stageName, setStageName] = useState('');
  const [genre, setGenre] = useState('Afrobeat');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);

  const handleAvatarFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUserId) return;

    setIsUploadingAvatar(true);
    setAuthError(null);
    try {
      const upload = await uploadAppFile(currentUserId, 'avatars', 'profile', file);
      const uploadedUrl = upload.publicUrl || upload.signedUrl;
      if (upload.error || !uploadedUrl) {
        setAuthError(upload.error || 'Failed to upload profile photo.');
        return;
      }

      await supabase
        .from('profiles')
        .upsert({ id: currentUserId, avatar_url: uploadedUrl, updated_at: new Date().toISOString() });

      await supabase.auth
        .updateUser({ data: { avatar_url: uploadedUrl, picture: uploadedUrl } })
        .catch(() => {});

      if (onUpdateAvatar) {
        onUpdateAvatar(uploadedUrl);
      }
    } catch (err: any) {
      setAuthError(err?.message || 'Failed to upload profile photo.');
    } finally {
      setIsUploadingAvatar(false);
    }
  };

  React.useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get('registered') === 'true') {
        const emailParam = params.get('email');
        if (emailParam) {
          setEmail(emailParam);
        }
        setSuccessMessage('Your account has been created. Please check your email and verify your address before logging in.');
        setIsSignUp(false);
      }
    } catch {
      // ignore
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) return;

    setAuthError(null);
    setSuccessMessage(null);
    setIsLoading(true);

    try {
      if (isSignUp) {
        // 1) For Sign Up:
        const finalDisplayName = accountType === 'artist' && stageName.trim() ? stageName.trim() : email.trim().split('@')[0];
        const { error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            data: {
              full_name: finalDisplayName,
              role: accountType,
              stage_name: accountType === 'artist' ? finalDisplayName : undefined,
              genre: accountType === 'artist' ? genre : undefined,
            },
          },
        });

        if (error) {
          setAuthError(error.message);
          setIsLoading(false);
          return;
        }

        // 1) After a successful Supabase signUp:
        // - Do NOT auto-login.
        // - Redirect / transition user to the Sign In page.
        // - Keep / pre-fill the email they just used for signup.
        const registeredEmail = email.trim();
        setPassword('');
        setIsSignUp(false);
        setSuccessMessage('Your account has been created. Please check your email and verify your address before logging in.');

        // Pass email to Sign In using query parameter
        try {
          const newUrl = new URL(window.location.href);
          newUrl.searchParams.set('registered', 'true');
          newUrl.searchParams.set('email', registeredEmail);
          window.history.replaceState({}, '', newUrl.toString());
        } catch {
          // ignore
        }
      } else {
        // 2) For Sign In: Use supabase.auth.signInWithPassword({ email, password })
        const { data, error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });

        if (error) {
          setAuthError(error.message);
          setIsLoading(false);
          return;
        }

        // Only complete login when a real session exists after login:
        if (data?.session) {
          const u = data.user;
          const stage = u?.user_metadata?.stage_name || u?.user_metadata?.full_name;
          onLogin(
            stage || u?.email || email.trim(),
            u?.email || email.trim(),
            u?.user_metadata?.avatar_url,
            u?.user_metadata?.role as any,
            stage,
            u?.user_metadata?.genre,
            u?.user_metadata?.bio,
            u?.user_metadata?.location,
            u?.id
          );
        } else {
          setAuthError('Check your email and confirm your account before logging in.');
          setIsLoading(false);
        }
      }
    } catch (err: any) {
      setAuthError(err?.message || 'Authentication error. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setAuthError(null);
    setSuccessMessage(null);

    await initiateRealGoogleLogin(setIsLoading, {
      onSuccess: (user) => {
        onLogin(user.name || user.email, user.email, user.avatar);
      },
      onError: (errMsg) => {
        setAuthError(errMsg);
      },
    });
  };

  return (
    <aside className="w-full space-y-4">
      
      {/* 1. Welcome Back! Login Card */}
      <div className="w-full rounded-2xl md:rounded-3xl p-5 md:p-6 shadow-2xl border border-blue-400/30 bg-gradient-to-b from-[#0066d6] via-[#024ea2] to-[#1a237e] text-white">
        {currentUser.isLoggedIn ? (
          <div className="text-center space-y-3">
            <div className="relative w-16 h-16 mx-auto group">
              {currentUser.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-16 h-16 rounded-full mx-auto object-cover shadow-lg ring-4 ring-white/20"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-yellow-400 to-amber-200 text-slate-950 font-black text-2xl flex items-center justify-center mx-auto shadow-lg ring-4 ring-white/20">
                  {currentUser.name[0]?.toUpperCase() || 'U'}
                </div>
              )}
              {currentUserId && (
                <label
                  htmlFor="sidebar-avatar-input"
                  className="absolute bottom-0 right-0 p-1.5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 rounded-full shadow-md cursor-pointer transition-transform active:scale-90"
                  title="Upload profile picture to app-files"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <input
                    type="file"
                    id="sidebar-avatar-input"
                    accept="image/*"
                    onChange={handleAvatarFileChange}
                    className="hidden"
                    disabled={isUploadingAvatar}
                  />
                </label>
              )}
            </div>
            <div>
              <h3 className="text-xl font-black">{currentUser.name}</h3>
              <p className="text-xs text-blue-200 font-medium break-all">{currentUser.email || '@' + currentUser.username}</p>
              {currentUser.role === 'artist' ? (
                <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-yellow-400/20 text-yellow-300 text-xs font-bold border border-yellow-400/30">
                  <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
                  <span>Verified Artist • {currentUser.genre || 'Musician'}</span>
                </div>
              ) : (
                <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-yellow-400/20 text-yellow-300 text-xs font-bold border border-yellow-400/30">
                  <Check className="w-3.5 h-3.5" />
                  <span>Active Member • Free Streamer</span>
                </div>
              )}
            </div>

            {/* Quick Actions for Artists or Upgrade to Artist */}
            <div className="space-y-1.5 pt-1">
              <button
                onClick={onOpenUpload}
                className="w-full py-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 rounded-xl text-xs font-black shadow-md transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Music & Cover Photo</span>
              </button>

              <button
                onClick={onOpenArtistSetup}
                className="w-full py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-all border border-white/20 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <span>{currentUser.role === 'artist' ? 'Edit Artist Profile & Photo' : 'Create Artist Profile 🎵'}</span>
              </button>

              {onOpenWallet && (
                <button
                  type="button"
                  onClick={onOpenWallet}
                  className="w-full py-2 bg-[#02183d]/70 hover:bg-[#02183d] text-[#FFCC00] rounded-xl text-xs font-black transition-all border border-[#FFCC00]/40 cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <Wallet className="w-3.5 h-3.5" />
                  <span>Artist Wallet</span>
                </button>
              )}
            </div>

            <button
              onClick={onLogout}
              className="w-full py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-all border border-white/20 cursor-pointer"
            >
              Sign Out
            </button>
          </div>
        ) : (
          <div>
            <h3 className="text-2xl font-black tracking-tight mb-1 text-white">
              {isSignUp ? 'Create Account' : 'Welcome Back!'}
            </h3>
            <p className="text-xs text-blue-100/80 mb-3 font-medium">
              {isSignUp ? 'Join Teso Melodies to stream or upload music.' : 'Log in to your account or create a new one.'}
            </p>

            {/* 2) On the Sign In page: Show clear success message ABOVE the form */}
            {successMessage && !isSignUp && (
              <div className="mb-3.5 p-3 rounded-xl bg-emerald-950/70 border border-emerald-400/50 text-emerald-200 text-xs font-semibold leading-relaxed text-center animate-in fade-in duration-200 shadow-sm">
                {successMessage}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-3">
              {/* Account Role Selector during Sign Up */}
              {isSignUp && (
                <div className="p-1 bg-black/25 rounded-xl flex items-center gap-1 border border-white/15 mb-2">
                  <button
                    type="button"
                    onClick={() => setAccountType('fan')}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      accountType === 'fan'
                        ? 'bg-[#FFCC00] text-slate-950 shadow-sm'
                        : 'text-blue-200 hover:text-white'
                    }`}
                  >
                    🎧 Fan
                  </button>
                  <button
                    type="button"
                    onClick={() => setAccountType('artist')}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      accountType === 'artist'
                        ? 'bg-[#FFCC00] text-slate-950 shadow-sm'
                        : 'text-blue-200 hover:text-white'
                    }`}
                  >
                    🎵 Artist
                  </button>
                </div>
              )}

              {/* Artist Stage Name and Genre if Artist is chosen */}
              {isSignUp && accountType === 'artist' && (
                <>
                  <div>
                    <input
                      type="text"
                      value={stageName}
                      onChange={(e) => setStageName(e.target.value)}
                      placeholder="Stage / Musician Name (e.g. Master J)"
                      required
                      className="w-full bg-[#4a148c]/50 hover:bg-[#4a148c]/70 focus:bg-[#4a148c]/80 border border-purple-400/30 focus:border-yellow-400 rounded-xl px-4 py-2.5 text-xs text-white placeholder-purple-200/60 focus:outline-none transition-all shadow-inner font-semibold"
                    />
                  </div>
                  <div>
                    <select
                      value={genre}
                      onChange={(e) => setGenre(e.target.value)}
                      className="w-full bg-[#4a148c]/80 border border-purple-400/30 focus:border-yellow-400 rounded-xl px-3 py-2 text-xs text-white focus:outline-none transition-all"
                    >
                      <option value="teso worship">teso worship</option>
                      <option value="Gospel">Gospel</option>
                      <option value="Akoogo">Akoogo</option>
                      <option value="R&B">R&B</option>
                      <option value="Reggae">Reggae</option>
                      <option value="Rock">Rock</option>
                      <option value="Afrobeat">Afrobeat</option>
                      <option value="Country">Country</option>
                      <option value="Amapiano">Amapiano</option>
                      <option value="Jazz">Jazz</option>
                      <option value="Teso Dancehall">Teso Dancehall</option>
                    </select>
                  </div>
                </>
              )}

              {/* Email / Username Input */}
              <div className="relative">
                <User className="w-4 h-4 text-purple-300 absolute left-4 top-3.5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email"
                  required
                  className="w-full bg-[#4a148c]/50 hover:bg-[#4a148c]/70 focus:bg-[#4a148c]/80 border border-purple-400/30 focus:border-yellow-400 rounded-xl pl-11 pr-4 py-2.5 text-xs text-white placeholder-purple-200/60 focus:outline-none transition-all shadow-inner"
                />
              </div>

              {/* Password Input with eye toggle */}
              <div className="relative">
                <Lock className="w-4 h-4 text-purple-300 absolute left-4 top-3.5" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  required
                  className="w-full bg-[#4a148c]/50 hover:bg-[#4a148c]/70 focus:bg-[#4a148c]/80 border border-purple-400/30 focus:border-yellow-400 rounded-xl pl-11 pr-11 py-2.5 text-xs text-white placeholder-purple-200/60 focus:outline-none transition-all shadow-inner"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3.5 text-purple-300 hover:text-white transition-colors cursor-pointer"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* Error Message Under Form */}
              {authError && (
                <p className="text-xs text-red-200 bg-red-900/60 border border-red-500/50 rounded-lg p-2 text-center font-medium animate-in fade-in duration-150">
                  {authError}
                </p>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-sm rounded-xl shadow-lg transition-all active:scale-[0.98] cursor-pointer disabled:opacity-70"
              >
                {isLoading ? (isSignUp ? 'Signing Up...' : 'Logging In...') : (isSignUp ? 'Sign Up' : 'Login')}
              </button>

              {/* Sign up / Sign in toggle prompt */}
              <div className="text-center text-xs text-blue-100 font-medium pt-1">
                <span>{isSignUp ? 'Already have an account? ' : "Don't have an account? "}</span>
                <button
                  type="button"
                  onClick={() => {
                    setIsSignUp(!isSignUp);
                    setAuthError(null);
                    setSuccessMessage(null);
                  }}
                  className="text-yellow-300 hover:text-yellow-200 font-bold underline cursor-pointer"
                >
                  {isSignUp ? 'Sign In' : 'Sign Up'}
                </button>
              </div>

              {/* Divider */}
              <div className="flex items-center gap-3 my-2">
                <div className="h-px bg-white/20 flex-1" />
                <span className="text-[10px] text-blue-200 font-bold uppercase tracking-widest">
                  OR
                </span>
                <div className="h-px bg-white/20 flex-1" />
              </div>

              {/* Social Login 1: Continue with Facebook */}
              <button
                type="button"
                onClick={() =>
                  setAuthError('Facebook sign in is currently disabled on the backend. Please use Continue with Google or Email.')
                }
                className="w-full py-2 px-3 bg-[#1877F2] hover:bg-[#166fe5] text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
              >
                <svg className="w-4 h-4 fill-white shrink-0" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
                <span>{isSignUp ? 'Sign up with Facebook' : 'Continue with Facebook'}</span>
              </button>

              {/* Social Login 2: Continue with Google */}
              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={isLoading}
                className="w-full py-2 px-3 bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-70"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>{isSignUp ? 'Sign up with Google' : 'Continue with Google'}</span>
              </button>
            </form>
          </div>
        )}
      </div>

      {/* 2. Latest Announcements Card */}
      <div className="w-full bg-white rounded-2xl md:rounded-3xl p-4 sm:p-5 shadow-xl border border-slate-100">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-red-50 flex items-center justify-center text-red-500">
              <Megaphone className="w-4 h-4 fill-red-500" />
            </div>
            <h3 className="text-base font-black text-[#032b69] tracking-tight">
              Latest Announcements
            </h3>
          </div>
          <button
            onClick={() => {
              if (announcements.length > 0) onSelectAnnouncement(announcements[0]);
            }}
            className="text-xs font-bold text-[#E53935] hover:text-red-700 flex items-center gap-1 group cursor-pointer"
          >
            <span>View All</span>
            <span className="group-hover:translate-x-0.5 transition-transform">→</span>
          </button>
        </div>

        <div className="space-y-3">
          {announcements.map((ann) => (
            <div
              key={ann.id}
              onClick={() => onSelectAnnouncement(ann)}
              className="flex items-start gap-3 p-1.5 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer group"
            >
              <div className="w-11 h-11 rounded-lg overflow-hidden shrink-0 bg-slate-200 shadow-sm mt-0.5">
                <img
                  src={ann.thumbnail}
                  alt={ann.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-bold text-[#032b69] group-hover:text-blue-600 truncate transition-colors">
                  {ann.title}
                </h4>
                <p className="text-[11px] text-slate-500 line-clamp-2 leading-snug">
                  {ann.description}
                </p>
                <div className="text-[10px] text-slate-400 font-semibold text-right mt-1">
                  {ann.date}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Advertise Your Brand Here Card */}
      <div className="relative w-full rounded-2xl md:rounded-3xl overflow-hidden shadow-xl border border-blue-400/30 group bg-gradient-to-b from-[#032b69] to-[#02183d]">
        <div className="relative h-36 overflow-hidden">
          <img
            src={HERO_ASSETS.adMegaphone}
            alt="Advertise your brand with megaphone"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#021338] via-[#021338]/60 to-transparent flex flex-col justify-end p-4">
            <h3 className="text-lg font-black text-white leading-tight drop-shadow">
              Advertise<br />Your Brand Here
            </h3>
            <p className="text-[11px] text-blue-100 font-medium drop-shadow">
              Reach thousands of music lovers on Teso Melodies!
            </p>
          </div>
        </div>

        {/* Public Brand Inquiry CTA */}
        <div className="p-3.5 space-y-2 border-t border-blue-400/20 bg-[#02163b]">
          <div className="p-2.5 rounded-xl bg-blue-900/40 hover:bg-blue-900/60 border border-blue-400/20 transition-all flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-300 flex items-center justify-center shrink-0 border border-purple-400/30">
                <Megaphone className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-white truncate">Advertise on Teso Melodies</h4>
                <p className="text-[10px] text-blue-200/80 truncate">Promote brands, tracks & services</p>
              </div>
            </div>
            <button
              onClick={onOpenAdvertise}
              className="shrink-0 px-3 py-1.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-[11px] rounded-lg shadow transition-all active:scale-95 cursor-pointer"
            >
              Advertise
            </button>
          </div>

          {/* Admin-Only Publishing & Control Panel (Strict UI Gate) */}
          {isAdmin && (
            <div className="pt-2 space-y-2 border-t border-blue-400/20">
              <div className="text-[10px] font-black uppercase tracking-wider text-yellow-400 flex items-center justify-between">
                <span>Admin Controls</span>
                <span className="text-[9px] text-emerald-300 font-semibold">Verified Admin</span>
              </div>

              {onOpenAdminDashboard && (
                <button
                  onClick={onOpenAdminDashboard}
                  className="w-full py-2 px-3 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Open Admin News Panel</span>
                </button>
              )}

              <div className="grid grid-cols-2 gap-1.5">
                <button
                  onClick={onOpenPostNews}
                  className="px-2.5 py-1.5 bg-blue-900/60 hover:bg-blue-800 text-white font-bold text-[11px] rounded-lg border border-blue-400/30 flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Newspaper className="w-3.5 h-3.5 text-[#FFCC00]" />
                  <span>Post News</span>
                </button>
                <button
                  onClick={onOpenPublishLive}
                  className="px-2.5 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-[11px] rounded-lg flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Radio className="w-3.5 h-3.5" />
                  <span>Go Live</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 4. Top Artists Card */}
      <div className="w-full bg-white rounded-2xl md:rounded-3xl p-4 sm:p-5 shadow-xl border border-slate-100">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-pink-50 flex items-center justify-center text-[#e91e63]">
              <Users className="w-4 h-4" />
            </div>
            <h3 className="text-base font-black text-[#032b69] tracking-tight">
              Top Artists
            </h3>
          </div>
          <button
            onClick={() => {
              if (onViewAllArtists) onViewAllArtists();
              else if (topArtist) onFollowArtist(topArtist.id);
            }}
            className="text-xs font-bold text-[#E53935] hover:text-red-700 flex items-center gap-1 group cursor-pointer"
          >
            <span>View All</span>
            <span className="group-hover:translate-x-0.5 transition-transform">→</span>
          </button>
        </div>

        {(() => {
          const featuredArtists = (
            topArtists && topArtists.length > 0 ? topArtists : topArtist ? [topArtist] : []
          ).slice(0, 5);

          if (featuredArtists.length === 0) {
            return (
              <p className="text-xs text-slate-400 py-3 text-center">
                Loading top creators from Teso Melodies...
              </p>
            );
          }

          return (
            <div className="divide-y divide-slate-100">
              {featuredArtists.map((artist, index) => (
                <div
                  key={`sidebar-top-artist-${artist.id}-${index}`}
                  className="flex items-center justify-between gap-2 py-2.5 first:pt-1 last:pb-1"
                >
                  <a
                    href={getArtistSeoPath(artist.name)}
                    onClick={(e) => {
                      if (onSelectArtist && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) {
                        e.preventDefault();
                        onSelectArtist(artist);
                      }
                    }}
                    className={`flex items-center gap-2.5 min-w-0 flex-1 ${
                      onSelectArtist ? 'cursor-pointer group' : ''
                    }`}
                  >
                    <div
                      className={`w-6 h-6 rounded-full font-black text-xs flex items-center justify-center shrink-0 shadow-sm ${
                        index === 0
                          ? 'bg-[#FFCC00] text-black'
                          : index === 1
                            ? 'bg-slate-200 text-slate-800'
                            : index === 2
                              ? 'bg-amber-100 text-amber-900'
                              : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {index + 1}
                    </div>

                    <div className="w-11 h-11 rounded-full overflow-hidden shrink-0 ring-2 ring-blue-500/30 shadow-sm bg-slate-200">
                      <img
                        src={artist.avatar || HERO_ASSETS.announcement}
                        alt={artist.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    <div className="min-w-0">
                      <h4 className="text-sm font-bold text-slate-900 leading-tight truncate group-hover:text-[#0072ce] transition-colors">
                        {artist.name}
                      </h4>
                      <p className="text-xs text-slate-500 font-medium flex items-center gap-1.5 flex-wrap">
                        <span>
                          {artist.followers === 1
                            ? '1 follower'
                            : `${(artist.followers || 0).toLocaleString()} followers`}
                        </span>
                        {artist.totalLikes !== undefined && (
                          <>
                            <span className="text-slate-300">•</span>
                            <span className="text-red-600 font-bold flex items-center gap-0.5">
                              ❤️ {(artist.totalLikes || 0).toLocaleString()}
                            </span>
                          </>
                        )}
                      </p>
                    </div>
                  </a>

                  <button
                    onClick={() => onFollowArtist(artist.id)}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all shadow-sm active:scale-95 cursor-pointer shrink-0 ${
                      artist.isFollowed
                        ? 'bg-slate-100 text-slate-800 border border-slate-300 hover:bg-slate-200'
                        : 'bg-[#0072ce] hover:bg-[#005fb8] text-white'
                    }`}
                  >
                    {artist.isFollowed ? 'Following' : 'Follow'}
                  </button>
                </div>
              ))}
            </div>
          );
        })()}
      </div>

    </aside>
  );
};
