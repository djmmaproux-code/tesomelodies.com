import React, { useEffect } from 'react';
import {
  Download,
  X,
  Share,
  PlusSquare,
  Smartphone,
  WifiOff,
  CheckCircle2,
  MoreVertical,
  Music,
} from 'lucide-react';
import { useOnlineStatus } from '../hooks/usePWAInstall';

interface PWAInstallPromptProps {
  isVisible: boolean;
  isInstalled: boolean;
  isInstallable: boolean;
  isIOS: boolean;
  isAndroid: boolean;
  isInstalling: boolean;
  onInstall: () => Promise<'accepted' | 'dismissed' | 'unavailable'>;
  onMaybeLater: () => void;
  onClose: () => void;
  onInstalled?: () => void;
}

export const PWAInstallPrompt: React.FC<PWAInstallPromptProps> = ({
  isVisible,
  isInstalled,
  isInstallable,
  isIOS,
  isAndroid,
  isInstalling,
  onInstall,
  onMaybeLater,
  onClose,
  onInstalled,
}) => {
  useEffect(() => {
    if (!isVisible) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isVisible, onClose]);

  if (isInstalled || !isVisible) {
    return null;
  }

  const handleNativeInstall = async () => {
    const result = await onInstall();
    if (result === 'accepted' && onInstalled) {
      onInstalled();
    }
  };

  const showIOSInstructions = isIOS && !isInstallable;
  const showManualFallback = !isInstallable && !isIOS;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-sm animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pwa-install-title"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md rounded-2xl bg-[#032357] border border-[#0b4ca6] shadow-2xl overflow-hidden text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Accent Bar */}
        <div className="h-1 w-full bg-gradient-to-r from-[#034ea2] via-[#FFCC00] to-[#034ea2]" />

        {/* Close (X) Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Close install popup"
          className="absolute top-3.5 right-3.5 p-1.5 rounded-full text-blue-200/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-5 sm:p-6">
          {/* App Identity Header (Original Logo Untouched) */}
          <div className="flex items-center gap-4 pr-7">
            <div className="w-16 h-16 shrink-0 rounded-2xl bg-[#01010A] border border-white/15 shadow-lg overflow-hidden flex items-center justify-center">
              <img
                src="/pwa-192x192.png"
                alt="TESO MELODIES App Icon"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-wider text-[#FFCC00] flex items-center gap-1.5">
                <Smartphone className="w-3.5 h-3.5 shrink-0" />
                {showIOSInstructions
                  ? 'iPhone & iPad (Safari)'
                  : isAndroid
                    ? 'Official Android App'
                    : 'Official Web App'}
              </p>
              <h2
                id="pwa-install-title"
                className="text-lg sm:text-xl font-extrabold tracking-tight text-white leading-tight mt-0.5"
              >
                INSTALL TESO MELODIES
              </h2>
              <p className="text-xs text-blue-200/85 truncate mt-0.5">
                tesomelodies.com &bull; Home of Teso Music
              </p>
            </div>
          </div>

          {/* Native Android / Chromium Install View */}
          {isInstallable && (
            <>
              <div className="mt-4 rounded-xl bg-[#021940]/80 border border-white/10 p-3.5 space-y-2 text-xs sm:text-sm text-blue-100">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#FFCC00] shrink-0 mt-0.5" />
                  <span>Launch TESO MELODIES in one tap straight from your Home Screen.</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <Music className="w-4 h-4 text-[#FFCC00] shrink-0 mt-0.5" />
                  <span>Full-screen music player with live streaming and instant MP3 downloads.</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <Download className="w-4 h-4 text-[#FFCC00] shrink-0 mt-0.5" />
                  <span>Lightweight, fast, and always up to date with the latest Teso releases.</span>
                </div>
              </div>

              <div className="mt-5 flex flex-col gap-2.5">
                <button
                  type="button"
                  onClick={handleNativeInstall}
                  disabled={isInstalling}
                  className="w-full py-3 px-4 rounded-xl bg-[#FFCC00] hover:bg-[#ffd633] active:scale-[0.99] text-[#021940] font-extrabold text-sm sm:text-base shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-70"
                >
                  <Download className="w-4 h-4 stroke-[2.5]" />
                  {isInstalling ? 'Opening Installer...' : 'Install Now'}
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={onMaybeLater}
                    className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-blue-100 font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
                  >
                    Maybe Later
                  </button>
                  <button
                    type="button"
                    onClick={onClose}
                    className="py-2.5 px-3 rounded-xl bg-transparent hover:bg-white/10 border border-white/15 text-blue-200 font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
            </>
          )}

          {/* Separate Manual iPhone / iPad (iOS Safari) Installation Instructions */}
          {showIOSInstructions && (
            <>
              <p className="mt-4 text-xs sm:text-sm text-blue-100/90 leading-relaxed">
                Install TESO MELODIES on your iPhone or iPad in 3 quick steps using Safari:
              </p>

              <ol className="mt-3 space-y-2.5 text-xs sm:text-sm text-blue-100">
                <li className="flex items-start gap-3 rounded-xl bg-[#021940]/80 border border-white/10 p-3">
                  <span className="w-6 h-6 rounded-full bg-[#FFCC00] text-[#021940] font-extrabold text-xs flex items-center justify-center shrink-0">
                    1
                  </span>
                  <span className="leading-snug">
                    Tap the{' '}
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-white/15 text-white font-semibold align-middle">
                      <Share className="w-3.5 h-3.5 text-[#FFCC00]" />
                      Share
                    </span>{' '}
                    button in Safari&apos;s toolbar.
                  </span>
                </li>
                <li className="flex items-start gap-3 rounded-xl bg-[#021940]/80 border border-white/10 p-3">
                  <span className="w-6 h-6 rounded-full bg-[#FFCC00] text-[#021940] font-extrabold text-xs flex items-center justify-center shrink-0">
                    2
                  </span>
                  <span className="leading-snug">
                    Scroll down the menu and tap{' '}
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-white/15 text-white font-semibold align-middle">
                      <PlusSquare className="w-3.5 h-3.5 text-[#FFCC00]" />
                      Add to Home Screen
                    </span>
                    .
                  </span>
                </li>
                <li className="flex items-start gap-3 rounded-xl bg-[#021940]/80 border border-white/10 p-3">
                  <span className="w-6 h-6 rounded-full bg-[#FFCC00] text-[#021940] font-extrabold text-xs flex items-center justify-center shrink-0">
                    3
                  </span>
                  <span className="leading-snug">
                    Tap <strong className="text-white">Add</strong> in the top-right corner to place TESO MELODIES on your Home Screen.
                  </span>
                </li>
              </ol>

              <div className="mt-5 grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={onMaybeLater}
                  className="py-2.5 px-3 rounded-xl bg-[#FFCC00] hover:bg-[#ffd633] text-[#021940] font-extrabold text-xs sm:text-sm transition-colors cursor-pointer"
                >
                  Maybe Later
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </>
          )}

          {/* Manual Fallback (when permanent Install App button is tapped on browsers without beforeinstallprompt) */}
          {showManualFallback && (
            <>
              <p className="mt-4 text-xs sm:text-sm text-blue-100/90 leading-relaxed">
                Install TESO MELODIES directly from your browser menu:
              </p>

              <ol className="mt-3 space-y-2.5 text-xs sm:text-sm text-blue-100">
                <li className="flex items-start gap-3 rounded-xl bg-[#021940]/80 border border-white/10 p-3">
                  <span className="w-6 h-6 rounded-full bg-[#FFCC00] text-[#021940] font-extrabold text-xs flex items-center justify-center shrink-0">
                    1
                  </span>
                  <span className="leading-snug">
                    Open your browser menu{' '}
                    <span className="inline-flex items-center px-1 py-0.5 rounded bg-white/15 text-white align-middle">
                      <MoreVertical className="w-3.5 h-3.5 text-[#FFCC00]" />
                    </span>{' '}
                    or click the install icon in the address bar.
                  </span>
                </li>
                <li className="flex items-start gap-3 rounded-xl bg-[#021940]/80 border border-white/10 p-3">
                  <span className="w-6 h-6 rounded-full bg-[#FFCC00] text-[#021940] font-extrabold text-xs flex items-center justify-center shrink-0">
                    2
                  </span>
                  <span className="leading-snug">
                    Tap <strong className="text-white">Install app</strong> or{' '}
                    <strong className="text-white">Add to Home screen</strong> and confirm.
                  </span>
                </li>
              </ol>

              <div className="mt-5 grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={onMaybeLater}
                  className="py-2.5 px-3 rounded-xl bg-[#FFCC00] hover:bg-[#ffd633] text-[#021940] font-extrabold text-xs sm:text-sm transition-colors cursor-pointer"
                >
                  Maybe Later
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-20 left-3 z-[90] flex items-center gap-2 rounded-full bg-[#021940] border border-[#FFCC00]/50 px-3.5 py-2 text-xs font-semibold text-[#FFCC00] shadow-lg"
    >
      <WifiOff className="w-3.5 h-3.5 shrink-0" />
      <span>You are offline &mdash; reconnect to stream music</span>
    </div>
  );
};
