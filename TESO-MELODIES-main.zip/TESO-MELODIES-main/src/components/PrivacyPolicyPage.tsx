import React, { useState, useEffect } from 'react';
import { ShieldCheck, ArrowLeft, Printer, FileText, Mail, MapPin, Phone, Lock, ExternalLink, Calendar, Edit3, CheckCircle2 } from 'lucide-react';
import { getPrivacyPolicy, LegalDocument } from '../services/legalService';
import { isUserAdminEmail } from '../services/adminService';
import { UserProfile } from '../types/music';

interface PrivacyPolicyPageProps {
  onBackToHome: () => void;
  onNavigateToTerms: () => void;
  currentUser?: UserProfile;
  onOpenAdminLegal?: (docType: 'privacy' | 'terms') => void;
}

export const PrivacyPolicyPage: React.FC<PrivacyPolicyPageProps> = ({
  onBackToHome,
  onNavigateToTerms,
  currentUser,
  onOpenAdminLegal,
}) => {
  const [doc, setDoc] = useState<LegalDocument>(getPrivacyPolicy());
  const [activeSection, setActiveSection] = useState<string>('introduction');
  const isAdmin = isUserAdminEmail(currentUser?.email);

  useEffect(() => {
    setDoc(getPrivacyPolicy());
    document.title = 'Privacy Policy - TESO MELODIES.com | Official Legal Notice';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-in fade-in duration-200">
      
      {/* Top Breadcrumb & Action Header */}
      <div className="bg-white rounded-2xl md:rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-100 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToHome}
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            title="Back to Home"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Back to Home</span>
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-[#0072ce] text-[10px] font-black uppercase tracking-wider">
                Official Document
              </span>
              <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                Last Updated: {doc.lastUpdated}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-[#032b69] tracking-tight mt-0.5">
              TESO MELODIES Privacy Policy
            </h1>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {isAdmin && onOpenAdminLegal && (
            <button
              onClick={() => onOpenAdminLegal('privacy')}
              className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
              title="Edit Privacy Policy as Admin"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Admin: Edit Policy</span>
            </button>
          )}

          <button
            onClick={onNavigateToTerms}
            className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-blue-50 text-[#0072ce] font-bold text-xs flex items-center gap-1.5 transition-all border border-blue-200/60 cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Terms & Conditions</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            title="Print or Save PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Main Legal Content Container with Sidebar Table of Contents */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Table of Contents Sticky Sidebar */}
        <aside className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-2xl md:rounded-3xl p-5 shadow-xl border border-slate-100 sticky top-24">
            <div className="flex items-center gap-2 pb-3 mb-3 border-b border-slate-100">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <h3 className="text-sm font-black text-slate-900 tracking-tight">Table of Contents</h3>
            </div>
            
            <nav className="space-y-1 max-h-[60vh] overflow-y-auto pr-1 text-xs">
              {doc.sections.map((section, idx) => {
                const isActive = activeSection === section.id;
                return (
                  <a
                    key={section.id}
                    href={`#${section.id}`}
                    onClick={() => setActiveSection(section.id)}
                    className={`block py-1.5 px-2.5 rounded-lg font-medium transition-colors ${
                      isActive
                        ? 'bg-blue-50 text-[#0072ce] font-bold'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <span className="truncate block">{section.title}</span>
                  </a>
                );
              })}
            </nav>

            {/* Quick summary box */}
            <div className="mt-4 pt-4 border-t border-slate-100 bg-blue-50/60 rounded-xl p-3 text-[11px] text-blue-900 leading-relaxed">
              <p className="font-bold flex items-center gap-1 text-[#032b69] mb-1">
                <Lock className="w-3.5 h-3.5 text-blue-600" />
                <span>Our Privacy Promise</span>
              </p>
              We do not sell, rent, or trade your personal data. We use Supabase and Google OAuth strictly to authenticate your account and stream music.
            </div>
          </div>
        </aside>

        {/* Legal Text Document Content */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white rounded-2xl md:rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-100 text-slate-700 space-y-6 leading-relaxed">
            
            {/* Header Badge & Brand Info */}
            <div className="pb-4 border-b border-slate-100">
              <div className="text-xs text-slate-500 font-medium">
                Website: <span className="text-[#032b69] font-bold">TESO MELODIES.com</span> • Jurisdiction: <span className="text-slate-800 font-bold">{doc.governingJurisdiction}</span>
              </div>
              <div className="text-xs text-slate-500 font-medium mt-1">
                Contact Email: <a href={`mailto:${doc.contactEmail}`} className="text-[#0072ce] font-bold underline">{doc.contactEmail}</a>
              </div>
            </div>

            {/* Sections */}
            {doc.sections.map((section) => (
              <section key={section.id} id={section.id} className="pt-2 scroll-mt-28">
                <h2 className="text-base sm:text-lg font-black text-[#032b69] pb-2 border-b border-slate-100/80 flex items-center gap-2">
                  <span>{section.title}</span>
                </h2>
                <div className="text-xs sm:text-sm text-slate-600 font-normal leading-relaxed whitespace-pre-line mt-3 space-y-2">
                  {section.content}
                </div>
              </section>
            ))}

            {/* Bottom Contact Verification Banner */}
            <div className="mt-8 pt-6 border-t border-slate-200/80 bg-slate-50 rounded-2xl p-5 text-xs text-slate-600 space-y-2">
              <h4 className="font-bold text-[#032b69] text-sm flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Verified Legal Record – TESO MELODIES</span>
              </h4>
              <p>
                This document is publicly accessible and maintained in accordance with the laws of the Republic of Uganda. For formal legal notices or inquiries, please write directly to <span className="font-bold text-[#032b69]">tesomelodies@gmail.com</span>.
              </p>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
