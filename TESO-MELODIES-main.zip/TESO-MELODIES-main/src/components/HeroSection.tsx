import React from 'react';
import { User, LogIn, Music, Users, Heart, Megaphone, Bell, Upload, Sparkles } from 'lucide-react';
import { HERO_ASSETS } from '../data/initialData';
import { UserProfile } from '../types/music';

interface HeroSectionProps {
  currentUser: UserProfile;
  onOpenSignUp: () => void;
  onOpenLogin: () => void;
  onOpenUpload: () => void;
  onOpenEarn: () => void;
  onOpenAdvertise: () => void;
  onOpenAnnouncements: () => void;
  onSupportArtists?: () => void;
  onOpenArtistSetup?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  currentUser,
  onOpenSignUp,
  onOpenLogin,
  onOpenUpload,
  onOpenEarn,
  onOpenAdvertise,
  onOpenAnnouncements,
  onSupportArtists,
  onOpenArtistSetup,
}) => {
  return (
    <div className="relative w-full rounded-2xl md:rounded-3xl overflow-hidden shadow-2xl border border-blue-400/30 bg-gradient-to-r from-[#034ea2] via-[#2a2b7c] to-[#6d1b7b]">
      
      {/* Background panoramic sunset with the man wearing headphones */}
      <div className="relative min-h-[340px] md:min-h-[390px] lg:min-h-[420px] flex flex-col justify-between overflow-hidden">
        
        {/* Scenic hero man photograph right aligned */}
        <div className="absolute inset-0 z-0">
          <img
            src={HERO_ASSETS.heroMan}
            alt="Man vibing with headphones at sunset"
            className="w-full h-full object-cover object-right md:object-[75%_center]"
            referrerPolicy="no-referrer"
          />
          {/* Measured gradient scrim for crystal clear readability on the left */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#032b69]/95 via-[#0c397b]/80 md:via-[#0c397b]/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#021b44]/90 via-transparent to-transparent md:hidden" />
        </div>

        {/* Hero Content Area */}
        <div className="relative z-10 px-5 sm:px-8 md:px-10 pt-7 md:pt-9 pb-4 max-w-2xl lg:max-w-2xl">
          {/* Slogan Kicker */}
          <div className="text-[11px] sm:text-xs font-extrabold tracking-widest uppercase text-cyan-300 drop-shadow flex items-center gap-1.5 mb-1.5">
            <span>YOUR MUSIC</span>
            <span className="text-yellow-400 font-bold">•</span>
            <span>YOUR VIBES</span>
            <span className="text-yellow-400 font-bold">•</span>
            <span>OUR COMMUNITY</span>
          </div>

          {/* Main Title: TESO MELODIES */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-none text-white drop-shadow-md">
            TESO <span className="text-[#FFCC00]">MELODIES</span>
          </h1>

          {/* Slogan: Music Unites Us (in cursive script) */}
          <div className="font-script text-3xl sm:text-4xl md:text-5xl text-white font-bold tracking-wide -mt-1 sm:-mt-2 mb-3 drop-shadow-lg">
            Music Unites Us
          </div>

          {/* Description */}
          <p className="text-xs sm:text-sm text-blue-100/90 leading-relaxed font-medium mb-6 max-w-lg drop-shadow">
            Stream, watch, share and support your favorite artists, Upload your music and videos, get discovered, and earn. All for free — no charges for downloads, comments, likes or sharing!
          </p>

          {/* CTA Action Buttons: Automatically hidden when user is authenticated */}
          {!currentUser.isLoggedIn ? (
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={onOpenSignUp}
                className="inline-flex items-center gap-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs sm:text-sm px-5 sm:px-6 py-2.5 rounded-xl shadow-lg hover:shadow-xl transition-all active:scale-95 cursor-pointer"
              >
                <User className="w-4 h-4 fill-current" />
                <span>Sign Up Free</span>
              </button>

              <button
                onClick={onOpenLogin}
                className="inline-flex items-center gap-2 bg-blue-950/40 hover:bg-blue-900/60 text-white font-bold text-xs sm:text-sm px-5 sm:px-6 py-2.5 rounded-xl border border-white/40 backdrop-blur-sm shadow-md hover:shadow-lg transition-all active:scale-95 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>Login</span>
              </button>
            </div>
          ) : (
            <div className="flex flex-wrap items-center gap-3">
              <div className="inline-flex items-center gap-2.5 bg-blue-900/60 backdrop-blur-md border border-cyan-400/40 rounded-xl px-4 py-2 shadow-lg">
                <div className="w-7 h-7 rounded-full bg-[#FFCC00] text-slate-950 font-black text-xs flex items-center justify-center shadow-md">
                  {currentUser.name[0]?.toUpperCase() || 'U'}
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5 leading-tight">
                    <span>Welcome back, {currentUser.name}!</span>
                    <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
                  </div>
                  <div className="text-[10px] text-cyan-200">Active Member • Free Streaming</div>
                </div>
              </div>

              <button
                onClick={onOpenUpload}
                className="inline-flex items-center gap-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs sm:text-sm px-4 sm:px-5 py-2.5 rounded-xl shadow-lg transition-all active:scale-95 cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Upload Music</span>
              </button>

              {onOpenArtistSetup && (
                <button
                  onClick={onOpenArtistSetup}
                  className="inline-flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white font-bold text-xs sm:text-sm px-3.5 sm:px-4 py-2.5 rounded-xl border border-white/20 backdrop-blur-sm transition-all active:scale-95 cursor-pointer"
                >
                  <span>{currentUser.role === 'artist' ? 'Artist Profile' : 'Become Artist 🎵'}</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Right side floating brand badge next to the man */}
        <div className="absolute right-4 md:right-8 bottom-16 sm:bottom-20 z-10 text-right pointer-events-none hidden sm:block">
          <div className="flex items-center justify-end gap-1.5 text-yellow-300 drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]">
            <span className="font-script text-3xl md:text-4xl lg:text-5xl font-black text-[#FFCC00]">
              Teso
            </span>
            {/* Equalizer mini graphic */}
            <svg viewBox="0 0 24 24" className="w-6 h-6 fill-[#FFCC00]" xmlns="http://www.w3.org/2000/svg">
              <rect x="2" y="8" width="2" height="8" rx="1" />
              <rect x="6" y="4" width="2" height="16" rx="1" />
              <rect x="10" y="2" width="2" height="20" rx="1" />
              <rect x="14" y="5" width="2" height="14" rx="1" />
              <rect x="18" y="9" width="2" height="6" rx="1" />
            </svg>
          </div>
          <div className="font-script text-2xl md:text-3xl text-white font-bold drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)] -mt-2">
            Melodies
          </div>
          <div className="text-[10px] md:text-xs font-semibold text-yellow-300 drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)] tracking-wider mt-0.5">
            Music • Videos • Community • Earnings
          </div>
        </div>

        {/* Bottom Feature Strip (Glass Bar inside Hero) */}
        <div className="relative z-10 bg-slate-950/70 backdrop-blur-md border-t border-white/15 px-3 sm:px-6 py-2.5">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 sm:gap-3">
            
            {/* Feature 1 */}
            <button
              onClick={onOpenUpload}
              className="flex items-center gap-2.5 text-left text-white group p-2 rounded-xl bg-white/5 hover:bg-white/15 transition-all cursor-pointer min-h-[44px]"
            >
              <div className="p-1.5 rounded-lg bg-white/10 group-hover:bg-yellow-400/20 shrink-0">
                <Music className="w-4 h-4 text-white group-hover:text-yellow-300" />
              </div>
              <div className="leading-tight min-w-0">
                <div className="text-xs font-bold truncate">Upload Music</div>
                <div className="text-[10px] text-blue-200/80 group-hover:text-blue-100 truncate">& Videos</div>
              </div>
            </button>

            {/* Feature 2 */}
            <button
              onClick={onOpenEarn}
              className="flex items-center gap-2.5 text-left text-white group p-2 rounded-xl bg-white/5 hover:bg-white/15 transition-all cursor-pointer min-h-[44px]"
            >
              <div className="p-1.5 rounded-lg bg-white/10 group-hover:bg-yellow-400/20 shrink-0">
                <Users className="w-4 h-4 text-white group-hover:text-yellow-300" />
              </div>
              <div className="leading-tight min-w-0">
                <div className="text-xs font-bold truncate">Get Discovered</div>
                <div className="text-[10px] text-blue-200/80 group-hover:text-blue-100 truncate">& Earn</div>
              </div>
            </button>

            {/* Feature 3 */}
            <button
              onClick={onSupportArtists}
              className="flex items-center gap-2.5 text-left text-white group p-2 rounded-xl bg-white/5 hover:bg-white/15 transition-all cursor-pointer min-h-[44px]"
            >
              <div className="p-1.5 rounded-lg bg-white/10 group-hover:bg-yellow-400/20 shrink-0">
                <Heart className="w-4 h-4 text-white group-hover:text-red-400" />
              </div>
              <div className="leading-tight min-w-0">
                <div className="text-xs font-bold truncate">Support Artists</div>
                <div className="text-[10px] text-blue-200/80 group-hover:text-blue-100 truncate">(Like / Comment)</div>
              </div>
            </button>

            {/* Feature 4 */}
            <button
              onClick={onOpenAdvertise}
              className="flex items-center gap-2.5 text-left text-white group p-2 rounded-xl bg-white/5 hover:bg-white/15 transition-all cursor-pointer min-h-[44px]"
            >
              <div className="p-1.5 rounded-lg bg-white/10 group-hover:bg-yellow-400/20 shrink-0">
                <Megaphone className="w-4 h-4 text-white group-hover:text-yellow-300" />
              </div>
              <div className="leading-tight min-w-0">
                <div className="text-xs font-bold truncate">Advertise</div>
                <div className="text-[10px] text-blue-200/80 group-hover:text-blue-100 truncate">Your Brand</div>
              </div>
            </button>

            {/* Feature 5 */}
            <button
              onClick={onOpenAnnouncements}
              className="flex items-center gap-2.5 text-left text-white group p-2 rounded-xl bg-white/5 hover:bg-white/15 transition-all cursor-pointer min-h-[44px] col-span-2 sm:col-span-1"
            >
              <div className="p-1.5 rounded-lg bg-white/10 group-hover:bg-yellow-400/20 shrink-0">
                <Bell className="w-4 h-4 text-white group-hover:text-yellow-300" />
              </div>
              <div className="leading-tight min-w-0">
                <div className="text-xs font-bold truncate">Latest News</div>
                <div className="text-[10px] text-blue-200/80 group-hover:text-blue-100 truncate">& Announcements</div>
              </div>
            </button>

          </div>
        </div>
      </div>
    </div>
  );
};
