import React, { useMemo, useState } from 'react';
import { Video, Play, Upload, RotateCw, Heart, Share2, Trash2, AlertCircle, Film } from 'lucide-react';
import { VideoItem, VideoQualityKey } from '../types/music';
import { VIDEO_QUALITY_ORDER } from '../services/videoService';

interface VideosLibraryProps {
  videos: VideoItem[];
  isLoading: boolean;
  error: string | null;
  searchQuery: string;
  onRefresh: () => void;
  onOpenUpload: () => void;
  onSelectVideo: (video: VideoItem) => void;
  onShareVideo: (video: VideoItem) => void;
  onLikeVideo: (videoId: string) => void;
  onDeleteVideo: (video: VideoItem) => void;
  likedVideoIds: Set<string>;
  currentUserId?: string | null;
  isAdmin?: boolean;
}

export const VideosLibrary: React.FC<VideosLibraryProps> = ({
  videos,
  isLoading,
  error,
  searchQuery,
  onRefresh,
  onOpenUpload,
  onSelectVideo,
  onShareVideo,
  onLikeVideo,
  onDeleteVideo,
  likedVideoIds,
  currentUserId,
  isAdmin = false,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'newest' | 'views' | 'likes'>('newest');

  const categories = useMemo(() => {
    const set = new Set<string>(['All']);
    videos.forEach((v) => {
      if (v.category) set.add(v.category);
    });
    return Array.from(set);
  }, [videos]);

  const filteredVideos = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = videos.filter((v) => {
      const matchesCat =
        selectedCategory === 'All' || v.category.toLowerCase() === selectedCategory.toLowerCase();
      const matchesSearch =
        !q ||
        v.title.toLowerCase().includes(q) ||
        v.artist.toLowerCase().includes(q) ||
        (v.description || '').toLowerCase().includes(q) ||
        v.category.toLowerCase().includes(q);
      return matchesCat && matchesSearch;
    });

    if (sortBy === 'views') {
      return [...list].sort((a, b) => (b.viewsCount || 0) - (a.viewsCount || 0));
    }
    if (sortBy === 'likes') {
      return [...list].sort((a, b) => (b.likes || 0) - (a.likes || 0));
    }
    return list;
  }, [videos, selectedCategory, searchQuery, sortBy]);

  const getHighestQualityBadge = (video: VideoItem): VideoQualityKey => {
    if (video.qualityUrls) {
      for (const q of VIDEO_QUALITY_ORDER) {
        if (video.qualityUrls[q]) return q;
      }
    }
    return video.defaultQuality || '720p';
  };

  return (
    <div className="space-y-5">
      {/* Header Card */}
      <div className="bg-white rounded-2xl md:rounded-3xl p-4 sm:p-6 shadow-xl border border-slate-100">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center shrink-0">
              <Video className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-[#032b69] tracking-tight">
                Official Music Videos &amp; Visualizers
              </h2>
              <p className="text-xs text-slate-500 font-medium tabular-nums">
                {videos.length} {videos.length === 1 ? 'video' : 'videos'} streaming in HD on Teso Melodies
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onRefresh}
              disabled={isLoading}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
            >
              <RotateCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#0072ce]' : ''}`} />
              <span>Refresh</span>
            </button>

            <button
              onClick={onOpenUpload}
              className="px-4 py-2 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Video</span>
            </button>
          </div>
        </div>

        {/* Category Filter Tabs & Sort */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-[#0072ce] text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
            <span className="text-[11px] text-slate-500 font-semibold">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'newest' | 'views' | 'likes')}
              className="px-2.5 py-1.5 text-xs font-bold bg-slate-100 text-slate-800 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0072ce] cursor-pointer"
            >
              <option value="newest">Newest</option>
              <option value="views">Most Viewed</option>
              <option value="likes">Most Liked</option>
            </select>
          </div>
        </div>

        {/* Loading State */}
        {isLoading && videos.length === 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div
                key={`video-skeleton-${i}`}
                className="rounded-2xl overflow-hidden border border-slate-200 bg-slate-50 animate-pulse"
              >
                <div className="aspect-video w-full bg-slate-200" />
                <div className="p-3.5 space-y-2">
                  <div className="h-4 bg-slate-200 rounded w-3/4" />
                  <div className="h-3 bg-slate-200 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          /* Error State */
          <div className="py-12 px-4 text-center rounded-2xl border border-red-200 bg-red-50/70">
            <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-slate-900">Unable to load videos</h3>
            <p className="text-xs text-slate-600 mt-1 mb-4 max-w-md mx-auto">{error}</p>
            <button
              onClick={onRefresh}
              className="px-4 py-2 bg-[#0072ce] hover:bg-blue-700 text-white font-bold text-xs rounded-xl cursor-pointer inline-flex items-center gap-1.5"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Retry</span>
            </button>
          </div>
        ) : filteredVideos.length === 0 ? (
          /* Empty State (Real Database, Zero Sample Videos) */
          <div className="py-14 px-4 text-center rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50/70">
            <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center">
              <Film className="w-7 h-7" />
            </div>
            <h3 className="text-base font-black text-[#032b69]">
              {videos.length === 0 ? 'No videos uploaded yet' : 'No matching videos found'}
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4">
              {videos.length === 0
                ? 'Be the first artist or creator to upload an official music video, live session, or worship performance to Teso Melodies.'
                : 'Try clearing your search or switching video categories.'}
            </p>
            {videos.length === 0 ? (
              <button
                onClick={onOpenUpload}
                className="px-5 py-2.5 bg-[#FFCC00] hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow cursor-pointer inline-flex items-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload First Video</span>
              </button>
            ) : (
              <button
                onClick={() => setSelectedCategory('All')}
                className="px-4 py-2 bg-[#0072ce] text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                Show All Videos
              </button>
            )}
          </div>
        ) : (
          /* Responsive 16:9 Video Cards Grid */
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredVideos.map((vid) => {
              const isLiked = likedVideoIds.has(vid.id);
              const canDelete = Boolean(
                isAdmin || (currentUserId && vid.userId && currentUserId === vid.userId)
              );
              const topQuality = getHighestQualityBadge(vid);

              return (
                <div
                  key={`video-card-${vid.id}`}
                  className="group bg-slate-50 hover:bg-blue-50/60 rounded-2xl overflow-hidden border border-slate-200/80 shadow-sm hover:shadow-md transition-all flex flex-col"
                >
                  {/* 16:9 Video Thumbnail */}
                  <div
                    onClick={() => onSelectVideo(vid)}
                    className="relative aspect-video w-full overflow-hidden bg-slate-900 cursor-pointer"
                  >
                    <img
                      src={vid.thumbnail}
                      alt={vid.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent flex items-center justify-center">
                      <div className="w-12 h-12 rounded-full bg-[#FFCC00] text-slate-950 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                        <Play className="w-5 h-5 fill-current ml-0.5" />
                      </div>
                    </div>
                    <span className="absolute top-2 right-2 bg-black/75 text-white text-[10px] font-bold px-2 py-0.5 rounded tabular-nums">
                      {topQuality}
                    </span>
                    <span className="absolute bottom-2 right-2 bg-black/80 text-white text-[10px] font-bold px-2 py-0.5 rounded tabular-nums">
                      {vid.duration}
                    </span>
                  </div>

                  {/* Card Details */}
                  <div className="p-3.5 flex-1 flex flex-col justify-between gap-2">
                    <div className="cursor-pointer" onClick={() => onSelectVideo(vid)}>
                      <h3 className="text-sm font-bold text-slate-900 group-hover:text-[#0072ce] line-clamp-2 leading-snug transition-colors">
                        {vid.title}
                      </h3>
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-600 font-medium mt-1">
                        <span className="font-semibold text-slate-800">{vid.artist}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-slate-500">{vid.category}</span>
                      </div>
                      {vid.description && (
                        <p className="text-[11px] text-slate-500 line-clamp-2 mt-1 leading-snug">
                          {vid.description}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-200/70 text-[11px] text-slate-500 font-medium tabular-nums">
                      <div className="flex items-center gap-1.5 truncate">
                        <span>{vid.views}</span>
                        <span aria-hidden="true">·</span>
                        <span>{vid.releaseDate}</span>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => onLikeVideo(vid.id)}
                          className={`px-2 py-1 rounded-lg flex items-center gap-1 text-[11px] font-bold transition-colors cursor-pointer ${
                            isLiked
                              ? 'bg-red-50 text-red-600'
                              : 'hover:bg-slate-200/70 text-slate-600'
                          }`}
                          title={isLiked ? 'Unlike video' : 'Like video'}
                        >
                          <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-red-500 text-red-500' : ''}`} />
                          <span>{vid.likes || 0}</span>
                        </button>

                        <button
                          onClick={() => onShareVideo(vid)}
                          className="p-1.5 rounded-lg hover:bg-slate-200/70 text-slate-600 transition-colors cursor-pointer"
                          title="Share video link"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                        </button>

                        {canDelete && (
                          <button
                            onClick={() => {
                              if (window.confirm(`Delete "${vid.title}" permanently from Teso Melodies?`)) {
                                onDeleteVideo(vid);
                              }
                            }}
                            className="p-1.5 rounded-lg hover:bg-red-100 text-red-600 transition-colors cursor-pointer"
                            title="Delete video"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
