import { useState, useEffect, useCallback } from 'react';

export interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

const DISMISS_STORAGE_KEY = 'teso_pwa_dismissed_until';
const MAYBE_LATER_COOLDOWN_MS = 3 * 24 * 60 * 60 * 1000; // 3 days
const CLOSE_COOLDOWN_MS = 14 * 24 * 60 * 60 * 1000; // 14 days
const AUTO_SHOW_DELAY_MS = 2500;

function checkIsStandaloneInstalled(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    if (window.matchMedia('(display-mode: standalone)').matches) return true;
    if (window.matchMedia('(display-mode: fullscreen)').matches) return true;
    if ((window.navigator as Navigator & { standalone?: boolean }).standalone === true) return true;
    if (document.referrer && document.referrer.startsWith('android-app://')) return true;
  } catch {
    // Ignore matchMedia errors in unsupported environments
  }
  return false;
}

function detectIOSDevice(): boolean {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent || '';
  if (/iphone|ipad|ipod/i.test(ua)) return true;
  if (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1) return true;
  return false;
}

function detectAndroidDevice(): boolean {
  if (typeof navigator === 'undefined') return false;
  return /android/i.test(navigator.userAgent || '');
}

function isInDismissCooldown(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const raw = window.localStorage.getItem(DISMISS_STORAGE_KEY);
    if (!raw) return false;
    const until = Number(raw);
    return Number.isFinite(until) && Date.now() < until;
  } catch {
    return false;
  }
}

function setDismissCooldown(durationMs: number): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(DISMISS_STORAGE_KEY, String(Date.now() + durationMs));
  } catch {
    // Ignore storage quota / privacy mode errors
  }
}

function clearDismissCooldown(): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.removeItem(DISMISS_STORAGE_KEY);
  } catch {
    // Ignore storage errors
  }
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(() => checkIsStandaloneInstalled());
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [isInstalling, setIsInstalling] = useState<boolean>(false);
  const [isManualOpen, setIsManualOpen] = useState<boolean>(false);

  const isIOS = detectIOSDevice();
  const isAndroid = detectAndroidDevice();

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const standaloneQuery = window.matchMedia('(display-mode: standalone)');

    const syncInstalledState = () => {
      const installed = checkIsStandaloneInstalled();
      setIsInstalled(installed);
      if (installed) {
        setIsVisible(false);
        setIsManualOpen(false);
        setDeferredPrompt(null);
      }
    };

    syncInstalledState();

    const handleBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      if (checkIsStandaloneInstalled()) return;
      setDeferredPrompt(event as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setIsVisible(false);
      setIsManualOpen(false);
      setDeferredPrompt(null);
      clearDismissCooldown();
    };

    const handleDisplayModeChange = (e: MediaQueryListEvent) => {
      if (e.matches) {
        handleAppInstalled();
      }
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    if (typeof standaloneQuery.addEventListener === 'function') {
      standaloneQuery.addEventListener('change', handleDisplayModeChange);
    } else if (typeof standaloneQuery.addListener === 'function') {
      standaloneQuery.addListener(handleDisplayModeChange);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      if (typeof standaloneQuery.removeEventListener === 'function') {
        standaloneQuery.removeEventListener('change', handleDisplayModeChange);
      } else if (typeof standaloneQuery.removeListener === 'function') {
        standaloneQuery.removeListener(handleDisplayModeChange);
      }
    };
  }, []);

  // Auto-show install popup once browser signals native installability (Android/Chrome)
  // or on iPhone/iPad Safari, respecting cooldown and installed state.
  useEffect(() => {
    if (isInstalled || isManualOpen) return;
    if (isInDismissCooldown()) return;

    const canAutoPrompt = Boolean(deferredPrompt) || isIOS;
    if (!canAutoPrompt) return;

    const timer = window.setTimeout(() => {
      if (!checkIsStandaloneInstalled() && !isInDismissCooldown()) {
        setIsVisible(true);
      }
    }, AUTO_SHOW_DELAY_MS);

    return () => window.clearTimeout(timer);
  }, [deferredPrompt, isIOS, isInstalled, isManualOpen]);

  const install = useCallback(async (): Promise<'accepted' | 'dismissed' | 'unavailable'> => {
    if (!deferredPrompt) {
      return 'unavailable';
    }
    setIsInstalling(true);
    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      setDeferredPrompt(null);

      if (outcome === 'accepted') {
        setIsInstalled(true);
        setIsVisible(false);
        setIsManualOpen(false);
        clearDismissCooldown();
        return 'accepted';
      }

      setIsVisible(false);
      setIsManualOpen(false);
      setDismissCooldown(MAYBE_LATER_COOLDOWN_MS);
      return 'dismissed';
    } catch {
      setDeferredPrompt(null);
      return 'unavailable';
    } finally {
      setIsInstalling(false);
    }
  }, [deferredPrompt]);

  const dismissMaybeLater = useCallback(() => {
    setIsVisible(false);
    setIsManualOpen(false);
    setDismissCooldown(MAYBE_LATER_COOLDOWN_MS);
  }, []);

  const dismissClose = useCallback(() => {
    setIsVisible(false);
    setIsManualOpen(false);
    setDismissCooldown(CLOSE_COOLDOWN_MS);
  }, []);

  const openInstallModal = useCallback(() => {
    if (checkIsStandaloneInstalled() || isInstalled) return;
    setIsManualOpen(true);
    setIsVisible(true);
  }, [isInstalled]);

  return {
    isInstallable: Boolean(deferredPrompt) && !isInstalled,
    isInstalled,
    isIOS,
    isAndroid,
    isVisible: isVisible && !isInstalled,
    isInstalling,
    install,
    dismissMaybeLater,
    dismissClose,
    openInstallModal,
  };
}

export function useOnlineStatus(): boolean {
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
}
