export interface Song {
  id: string;
  title: string;
  artist: string;
  duration: string;
  durationSec: number;
  coverUrl: string;
  category: 'new' | 'trending' | 'hot100';
  rank?: number;
  genre: string;
  plays: number;
  likes: number;
  downloadsCount?: number;
  description?: string;
  audioToneFreq?: number; // For synthesized melodic audio preview
  userId?: string;
  artistId?: string;
  audioUrl?: string;
  audioPath?: string;
  coverPath?: string;
  audioSize?: number;
  audioMimeType?: string;
  storageProvider?: string;
  isRealUpload?: boolean;
  isPublished?: boolean;
  createdAt?: string;
  artistAvatar?: string;
}

export interface Announcement {
  id: string;
  title: string;
  description: string;
  fullContent?: string;
  date: string;
  thumbnail: string;
  badge?: string;
}

export interface Artist {
  id: string;
  name: string;
  genre: string;
  followers: number;
  isFollowed?: boolean;
  avatar: string;
  bio: string;
  location?: string;
  monthlyListeners: string;
  topTracks?: string[];
  userId?: string;
  legacyFollowUserId?: string;
  isRealArtist?: boolean;
  totalSongs?: number;
  totalLikes?: number;
  totalDownloads?: number;
  realFollowers?: number;
  songBonusFollowers?: number;
}

export interface Genre {
  id: string;
  name: string;
  color: string;
  icon: string;
}

export interface UserProfile {
  id?: string;
  name: string;
  username: string;
  email: string;
  isLoggedIn: boolean;
  avatar?: string;
  role: 'fan' | 'artist';
  stageName?: string;
  bio?: string;
  genre?: string;
  location?: string;
  totalSongs?: number;
  totalLikes?: number;
  totalDownloads?: number;
}

export type VideoQualityKey = '360p' | '480p' | '720p' | '1080p';

export interface VideoItem {
  id: string;
  userId?: string;
  title: string;
  artist: string;
  description?: string;
  category: string;
  views: string;
  viewsCount: number;
  likes: number;
  duration: string;
  durationSec?: number;
  thumbnail: string;
  videoUrl: string;
  videoPath?: string;
  thumbnailPath?: string;
  fileSize?: number;
  mimeType?: string;
  qualityUrls?: Partial<Record<VideoQualityKey, string>>;
  defaultQuality?: VideoQualityKey;
  genre: string;
  releaseDate: string;
  createdAt?: string;
  isRealUpload?: boolean;
}
