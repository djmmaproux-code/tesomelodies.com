import { supabase } from '../supabaseClient';
import { Announcement } from '../types/music';
import { HERO_ASSETS } from '../data/initialData';
import { uploadAppFile } from './storageService';
import { normalizeR2Url } from './musicService';

export type NewsStatus = 'draft' | 'published' | 'archived';

export interface NewsArticle {
  id: string;
  title: string;
  description: string;
  fullContent: string;
  category: string;
  badge: string;
  imageUrl: string;
  status: NewsStatus;
  authorId?: string;
  authorEmail?: string;
  publishedAt: string;
  createdAt: string;
  updatedAt: string;
}

const AUTHORIZED_ADMIN_EMAIL = 'tesomelodies@gmail.com';

const isMissingTableError = (err: any): boolean => {
  if (!err) return false;
  const code = String(err.code || '').toUpperCase();
  const msg = String(err.message || err.error || '').toLowerCase();
  return (
    code === 'PGRST205' ||
    code === '42P01' ||
    msg.includes('could not find the table') ||
    msg.includes('does not exist')
  );
};

export const formatNewsDate = (iso?: string | null): string => {
  if (!iso) {
    return new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  }
  const parsed = new Date(iso);
  if (Number.isNaN(parsed.getTime())) return String(iso);
  return parsed.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
};

export const mapNewsRow = (row: any): NewsArticle => {
  const createdAt = row.created_at || row.createdAt || new Date().toISOString();
  const publishedAt = row.published_at || row.publishedAt || createdAt;
  const category = String(row.category || row.badge || 'Portal News').trim();
  const badge = String(row.badge || category || 'News').trim();
  const rawImg = String(row.image_url || row.imageUrl || row.thumbnail || '').trim();
  const normalizedImg = rawImg ? normalizeR2Url(rawImg) || rawImg : '';

  return {
    id: String(row.id),
    title: String(row.title || 'Untitled').trim(),
    description: String(row.description || '').trim(),
    fullContent: String(row.full_content || row.fullContent || row.description || '').trim(),
    category,
    badge,
    imageUrl: normalizedImg || HERO_ASSETS.announcement,
    status: (['draft', 'published', 'archived'].includes(String(row.status))
      ? row.status
      : 'published') as NewsStatus,
    authorId: row.author_id || row.authorId || undefined,
    authorEmail: row.author_email || row.authorEmail || undefined,
    publishedAt,
    createdAt,
    updatedAt: row.updated_at || row.updatedAt || createdAt,
  };
};

export const toAnnouncement = (article: NewsArticle): Announcement => ({
  id: article.id,
  title: article.title,
  description: article.description,
  fullContent: article.fullContent || article.description,
  date: formatNewsDate(article.publishedAt || article.createdAt),
  thumbnail: article.imageUrl || HERO_ASSETS.announcement,
  badge: article.badge || article.category || 'News',
});

async function getAdminSession(): Promise<{
  ok: boolean;
  userId?: string;
  email?: string;
  error?: string;
}> {
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    return {
      ok: false,
      error: `Authentication required. Please sign in as ${AUTHORIZED_ADMIN_EMAIL}.`,
    };
  }

  const email = (user.email || '').trim().toLowerCase();
  if (email !== AUTHORIZED_ADMIN_EMAIL) {
    return {
      ok: false,
      error: `Unauthorized: Only ${AUTHORIZED_ADMIN_EMAIL} can manage news articles.`,
    };
  }

  return {
    ok: true,
    userId: user.id,
    email,
  };
}

export const fetchPublishedNews = async (): Promise<{
  articles: NewsArticle[];
  announcements: Announcement[];
  tableMissing: boolean;
  error: string | null;
}> => {
  try {
    const { data, error } = await supabase
      .from('news')
      .select('*')
      .eq('status', 'published')
      .order('published_at', { ascending: false })
      .order('created_at', { ascending: false });

    if (!error && Array.isArray(data)) {
      const articles = data.map(mapNewsRow);
      return {
        articles,
        announcements: articles.map(toAnnouncement),
        tableMissing: false,
        error: null,
      };
    }

    if (error && isMissingTableError(error)) {
      return { articles: [], announcements: [], tableMissing: true, error: null };
    }

    if (error) {
      return { articles: [], announcements: [], tableMissing: false, error: error.message };
    }
  } catch (err: any) {
    return {
      articles: [],
      announcements: [],
      tableMissing: false,
      error: err?.message || 'Failed to fetch published news.',
    };
  }

  return { articles: [], announcements: [], tableMissing: false, error: null };
};

export const fetchAllNewsForAdmin = async (): Promise<{
  articles: NewsArticle[];
  tableMissing: boolean;
  error: string | null;
}> => {
  const auth = await getAdminSession();
  if (!auth.ok) {
    return { articles: [], tableMissing: false, error: auth.error || 'Unauthorized' };
  }

  try {
    const { data, error } = await supabase
      .from('news')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && Array.isArray(data)) {
      return { articles: data.map(mapNewsRow), tableMissing: false, error: null };
    }

    if (error && isMissingTableError(error)) {
      return {
        articles: [],
        tableMissing: true,
        error:
          'The public.news table is not created yet. Run supabase-news-likes-migration.sql in Supabase SQL Editor.',
      };
    }

    if (error) {
      return { articles: [], tableMissing: false, error: error.message };
    }
  } catch (err: any) {
    return {
      articles: [],
      tableMissing: false,
      error: err?.message || 'Failed to load admin news.',
    };
  }

  return { articles: [], tableMissing: false, error: null };
};

export interface CreateNewsInput {
  title: string;
  description: string;
  fullContent?: string;
  category?: string;
  badge?: string;
  imageUrl?: string;
  coverFile?: File | null;
  status?: NewsStatus;
}

export const createNewsArticle = async (
  input: CreateNewsInput
): Promise<{
  success: boolean;
  article?: NewsArticle;
  announcement?: Announcement;
  tableMissing?: boolean;
  error?: string;
}> => {
  const auth = await getAdminSession();
  if (!auth.ok || !auth.userId) {
    return { success: false, error: auth.error || 'Unauthorized' };
  }

  const cleanTitle = (input.title || '').trim();
  const cleanDescription = (input.description || '').trim();
  if (!cleanTitle || !cleanDescription) {
    return { success: false, error: 'Headline and summary are required.' };
  }

  const id =
    typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID()
      : `news-${Date.now()}`;

  let resolvedImageUrl = String(input.imageUrl || '').trim();

  if (input.coverFile) {
    const uploadRes = await uploadAppFile(auth.userId, 'covers', `news-${id}`, input.coverFile);
    if (uploadRes.error || !uploadRes.publicUrl) {
      return {
        success: false,
        error: uploadRes.error || 'Failed to upload news cover image.',
      };
    }
    resolvedImageUrl = uploadRes.publicUrl;
  }

  const nowIso = new Date().toISOString();
  const status: NewsStatus = input.status || 'published';
  const category = (input.category || 'Portal News').trim();
  const badge = (input.badge || category || 'News').trim();

  const payload = {
    id,
    title: cleanTitle,
    description: cleanDescription,
    full_content: (input.fullContent || cleanDescription).trim(),
    category,
    badge,
    image_url: resolvedImageUrl || null,
    status,
    author_id: auth.userId,
    author_email: auth.email,
    published_at: status === 'published' ? nowIso : null,
    created_at: nowIso,
    updated_at: nowIso,
  };

  try {
    const { data, error } = await supabase.from('news').insert([payload]).select('*').single();

    if (!error && data) {
      const article = mapNewsRow(data);
      return {
        success: true,
        article,
        announcement: toAnnouncement(article),
      };
    }

    if (error && isMissingTableError(error)) {
      return {
        success: false,
        tableMissing: true,
        error:
          'The public.news database table has not been created yet. Run supabase-news-likes-migration.sql in Supabase SQL Editor.',
      };
    }

    return {
      success: false,
      error: error?.message || 'Failed to save news article to database.',
    };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed to create news article.' };
  }
};

export interface UpdateNewsInput {
  title?: string;
  description?: string;
  fullContent?: string;
  category?: string;
  badge?: string;
  imageUrl?: string;
  coverFile?: File | null;
  status?: NewsStatus;
}

export const updateNewsArticle = async (
  articleId: string,
  updates: UpdateNewsInput
): Promise<{
  success: boolean;
  article?: NewsArticle;
  announcement?: Announcement;
  error?: string;
}> => {
  const auth = await getAdminSession();
  if (!auth.ok || !auth.userId) {
    return { success: false, error: auth.error || 'Unauthorized' };
  }

  let uploadedImageUrl: string | undefined;
  if (updates.coverFile) {
    const uploadRes = await uploadAppFile(
      auth.userId,
      'covers',
      `news-${articleId}`,
      updates.coverFile
    );
    if (uploadRes.error || !uploadRes.publicUrl) {
      return {
        success: false,
        error: uploadRes.error || 'Failed to upload updated cover image.',
      };
    }
    uploadedImageUrl = uploadRes.publicUrl;
  }

  const nowIso = new Date().toISOString();
  const dbUpdates: Record<string, any> = {
    updated_at: nowIso,
  };

  if (updates.title !== undefined) dbUpdates.title = updates.title.trim();
  if (updates.description !== undefined) dbUpdates.description = updates.description.trim();
  if (updates.fullContent !== undefined) dbUpdates.full_content = updates.fullContent.trim();
  if (updates.category !== undefined) dbUpdates.category = updates.category.trim();
  if (updates.badge !== undefined) dbUpdates.badge = updates.badge.trim();
  if (uploadedImageUrl !== undefined) {
    dbUpdates.image_url = uploadedImageUrl;
  } else if (updates.imageUrl !== undefined) {
    dbUpdates.image_url = String(updates.imageUrl || '').trim() || null;
  }
  if (updates.status !== undefined) {
    dbUpdates.status = updates.status;
    if (updates.status === 'published') {
      dbUpdates.published_at = nowIso;
    }
  }

  try {
    const { data, error } = await supabase
      .from('news')
      .update(dbUpdates)
      .eq('id', articleId)
      .select('*')
      .single();

    if (!error && data) {
      const article = mapNewsRow(data);
      return {
        success: true,
        article,
        announcement: toAnnouncement(article),
      };
    }

    return { success: false, error: error?.message || 'Failed to update news article.' };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed to update news article.' };
  }
};

export const deleteNewsArticle = async (
  articleId: string
): Promise<{ success: boolean; error?: string }> => {
  const auth = await getAdminSession();
  if (!auth.ok) {
    return { success: false, error: auth.error || 'Unauthorized' };
  }

  try {
    const { error } = await supabase.from('news').delete().eq('id', articleId);
    if (!error) {
      return { success: true };
    }
    return { success: false, error: error?.message || 'Failed to delete news article.' };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed to delete news article.' };
  }
};
