import { supabase, SUPABASE_URL } from '../supabaseClient';

export const R2_STORAGE_BUCKET = 'hesomelodies-files';
export const R2_PUBLIC_BASE_URL = 'https://pub-ed44af9b41f345169fbf124e602171bd.r2.dev';

export type UploadFeatureType =
  | 'tracks'
  | 'covers'
  | 'avatars'
  | 'attachments'
  | 'videos'
  | 'thumbnails'
  | 'private';

export interface UploadProgressInfo {
  percent: number;
  stage: string;
}

export interface UploadFileResult {
  path: string;
  key: string;
  publicUrl: string | null;
  signedUrl: string | null;
  error: string | null;
  bucket: string;
  contentType?: string;
  fileSize?: number;
  userId?: string;
}

const MAX_FILE_SIZE_BY_FEATURE: Record<UploadFeatureType, number> = {
  tracks: 250 * 1024 * 1024, // 250 MB
  videos: 500 * 1024 * 1024, // 500 MB
  covers: 25 * 1024 * 1024, // 25 MB
  avatars: 25 * 1024 * 1024, // 25 MB
  thumbnails: 25 * 1024 * 1024, // 25 MB
  attachments: 50 * 1024 * 1024, // 50 MB
  private: 100 * 1024 * 1024, // 100 MB
};

const BLOCKED_EXTENSIONS = new Set([
  'html',
  'htm',
  'xhtml',
  'svg',
  'js',
  'mjs',
  'cjs',
  'ts',
  'jsx',
  'tsx',
  'php',
  'sh',
  'bash',
  'bat',
  'cmd',
  'exe',
  'dll',
  'msi',
  'ps1',
  'vbs',
]);

export const getFileExtension = (file: File): string => {
  const parts = file.name.split('.');
  if (parts.length > 1) {
    const ext = parts.pop()?.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (ext) return ext;
  }
  const typeMap: Record<string, string> = {
    'audio/mpeg': 'mp3',
    'audio/mp3': 'mp3',
    'audio/wav': 'wav',
    'audio/x-wav': 'wav',
    'audio/wave': 'wav',
    'audio/ogg': 'ogg',
    'audio/opus': 'opus',
    'audio/aac': 'aac',
    'audio/x-aac': 'aac',
    'audio/mp4': 'm4a',
    'audio/x-m4a': 'm4a',
    'audio/m4a': 'm4a',
    'audio/flac': 'flac',
    'audio/x-flac': 'flac',
    'audio/webm': 'weba',
    'video/mp4': 'mp4',
    'video/webm': 'webm',
    'video/quicktime': 'mov',
    'video/x-matroska': 'mkv',
    'video/ogg': 'ogv',
    'video/x-m4v': 'm4v',
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/pjpeg': 'jpg',
    'image/png': 'png',
    'image/webp': 'webp',
    'image/gif': 'gif',
    'image/avif': 'avif',
    'application/json': 'json',
    'application/pdf': 'pdf',
    'text/plain': 'txt',
    'application/zip': 'zip',
  };
  return typeMap[file.type?.toLowerCase()] || 'bin';
};

export const normalizeMimeType = (file: File, featureName: UploadFeatureType): string => {
  const ext = getFileExtension(file);
  const extMimeMap: Record<string, string> = {
    mp3: 'audio/mpeg',
    wav: 'audio/wav',
    ogg: 'audio/ogg',
    opus: 'audio/opus',
    aac: 'audio/aac',
    m4a: 'audio/mp4',
    flac: 'audio/flac',
    weba: 'audio/webm',
    mp4: featureName === 'tracks' ? 'audio/mp4' : 'video/mp4',
    webm: 'video/webm',
    mov: 'video/quicktime',
    mkv: 'video/x-matroska',
    ogv: 'video/ogg',
    m4v: 'video/mp4',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    jfif: 'image/jpeg',
    png: 'image/png',
    webp: 'image/webp',
    gif: 'image/gif',
    avif: 'image/avif',
    json: 'application/json',
    pdf: 'application/pdf',
    txt: 'text/plain',
    lrc: 'text/plain',
    srt: 'text/plain',
    zip: 'application/zip',
    doc: 'application/msword',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  };

  if (file.type && file.type !== 'application/octet-stream') {
    const lower = file.type.toLowerCase();
    if (lower === 'audio/mp3') return 'audio/mpeg';
    if (lower === 'audio/x-m4a') return 'audio/mp4';
    if (lower === 'audio/x-flac') return 'audio/flac';
    return lower;
  }

  return (
    extMimeMap[ext] ||
    (featureName === 'tracks'
      ? 'audio/mpeg'
      : featureName === 'videos'
      ? 'video/mp4'
      : featureName === 'attachments' || featureName === 'private'
      ? 'application/octet-stream'
      : 'image/jpeg')
  );
};

export const validateFileForUpload = (
  file: File,
  featureName: UploadFeatureType
): { ok: true; mimeType: string; ext: string } | { ok: false; error: string } => {
  if (!file || file.size <= 0) {
    return {
      ok: false,
      error: 'The selected file is empty (0 bytes). Please choose a valid file.',
    };
  }

  const ext = getFileExtension(file);
  if (BLOCKED_EXTENSIONS.has(ext)) {
    return {
      ok: false,
      error: `Unsupported or unsafe file type (.${ext}).`,
    };
  }

  const maxBytes = MAX_FILE_SIZE_BY_FEATURE[featureName] || 500 * 1024 * 1024;
  if (file.size > maxBytes) {
    const maxMb = Math.round(maxBytes / (1024 * 1024));
    return {
      ok: false,
      error: `File size exceeds the ${maxMb} MB limit allowed for ${featureName}.`,
    };
  }

  const mimeType = normalizeMimeType(file, featureName);

  if (featureName === 'tracks' && !mimeType.startsWith('audio/')) {
    return {
      ok: false,
      error: 'Please select a valid audio file (MP3, WAV, AAC, FLAC, M4A, OGG).',
    };
  }

  if (['covers', 'avatars', 'thumbnails'].includes(featureName) && !mimeType.startsWith('image/')) {
    return {
      ok: false,
      error: 'Please select a valid image file (JPG, PNG, WebP, GIF).',
    };
  }

  if (featureName === 'videos' && !mimeType.startsWith('video/')) {
    return {
      ok: false,
      error: 'Please select a valid video file (MP4, WebM, MOV, MKV).',
    };
  }

  return { ok: true, mimeType, ext };
};

export const buildStoragePath = (
  userId: string,
  featureName: string,
  itemId: string,
  file: File,
  fixedFileName?: string
): string => {
  const ext = getFileExtension(file);
  const cleanUser = (userId || 'public').replace(/[^a-zA-Z0-9_-]/g, '');
  const cleanFeature = featureName.replace(/[^a-zA-Z0-9_-]/g, '');
  const cleanItem = itemId.replace(/[^a-zA-Z0-9_-]/g, '');

  if (fixedFileName) {
    const cleanFixed = fixedFileName.replace(/[^a-zA-Z0-9._-]/g, '');
    if (cleanFixed) {
      return `${cleanUser}/${cleanFeature}/${cleanItem}/${cleanFixed}`;
    }
  }

  const uuid =
    typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

  return `${cleanUser}/${cleanFeature}/${cleanItem}/${uuid}.${ext}`;
};

const isNetworkFetchError = (msg?: string | null): boolean => {
  if (!msg) return false;
  const lower = msg.toLowerCase();
  return (
    lower.includes('failed to fetch') ||
    lower.includes('networkerror') ||
    lower.includes('network request failed') ||
    lower.includes('load failed') ||
    lower.includes('err_connection') ||
    lower.includes('timeout') ||
    lower.includes('aborted')
  );
};

const getFreshSession = async () => {
  let {
    data: { session },
  } = await supabase.auth.getSession();

  const nowSec = Math.floor(Date.now() / 1000);
  if (!session || (session.expires_at && session.expires_at - nowSec < 60)) {
    try {
      const { data: refreshed } = await supabase.auth.refreshSession();
      if (refreshed?.session) {
        session = refreshed.session;
      }
    } catch {
      // ignore
    }
  }

  return {
    session,
    accessToken: session?.access_token || null,
    userId: session?.user?.id || null,
  };
};

const uploadToCloudflareR2 = async (
  filePath: string,
  featureName: UploadFeatureType,
  file: File,
  mimeType: string,
  accessToken: string,
  authenticatedUserId: string,
  onProgress?: (info: UploadProgressInfo) => void
): Promise<UploadFileResult> => {
  try {
    onProgress?.({ percent: 10, stage: 'Requesting secure Cloudflare R2 upload link...' });

    const presignRes = await fetch('/.netlify/functions/r2-presign', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        filePath,
        featureName,
        contentType: mimeType,
        fileSize: file.size,
      }),
    });

    const contentType = presignRes.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      return {
        path: filePath,
        key: filePath,
        publicUrl: null,
        signedUrl: null,
        error: 'Cloudflare R2 upload endpoint is unavailable. Please check your R2 function deployment.',
        bucket: R2_STORAGE_BUCKET,
      };
    }

    const presignData = await presignRes.json();
    if (!presignRes.ok || !presignData.presignedUrl) {
      return {
        path: filePath,
        key: filePath,
        publicUrl: null,
        signedUrl: null,
        error: presignData.error || 'Could not initialize Cloudflare R2 upload.',
        bucket: R2_STORAGE_BUCKET,
      };
    }

    await new Promise<void>((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('PUT', presignData.presignedUrl, true);
      xhr.setRequestHeader('Content-Type', mimeType);

      xhr.upload.onprogress = (evt) => {
        if (evt.lengthComputable) {
          const pct = 15 + Math.round((evt.loaded / evt.total) * 80);
          onProgress?.({
            percent: Math.min(95, pct),
            stage: `Uploading to Cloudflare R2 (${Math.min(95, pct)}%)...`,
          });
        }
      };

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve();
        } else {
          reject(new Error(`Cloudflare R2 upload failed (HTTP ${xhr.status})`));
        }
      };

      xhr.onerror = () => reject(new Error('Network error while uploading to Cloudflare R2.'));
      xhr.send(file);
    });

    onProgress?.({ percent: 100, stage: 'Upload complete!' });

    const finalKey = presignData.key || presignData.path || filePath;
    const finalPublicUrl = presignData.publicUrl || `${R2_PUBLIC_BASE_URL}/${finalKey}`;

    return {
      path: finalKey,
      key: finalKey,
      publicUrl: finalPublicUrl,
      signedUrl: finalPublicUrl,
      error: null,
      bucket: presignData.bucket || R2_STORAGE_BUCKET,
      contentType: mimeType,
      fileSize: file.size,
      userId: presignData.userId || authenticatedUserId,
    };
  } catch (err: any) {
    return {
      path: filePath,
      key: filePath,
      publicUrl: null,
      signedUrl: null,
      error: err?.message || 'Cloudflare R2 upload failed.',
      bucket: R2_STORAGE_BUCKET,
    };
  }
};

const formatUploadError = (rawError: string | null): string => {
  const err = (rawError || 'Upload failed').trim();
  const lower = err.toLowerCase();

  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return 'You appear to be offline. Please check your internet connection and try again.';
  }

  if (lower.includes('unauthorized') || lower.includes('401') || lower.includes('session')) {
    return 'Your login session has expired. Please sign in again to upload to Cloudflare R2.';
  }

  if (lower.includes('forbidden') || lower.includes('403')) {
    return 'Permission denied: you can only upload or manage files belonging to your own account.';
  }

  if (isNetworkFetchError(err)) {
    return 'Network connection to Cloudflare R2 failed or timed out. Please check your internet connection and try again.';
  }

  return err;
};

/**
 * Routes ALL website file uploads (small & large, audio, images, avatars, thumbnails,
 * videos, documents & attachments) unconditionally to Cloudflare R2.
 * Supabase Auth is verified on every upload and files are stored under the user's ID.
 */
export const uploadAppFile = async (
  userId: string,
  featureName: UploadFeatureType,
  itemId: string,
  file: File,
  onProgress?: (info: UploadProgressInfo) => void,
  options?: { fixedFileName?: string }
): Promise<UploadFileResult> => {
  try {
    const validation = validateFileForUpload(file, featureName);
    if (!validation.ok) {
      return {
        path: '',
        key: '',
        publicUrl: null,
        signedUrl: null,
        error: validation.error,
        bucket: R2_STORAGE_BUCKET,
      };
    }

    onProgress?.({ percent: 5, stage: 'Verifying authentication session...' });
    const { accessToken, userId: sessionUserId } = await getFreshSession();
    const activeUserId = sessionUserId;

    if (!activeUserId || !accessToken) {
      return {
        path: '',
        key: '',
        publicUrl: null,
        signedUrl: null,
        error: 'Your login session has expired or is missing. Please sign in again to upload.',
        bucket: R2_STORAGE_BUCKET,
      };
    }

    if (userId && userId !== activeUserId) {
      console.warn('Upload caller userId aligned to authenticated session userId.');
    }

    const filePath = buildStoragePath(
      activeUserId,
      featureName,
      itemId,
      file,
      options?.fixedFileName
    );

    const res = await uploadToCloudflareR2(
      filePath,
      featureName,
      file,
      validation.mimeType,
      accessToken,
      activeUserId,
      onProgress
    );

    if (res.error) {
      return {
        ...res,
        error: formatUploadError(res.error),
      };
    }

    return res;
  } catch (err: any) {
    return {
      path: '',
      key: '',
      publicUrl: null,
      signedUrl: null,
      error: formatUploadError(err?.message || 'Unexpected Cloudflare R2 upload error'),
      bucket: R2_STORAGE_BUCKET,
    };
  }
};

/**
 * Resolves stored R2 keys, bare r2.dev links, full R2 public URLs, and legacy pre-existing Supabase URLs
 * so playback, cover art, avatars, and downloads continue working seamlessly.
 */
export const getSignedFileUrl = async (
  filePathOrUrl: string,
  options?: { isPrivate?: boolean }
): Promise<string> => {
  if (!filePathOrUrl) return '';
  const trimmed = String(filePathOrUrl).trim();
  if (!trimmed) return '';

  if (trimmed.startsWith('data:') || trimmed.startsWith('blob:') || trimmed.startsWith('/')) {
    return trimmed;
  }

  const normalizedUrl = trimmed.replace(/^https?:\/\/r2\.dev(?=\/|$)/i, R2_PUBLIC_BASE_URL);

  if (options?.isPrivate || normalizedUrl.includes('/private/')) {
    const { accessToken } = await getFreshSession();
    const targetUrl = /^https?:\/\//i.test(normalizedUrl)
      ? normalizedUrl
      : `${R2_PUBLIC_BASE_URL}/${normalizedUrl.replace(/^\/+/, '')}`;
    const tokenParam = accessToken ? `&token=${encodeURIComponent(accessToken)}` : '';
    return `/.netlify/functions/r2-download?url=${encodeURIComponent(targetUrl)}&private=1${tokenParam}`;
  }

  if (normalizedUrl.startsWith('http://') || normalizedUrl.startsWith('https://')) {
    return normalizedUrl;
  }

  // Legacy "bucket:path" read compatibility for pre-existing historical database rows
  if (normalizedUrl.includes(':') && !normalizedUrl.includes('://')) {
    const parts = normalizedUrl.split(':');
    const legacyBucket = parts.at(0) || 'songs';
    const legacyPath = parts.slice(1).join(':').replace(/^\/+/, '');
    if (legacyBucket === R2_STORAGE_BUCKET) {
      return `${R2_PUBLIC_BASE_URL}/${legacyPath}`;
    }
    return `${SUPABASE_URL}/storage/v1/object/public/${encodeURIComponent(legacyBucket)}/${legacyPath}`;
  }

  // Default: resolve relative R2 object key to active Cloudflare R2 public URL
  return `${R2_PUBLIC_BASE_URL}/${normalizedUrl.replace(/^\/+/, '')}`;
};

/**
 * Deletes an uploaded object cleanly.
 * - Cloudflare R2 URLs/keys go through authenticated /.netlify/functions/r2-delete (owner-or-admin only).
 * - Legacy pre-existing Supabase Storage URLs remain supported during artist-initiated track deletion.
 */
export const deleteStorageFile = async (filePathOrUrl?: string): Promise<boolean> => {
  if (!filePathOrUrl) return false;
  const trimmed = String(filePathOrUrl).trim();
  if (!trimmed || trimmed.startsWith('/src/') || trimmed.startsWith('data:') || trimmed.startsWith('blob:')) {
    return false;
  }

  // 1. Legacy Supabase Storage read/cleanup support for older historical records
  if (trimmed.includes('.supabase.co/storage/v1/object/')) {
    let bucket = 'songs';
    let rawPath = trimmed;

    if (trimmed.includes('/videos/')) {
      bucket = 'videos';
      rawPath = trimmed.split('/videos/').at(1) || trimmed;
    } else if (trimmed.includes('/songs/')) {
      bucket = 'songs';
      rawPath = trimmed.split('/songs/').at(1) || trimmed;
    } else if (trimmed.includes('/app-files/')) {
      bucket = 'app-files';
      rawPath = trimmed.split('/app-files/').at(1) || trimmed;
    }
    rawPath = rawPath.split('?').at(0) || rawPath;

    try {
      await supabase.storage.from(bucket).remove([rawPath]);
      return true;
    } catch {
      return false;
    }
  }

  // 2. Cloudflare R2 object deletion via authenticated backend endpoint
  try {
    const { accessToken } = await getFreshSession();
    if (!accessToken) return false;

    const res = await fetch('/.netlify/functions/r2-delete', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(
        /^https?:\/\//i.test(trimmed) ? { url: trimmed } : { key: trimmed }
      ),
    });
    return res.ok;
  } catch {
    return false;
  }
};
