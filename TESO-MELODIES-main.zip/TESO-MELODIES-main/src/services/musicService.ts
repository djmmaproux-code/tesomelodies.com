import { supabase } from '../supabaseClient';
import { Song, Artist } from '../types/music';
import { HERO_ASSETS } from '../data/initialData';
import { deleteStorageFile } from './storageService';
import {
  fetchSongLikesData,
  toggleSongLikeInBackend,
  fetchArtistFollowsData,
  toggleArtistFollowInBackend,
  calculateSongMilestoneFollowers,
  fetchArtistFollowerStatsFromSupabase,
  fetchSingleArtistFollowerStat,
  type ArtistFollowerStatRow,
} from './socialService';
export {
  calculateSongMilestoneFollowers,
  fetchArtistFollowerStatsFromSupabase,
  fetchSingleArtistFollowerStat,
};
export type { ArtistFollowerStatRow };

/**
 * Unique visitor ID for tracking anonymous likes and interactions
 */
export const getOrCreateVisitorId = (): string => {
  if (typeof window === 'undefined') return 'anon-visitor';
  try {
    let vid = localStorage.getItem('teso_visitor_id');
    if (!vid) {
      if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
        vid = crypto.randomUUID();
      } else {
        vid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
          const r = (Math.random() * 16) | 0;
          const v = c === 'x' ? r : (r & 0x3) | 0x8;
          return v.toString(16);
        });
      }
      localStorage.setItem('teso_visitor_id', vid);
    }
    return vid;
  } catch {
    return 'anon-visitor';
  }
};

const R2_PUBLIC_BASE = 'https://pub-ed44af9b41f345169fbf124e602171bd.r2.dev';

/**
 * Normalizes bare https://r2.dev URLs to the active Cloudflare R2 public bucket subdomain.
 */
export const normalizeR2Url = (url?: string | null): string | undefined => {
  if (!url) return undefined;
  const trimmed = String(url).trim();
  if (!trimmed) return undefined;
  return trimmed.replace(/^https?:\/\/r2\.dev(?=\/|$)/i, R2_PUBLIC_BASE);
};

export const extractR2KeyFromUrl = (url?: string | null): string | undefined => {
  const normalized = normalizeR2Url(url);
  if (!normalized) return undefined;
  try {
    const parsed = new URL(normalized);
    if (parsed.hostname.toLowerCase().endsWith('.r2.dev')) {
      const key = decodeURIComponent(parsed.pathname.replace(/^\/+/, ''));
      return key || undefined;
    }
  } catch {
    // ignore
  }
  return undefined;
};

export const canonicalArtistSlug = (value?: string | null): string =>
  String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'artist';

/**
 * Map Supabase "public.songs" row to frontend Song model
 */
export const mapSongRow = (row: any): Song => {
  const dbLikes = typeof row.likes === 'number' ? Math.max(0, row.likes) : 0;
  const dbPlays = typeof row.plays === 'number' ? Math.max(0, row.plays) : 0;
  const dbDownloads =
    typeof row.downloads_count === 'number'
      ? Math.max(0, row.downloads_count)
      : typeof row.downloadsCount === 'number'
      ? Math.max(0, row.downloadsCount)
      : 0;

  const normalizedCover = normalizeR2Url(row.cover_url);
  const normalizedAudio = normalizeR2Url(row.audio_url);

  return {
    id: String(row.id),
    title: row.title || 'Untitled',
    artist: row.artist || 'Independent Artist',
    genre: row.genre || 'Afrobeat',
    duration: row.duration || '03:30',
    durationSec: row.duration_sec || 210,
    category: (row.category as 'new' | 'trending' | 'hot100') || 'new',
    coverUrl: normalizedCover || HERO_ASSETS.announcement,
    audioUrl: normalizedAudio,
    audioPath: row.audio_path || extractR2KeyFromUrl(normalizedAudio),
    coverPath: row.cover_path || extractR2KeyFromUrl(normalizedCover),
    audioSize: typeof row.file_size === 'number' ? row.file_size : undefined,
    audioMimeType: row.mime_type || undefined,
    storageProvider:
      row.storage_provider || (normalizedAudio?.includes('.r2.dev/') ? 'cloudflare-r2' : undefined),
    plays: dbPlays,
    likes: dbLikes,
    downloadsCount: dbDownloads,
    description: row.description || undefined,
    rank: typeof row.rank === 'number' ? row.rank : undefined,
    userId: row.user_id || undefined,
    createdAt: row.created_at || undefined,
    isPublished: true,
    isRealUpload: true,
  };
};

// Alias for backwards compatibility
export const mapMusicRowToSong = mapSongRow;

const isVideoMediaRow = (row: any): boolean => {
  if (!row) return false;
  if (String(row.category || '').toLowerCase() === 'video') return true;
  const mediaUrl = String(row.audio_url || '').toLowerCase().split('?')[0];
  return /\.(mp4|webm|mov|mkv|m4v|ogv)$/.test(mediaUrl);
};

/**
 * 1. LOAD: Fetch all audio songs from "public.songs" (strictly excluding video records)
 */
export const fetchSongsFromSupabase = async (): Promise<Song[]> => {
  try {
    const { data, error } = await supabase
      .from('songs')
      .select('*')
      .neq('category', 'video')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching songs from public.songs:', error.message);
      return [];
    }

    if (!data || data.length === 0) {
      return [];
    }

    return data.filter((row) => !isVideoMediaRow(row)).map(mapSongRow);
  } catch (err: any) {
    console.error('Unexpected error loading songs from Supabase:', err);
    return [];
  }
};

/**
 * 1a. Fetch a single song by ID directly from "public.songs" (used for /song/:id and #song= deep links)
 */
export const fetchSongByIdFromSupabase = async (songId: string): Promise<Song | null> => {
  if (!songId) return null;
  try {
    const { data, error } = await supabase
      .from('songs')
      .select('*')
      .eq('id', songId)
      .maybeSingle();

    if (error || !data || isVideoMediaRow(data)) {
      return null;
    }

    return mapSongRow(data);
  } catch {
    return null;
  }
};

/**
 * 1b. Fetch audio songs uploaded by a specific user from "public.songs"
 */
export const fetchUserUploadedSongs = async (userId: string): Promise<Song[]> => {
  if (!userId) return [];
  try {
    const { data, error } = await supabase
      .from('songs')
      .select('*')
      .eq('user_id', userId)
      .neq('category', 'video')
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Notice loading user uploaded songs:', error.message);
      return [];
    }

    if (!data || data.length === 0) return [];
    return data.filter((row) => !isVideoMediaRow(row)).map(mapSongRow);
  } catch (err) {
    console.warn('Notice loading user songs from Supabase:', err);
    return [];
  }
};

/**
 * 2. CREATE: Insert a new song record into "public.songs"
 * Starts honestly with 0 plays and 0 likes.
 */
export const createSongInSupabase = async (
  songData: Partial<Song>,
  userId?: string
): Promise<{ song: Song | null; error: string | null }> => {
  try {
    let effectiveUserId = userId;
    if (!effectiveUserId) {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      effectiveUserId = user?.id;
    }

    if (!effectiveUserId) {
      return { song: null, error: 'You must be signed in to upload and save music.' };
    }

    if (!songData.audioUrl) {
      return {
        song: null,
        error: 'The audio file was not uploaded properly. A valid public audio URL is required.',
      };
    }

    const normalizedCoverUrl = normalizeR2Url(songData.coverUrl) || songData.coverUrl || HERO_ASSETS.announcement;
    const normalizedAudioUrl = normalizeR2Url(songData.audioUrl) || songData.audioUrl;

    const basePayload: Record<string, any> = {
      user_id: effectiveUserId,
      title: (songData.title || 'Untitled').trim(),
      artist: (songData.artist || 'Independent Artist').trim(),
      genre: songData.genre || 'Afrobeat',
      duration: songData.duration || '03:30',
      duration_sec: songData.durationSec || 210,
      category: songData.category || 'new',
      cover_url: normalizedCoverUrl,
      audio_url: normalizedAudioUrl,
      plays: 0,
      likes: 0,
      rank: null,
    };

    const resolvedAudioPath = songData.audioPath || extractR2KeyFromUrl(normalizedAudioUrl);
    const resolvedCoverPath = songData.coverPath || extractR2KeyFromUrl(normalizedCoverUrl);

    const fullPayload = {
      ...basePayload,
      ...(songData.description ? { description: songData.description.trim() } : {}),
      ...(resolvedAudioPath ? { audio_path: resolvedAudioPath } : {}),
      ...(resolvedCoverPath ? { cover_path: resolvedCoverPath } : {}),
      ...(songData.audioSize ? { file_size: songData.audioSize } : {}),
      ...(songData.audioMimeType ? { mime_type: songData.audioMimeType } : {}),
      storage_provider: 'cloudflare-r2',
    };

    // Ensure profile has role: 'artist' in public.profiles
    try {
      const { data: curProfile } = await supabase
        .from('profiles')
        .select('id, role')
        .eq('id', effectiveUserId)
        .maybeSingle();

      if (!curProfile) {
        await supabase.from('profiles').insert([
          {
            id: effectiveUserId,
            full_name: (songData.artist || 'Artist').trim(),
            username: (songData.artist || 'artist').trim().toLowerCase().replace(/[^a-z0-9_]/g, '_'),
            role: 'artist',
            updated_at: new Date().toISOString(),
          },
        ]);
      } else if (curProfile.role !== 'artist') {
        await supabase
          .from('profiles')
          .update({ role: 'artist', updated_at: new Date().toISOString() })
          .eq('id', effectiveUserId);
      }
    } catch (profErr) {
      console.warn('Notice ensuring artist profile for song upload:', profErr);
    }

    let { data: insertedSong, error: insertError } = await supabase
      .from('songs')
      .insert([fullPayload])
      .select('*')
      .single();

    // Compatibility fallback if additive metadata columns haven't been migrated yet
    if (
      insertError &&
      (insertError.message?.includes('schema cache') ||
        insertError.message?.includes('column') ||
        insertError.code === 'PGRST204' ||
        insertError.code === '42703')
    ) {
      const descPayload = songData.description
        ? { ...basePayload, description: songData.description.trim() }
        : basePayload;
      const retry = await supabase.from('songs').insert([descPayload]).select('*').single();
      insertedSong = retry.data;
      insertError = retry.error;

      if (
        insertError &&
        (insertError.message?.includes('description') || insertError.message?.includes('schema cache'))
      ) {
        const retryBase = await supabase.from('songs').insert([basePayload]).select('*').single();
        insertedSong = retryBase.data;
        insertError = retryBase.error;
      }
    }

    if (insertError) {
      console.error('Error inserting into public.songs:', insertError);
      return { song: null, error: insertError.message };
    }

    return { song: mapSongRow(insertedSong), error: null };
  } catch (err: any) {
    console.error('Exception creating song in Supabase:', err);
    return { song: null, error: err?.message || 'Failed to save song in database' };
  }
};

/**
 * 3. UPDATE: Update song metadata & metrics in "public.songs"
 */
export const updateSongInSupabase = async (
  songId: string,
  updates: Partial<Song>
): Promise<{ success: boolean; error: string | null }> => {
  try {
    const songsUpdates: Record<string, any> = {
      updated_at: new Date().toISOString(),
    };
    if (updates.title !== undefined) songsUpdates.title = updates.title;
    if (updates.artist !== undefined) songsUpdates.artist = updates.artist;
    if (updates.genre !== undefined) songsUpdates.genre = updates.genre;
    if (updates.category !== undefined) songsUpdates.category = updates.category;
    if (updates.plays !== undefined) songsUpdates.plays = Math.max(0, updates.plays);
    if (updates.likes !== undefined) songsUpdates.likes = Math.max(0, updates.likes);
    if (updates.downloadsCount !== undefined) {
      songsUpdates.downloads_count = Math.max(0, updates.downloadsCount);
    }
    if (updates.description !== undefined) songsUpdates.description = updates.description;
    if (updates.coverUrl !== undefined) songsUpdates.cover_url = updates.coverUrl;
    if (updates.audioUrl !== undefined) songsUpdates.audio_url = updates.audioUrl;
    if (updates.rank !== undefined) songsUpdates.rank = updates.rank;

    let { error } = await supabase.from('songs').update(songsUpdates).eq('id', songId);

    if (
      error &&
      (error.message?.includes('downloads_count') ||
        error.message?.includes('description') ||
        error.message?.includes('schema cache'))
    ) {
      delete songsUpdates.downloads_count;
      delete songsUpdates.description;
      const retry = await supabase.from('songs').update(songsUpdates).eq('id', songId);
      error = retry.error;
    }

    if (error) {
      console.error('Error updating song in public.songs:', error.message);
      return { success: false, error: error.message };
    }

    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed to update song in Supabase' };
  }
};

/**
 * 3b. Record genuine music stream via anti-fraud RPC (falls back cleanly to legacy RPC / update)
 */
export const incrementSongPlayInSupabase = async (
  songId: string,
  fallbackNextPlays?: number,
  actorId?: string | null
): Promise<number | null> => {
  const resolvedActor = (actorId && actorId.trim()) || getOrCreateVisitorId();
  try {
    const { data, error } = await supabase.rpc('record_song_stream', {
      p_song_id: songId,
      p_actor_id: resolvedActor,
      p_duration_sec: 30,
    });
    if (!error && data && typeof (data as any).plays === 'number') {
      return (data as any).plays as number;
    }
  } catch {
    // record_song_stream not migrated yet — fall back cleanly
  }

  try {
    const { data, error } = await supabase.rpc('increment_song_play', { p_song_id: songId });
    if (!error && typeof data === 'number') {
      return data;
    }
  } catch {
    // RPC not created yet
  }

  if (typeof fallbackNextPlays === 'number') {
    await updateSongInSupabase(songId, { plays: fallbackNextPlays }).catch(() => {});
  }
  return null;
};

/**
 * Format download count cleanly for song cards, player bar, and detail views
 */
export const formatDownloadCount = (count?: number): string => {
  const safe = Math.max(0, Math.floor(count || 0));
  if (safe >= 1_000_000) return `${(safe / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`;
  if (safe >= 10_000) return `${(safe / 1_000).toFixed(1).replace(/\.0$/, '')}K`;
  return safe.toLocaleString();
};

const DOWNLOAD_COOLDOWN_MS = 10 * 60 * 1000; // 10 minutes per song per visitor/user
const DOWNLOAD_COOLDOWN_KEY = 'teso_download_cooldowns_v1';

const isWithinLocalDownloadCooldown = (songId: string): boolean => {
  if (typeof window === 'undefined') return false;
  try {
    const raw = localStorage.getItem(DOWNLOAD_COOLDOWN_KEY);
    if (!raw) return false;
    const map = JSON.parse(raw) as Record<string, number>;
    const lastTs = map[String(songId)];
    return typeof lastTs === 'number' && Date.now() - lastTs < DOWNLOAD_COOLDOWN_MS;
  } catch {
    return false;
  }
};

const markLocalDownloadCooldown = (songId: string) => {
  if (typeof window === 'undefined') return;
  try {
    const raw = localStorage.getItem(DOWNLOAD_COOLDOWN_KEY);
    const map: Record<string, number> = raw ? JSON.parse(raw) : {};
    const now = Date.now();
    // Prune expired entries so localStorage stays tiny
    Object.keys(map).forEach((k) => {
      if (now - map[k] > DOWNLOAD_COOLDOWN_MS * 2) {
        delete map[k];
      }
    });
    map[String(songId)] = now;
    localStorage.setItem(DOWNLOAD_COOLDOWN_KEY, JSON.stringify(map));
  } catch {
    // ignore storage quota errors
  }
};

/**
 * 4a. DOWNLOADS MAP: Publicly fetch authoritative per-song download totals
 * from Supabase (`public.songs.downloads_count` + `public.song_downloads`) and
 * merge optional Express `/api/downloads` fallback so visitors see live counts
 * whether signed in or browsing as guests.
 */
export const fetchSongDownloadsMap = async (): Promise<Record<string, number>> => {
  const downloadsMap: Record<string, number> = {};

  // A. Read public.songs.downloads_count if column exists
  try {
    const { data: dbSongs, error } = await supabase
      .from('songs')
      .select('id, downloads_count')
      .neq('category', 'video');

    if (!error && Array.isArray(dbSongs)) {
      dbSongs.forEach((row: any) => {
        if (row?.id && typeof row.downloads_count === 'number') {
          downloadsMap[String(row.id)] = Math.max(0, row.downloads_count);
        }
      });
    }
  } catch {
    // Column may not be migrated yet
  }

  // B. Optional Express /api/downloads fallback (active in local full-stack preview or before SQL migration)
  try {
    const base = typeof window !== 'undefined' ? '' : 'http://localhost:3000';
    const res = await fetch(`${base}/api/downloads`, { cache: 'no-store' });
    const ct = (res.headers.get('content-type') || '').toLowerCase();
    if (res.ok && ct.includes('application/json')) {
      const data = await res.json();
      if (data?.success && data.downloadsMap && typeof data.downloadsMap === 'object') {
        Object.entries(data.downloadsMap).forEach(([sId, count]) => {
          if (typeof count === 'number' && count >= 0) {
            downloadsMap[sId] = Math.max(downloadsMap[sId] || 0, count);
          }
        });
      }
    }
  } catch {
    // Express API optional on static Netlify deployments
  }

  return downloadsMap;
};

export interface RecordSongDownloadResult {
  success: boolean;
  counted: boolean;
  downloadsCount: number;
  reason?: string;
}

/**
 * 4b. DOWNLOAD: Record a genuine, completed song download in Supabase
 * - Works for both Cloudflare R2 (.r2.dev) and Supabase Storage songs.
 * - Uses atomic anti-spam RPC `record_song_download` (10-minute cooldown per song/actor).
 * - Falls back cleanly to Express `/api/downloads/record` if the SQL migration hasn't been run yet.
 */
export const recordSongDownloadInSupabase = async (
  songId: string,
  options?: {
    currentDownloads?: number;
    userId?: string | null;
    storageSource?: 'r2' | 'supabase' | 'other';
    downloadMode?: 'branded' | 'direct';
  }
): Promise<RecordSongDownloadResult> => {
  const currentDownloads = Math.max(0, options?.currentDownloads || 0);
  if (!songId) {
    return { success: false, counted: false, downloadsCount: currentDownloads, reason: 'missing_song_id' };
  }

  let effectiveUserId = options?.userId || null;
  try {
    if (!effectiveUserId) {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (session?.user?.id) {
        effectiveUserId = session.user.id;
      }
    }
  } catch {
    // ignore
  }

  const actorId = (effectiveUserId || getOrCreateVisitorId() || 'anon-visitor').trim();
  const storageSource = options?.storageSource || 'r2';
  const downloadMode = options?.downloadMode || 'branded';

  // 1. Primary: Atomic PostgreSQL SECURITY DEFINER RPC (deduplicated + increments public.songs.downloads_count)
  try {
    const { data, error } = await supabase.rpc('record_song_download', {
      p_song_id: songId,
      p_actor_id: actorId,
      p_storage_source: storageSource,
      p_download_mode: downloadMode,
    });

    if (!error && data && typeof data === 'object') {
      const counted = Boolean((data as any).counted);
      const countVal =
        typeof (data as any).downloads_count === 'number'
          ? Math.max(0, (data as any).downloads_count)
          : currentDownloads + (counted ? 1 : 0);
      const reason = String((data as any).reason || (counted ? 'recorded' : 'cooldown'));

      if (counted) {
        markLocalDownloadCooldown(songId);
      }

      // Mirror to Express SSE if running locally so all tabs update immediately
      if (counted) {
        try {
          const base = typeof window !== 'undefined' ? '' : 'http://localhost:3000';
          fetch(`${base}/api/downloads/record`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'x-visitor-id': actorId },
            body: JSON.stringify({
              songId,
              actorId,
              storageSource,
              downloadMode,
              authoritativeCount: countVal,
            }),
          }).catch(() => {});
        } catch {
          // optional
        }
      }

      return {
        success: true,
        counted,
        downloadsCount: countVal,
        reason,
      };
    }
  } catch {
    // RPC not created yet — try legacy RPC or Express backend
  }

  // 2. Backwards-compatible legacy RPC (only if not within local 10-min cooldown)
  if (!isWithinLocalDownloadCooldown(songId)) {
    try {
      const { data, error } = await supabase.rpc('increment_song_download', { p_song_id: songId });
      if (!error && typeof data === 'number') {
        markLocalDownloadCooldown(songId);
        return {
          success: true,
          counted: true,
          downloadsCount: Math.max(0, data),
          reason: 'recorded',
        };
      }
    } catch {
      // Legacy RPC not created yet
    }
  }

  // 3. Express backend fallback (/api/downloads/record — enforces 10-min cooldown & broadcasts SSE)
  try {
    const base = typeof window !== 'undefined' ? '' : 'http://localhost:3000';
    const res = await fetch(`${base}/api/downloads/record`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-visitor-id': actorId,
      },
      body: JSON.stringify({
        songId,
        actorId,
        storageSource,
        downloadMode,
      }),
    });
    const ct = (res.headers.get('content-type') || '').toLowerCase();
    if (res.ok && ct.includes('application/json')) {
      const data = await res.json();
      if (data?.success && typeof data.downloadsCount === 'number') {
        if (data.counted) {
          markLocalDownloadCooldown(songId);
        }
        return {
          success: true,
          counted: Boolean(data.counted),
          downloadsCount: Math.max(0, data.downloadsCount),
          reason: data.reason || (data.counted ? 'recorded' : 'cooldown'),
        };
      }
    }
  } catch {
    // Express API not present on static host
  }

  // 4. Safe non-inflating fallback if neither SQL migration nor Express backend is available yet
  if (isWithinLocalDownloadCooldown(songId)) {
    return {
      success: false,
      counted: false,
      downloadsCount: currentDownloads,
      reason: 'cooldown',
    };
  }

  return {
    success: false,
    counted: false,
    downloadsCount: currentDownloads,
    reason: 'migration_pending',
  };
};

/**
 * 5. DELETE: Remove song and files from Supabase Storage & "public.songs"
 */
export const deleteSongFromSupabase = async (
  songId: string,
  audioUrl?: string,
  coverUrl?: string
): Promise<{ success: boolean; error: string | null }> => {
  try {
    if (audioUrl) {
      await deleteStorageFile(audioUrl);
    }
    if (coverUrl && !coverUrl.startsWith('/src/')) {
      await deleteStorageFile(coverUrl);
    }

    const { error: deleteError } = await supabase.from('songs').delete().eq('id', songId);

    if (deleteError) {
      console.error('Error deleting from public.songs:', deleteError.message);
      return { success: false, error: deleteError.message };
    }

    try {
      await supabase.from('user_favorites').delete().eq('song_id', songId);
      await supabase.from('song_likes').delete().eq('song_id', String(songId));
    } catch {
      // ignore
    }

    return { success: true, error: null };
  } catch (err: any) {
    console.error('Exception deleting song:', err);
    return { success: false, error: err?.message || 'Failed to delete song' };
  }
};

/**
 * 6. LIKES: Fetch liked song IDs for the authenticated user and/or visitor
 */
export const fetchLikedSongIdsFromSupabase = async (
  userId?: string | null,
  _visitorId?: string
): Promise<string[]> => {
  const result = await fetchSongLikesData(userId);
  return result.userLikedSongIds || [];
};

/**
 * 7. LIKES: Toggle like permanently in Supabase / backend
 */
export const toggleMusicLikeInSupabase = async (
  songId: string,
  userId?: string | null,
  visitorId?: string,
  isCurrentlyLiked = false,
  userEmail?: string,
  userName?: string
): Promise<{ isLiked: boolean; error: string | null; totalLikes?: number }> => {
  const effectiveId = userId || visitorId || getOrCreateVisitorId();
  const res = await toggleSongLikeInBackend(
    songId,
    effectiveId,
    isCurrentlyLiked,
    userEmail,
    userName
  );
  if (res.success) {
    return {
      isLiked: res.isLiked,
      error: null,
      totalLikes: typeof res.totalLikes === 'number' ? res.totalLikes : undefined,
    };
  }
  return { isLiked: !isCurrentlyLiked, error: res.error || null };
};

/**
 * 8. ARTIST PROFILES: Save or update artist profile in "public.profiles"
 */
export const saveArtistProfileInSupabase = async (
  userId: string,
  profileData: {
    stageName: string;
    genre: string;
    location?: string;
    bio?: string;
    avatarUrl?: string;
  }
): Promise<{ success: boolean; error: string | null }> => {
  try {
    await supabase.auth.updateUser({
      data: {
        stage_name: profileData.stageName,
        full_name: profileData.stageName,
        genre: profileData.genre,
        location: profileData.location || 'Teso, Uganda',
        bio: profileData.bio || '',
        avatar_url: profileData.avatarUrl,
        picture: profileData.avatarUrl,
        role: 'artist',
      },
    });

    const profilePayload: Record<string, any> = {
      id: userId,
      full_name: profileData.stageName,
      username: profileData.stageName.toLowerCase().replace(/[^a-z0-9_]/g, '_'),
      role: 'artist',
      updated_at: new Date().toISOString(),
    };
    if (profileData.avatarUrl) profilePayload.avatar_url = profileData.avatarUrl;
    if (profileData.bio !== undefined) profilePayload.bio = profileData.bio;

    const { error } = await supabase.from('profiles').upsert(profilePayload, { onConflict: 'id' });

    if (error) {
      console.warn('Notice saving to public.profiles:', error.message);
    }

    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed to save artist profile' };
  }
};

/**
 * 9. ARTISTS DIRECTORY: Fetch genuine artists from "public.profiles" and uploaded "public.songs"
 * Strictly computes real followers from "public.artist_follows" and real likes from artist songs.
 */
export const fetchArtistsFromSupabase = async (
  songsList?: Song[],
  currentUserId?: string | null
): Promise<Artist[]> => {
  try {
    const songs = songsList || (await fetchSongsFromSupabase());

    const canonicalFollowers = new Map<string, Set<string>>();
    const canonicalCounts = new Map<string, number>();
    const userFollowedSet = new Set<string>();

    const registerFollowRow = (artistRaw: string, followerId?: string) => {
      const slug = canonicalArtistSlug(artistRaw);
      const rawLower = String(artistRaw).toLowerCase().trim();
      [slug, rawLower].forEach((k) => {
        if (!k) return;
        if (!canonicalFollowers.has(k)) canonicalFollowers.set(k, new Set());
        if (followerId) canonicalFollowers.get(k)!.add(followerId);
      });
    };

    const registerFollowedAlias = (artistRaw: string) => {
      const raw = String(artistRaw).toLowerCase().trim();
      const slug = canonicalArtistSlug(artistRaw);
      if (raw) userFollowedSet.add(raw);
      if (slug) userFollowedSet.add(slug);
      userFollowedSet.add(raw.replace(/-/g, ' '));
    };

    const visitorId = getOrCreateVisitorId();
    const actorIds = new Set<string>(
      [currentUserId, visitorId].filter((id): id is string => Boolean(id && id !== 'anon-visitor'))
    );

    // A. Current user / visitor's real follows from public.artist_follows
    if (actorIds.size > 0) {
      try {
        const { data: myFollows } = await supabase
          .from('artist_follows')
          .select('artist_id, artist_name')
          .in('user_id', Array.from(actorIds));
        if (Array.isArray(myFollows)) {
          myFollows.forEach((f: any) => {
            if (f.artist_id) registerFollowedAlias(f.artist_id);
            if (f.artist_name) registerFollowedAlias(f.artist_name);
          });
        }
      } catch (err) {
        console.warn('Notice loading user follows from Supabase:', err);
      }
    }

    // B. Guest follows in localStorage (used when visitor hasn't synced with DB yet)
    if (typeof window !== 'undefined' && !currentUserId) {
      try {
        const guestFollowsRaw = localStorage.getItem('teso_guest_followed_artists');
        if (guestFollowsRaw) {
          const parsed = JSON.parse(guestFollowsRaw);
          if (Array.isArray(parsed)) {
            parsed.forEach((id: string) => registerFollowedAlias(id));
          }
        }
      } catch {
        // ignore
      }
    }

    // C. All real follow rows from Supabase artist_follows (publicly readable so anyone sees real followers)
    try {
      const { data: dbFollows } = await supabase
        .from('artist_follows')
        .select('artist_id, artist_name, user_id');
      if (Array.isArray(dbFollows)) {
        dbFollows.forEach((f: any) => {
          const uid = f.user_id ? String(f.user_id) : undefined;
          if (f.artist_id) registerFollowRow(String(f.artist_id), uid);
          if (f.artist_name) registerFollowRow(String(f.artist_name), uid);
          if (uid && actorIds.has(uid)) {
            if (f.artist_id) registerFollowedAlias(String(f.artist_id));
            if (f.artist_name) registerFollowedAlias(String(f.artist_name));
          }
        });
      }
    } catch {
      // ignore
    }

    // D. Merge backend follows API if active
    try {
      const followsData = await fetchArtistFollowsData(currentUserId || visitorId);
      if (followsData?.followsMap) {
        Object.entries(followsData.followsMap).forEach(([k, count]) => {
          const slug = canonicalArtistSlug(k);
          const lower = k.toLowerCase().trim();
          canonicalCounts.set(slug, Math.max(canonicalCounts.get(slug) || 0, count));
          canonicalCounts.set(lower, Math.max(canonicalCounts.get(lower) || 0, count));
        });
      }
      if (followsData?.userFollowedArtistIds) {
        followsData.userFollowedArtistIds.forEach((id) => registerFollowedAlias(id));
      }
    } catch {
      // ignore
    }

    // E. Authoritative combined artist follower statistics from Supabase view `public.artist_follower_stats`
    const { rows: viewStatsRows, byKey: viewStatsByKey } = await fetchArtistFollowerStatsFromSupabase();

    const resolveFollowerStats = (
      keys: Array<string | undefined>,
      fallbackSongCount: number
    ): { realFollowers: number; songBonusFollowers: number; totalFollowers: number; songCount: number } => {
      // 1. Prefer authoritative Supabase `public.artist_follower_stats` view directly
      for (const k of keys) {
        if (!k) continue;
        const lower = k.toLowerCase().trim();
        const slug = canonicalArtistSlug(k);
        const match = viewStatsByKey.get(slug) || viewStatsByKey.get(lower);
        if (match) {
          return {
            realFollowers: match.real_followers,
            songBonusFollowers: match.bonus_followers,
            totalFollowers: match.total_followers,
            songCount: Math.max(fallbackSongCount, match.song_count),
          };
        }
      }

      // 2. Fallback for registered artists with 0 uploaded songs yet (not yet in view)
      const uniqueIds = new Set<string>();
      let maxFallback = 0;
      keys.forEach((k) => {
        if (!k) return;
        const lower = k.toLowerCase().trim();
        const slug = canonicalArtistSlug(k);
        [lower, slug].forEach((variant) => {
          const set = canonicalFollowers.get(variant);
          if (set) set.forEach((uid) => uniqueIds.add(uid));
          maxFallback = Math.max(maxFallback, canonicalCounts.get(variant) || 0);
        });
      });
      const realFollowers = Math.max(uniqueIds.size, maxFallback);
      const songBonusFollowers = calculateSongMilestoneFollowers(fallbackSongCount);
      return {
        realFollowers,
        songBonusFollowers,
        totalFollowers: realFollowers + songBonusFollowers,
        songCount: fallbackSongCount,
      };
    };

    const { data: profiles, error } = await supabase.from('profiles').select('*');

    // Track how many distinct artist names each uploader user_id has uploaded songs for.
    // Only attach legacy UUID follows to an artist when that user_id unambiguously represents a single artist
    // (or matches the profile's own stage name), preventing admin/multi-artist uploaders from sharing follows.
    const uploaderArtistNames = new Map<string, Set<string>>();
    songs.forEach((s) => {
      if (!s.userId || !s.artist) return;
      const uid = String(s.userId).toLowerCase().trim();
      const aName = s.artist.toLowerCase().trim();
      if (!uploaderArtistNames.has(uid)) uploaderArtistNames.set(uid, new Set());
      uploaderArtistNames.get(uid)!.add(aName);
    });

    const isUnambiguousUploaderForArtist = (uid?: string | null, artistNameLower?: string): boolean => {
      if (!uid) return false;
      const cleanUid = String(uid).toLowerCase().trim();
      const set = uploaderArtistNames.get(cleanUid);
      if (!set || set.size === 0) return true;
      if (set.size === 1) return true;
      return Boolean(artistNameLower && set.size === 1 && set.has(artistNameLower));
    };

    const artistsMap = new Map<string, Artist>();
    const usedIds = new Set<string>();

    const ensureUniqueId = (candidateId?: string | null, fallbackSlug?: string): string => {
      let id = (candidateId || fallbackSlug || 'artist').trim();
      if (!usedIds.has(id)) {
        usedIds.add(id);
        return id;
      }
      let counter = 2;
      while (usedIds.has(`${id}-${counter}`)) {
        counter++;
      }
      const uniqueId = `${id}-${counter}`;
      usedIds.add(uniqueId);
      return uniqueId;
    };

    // 1. Registered Artist Profiles
    if (!error && profiles) {
      profiles.forEach((p: any) => {
        const rawName = (p.full_name || p.username || '').trim();
        const userSongs = songs.filter(
          (s) =>
            (rawName && s.artist.toLowerCase().trim() === rawName.toLowerCase()) ||
            (!rawName && s.userId === p.id)
        );
        const isExplicitArtist = p.role === 'artist';

        if (!rawName && userSongs.length === 0) return;
        if (!isExplicitArtist && userSongs.length === 0) return;

        const artistName = rawName || (userSongs[0] ? userSongs[0].artist : null);
        if (!artistName) return;

        const artistKey = artistName.toLowerCase().trim();
        if (artistsMap.has(artistKey)) return;

        const slugKey = canonicalArtistSlug(artistName);
        const artistId = ensureUniqueId(slugKey, `artist-${slugKey}`);
        const allowLegacyUid =
          Boolean(p.id) &&
          (Boolean(rawName) || isUnambiguousUploaderForArtist(p.id, artistKey));
        const legacyFollowUserId = allowLegacyUid ? String(p.id) : undefined;

        const totalLikes = userSongs.reduce(
          (acc, s) => acc + (typeof s.likes === 'number' ? s.likes : 0),
          0
        );
        const totalPlays = userSongs.reduce((acc, s) => acc + (s.plays || 0), 0);
        const totalDownloads = userSongs.reduce((acc, s) => acc + (s.downloadsCount || 0), 0);
        const {
          realFollowers,
          songBonusFollowers,
          totalFollowers,
          songCount: resolvedSongCount,
        } = resolveFollowerStats(
          [slugKey, artistKey, artistId, legacyFollowUserId],
          userSongs.length
        );

        const isFollowed = Boolean(
          userFollowedSet.has(artistId) ||
            userFollowedSet.has(artistKey) ||
            userFollowedSet.has(slugKey) ||
            (legacyFollowUserId &&
              userFollowedSet.has(legacyFollowUserId.toLowerCase().trim()))
        );

        artistsMap.set(artistKey, {
          id: artistId,
          name: artistName,
          genre: p.genre || userSongs[0]?.genre || 'Afrobeat',
          followers: totalFollowers,
          realFollowers,
          songBonusFollowers,
          isFollowed,
          avatar: normalizeR2Url(p.avatar_url) || userSongs[0]?.coverUrl || HERO_ASSETS.announcement,
          bio: p.bio || `${artistName} is a verified artist on Teso Melodies.`,
          location: p.location || 'Teso, Uganda',
          monthlyListeners:
            totalPlays > 0 ? `${totalPlays.toLocaleString()} streams` : `${totalLikes} likes`,
          topTracks: userSongs.map((s) => s.title),
          userId: p.id,
          legacyFollowUserId,
          isRealArtist: true,
          totalSongs: resolvedSongCount,
          totalLikes,
          totalDownloads,
        });
      });
    }

    // 2. Artists inferred from uploaded songs in public.songs
    songs.forEach((s) => {
      if (!s.artist) return;
      const key = s.artist.toLowerCase().trim();
      if (!artistsMap.has(key)) {
        const artistSongs = songs.filter((song) => song.artist.toLowerCase().trim() === key);
        const totalLikes = artistSongs.reduce(
          (acc, song) => acc + (typeof song.likes === 'number' ? song.likes : 0),
          0
        );
        const totalPlays = artistSongs.reduce((acc, song) => acc + (song.plays || 0), 0);
        const totalDownloads = artistSongs.reduce((acc, song) => acc + (song.downloadsCount || 0), 0);

        const slugKey = canonicalArtistSlug(s.artist);
        const artistId = ensureUniqueId(slugKey, `artist-${slugKey}`);
        const legacyFollowUserId =
          s.userId && isUnambiguousUploaderForArtist(s.userId, key)
            ? String(s.userId)
            : undefined;
        const {
          realFollowers,
          songBonusFollowers,
          totalFollowers,
          songCount: resolvedSongCount,
        } = resolveFollowerStats(
          [slugKey, key, artistId, legacyFollowUserId],
          artistSongs.length
        );

        const isFollowed = Boolean(
          userFollowedSet.has(artistId) ||
            userFollowedSet.has(key) ||
            userFollowedSet.has(slugKey) ||
            (legacyFollowUserId &&
              userFollowedSet.has(legacyFollowUserId.toLowerCase().trim()))
        );

        artistsMap.set(key, {
          id: artistId,
          name: s.artist,
          genre: s.genre || 'Afrobeat',
          followers: totalFollowers,
          realFollowers,
          songBonusFollowers,
          isFollowed,
          avatar: s.coverUrl || HERO_ASSETS.announcement,
          bio: `${s.artist} is an active recording artist on Teso Melodies.`,
          monthlyListeners:
            totalPlays > 0 ? `${totalPlays.toLocaleString()} streams` : `${totalLikes} likes`,
          topTracks: artistSongs.map((song) => song.title),
          userId: s.userId,
          legacyFollowUserId,
          isRealArtist: true,
          totalSongs: resolvedSongCount,
          totalLikes,
          totalDownloads,
        });
      }
    });

    // 3. Guarantee every artist returned by `public.artist_follower_stats` is represented automatically
    viewStatsRows.forEach((stat) => {
      const key = stat.artist_name.toLowerCase().trim();
      if (!key || artistsMap.has(key)) return;
      const slugKey = stat.artist_slug || canonicalArtistSlug(stat.artist_name);
      const artistId = ensureUniqueId(slugKey, `artist-${slugKey}`);
      const isFollowed = Boolean(
        userFollowedSet.has(artistId) ||
          userFollowedSet.has(key) ||
          userFollowedSet.has(slugKey)
      );
      artistsMap.set(key, {
        id: artistId,
        name: stat.artist_name,
        genre: 'Afrobeat',
        followers: stat.total_followers,
        realFollowers: stat.real_followers,
        songBonusFollowers: stat.bonus_followers,
        isFollowed,
        avatar: HERO_ASSETS.announcement,
        bio: `${stat.artist_name} is an active recording artist on Teso Melodies.`,
        monthlyListeners: `${stat.song_count} songs`,
        topTracks: [],
        isRealArtist: true,
        totalSongs: stat.song_count,
        totalLikes: 0,
        totalDownloads: 0,
      });
    });

    return Array.from(artistsMap.values()).sort(
      (a, b) =>
        (b.followers || 0) - (a.followers || 0) ||
        (b.totalLikes || 0) - (a.totalLikes || 0) ||
        (b.totalSongs || 0) - (a.totalSongs || 0)
    );
  } catch (err) {
    console.warn('Notice loading artists from Supabase:', err);
    return [];
  }
};

/**
 * 10. FOLLOW: Toggle follow artist with real database persistence + 20-per-5-songs milestone bonus
 */
export const toggleFollowArtistInSupabase = async (
  userId?: string | null,
  artistId?: string,
  wasFollowed = false,
  artistName?: string,
  userEmail?: string,
  userName?: string,
  options?: {
    artistUserId?: string;
    songCount?: number;
  }
): Promise<{
  success: boolean;
  isFollowed: boolean;
  realFollowers?: number;
  bonusFollowers?: number;
  followers?: number;
  error?: string;
}> => {
  if (!artistId && !artistName) {
    return { success: false, isFollowed: wasFollowed, error: 'Artist identifier missing' };
  }

  const cleanArtistId = (artistId || artistName || '').trim();
  const effectiveUserId = userId || getOrCreateVisitorId();

  const normalizedKey = (artistName || artistId || '').trim().toLowerCase();
  const slugKey = canonicalArtistSlug(artistName || artistId);
  const candidateKeys = Array.from(new Set([cleanArtistId, normalizedKey, slugKey]));

  const syncGuestCache = (followed: boolean) => {
    if (typeof window === 'undefined') return;
    try {
      const raw = localStorage.getItem('teso_guest_followed_artists');
      const set = new Set<string>(raw ? JSON.parse(raw) : []);
      // Store only canonical slug to prevent multi-alias duplicate toggles on login migration
      candidateKeys.forEach((k) => set.delete(k));
      if (followed) {
        set.add(slugKey);
      }
      localStorage.setItem('teso_guest_followed_artists', JSON.stringify(Array.from(set)));
    } catch {
      // ignore
    }
  };

  try {
    const res = await toggleArtistFollowInBackend(
      cleanArtistId,
      artistName || cleanArtistId,
      effectiveUserId,
      wasFollowed,
      userEmail,
      userName,
      options
    );
    if (res.success) {
      syncGuestCache(res.isFollowed);
      return {
        success: true,
        isFollowed: res.isFollowed,
        realFollowers: res.realFollowers,
        bonusFollowers: res.bonusFollowers,
        followers: typeof res.followers === 'number' ? res.followers : undefined,
      };
    }
    return {
      success: false,
      isFollowed: wasFollowed,
      error: res.error || 'Could not save follow in database.',
    };
  } catch (err: any) {
    console.warn('Notice in toggleFollowArtistInSupabase:', err);
    return {
      success: false,
      isFollowed: wasFollowed,
      error: err?.message || 'Could not save follow right now.',
    };
  }
};
