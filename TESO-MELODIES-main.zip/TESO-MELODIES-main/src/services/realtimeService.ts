/**
 * Centralized Real-Time Service for TESO MELODIES
 * Listens to Server-Sent Events (SSE) from /api/realtime and Supabase Realtime
 * Broadcasts instant updates for likes, followers, and comments to all components without page refresh.
 */

import { supabase } from '../supabaseClient';
import { fetchSingleArtistFollowerStat } from './socialService';

export interface SongLikeEvent {
  songId: string;
  likes: number;
  userId?: string;
  isLiked?: boolean;
}

export interface SongDownloadEvent {
  songId: string;
  downloadsCount: number;
  actorId?: string;
}

export interface ArtistFollowEvent {
  artistId: string;
  artistName?: string;
  followers?: number;
  realFollowers?: number;
  bonusFollowers?: number;
  totalFollowers?: number;
  songCount?: number;
  userId?: string;
  isFollowed?: boolean;
}

export interface CommentEvent {
  action: 'create' | 'like' | 'delete' | 'update';
  songId: string;
  commentId?: string;
  comment?: any;
  stats?: {
    totalComments: number;
    averageRating: number;
    totalRatings: number;
  };
}

type LikeListener = (event: SongLikeEvent) => void;
type DownloadListener = (event: SongDownloadEvent) => void;
type FollowListener = (event: ArtistFollowEvent) => void;
type CommentListener = (event: CommentEvent) => void;

class RealtimeManager {
  private eventSource: EventSource | null = null;
  private likeListeners = new Set<LikeListener>();
  private downloadListeners = new Set<DownloadListener>();
  private followListeners = new Set<FollowListener>();
  private commentListeners = new Set<CommentListener>();
  private reconnectTimeout: any = null;
  private isConnected = false;
  private supabaseChannel: any = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.initSSE();
      this.initSupabaseRealtime();
    }
  }

  private initSSE() {
    try {
      if (this.eventSource) {
        this.eventSource.close();
      }

      this.eventSource = new EventSource('/api/realtime');

      this.eventSource.onopen = () => {
        this.isConnected = true;
      };

      // 1. Song Like Updated
      this.eventSource.addEventListener('song_like_updated', (e: MessageEvent) => {
        try {
          const data: SongLikeEvent = JSON.parse(e.data);
          this.likeListeners.forEach((listener) => {
            try {
              listener(data);
            } catch (err) {
              console.warn('Error in like listener:', err);
            }
          });
        } catch (err) {
          console.warn('Error parsing song_like_updated SSE:', err);
        }
      });

      // 1b. Song Download Updated
      this.eventSource.addEventListener('song_download_updated', (e: MessageEvent) => {
        try {
          const data: SongDownloadEvent = JSON.parse(e.data);
          if (data?.songId && typeof data.downloadsCount === 'number') {
            this.downloadListeners.forEach((listener) => {
              try {
                listener(data);
              } catch (err) {
                console.warn('Error in download listener:', err);
              }
            });
          }
        } catch (err) {
          console.warn('Error parsing song_download_updated SSE:', err);
        }
      });

      // 2. Artist Follow Updated
      this.eventSource.addEventListener('artist_follow_updated', (e: MessageEvent) => {
        try {
          const data: ArtistFollowEvent = JSON.parse(e.data);
          this.followListeners.forEach((listener) => {
            try {
              listener(data);
            } catch (err) {
              console.warn('Error in follow listener:', err);
            }
          });
        } catch (err) {
          console.warn('Error parsing artist_follow_updated SSE:', err);
        }
      });

      // 3. Comments Events
      this.eventSource.addEventListener('comment_created', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          this.commentListeners.forEach((listener) => {
            try {
              listener({ action: 'create', songId: data.songId, comment: data.comment, stats: data.stats });
            } catch (err) {
              console.warn('Error in comment listener:', err);
            }
          });
        } catch (err) {
          console.warn('Error parsing comment_created SSE:', err);
        }
      });

      this.eventSource.addEventListener('comment_liked', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          this.commentListeners.forEach((listener) => {
            try {
              listener({ action: 'like', songId: data.songId, commentId: data.commentId, comment: data });
            } catch (err) {
              console.warn('Error in comment listener:', err);
            }
          });
        } catch (err) {
          console.warn('Error parsing comment_liked SSE:', err);
        }
      });

      this.eventSource.addEventListener('comment_deleted', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          this.commentListeners.forEach((listener) => {
            try {
              listener({ action: 'delete', songId: data.songId, commentId: data.commentId, stats: data.stats });
            } catch (err) {
              console.warn('Error in comment listener:', err);
            }
          });
        } catch (err) {
          console.warn('Error parsing comment_deleted SSE:', err);
        }
      });

      this.eventSource.addEventListener('comment_updated', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          this.commentListeners.forEach((listener) => {
            try {
              listener({ action: 'update', songId: data.songId, comment: data.comment });
            } catch (err) {
              console.warn('Error in comment listener:', err);
            }
          });
        } catch (err) {
          console.warn('Error parsing comment_updated SSE:', err);
        }
      });

      this.eventSource.onerror = () => {
        this.isConnected = false;
        if (this.eventSource) {
          this.eventSource.close();
          this.eventSource = null;
        }
        // Reconnect after 4s
        clearTimeout(this.reconnectTimeout);
        this.reconnectTimeout = setTimeout(() => {
          this.initSSE();
        }, 4000);
      };
    } catch (err) {
      console.warn('Notice establishing SSE connection:', err);
    }
  }

  private initSupabaseRealtime() {
    try {
      this.supabaseChannel = supabase
        .channel('public:database_realtime')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'songs' },
          async (payload: any) => {
            if (payload?.new?.id) {
              const updatedSong = payload.new;
              const sId = String(updatedSong.id);
              if (typeof updatedSong.likes === 'number') {
                this.likeListeners.forEach((listener) => {
                  try {
                    listener({ songId: sId, likes: updatedSong.likes });
                  } catch (err) {
                    console.warn('Error in Supabase Realtime like listener:', err);
                  }
                });
              }
              if (typeof updatedSong.downloads_count === 'number') {
                const liveDownloads = Math.max(0, updatedSong.downloads_count);
                this.downloadListeners.forEach((listener) => {
                  try {
                    listener({ songId: sId, downloadsCount: liveDownloads });
                  } catch (err) {
                    console.warn('Error in Supabase Realtime download listener:', err);
                  }
                });
              }
            }

            // When a song is added or removed, refresh that artist's milestone + total follower stats
            if (payload?.eventType === 'INSERT' || payload?.eventType === 'DELETE') {
              const songRow = payload.new || payload.old;
              const artistName = String(songRow?.artist || '').trim();
              if (artistName && songRow?.category !== 'video') {
                const stat = await fetchSingleArtistFollowerStat(undefined, artistName);
                if (stat) {
                  this.followListeners.forEach((listener) => {
                    try {
                      listener({
                        artistId: stat.artist_slug,
                        artistName: stat.artist_name,
                        realFollowers: stat.real_followers,
                        bonusFollowers: stat.bonus_followers,
                        totalFollowers: stat.total_followers,
                        followers: stat.total_followers,
                        songCount: stat.song_count,
                      });
                    } catch (err) {
                      console.warn('Error in Supabase Realtime song-milestone follow listener:', err);
                    }
                  });
                }
              }
            }
          }
        )
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'artist_follows' },
          async (payload: any) => {
            const record = payload.new || payload.old;
            if (record?.artist_id || record?.artist_name) {
              const isInsert = payload.eventType === 'INSERT';
              const rawId = String(record.artist_id || '').trim().toLowerCase();
              const rawName = String(record.artist_name || '').trim().toLowerCase();
              const slug =
                (rawName || rawId).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || rawId;

              // Prefer authoritative combined stats directly from public.artist_follower_stats
              const stat = await fetchSingleArtistFollowerStat(record.artist_id, record.artist_name);
              if (stat) {
                this.followListeners.forEach((listener) => {
                  try {
                    listener({
                      artistId: stat.artist_slug || String(record.artist_id || slug),
                      artistName: stat.artist_name || record.artist_name || undefined,
                      userId: record.user_id,
                      realFollowers: stat.real_followers,
                      bonusFollowers: stat.bonus_followers,
                      totalFollowers: stat.total_followers,
                      followers: stat.total_followers,
                      songCount: stat.song_count,
                      isFollowed: isInsert,
                    });
                  } catch (err) {
                    console.warn('Error in Supabase Realtime follow listener:', err);
                  }
                });
                return;
              }

              // Fallback for artists not yet in the view (e.g. 0 uploaded songs)
              const matchSet = new Set(
                [rawId, rawName, slug, rawName.replace(/-/g, ' '), rawId.replace(/-/g, ' ')].filter(
                  Boolean
                )
              );
              let realFollowerCount: number | undefined;
              try {
                const { data: rows } = await supabase
                  .from('artist_follows')
                  .select('artist_id, artist_name, user_id');
                if (Array.isArray(rows)) {
                  const uniqueUsers = new Set<string>();
                  rows.forEach((r: any) => {
                    const aId = String(r.artist_id || '').trim().toLowerCase();
                    const aName = String(r.artist_name || '').trim().toLowerCase();
                    const aSlug = (aName || aId)
                      .replace(/[^a-z0-9]+/g, '-')
                      .replace(/^-|-$/g, '');
                    if (
                      matchSet.has(aId) ||
                      (aName && matchSet.has(aName)) ||
                      (aSlug && matchSet.has(aSlug))
                    ) {
                      if (r.user_id) uniqueUsers.add(String(r.user_id));
                    }
                  });
                  realFollowerCount = uniqueUsers.size;
                }
              } catch {
                realFollowerCount = undefined;
              }
              this.followListeners.forEach((listener) => {
                try {
                  listener({
                    artistId: String(record.artist_id || slug),
                    artistName: record.artist_name || undefined,
                    userId: record.user_id,
                    realFollowers: realFollowerCount,
                    followers: realFollowerCount,
                    isFollowed: isInsert,
                  });
                } catch (err) {
                  console.warn('Error in Supabase Realtime follow listener:', err);
                }
              });
            }
          }
        )
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'song_comments' },
          (payload: any) => {
            if (payload?.new?.id) {
              const row = payload.new;
              const comment = {
                id: String(row.id),
                songId: String(row.song_id),
                songTitle: row.song_title,
                artistName: row.artist_name,
                userId: row.user_id,
                userEmail: row.user_email,
                userName: row.user_name || 'Fan',
                userAvatar: row.user_avatar,
                content: row.content || '',
                rating: typeof row.rating === 'number' ? row.rating : 5,
                likes: typeof row.likes === 'number' ? row.likes : 0,
                likedBy: Array.isArray(row.liked_by) ? row.liked_by : [],
                replyToId: row.reply_to_id,
                replyToUserName: row.reply_to_user_name,
                createdAt: row.created_at || new Date().toISOString(),
                updatedAt: row.updated_at,
              };
              this.commentListeners.forEach((listener) => {
                try {
                  listener({
                    action: payload.eventType === 'DELETE' ? 'delete' : 'create',
                    songId: comment.songId,
                    commentId: comment.id,
                    comment,
                  });
                } catch (err) {
                  console.warn('Error in Supabase Realtime comment listener:', err);
                }
              });
            }
          }
        )
        .subscribe();
    } catch (err) {
      console.warn('Notice establishing Supabase Realtime channel:', err);
    }
  }

  public onSongLike(listener: LikeListener): () => void {
    this.likeListeners.add(listener);
    return () => {
      this.likeListeners.delete(listener);
    };
  }

  public onSongDownload(listener: DownloadListener): () => void {
    this.downloadListeners.add(listener);
    return () => {
      this.downloadListeners.delete(listener);
    };
  }

  public onArtistFollow(listener: FollowListener): () => void {
    this.followListeners.add(listener);
    return () => {
      this.followListeners.delete(listener);
    };
  }

  public onComment(listener: CommentListener): () => void {
    this.commentListeners.add(listener);
    return () => {
      this.commentListeners.delete(listener);
    };
  }
}

export const realtime = new RealtimeManager();
