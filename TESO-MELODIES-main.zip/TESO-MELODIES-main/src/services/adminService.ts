import { supabase } from '../supabaseClient';
import { Announcement } from '../types/music';
import { HERO_ASSETS } from '../data/initialData';
import { NewsArticle, createNewsArticle, toAnnouncement } from './newsService';

export const AUTHORIZED_ADMIN_EMAIL = 'tesomelodies@gmail.com';

export interface AdminAuthResult {
  authorized: boolean;
  email: string | null;
  userId: string | null;
  error?: string;
}

/**
 * Synchronous UI convenience helper — authorization is enforced on Supabase Auth + RLS.
 */
export const isUserAdminEmail = (email?: string | null): boolean => {
  if (!email) return false;
  return email.trim().toLowerCase() === AUTHORIZED_ADMIN_EMAIL.toLowerCase();
};

/**
 * Verifies with Supabase Auth that the active session belongs to tesomelodies@gmail.com.
 */
export const verifyAdminAuthorization = async (): Promise<AdminAuthResult> => {
  try {
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser();

    if (error || !user) {
      return {
        authorized: false,
        email: null,
        userId: null,
        error: `Authentication required. Please sign in as ${AUTHORIZED_ADMIN_EMAIL}.`,
      };
    }

    const email = user.email?.trim().toLowerCase() || '';
    if (email !== AUTHORIZED_ADMIN_EMAIL.toLowerCase()) {
      return {
        authorized: false,
        email,
        userId: user.id,
        error: `Permission Denied: Only ${AUTHORIZED_ADMIN_EMAIL} is authorized to access the Admin News Panel.`,
      };
    }

    return {
      authorized: true,
      email,
      userId: user.id,
    };
  } catch (err: any) {
    return {
      authorized: false,
      email: null,
      userId: null,
      error: err?.message || 'Failed to verify administrator authorization.',
    };
  }
};

/**
 * Secure publishing for News items (persisted permanently in public.news).
 */
export const publishNewsItem = async (news: {
  title: string;
  category: string;
  description: string;
  fullContent: string;
  imageUrl?: string;
  coverFile?: File | null;
  status?: 'draft' | 'published';
}): Promise<{ success: boolean; announcement?: Announcement; article?: NewsArticle; error?: string }> => {
  const res = await createNewsArticle({
    title: news.title,
    category: news.category || 'Portal News',
    badge: news.category || 'News',
    description: news.description,
    fullContent: news.fullContent || news.description,
    imageUrl: news.imageUrl || HERO_ASSETS.announcement,
    coverFile: news.coverFile,
    status: news.status || 'published',
  });

  if (!res.success || !res.announcement) {
    return { success: false, error: res.error };
  }

  return { success: true, announcement: res.announcement, article: res.article };
};

/**
 * Secure publishing for "Teso Melodies is Live!" / official announcements.
 */
export const publishLiveAnnouncement = async (data: {
  title: string;
  tagline: string;
  details: string;
  badge?: string;
  imageUrl?: string;
}): Promise<{ success: boolean; announcement?: Announcement; article?: NewsArticle; error?: string }> => {
  const res = await createNewsArticle({
    title: data.title.trim() || 'Teso Melodies is Live!',
    category: 'Official Live',
    badge: data.badge || 'Official Live',
    description: data.tagline.trim(),
    fullContent: (data.details || data.tagline).trim(),
    imageUrl: data.imageUrl || HERO_ASSETS.announcement,
    status: 'published',
  });

  if (!res.success || !res.announcement) {
    return { success: false, error: res.error };
  }

  return { success: true, announcement: res.announcement, article: res.article };
};

/**
 * Secure publishing for Advertisements.
 */
export const publishAdvertisement = async (ad: {
  brandName: string;
  tagline: string;
  description: string;
  contactInfo: string;
  imageUrl?: string;
}): Promise<{ success: boolean; announcement?: Announcement; article?: NewsArticle; error?: string }> => {
  const res = await createNewsArticle({
    title: ad.brandName.trim(),
    category: 'Advertisement',
    badge: 'Sponsored',
    description: ad.tagline.trim(),
    fullContent: `${ad.description.trim()}\n\nContact / Inquiries: ${ad.contactInfo.trim()}`,
    imageUrl: ad.imageUrl || HERO_ASSETS.adMegaphone,
    status: 'published',
  });

  if (!res.success || !res.announcement) {
    return { success: false, error: res.error };
  }

  return { success: true, announcement: res.announcement, article: res.article };
};

export { toAnnouncement };
