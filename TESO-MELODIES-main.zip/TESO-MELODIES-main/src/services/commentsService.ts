import { supabase } from '../supabaseClient';
import { UserProfile } from '../types/music';
import { realtime } from './realtimeService';
import { SEEDED_SONG_COMMENTS } from '../data/seedEngagement';

export interface SongComment {
  id: string;
  songId: string;
  songTitle?: string;
  artistName?: string;
  userId?: string;
  userEmail?: string;
  userName: string;
  userAvatar?: string;
  content: string;
  rating: number; // 1 to 5 (0 if no rating provided)
  likes: number;
  likedBy: string[]; // user IDs or visitor IDs
  replyToId?: string;
  replyToUserName?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface SongReviewSummary {
  totalComments: number;
  totalRatings: number;
  averageRating: number;
}

const STORAGE_KEY = 'teso_song_comments_v1';
const DELETED_COMMENTS_KEY = 'teso_deleted_comment_ids_v1';
const COMMENTS_EVENT = 'teso_comments_updated';

const getDeletedCommentIds = (): Set<string> => {
  if (typeof window === 'undefined') return new Set();
  try {
    const raw = localStorage.getItem(DELETED_COMMENTS_KEY);
    if (!raw) return new Set();
    const parsed = JSON.parse(raw);
    return new Set(Array.isArray(parsed) ? parsed.map(String) : []);
  } catch {
    return new Set();
  }
};

const markCommentIdsDeleted = (ids: string[]) => {
  if (typeof window === 'undefined' || ids.length === 0) return;
  try {
    const set = getDeletedCommentIds();
    ids.forEach((id) => set.add(String(id)));
    localStorage.setItem(DELETED_COMMENTS_KEY, JSON.stringify(Array.from(set)));
  } catch {
    // ignore
  }
};

/**
 * Generate standard UUID required by Supabase PostgreSQL UUID columns
 */
export const generateUUID = (): string => {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
};

const isUuid = (val?: string | null): boolean =>
  Boolean(val && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(val));

/**
 * Retrieve comments from resilient local storage merged with seeded engagement comments
 */
export const getStoredComments = (): SongComment[] => {
  const deletedIds = getDeletedCommentIds();
  if (typeof window === 'undefined') {
    return [...SEEDED_SONG_COMMENTS];
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    const stored: SongComment[] = Array.isArray(parsed) ? parsed : [];
    const seenIds = new Set(stored.map((c) => c.id));
    const missingSeeded = SEEDED_SONG_COMMENTS.filter(
      (c) => !seenIds.has(c.id) && !deletedIds.has(c.id)
    );
    return [...stored, ...missingSeeded];
  } catch (err) {
    console.warn('Error reading stored comments:', err);
    return SEEDED_SONG_COMMENTS.filter((c) => !deletedIds.has(c.id));
  }
};

/**
 * Save comments to resilient local storage and trigger update event
 */
export const saveStoredComments = (comments: SongComment[]) => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(comments));
    window.dispatchEvent(new CustomEvent(COMMENTS_EVENT));
  } catch (err) {
    console.warn('Error saving comments to localStorage:', err);
  }
};

// Auto-sync real-time incoming comments across all open clients
if (typeof window !== 'undefined') {
  realtime.onComment((evt) => {
    try {
      const existing = getStoredComments();
      if (evt.action === 'create' && evt.comment) {
        if (!existing.some((c) => c.id === evt.comment.id)) {
          saveStoredComments([evt.comment, ...existing]);
        }
      } else if (evt.action === 'delete' && evt.commentId) {
        saveStoredComments(
          existing.filter((c) => c.id !== evt.commentId && c.replyToId !== evt.commentId)
        );
      } else if (evt.action === 'like' && evt.commentId && evt.comment) {
        saveStoredComments(
          existing.map((c) =>
            c.id === evt.commentId
              ? { ...c, likes: evt.comment.likes, likedBy: evt.comment.likedBy }
              : c
          )
        );
      } else if (evt.action === 'update' && evt.comment) {
        saveStoredComments(
          existing.map((c) => (c.id === evt.comment.id ? { ...c, ...evt.comment } : c))
        );
      }
    } catch (err) {
      console.warn('Notice processing real-time comment update:', err);
    }
  });
}

/**
 * 1. Fetch all comments for a specific song
 * Queries Supabase public.song_comments table directly so EVERY visitor
 * (including guests not logged in) can see all comments and replies.
 */
export const fetchSongComments = async (songId: string): Promise<SongComment[]> => {
  if (!songId) return [];

  const commentMap = new Map<string, SongComment>();

  // A. Query Supabase directly first (public read)
  try {
    const { data, error } = await supabase
      .from('song_comments')
      .select('*')
      .eq('song_id', String(songId))
      .order('created_at', { ascending: false });

    if (!error && data && Array.isArray(data)) {
      data.forEach((row: any) => {
        commentMap.set(String(row.id), {
          id: String(row.id),
          songId: String(row.song_id || songId),
          songTitle: row.song_title,
          artistName: row.artist_name,
          userId: row.user_id,
          userEmail: row.user_email,
          userName: row.user_name || 'Teso Melodies Fan',
          userAvatar: row.user_avatar,
          content: row.content || '',
          rating: typeof row.rating === 'number' ? row.rating : 5,
          likes: typeof row.likes === 'number' ? row.likes : 0,
          likedBy: Array.isArray(row.liked_by) ? row.liked_by : [],
          replyToId: row.reply_to_id || undefined,
          replyToUserName: row.reply_to_user_name || undefined,
          createdAt: row.created_at || new Date().toISOString(),
          updatedAt: row.updated_at,
        });
      });
    }
  } catch (err) {
    console.warn('Notice fetching comments from Supabase:', err);
  }

  // B. Query backend server database (/api/comments?songId=...) as secondary
  const deletedIds = getDeletedCommentIds();
  try {
    const res = await fetch(`/api/comments?songId=${encodeURIComponent(songId)}`);
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      const data = await res.json();
      if (data.success && Array.isArray(data.comments)) {
        data.comments.forEach((c: SongComment) => {
          if (!commentMap.has(c.id) && !deletedIds.has(c.id)) {
            commentMap.set(c.id, c);
          }
        });
      }
    }
  } catch {
    // Backend API may be offline on static host
  }

  // C. Merge with persistent local storage + seeded fan comments
  const localComments = getStoredComments();
  localComments
    .filter((c) => String(c.songId) === String(songId) && !deletedIds.has(c.id))
    .forEach((c) => {
      if (!commentMap.has(c.id)) {
        commentMap.set(c.id, c);
      } else if (c.id.startsWith('seed-cmt-')) {
        // Preserve any local like/edit state on seeded comments
        commentMap.set(c.id, c);
      }
    });

  const merged = Array.from(commentMap.values());
  // Sort newest first
  merged.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // Update persistent local cache
  try {
    const currentAll = getStoredComments();
    const otherSongs = currentAll.filter((c) => String(c.songId) !== String(songId));
    saveStoredComments([...merged, ...otherSongs]);
  } catch {
    // Ignore
  }

  return merged;
};

/**
 * 2. Add a new comment or reply and save it permanently to the database
 */
export const addSongComment = async (params: {
  songId: string;
  songTitle?: string;
  artistName?: string;
  content: string;
  rating?: number;
  user?: UserProfile;
  visitorName?: string;
  replyToId?: string;
  replyToUserName?: string;
}): Promise<{ success: boolean; comment?: SongComment; error?: string }> => {
  const {
    songId,
    songTitle,
    artistName,
    content,
    rating = 5,
    user,
    visitorName,
    replyToId,
    replyToUserName,
  } = params;

  if (!songId) {
    return { success: false, error: 'Song ID is required' };
  }

  const cleanContent = content.trim();
  if (!cleanContent) {
    return { success: false, error: 'Please write a comment or review before submitting.' };
  }

  // Detect authenticated user in Supabase
  let activeUserId: string | null = null;
  let activeEmail: string | null = null;
  try {
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (session?.user) {
      activeUserId = session.user.id;
      activeEmail = session.user.email || null;
    }
  } catch {
    // ignore
  }

  if (!activeUserId && user?.id && isUuid(user.id)) {
    activeUserId = user.id;
    activeEmail = user.email || null;
  }

  if (!activeUserId) {
    return {
      success: false,
      error: 'Please sign in or create an account to post comments and reviews.',
    };
  }

  // Generate valid UUID for Postgres UUID column
  const commentId = generateUUID();
  const now = new Date().toISOString();

  let authorName = 'Teso Melodies Fan';
  if (user?.stageName || user?.name) {
    authorName = user.stageName || user.name;
  } else if (visitorName && visitorName.trim()) {
    authorName = visitorName.trim();
  }

  const newComment: SongComment = {
    id: commentId,
    songId: String(songId),
    songTitle: songTitle || 'Song',
    artistName: artistName || 'Artist',
    userId: activeUserId,
    userEmail: activeEmail || user?.email,
    userName: authorName,
    userAvatar: user?.avatar,
    content: cleanContent,
    rating: Math.min(5, Math.max(0, Number(rating) || 5)),
    likes: 0,
    likedBy: [],
    replyToId: replyToId || undefined,
    replyToUserName: replyToUserName || undefined,
    createdAt: now,
  };

  // 1. Save directly to Supabase public.song_comments
  try {
    const { error: sbErr } = await supabase.from('song_comments').insert([
      {
        id: newComment.id,
        song_id: newComment.songId,
        song_title: newComment.songTitle,
        artist_name: newComment.artistName,
        user_id: newComment.userId,
        user_email: newComment.userEmail || null,
        user_name: newComment.userName,
        user_avatar: newComment.userAvatar || null,
        content: newComment.content,
        rating: newComment.rating,
        likes: 0,
        liked_by: [],
        reply_to_id: newComment.replyToId || null,
        reply_to_user_name: newComment.replyToUserName || null,
        created_at: newComment.createdAt,
      },
    ]);

    if (sbErr) {
      console.error('Supabase comment insert error:', sbErr);
      return { success: false, error: sbErr.message || 'Failed to save comment to database' };
    }
  } catch (err: any) {
    console.error('Unexpected Supabase insert error:', err);
    return { success: false, error: err?.message || 'Database connection error' };
  }

  // 2. Immediately write to persistent local cache and trigger UI update
  try {
    const existing = getStoredComments();
    saveStoredComments([newComment, ...existing]);
  } catch (err) {
    console.warn('LocalStorage save error:', err);
  }

  // 3. Also sync to backend API if available
  try {
    fetch('/api/comments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newComment),
    }).catch(() => {});
  } catch {
    // Non-fatal
  }

  return { success: true, comment: newComment };
};

/**
 * 3. Edit an existing comment
 */
export const editSongComment = async (params: {
  commentId: string;
  songId: string;
  content: string;
  rating?: number;
  user?: UserProfile;
}): Promise<{ success: boolean; comment?: SongComment; error?: string }> => {
  const { commentId, songId, content, rating, user } = params;

  if (!content.trim()) {
    return { success: false, error: 'Comment content cannot be empty.' };
  }

  const allComments = getStoredComments();
  const index = allComments.findIndex(
    (c) => c.id === commentId && String(c.songId) === String(songId)
  );

  if (index === -1) {
    return { success: false, error: 'Comment not found.' };
  }

  const target = allComments[index];
  const isAdmin = user?.email?.toLowerCase() === 'tesomelodies@gmail.com';
  const isAuthor =
    (user?.isLoggedIn && (user.id === target.userId || user.email === target.userEmail)) ||
    (!target.userId && !target.userEmail);

  if (!isAdmin && !isAuthor) {
    return { success: false, error: 'You are not authorized to edit this comment.' };
  }

  const updatedComment: SongComment = {
    ...target,
    content: content.trim(),
    rating: typeof rating === 'number' ? rating : target.rating,
    updatedAt: new Date().toISOString(),
  };

  allComments[index] = updatedComment;
  saveStoredComments(allComments);

  // Sync to Supabase
  try {
    await supabase
      .from('song_comments')
      .update({
        content: updatedComment.content,
        rating: updatedComment.rating,
        updated_at: updatedComment.updatedAt,
      })
      .eq('id', commentId);
  } catch {
    // ignore
  }

  // Sync to Backend Database
  try {
    fetch(`/api/comments/${encodeURIComponent(commentId)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: updatedComment.content,
        rating: updatedComment.rating,
        userEmail: user?.email,
        userId: user?.id,
      }),
    }).catch(() => {});
  } catch {
    // ignore
  }

  return { success: true, comment: updatedComment };
};

/**
 * 4. Delete a comment
 */
export const deleteSongComment = async (
  commentId: string,
  songId: string,
  user?: UserProfile
): Promise<{ success: boolean; error?: string }> => {
  const allComments = getStoredComments();
  const target = allComments.find(
    (c) => c.id === commentId && String(c.songId) === String(songId)
  );

  if (!target) {
    return { success: false, error: 'Comment not found.' };
  }

  const isAdmin = user?.email?.toLowerCase() === 'tesomelodies@gmail.com';
  const isAuthor =
    (user?.isLoggedIn && (user.id === target.userId || user.email === target.userEmail)) ||
    (!target.userId && !target.userEmail);

  if (!isAdmin && !isAuthor) {
    return { success: false, error: 'You are not authorized to delete this comment.' };
  }

  // Remove comment and any replies
  const removedIds = allComments
    .filter((c) => c.id === commentId || c.replyToId === commentId)
    .map((c) => c.id);
  markCommentIdsDeleted(removedIds);
  const remaining = allComments.filter((c) => c.id !== commentId && c.replyToId !== commentId);
  saveStoredComments(remaining);

  // Sync delete to Supabase
  try {
    await supabase.from('song_comments').delete().eq('id', commentId);
  } catch {
    // ignore
  }

  // Sync delete to backend database
  try {
    fetch(`/api/comments/${encodeURIComponent(commentId)}`, {
      method: 'DELETE',
      headers: {
        'x-user-email': user?.email || '',
        'x-user-id': user?.id || '',
      },
    }).catch(() => {});
  } catch {
    // ignore
  }

  return { success: true };
};

/**
 * 5. Like or unlike a comment
 */
export const toggleLikeComment = async (
  commentId: string,
  songId: string,
  visitorId: string
): Promise<{ success: boolean; likes: number; isLiked: boolean }> => {
  const allComments = getStoredComments();
  const index = allComments.findIndex(
    (c) => c.id === commentId && String(c.songId) === String(songId)
  );

  if (index === -1) {
    return { success: false, likes: 0, isLiked: false };
  }

  const comment = allComments[index];
  const likedBy = Array.isArray(comment.likedBy) ? [...comment.likedBy] : [];
  const alreadyLiked = likedBy.includes(visitorId);

  let updatedLikedBy: string[];
  let updatedLikes: number;

  if (alreadyLiked) {
    updatedLikedBy = likedBy.filter((id) => id !== visitorId);
    updatedLikes = Math.max(0, (comment.likes || 1) - 1);
  } else {
    updatedLikedBy = [...likedBy, visitorId];
    updatedLikes = (comment.likes || 0) + 1;
  }

  const updatedComment: SongComment = {
    ...comment,
    likes: updatedLikes,
    likedBy: updatedLikedBy,
  };

  allComments[index] = updatedComment;
  saveStoredComments(allComments);

  // Sync to Supabase
  try {
    await supabase
      .from('song_comments')
      .update({
        likes: updatedLikes,
        liked_by: updatedLikedBy,
      })
      .eq('id', commentId);
  } catch {
    // ignore
  }

  // Sync to Backend Database
  try {
    fetch(`/api/comments/${encodeURIComponent(commentId)}/like`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ visitorId, songId }),
    }).catch(() => {});
  } catch {
    // ignore
  }

  return {
    success: true,
    likes: updatedLikes,
    isLiked: !alreadyLiked,
  };
};

/**
 * 6. Get review stats for a specific song
 */
export const getSongReviewSummary = (songId: string): SongReviewSummary => {
  if (!songId) {
    return { totalComments: 0, totalRatings: 0, averageRating: 0 };
  }

  const all = getStoredComments();
  const forSong = all.filter((c) => String(c.songId) === String(songId));

  const totalComments = forSong.length;
  const ratings = forSong
    .filter((c) => typeof c.rating === 'number' && c.rating > 0)
    .map((c) => c.rating);
  const totalRatings = ratings.length;

  const averageRating =
    totalRatings > 0
      ? Number((ratings.reduce((acc, r) => acc + r, 0) / totalRatings).toFixed(1))
      : 0;

  return {
    totalComments,
    totalRatings,
    averageRating,
  };
};

/**
 * 7. Get all review summaries mapped by song ID
 */
export const getAllSongReviewSummaries = (): Record<string, SongReviewSummary> => {
  const all = getStoredComments();
  const map: Record<string, SongReviewSummary> = {};

  all.forEach((c) => {
    const sId = String(c.songId);
    if (!map[sId]) {
      map[sId] = { totalComments: 0, totalRatings: 0, averageRating: 0 };
    }
    map[sId].totalComments += 1;
  });

  Object.keys(map).forEach((sId) => {
    const forSong = all.filter(
      (c) => String(c.songId) === sId && typeof c.rating === 'number' && c.rating > 0
    );
    if (forSong.length > 0) {
      map[sId].totalRatings = forSong.length;
      map[sId].averageRating = Number(
        (forSong.reduce((acc, c) => acc + (c.rating || 0), 0) / forSong.length).toFixed(1)
      );
    }
  });

  return map;
};

/**
 * Background sync on app load to pull all latest Supabase comments into client
 */
export const syncServerComments = async () => {
  const deletedIds = getDeletedCommentIds();
  const map = new Map<string, SongComment>();

  // Seed with current local + seeded comments first
  getStoredComments().forEach((c) => {
    if (!deletedIds.has(c.id)) {
      map.set(c.id, c);
    }
  });

  // A. Query Supabase directly
  try {
    const { data, error } = await supabase
      .from('song_comments')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && Array.isArray(data)) {
      data.forEach((row: any) => {
        const c: SongComment = {
          id: String(row.id),
          songId: String(row.song_id),
          songTitle: row.song_title,
          artistName: row.artist_name,
          userId: row.user_id,
          userEmail: row.user_email,
          userName: row.user_name || 'Teso Melodies Fan',
          userAvatar: row.user_avatar,
          content: row.content || '',
          rating: typeof row.rating === 'number' ? row.rating : 5,
          likes: typeof row.likes === 'number' ? row.likes : 0,
          likedBy: Array.isArray(row.liked_by) ? row.liked_by : [],
          replyToId: row.reply_to_id || undefined,
          replyToUserName: row.reply_to_user_name || undefined,
          createdAt: row.created_at || new Date().toISOString(),
          updatedAt: row.updated_at,
        };
        if (!deletedIds.has(c.id)) {
          map.set(c.id, c);
        }
      });
    }
  } catch (err) {
    console.warn('Supabase comments sync notice:', err);
  }

  // B. Also merge comments from local server API without dropping seeded or Supabase entries
  try {
    const res = await fetch('/api/comments');
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      const data = await res.json();
      if (data.success && Array.isArray(data.comments)) {
        data.comments.forEach((c: SongComment) => {
          if (!deletedIds.has(c.id) && !map.has(c.id)) {
            map.set(c.id, c);
          }
        });
      }
    }
  } catch {
    // ignore
  }

  saveStoredComments(Array.from(map.values()));
};

/**
 * Listen for updates to comments
 */
export const onCommentsUpdated = (callback: () => void): (() => void) => {
  if (typeof window === 'undefined') return () => {};
  window.addEventListener(COMMENTS_EVENT, callback);
  return () => {
    window.removeEventListener(COMMENTS_EVENT, callback);
  };
};
