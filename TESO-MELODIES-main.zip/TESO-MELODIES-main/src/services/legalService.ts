/**
 * Legal Service for TESO MELODIES.com
 * Handles Privacy Policy and Terms & Conditions content, persistence,
 * and authorized administrator editing.
 */

import { AUTHORIZED_ADMIN_EMAIL, verifyAdminAuthorization } from './adminService';

export interface LegalDocument {
  title: string;
  lastUpdated: string;
  governingJurisdiction: string;
  contactEmail: string;
  content: string; // Markdown or formatted text
  sections: Array<{
    id: string;
    title: string;
    content: string;
  }>;
}

export const DEFAULT_PRIVACY_POLICY: LegalDocument = {
  title: 'Privacy Policy',
  lastUpdated: '8 November 2026',
  governingJurisdiction: 'Republic of Uganda',
  contactEmail: 'tesomelodies@gmail.com',
  content: '',
  sections: [
    {
      id: 'introduction',
      title: '1. Introduction and Overview',
      content: `Welcome to TESO MELODIES.com ("TESO MELODIES", "we", "our", or "us"). We are dedicated to celebrating, preserving, and distributing authentic Teso, Ugandan, and East African music, including traditional Akoogo melodies, Gospel, Teso Worship, R&B, Reggae, Dancehall, Amapiano, and Afrobeat.

We respect your privacy and are committed to protecting your personal data in accordance with the Data Protection and Privacy Act of Uganda and applicable international privacy standards. This Privacy Policy explains how we collect, use, process, disclose, and safeguard your personal information when you visit our website (https://tesomelodies.com), create a fan or artist account, upload audio tracks or album art, stream music, download tracks, or interact with our community services.`
    },
    {
      id: 'info-we-collect',
      title: '2. Information We Collect',
      content: `We collect information directly from you when you register, communicate with us, upload content, or interact with the platform, as well as technical information generated automatically through your usage of the website.`
    },
    {
      id: 'personal-info',
      title: '3. Personal Information',
      content: `Depending on how you use TESO MELODIES, we may collect the following personal information:
• Full Legal Name or Stage Name (for recording artists, vocalists, songwriters, and performers).
• Email Address: Used for account creation, identity verification, account security notices, and password resets.
• Profile Pictures and Photographs: Photos uploaded by artists or fans to represent their public profile or discography.
• Contact Phone Numbers: Mobile contact numbers (such as Airtel Uganda or MTN Uganda) provided voluntarily for artist booking inquiries, promotional campaigns, or mobile money royalties.
• Location / Region: Geographic region or city (e.g., Teso Sub-region, Soroti, Kumi, Kampala, Uganda) provided by artists to help fans discover local regional music.`
    },
    {
      id: 'account-and-profile',
      title: '4. Account and Profile Information',
      content: `• Listener / Fan Accounts: Registered email address, username, favorite songs list (saved in user_favorites), and followed artists list.
• Artist / Musician Accounts: Stage name, primary musical genre (e.g., Akoogo, Gospel, Teso Worship, Afrobeat), biography, avatar photo, catalog of uploaded songs, follower counts, and total listener likes.
• Google Authentication Data: When you choose to authenticate using Google Sign-In, we receive your basic public profile information (name, verified email address, and profile picture URL). We do NOT request or access your private Google Drive files, contacts, calendar, or emails.`
    },
    {
      id: 'technical-info',
      title: '5. Technical Information and IP Addresses',
      content: `When you visit or stream music on TESO MELODIES, our hosting infrastructure and backend automatically collect standard web server technical logs, including:
• Internet Protocol (IP) address.
• Browser type, version, and language preferences.
• Operating system (Android, iOS, Windows, macOS, Linux).
• Device identifiers, screen resolution, and referring website URLs.
• Anonymous visitor identifiers (visitor_id) generated locally in your browser to accurately register song plays, free downloads, and like metrics without requiring you to log in.`
    },
    {
      id: 'cookies-tracking',
      title: '6. Cookies and Local Storage Technologies',
      content: `We use cookies and browser LocalStorage solely to deliver essential platform functionality:
• Authentication & Session Tokens: Secure tokens managed by Supabase Auth to keep you signed in securely across browser sessions.
• User Preferences: LocalStorage keys (such as "teso_liked_songs" and "teso_followed_artists") that remember your favorite tracks and followed artists on your device even if you stream anonymously without an account.
• Playback State: Storing audio volume and repeat preferences in the web player.
• We do NOT deploy intrusive third-party cross-site behavioral advertising trackers or sell your tracking data to data brokers.`
    },
    {
      id: 'how-we-use',
      title: '7. How We Use Your Information',
      content: `We process your personal information strictly for legitimate business and artistic purposes:
• To create, maintain, and secure your fan or artist account.
• To host, stream, display, and distribute uploaded music, album cover art, and artist credits to visitors worldwide.
• To provide 100% free streaming and high-speed MP3 audio downloads for music listeners.
• To calculate and display accurate, real-time song like counts, stream counts, and artist followers.
• To administer the Community Royalty Pool and verify artist earnings eligibility.
• To facilitate music promotion, advertising bookings, and official announcements.
• To detect, investigate, and prevent fraudulent uploads, copyright violations, abusive behavior, and security breaches.
• To comply with legal obligations and enforce our Terms and Conditions.`
    },
    {
      id: 'music-video-uploads',
      title: '8. Music and Video Uploads',
      content: `When an artist uploads an audio file (MP3, WAV, AAC) and cover artwork to TESO MELODIES:
• The audio file is permanently stored in our secure dedicated Supabase Storage bucket ("songs").
• Metadata (song title, artist name, user_id, genre, duration, audio URL, cover URL, and timestamp) is stored in our "public.songs" database table.
• Uploaded audio and cover images are publicly accessible for streaming and downloading by visitors worldwide.
• Uploading artists are solely responsible for ensuring they possess all necessary copyrights, master recording rights, and performer rights for their uploads.`
    },
    {
      id: 'sharing-info',
      title: '9. Sharing of Information',
      content: `TESO MELODIES values your trust. We adhere to a strict policy:
• No Sale of Personal Data: We do not sell, rent, trade, or monetize your personal information or Google user data under any circumstances.
• Public Information: Your artist stage name, public profile biography, profile photo, and uploaded songs are publicly displayed on the website for music fans and visitors.
• Legal and Regulatory Disclosures: We may disclose your information if required to do so by law, court order, or subpoena issued by law enforcement authorities in the Republic of Uganda, or to protect the safety, rights, and property of TESO MELODIES, our artists, or the public.`
    },
    {
      id: 'third-party-services',
      title: '10. Third-Party Service Providers',
      content: `To operate a reliable, high-performance music platform, we work with trusted service providers who process data strictly on our behalf:
• Supabase Inc.: Database hosting (PostgreSQL), cloud storage for audio files and cover art, and secure user authentication. Data is transmitted securely via TLS/HTTPS and protected by Row Level Security (RLS).
• Google Identity Services: Client-side OAuth authentication allowing users to sign in with their Google accounts quickly and safely.
• Telecommunications & Mobile Money Partners: Official contact lines via Airtel Uganda (0752848442) and MTN Uganda (0788 900047) for bookings, creator promotions, and mobile money royalty disbursements.
• Messaging & Social Channels: WhatsApp Business (+256 788 900047), Telegram (t.me/tesomelodies), Facebook (@tesomelodies), TikTok (@tesomelodies), and YouTube (@TESOMELODIES) for official communications.`
    },
    {
      id: 'data-security',
      title: '11. Data Security',
      content: `We implement robust technical and organizational security measures to protect your personal information:
• End-to-end encryption in transit using Transport Layer Security (TLS 1.2 / 1.3 / HTTPS).
• Supabase Row Level Security (RLS) policies ensuring registered artists can only modify or delete their own uploaded tracks and profiles.
• Strict role-based backend authorization restricting news, advertising, and announcement publishing strictly to authorized administrator accounts.
• Password hashing using industry-standard bcrypt algorithms managed by Supabase Auth.`
    },
    {
      id: 'data-retention',
      title: '12. Data Retention and Account Deletion',
      content: `• We retain your account data for as long as your account remains active.
• Uploaded songs and cover art remain available on the platform until you choose to delete them through your Artist Dashboard or submit a formal deletion request.
• Account Deletion Request: You may delete your account and request complete erasure of your personal data at any time by sending an email from your registered address to tesomelodies@gmail.com. We process deletion requests within thirty (30) business days.`
    },
    {
      id: 'user-rights',
      title: '13. User Privacy Rights',
      content: `Under Ugandan law and international best practices, you have the right to:
• Access: Request a copy of the personal information we hold about you.
• Correction: Update or correct inaccurate or incomplete profile information through your dashboard.
• Erasure: Request the deletion of your personal account, uploaded tracks, or profile details.
• Objection & Restriction: Object to specific data processing activities or request restrictions on processing.
• To exercise any of these rights, contact our Data Protection team at tesomelodies@gmail.com.`
    },
    {
      id: 'childrens-privacy',
      title: "14. Children's Privacy",
      content: `TESO MELODIES is designed for general audiences. We do not knowingly collect personal identifiable information from children under the age of thirteen (13). If you are a parent or guardian and believe that your child has provided personal information to us without your consent, please contact us at tesomelodies@gmail.com so we can promptly remove the information.`
    },
    {
      id: 'international-transfers',
      title: '15. International Data Transfers',
      content: `Your information and uploaded audio tracks may be hosted on cloud servers located outside of Uganda (such as secure European or North American cloud data centers utilized by Supabase and cloud hosting providers). By using TESO MELODIES, you consent to the transfer, storage, and processing of your information in these secure facilities in accordance with this Privacy Policy.`
    },
    {
      id: 'links-other-sites',
      title: '16. Links to Other Websites and External Services',
      content: `Our website contains links to external social media platforms, messaging applications (WhatsApp, Telegram), and third-party services. We are not responsible for the privacy practices, terms of service, or content of those external websites. We encourage you to read the privacy policies of any third-party service you visit.`
    },
    {
      id: 'changes-policy',
      title: '17. Changes to This Privacy Policy',
      content: `We may periodically update this Privacy Policy to reflect platform improvements, legal requirements, or changes in our data processing practices. When updates are published, we will revise the "Last Updated" date at the top of this document. Continued use of TESO MELODIES following the posting of changes constitutes your acceptance of the revised policy.`
    },
    {
      id: 'contact-us',
      title: '18. Contact Us',
      content: `If you have questions, comments, concerns, or requests regarding this Privacy Policy or your personal information, please contact our Legal and Privacy team:

TESO MELODIES.com
Official Email: tesomelodies@gmail.com
Music Promotion & Booking Lines:
• Airtel Uganda: 0752848442
• MTN Uganda: 0788 900047
• WhatsApp: +256 788 900047
• Telegram: https://t.me/tesomelodies
Location: Kampala / Soroti, Republic of Uganda`
    }
  ]
};

export const DEFAULT_TERMS_AND_CONDITIONS: LegalDocument = {
  title: 'Terms and Conditions',
  lastUpdated: '8 November 2026',
  governingJurisdiction: 'Republic of Uganda',
  contactEmail: 'tesomelodies@gmail.com',
  content: '',
  sections: [
    {
      id: 'acceptance',
      title: '1. Introduction and Acceptance of Terms',
      content: `Welcome to TESO MELODIES.com ("TESO MELODIES", "the Website", "we", "our", or "us"). These Terms and Conditions govern your access to and use of https://tesomelodies.com, our mobile web applications, music player, creator dashboards, and related services.

By accessing, browsing, registering an account, uploading songs, streaming music, or downloading audio tracks from TESO MELODIES, you expressly agree to be bound by these Terms and Conditions and our Privacy Policy. If you do not agree to all of these terms, you must not access or use the Website.`
    },
    {
      id: 'about-platform',
      title: '2. About TESO MELODIES',
      content: `TESO MELODIES is East Africa's home for authentic musical expression, bridging the historic rhythms of the Akoogo with contemporary Teso Worship, Gospel, R&B, Reggae, Dancehall, Amapiano, and Afrobeat. Our platform provides 100% free streaming and high-quality MP3 downloads for fans, direct visibility and community royalties for recording artists, and professional promotion for regional and international creators. Tagline: "Teso Music, Our Pride ❤️".`
    },
    {
      id: 'user-registration',
      title: '3. User Registration and Accounts',
      content: `• Registration Options: Visitors may register as a "Listener / Fan" or as an "Artist / Musician".
• Age Requirement: You must be at least 13 years of age, or have the consent of a parent or legal guardian, to create an account.
• Accurate Information: You agree to provide accurate, current, and complete registration information (including email address and artist stage name) and keep your profile updated.
• Account Security: You are responsible for safeguarding your password and account credentials. You must notify us immediately at tesomelodies@gmail.com of any unauthorized use of your account.
• Account Agreement: During registration, all users are required to confirm that they have read and agreed to these Terms and Conditions and our Privacy Policy.`
    },
    {
      id: 'user-responsibilities',
      title: '4. User Responsibilities and Acceptable Use',
      content: `When using TESO MELODIES, you agree that you will not:
• Violate any applicable local, national, or international law or regulation of the Republic of Uganda.
• Upload, distribute, or promote content that is defamatory, obscene, pornographic, hateful, racially offensive, or incites violence.
• Attempt to interfere with, disrupt, reverse engineer, or compromise the security, infrastructure, or integrity of the Website or Supabase databases.
• Use automated bots, scrapers, or scripts to harvest user data, artificially inflate song plays, downloads, or likes.
• Impersonate any artist, individual, or entity, or falsely claim affiliation with any organization.`
    },
    {
      id: 'music-uploads-ip',
      title: '5. Music and Video Uploads – Creator Rights and Licensing',
      content: `CRITICAL OWNERSHIP & PERMISSION REQUIREMENTS:
• Proof of Rights: You must own all copyrights or have obtained all necessary written licenses, rights, consents, and permissions from the composer, lyricist, producer, and featured performers before uploading any song, audio track, music video, or cover artwork to TESO MELODIES.
• No Transfer of Ownership: Uploading content to TESO MELODIES DOES NOT transfer ownership of your intellectual property to TESO MELODIES. You retain 100% of your copyright, master recording rights, publishing rights, and artistic ownership.
• Grant of Non-Exclusive License: By uploading audio tracks, lyrics, artwork, or videos to TESO MELODIES, you grant TESO MELODIES a non-exclusive, worldwide, royalty-free (for fan streaming purposes), revocable license to host, store, index, transcode, display, stream, and distribute your content across our platform and players for its intended streaming and free promotional download services.
• Revocation / Deletion: You may revoke this license at any time by deleting your uploaded tracks from your Artist Dashboard. Upon deletion, the audio file and cover image will be removed from our public storage and database.`
    },
    {
      id: 'copyright-takedown',
      title: '6. Copyright and Intellectual Property Enforcement (Takedown Policy)',
      content: `TESO MELODIES respects the intellectual property rights of musicians, composers, and record labels. We maintain a zero-tolerance policy for copyright infringement.

If you are a copyright owner or an authorized agent and believe that content hosted on TESO MELODIES infringes upon your copyright, please submit a written Notice of Infringement to our designated agent at:
Email: tesomelodies@gmail.com
Subject: Copyright Infringement Notice

Your notice must contain:
1. Identification of the copyrighted work claimed to have been infringed (title, artist, album).
2. The specific URL or exact title/artist of the allegedly infringing material on TESO MELODIES.
3. Information sufficient to contact you (full legal name, phone number, email address, physical address).
4. A statement that you have a good faith belief that the disputed use is not authorized by the copyright owner, its agent, or the law.
5. A statement made under penalty of perjury that the information in your notice is accurate and that you are authorized to act on behalf of the owner.
6. A physical or electronic signature.

Upon receipt of a valid notice, we will promptly investigate and remove or disable access to the infringing material.`
    },
    {
      id: 'downloads-streaming',
      title: '7. Music Downloads and Free Streaming Policy',
      content: `• Free Streaming: Visitors and registered fans may stream published music tracks directly from the website without subscription fees.
• Free MP3 Downloads: Published songs equipped with a download button may be downloaded free of charge for personal, non-commercial, and offline listening purposes.
• Commercial Restrictions: You may not sell, rent, sublicense, commercially broadcast, or create derivative commercial products from downloaded tracks without explicit written authorization from the copyright holder.`
    },
    {
      id: 'community-rules',
      title: '8. Community Rules and User Conduct',
      content: `TESO MELODIES is built on unity, respect, and celebration of culture. Users engaging in community discussions, reviews, notes, or comments must adhere to civil discourse. Hate speech, cyberbullying, harassment, or malicious attacks against any artist or ethnic group will result in immediate termination of the offending account.`
    },
    {
      id: 'artist-metrics',
      title: '9. Artist Profiles, Likes, and Real Engagement',
      content: `• Verified Artist Profiles: Registered artists can manage their biographies, profile photos, genres, and discography.
• Real Metrics Integrity: Every like, stream count, and follower on TESO MELODIES must represent genuine human interaction. We strictly prohibit pay-for-fake-likes schemes, click farms, or automated script manipulation.
• Trending Chart Criteria: Songs featured in the "Trending Songs" list are ranked strictly based on real like counts and genuine audience appreciation.`
    },
    {
      id: 'monetization-earnings',
      title: '10. Artist Earnings and Monetization',
      content: `• Community Revenue Sharing: TESO MELODIES operates a creator monetization program where verified recording artists can earn from their creative works based on verified streams, audience reach, and community royalty pools.
• Eligibility & Verification: Monetization is subject to artist verification, minimum catalog requirements, and adherence to intellectual property rules.
• Payout Methods: Royalty distributions and earnings disbursements are processed via authorized local mobile money channels (such as Airtel Money or MTN Mobile Money) or designated bank transfers in Uganda.
• Taxes: Creators are responsible for reporting and paying any applicable taxes on their earnings in accordance with the tax laws of Uganda.`
    },
    {
      id: 'promotion-advertising',
      title: '11. Music Promotion, Advertising, and Bookings',
      content: `• Promotion Inquiries: Artists and brands may request official promotional placement, sponsored banner ads, and event broadcasting through our dedicated channels:
  - Airtel Uganda: 0752848442
  - MTN Uganda: 0788 900047
  - WhatsApp: +256 788 900047
  - Telegram: https://t.me/tesomelodies
• Administrative Restrictions: Only the authorized platform administrator account (tesomelodies@gmail.com) has authorization to publish official news articles, sponsored advertisements, and live broadcasts.`
    },
    {
      id: 'third-party-links',
      title: '12. Third-Party Links and External Services',
      content: `The Website may contain links to external third-party websites, video hosting platforms (YouTube), and social networks (Facebook, TikTok, Telegram). We have no control over and assume no liability for the content, privacy policies, or business practices of any third-party websites or services.`
    },
    {
      id: 'website-availability',
      title: '13. Website Availability and Modifications',
      content: `We strive to ensure continuous, high-speed platform availability. However, TESO MELODIES may undergo scheduled maintenance, infrastructure upgrades, or emergency repairs. We reserve the right to modify, suspend, or discontinue any feature, chart, or service without prior notice.`
    },
    {
      id: 'disclaimer-warranties',
      title: '14. Disclaimer of Warranties',
      content: `TO THE MAXIMUM EXTENT PERMITTED BY THE LAWS OF UGANDA, TESO MELODIES IS PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. WE DO NOT WARRANT THAT AUDIO STREAMING WILL BE UNINTERRUPTED, VIRUS-FREE, OR ERROR-FREE.`
    },
    {
      id: 'limitation-liability',
      title: '15. Limitation of Liability',
      content: `UNDER NO CIRCUMSTANCES SHALL TESO MELODIES, ITS FOUNDERS, OPERATORS, EMPLOYEES, OR AGENTS BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES ARISING FROM YOUR ACCESS TO, USE OF, OR INABILITY TO USE THE PLATFORM, OR FOR ANY UNAUTHORIZED UPLOAD OF CONTENT BY THIRD PARTIES.`
    },
    {
      id: 'suspension-termination',
      title: '16. Account Suspension and Termination',
      content: `We reserve the right, in our sole discretion, to suspend or permanently terminate your account, remove uploaded tracks, and restrict your access to TESO MELODIES if:
• You breach any provision of these Terms and Conditions or our Privacy Policy.
• You upload content that infringes upon the intellectual property rights of third parties.
• You engage in fraudulent activities, spam, or platform abuse.`
    },
    {
      id: 'changes-terms',
      title: '17. Changes to These Terms',
      content: `We may revise these Terms and Conditions at any time. When modifications occur, we will update the "Last Updated" date at the top of this document. Your continued use of TESO MELODIES following the posting of revised Terms confirms your binding acceptance of the updated Terms.`
    },
    {
      id: 'governing-law',
      title: '18. Governing Law and Dispute Resolution',
      content: `These Terms and Conditions shall be governed by, construed, and enforced in accordance with the laws of the Republic of Uganda. Any disputes arising out of or in connection with these Terms shall be subject to the exclusive jurisdiction of the competent courts of Uganda, with preliminary efforts made to resolve disputes amicably through good-faith dialogue.`
    },
    {
      id: 'contact-info',
      title: '19. Contact Information',
      content: `For any inquiries, legal notices, copyright complaints, or questions regarding these Terms and Conditions, please contact us:

TESO MELODIES.com
Official Email: tesomelodies@gmail.com
Music Promotion & Bookings:
• Airtel Uganda: 0752848442
• MTN Uganda: 0788 900047
• WhatsApp: +256 788 900047
• Telegram: https://t.me/tesomelodies
Location: Kampala / Soroti, Republic of Uganda`
    }
  ]
};

const STORAGE_KEY_PRIVACY = 'teso_legal_privacy_policy';
const STORAGE_KEY_TERMS = 'teso_legal_terms_conditions';

export const getPrivacyPolicy = (): LegalDocument => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PRIVACY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.sections && parsed.sections.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Notice loading privacy policy:', err);
  }
  return DEFAULT_PRIVACY_POLICY;
};

export const getTermsAndConditions = (): LegalDocument => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_TERMS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.sections && parsed.sections.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Notice loading terms and conditions:', err);
  }
  return DEFAULT_TERMS_AND_CONDITIONS;
};

export const saveLegalDocument = async (
  docType: 'privacy' | 'terms',
  document: LegalDocument
): Promise<{ success: boolean; error?: string }> => {
  // Verify administrator authorization
  const auth = await verifyAdminAuthorization();
  if (!auth.authorized) {
    return {
      success: false,
      error: auth.error || `Permission denied: Only ${AUTHORIZED_ADMIN_EMAIL} can edit legal documents.`,
    };
  }

  try {
    const key = docType === 'privacy' ? STORAGE_KEY_PRIVACY : STORAGE_KEY_TERMS;
    localStorage.setItem(key, JSON.stringify(document));
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed to save legal document.' };
  }
};

export const resetLegalDocumentToDefault = async (
  docType: 'privacy' | 'terms'
): Promise<{ success: boolean; error?: string }> => {
  const auth = await verifyAdminAuthorization();
  if (!auth.authorized) {
    return { success: false, error: auth.error };
  }

  const key = docType === 'privacy' ? STORAGE_KEY_PRIVACY : STORAGE_KEY_TERMS;
  localStorage.removeItem(key);
  return { success: true };
};
