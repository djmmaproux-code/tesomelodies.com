import { supabase, SUPABASE_URL } from '../supabaseClient';
import { VideoItem, VideoQualityKey } from '../types/music';
import { HERO_ASSETS } from '../data/initialData';
import { deleteStorageFile, R2_PUBLIC_BASE_URL, uploadAppFile } from './storageService';
import { extractR2KeyFromUrl, getOrCreateVisitorId, normalizeR2Url } from './musicService';

export const VIDEO_CATEGORIES = [
  'Music Video',
  'Live Performance',
  'Acoustic Session',
  'Teso Worship',
  'Gospel',
  'Akoogo',
  'Visualizer',
  'Teso Dancehall',
  'Afrobeat',
  'Lyrics Video',
  'Behind the Scenes',
] as const;

export const VIDEO_QUALITY_ORDER: VideoQualityKey[] = ['1080p', '720p', '480p', '360p'];

const isMissingTableError = (err: any): boolean => {
  if (!err) return false;
  const code = String(err.code || '').toUpperCase();
  const msg = String(err.message || '').toLowerCase();
  return (
    code === 'PGRST205' ||
    code === '42P01' ||
    msg.includes('could not find the table') ||
    msg.includes('does not exist')
  );
};

export const formatVideoDuration = (totalSeconds: number): string => {
  if (!Number.isFinite(totalSeconds) || totalSeconds <= 0) return '00:00';
  const secs = Math.round(totalSeconds);
  const hours = Math.floor(secs / 3600);
  const mins = Math.floor((secs % 3600) / 60);
  const remSecs = secs % 60;
  if (hours > 0) {
    return `${hours}:${mins.toString().padStart(2, '0')}:${remSecs.toString().padStart(2, '0')}`;
  }
  return `${mins.toString().padStart(2, '0')}:${remSecs.toString().padStart(2, '0')}`;
};

export const formatVideoViews = (count: number): string => {
  const safe = Math.max(0, Math.floor(count || 0));
  if (safe === 1) return '1 view';
  if (safe >= 1_000_000) return `${(safe / 1_000_000).toFixed(1).replace(/\.0$/, '')}M views`;
  if (safe >= 1_000) return `${(safe / 1_000).toFixed(1).replace(/\.0$/, '')}K views`;
  return `${safe.toLocaleString()} views`;
};

export const formatVideoDate = (isoDate?: string): string => {
  if (!isoDate) return 'Recently added';
  const created = new Date(isoDate);
  if (Number.isNaN(created.getTime())) return 'Recently added';
  const diffMs = Date.now() - created.getTime();
  const diffHours = Math.floor(diffMs / 3_600_000);
  if (diffHours < 1) return 'Just now';
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays === 1) return '1 day ago';
  if (diffDays < 7) return `${diffDays} days ago`;
  return created.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

export const detectQualityFromHeight = (height?: number): VideoQualityKey => {
  if (!height || !Number.isFinite(height)) return '720p';
  if (height >= 1000) return '1080p';
  if (height >= 680) return '720p';
  if (height >= 440) return '480p';
  return '360p';
};

export interface ExtractedVideoMetadata {
  durationSec: number;
  durationStr: string;
  width: number;
  height: number;
  detectedQuality: VideoQualityKey;
  autoThumbnailFile: File | null;
  autoThumbnailPreviewUrl: string | null;
}

/**
 * Inspects a local video File in the browser to determine its real duration,
 * native resolution (360p/480p/720p/1080p), and captures a preview thumbnail frame.
 */
export const extractVideoMetadata = (file: File): Promise<ExtractedVideoMetadata> => {
  return new Promise((resolve) => {
    const fallback: ExtractedVideoMetadata = {
      durationSec: 0,
      durationStr: '00:00',
      width: 1280,
      height: 720,
      detectedQuality: '720p',
      autoThumbnailFile: null,
      autoThumbnailPreviewUrl: null,
    };

    if (typeof document === 'undefined' || !file) {
      resolve(fallback);
      return;
    }

    let settled = false;
    const objectUrl = URL.createObjectURL(file);
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;

    const cleanup = () => {
      try {
        video.removeAttribute('src');
        video.load();
      } catch {
        // ignore
      }
      URL.revokeObjectURL(objectUrl);
    };

    const finish = (result: ExtractedVideoMetadata) => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve(result);
    };

    const timeout = window.setTimeout(() => {
      finish(fallback);
    }, 6500);

    video.onloadedmetadata = () => {
      const durationSec = Number.isFinite(video.duration) ? Math.round(video.duration) : 0;
      const durationStr = formatVideoDuration(durationSec);
      const width = video.videoWidth || 1280;
      const height = video.videoHeight || 720;
      const detectedQuality = detectQualityFromHeight(height);

      // Seek to ~1.5s (or 20% in) to grab a crisp poster frame
      const seekTarget = durationSec > 2 ? Math.min(1.5, durationSec * 0.25) : 0.1;
      try {
        video.currentTime = seekTarget;
      } catch {
        window.clearTimeout(timeout);
        finish({
          durationSec,
          durationStr,
          width,
          height,
          detectedQuality,
          autoThumbnailFile: null,
          autoThumbnailPreviewUrl: null,
        });
      }
    };

    video.onseeked = () => {
      const durationSec = Number.isFinite(video.duration) ? Math.round(video.duration) : 0;
      const durationStr = formatVideoDuration(durationSec);
      const width = video.videoWidth || 1280;
      const height = video.videoHeight || 720;
      const detectedQuality = detectQualityFromHeight(height);

      try {
        const scale = Math.min(1, 1280 / Math.max(1, width));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(320, Math.round(width * scale));
        canvas.height = Math.max(180, Math.round(height * scale));
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          window.clearTimeout(timeout);
          finish({
            durationSec,
            durationStr,
            width,
            height,
            detectedQuality,
            autoThumbnailFile: null,
            autoThumbnailPreviewUrl: null,
          });
          return;
        }
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(
          (blob) => {
            window.clearTimeout(timeout);
            if (!blob || blob.size < 200) {
              finish({
                durationSec,
                durationStr,
                width,
                height,
                detectedQuality,
                autoThumbnailFile: null,
                autoThumbnailPreviewUrl: null,
              });
              return;
            }
            const thumbFile = new File([blob], 'video-thumbnail.jpg', { type: 'image/jpeg' });
            const previewUrl = URL.createObjectURL(blob);
            finish({
              durationSec,
              durationStr,
              width,
              height,
              detectedQuality,
              autoThumbnailFile: thumbFile,
              autoThumbnailPreviewUrl: previewUrl,
            });
          },
          'image/jpeg',
          0.86
        );
      } catch {
        window.clearTimeout(timeout);
        finish({
          durationSec,
          durationStr,
          width,
          height,
          detectedQuality,
          autoThumbnailFile: null,
          autoThumbnailPreviewUrl: null,
        });
      }
    };

    video.onerror = () => {
      window.clearTimeout(timeout);
      finish(fallback);
    };

    video.src = objectUrl;
  });
};

const normalizeQualityUrls = (
  raw: any,
  primaryUrl: string,
  defaultQuality?: VideoQualityKey
): Partial<Record<VideoQualityKey, string>> => {
  const result: Partial<Record<VideoQualityKey, string>> = {};

  if (raw && typeof raw === 'object') {
    for (const q of VIDEO_QUALITY_ORDER) {
      const candidate = normalizeR2Url(raw[q]);
      if (candidate) {
        result[q] = candidate;
      }
    }
  }

  const normalizedPrimary = normalizeR2Url(primaryUrl) || primaryUrl;
  const fallbackQuality: VideoQualityKey =
    defaultQuality && VIDEO_QUALITY_ORDER.includes(defaultQuality) ? defaultQuality : '720p';

  if (normalizedPrimary && !Object.values(result).includes(normalizedPrimary)) {
    result[fallbackQuality] = result[fallbackQuality] || normalizedPrimary;
  }

  return result;
};

export const mapVideoRow = (row: any, metaOverride?: any): VideoItem | null => {
  const rawVideoUrl = normalizeR2Url(row.video_url || row.audio_url);
  if (!rawVideoUrl) return null;

  const viewsCount =
    typeof row.views === 'number'
      ? row.views
      : typeof row.plays === 'number'
      ? row.plays
      : 0;
  const likesCount = typeof row.likes === 'number' ? row.likes : 0;

  const defaultQuality: VideoQualityKey =
    metaOverride?.defaultQuality ||
    (VIDEO_QUALITY_ORDER.includes(row.default_quality) ? row.default_quality : '720p');

  const qualityUrls = normalizeQualityUrls(
    metaOverride?.qualityUrls || row.quality_urls,
    rawVideoUrl,
    defaultQuality
  );

  const category = metaOverride?.category || row.category || row.genre || 'Music Video';
  const normalizedCategory = category === 'video' ? row.genre || 'Music Video' : category;

  const normalizedThumb = normalizeR2Url(row.thumbnail_url || row.cover_url);
  return {
    id: String(row.id),
    userId: row.user_id || undefined,
    title: (row.title || 'Untitled Video').trim(),
    artist: (row.artist || 'Independent Artist').trim(),
    description: metaOverride?.description ?? row.description ?? '',
    category: normalizedCategory,
    genre: metaOverride?.genre || row.genre || normalizedCategory || 'Afrobeat',
    thumbnail: normalizedThumb || HERO_ASSETS.announcement,
    videoUrl: rawVideoUrl,
    videoPath: row.video_path || extractR2KeyFromUrl(rawVideoUrl),
    thumbnailPath: row.thumbnail_path || extractR2KeyFromUrl(normalizedThumb),
    fileSize: typeof row.file_size === 'number' ? row.file_size : undefined,
    mimeType: row.mime_type || undefined,
    qualityUrls,
    defaultQuality,
    duration: row.duration || formatVideoDuration(row.duration_sec || 0),
    durationSec: typeof row.duration_sec === 'number' ? row.duration_sec : 0,
    viewsCount,
    views: formatVideoViews(viewsCount),
    likes: likesCount,
    releaseDate: formatVideoDate(row.created_at),
    createdAt: row.created_at || undefined,
    isRealUpload: true,
  };
};

const buildMetaPublicUrls = (userId: string, videoId: string): string[] => {
  const cleanUser = userId.replace(/[^a-zA-Z0-9_-]/g, '');
  const cleanVideo = videoId.replace(/[^a-zA-Z0-9_-]/g, '');
  return [
    `${R2_PUBLIC_BASE_URL}/${cleanUser}/attachments/${cleanVideo}/video-meta.json`,
    `${SUPABASE_URL}/storage/v1/object/public/songs/${userId}/attachments/${videoId}/video-meta.json`,
    `${SUPABASE_URL}/storage/v1/object/public/app-files/${userId}/attachments/${videoId}/video-meta.json`,
  ];
};

const fetchSidecarMetadata = async (userId?: string, videoId?: string): Promise<any | null> => {
  if (!userId || !videoId) return null;
  for (const url of buildMetaPublicUrls(userId, videoId)) {
    try {
      const res = await fetch(url, { cache: 'no-store' });
      if (res.ok) {
        const ct = (res.headers.get('content-type') || '').toLowerCase();
        if (ct.includes('json') || ct.includes('octet-stream') || ct.includes('text/plain')) {
          return await res.json();
        }
      }
    } catch {
      // ignore missing manifest
    }
  }
  return null;
};

const uploadSidecarMetadata = async (userId: string, videoId: string, payload: Record<string, any>) => {
  try {
    const metaFile = new File([JSON.stringify(payload)], 'video-meta.json', {
      type: 'application/json',
    });
    const res = await uploadAppFile(userId, 'attachments', videoId, metaFile, undefined, {
      fixedFileName: 'video-meta.json',
    });
    return Boolean(!res.error && res.publicUrl);
  } catch {
    return false;
  }
};

/**
 * Fetches all real uploaded videos from Supabase.
 * Primary source: public.videos
 * Seamless compatibility fallback: public.songs (where category = 'video') if public.videos has not been created yet.
 */
export const fetchVideosFromSupabase = async (): Promise<{ videos: VideoItem[]; error: string | null }> => {
  const collected = new Map<string, VideoItem>();
  let videosTableExists = true;

  try {
    const { data, error } = await supabase
      .from('videos')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      if (isMissingTableError(error)) {
        videosTableExists = false;
      } else {
        return { videos: [], error: error.message };
      }
    } else if (Array.isArray(data)) {
      data.forEach((row) => {
        const mapped = mapVideoRow(row);
        if (mapped) collected.set(mapped.id, mapped);
      });
    }
  } catch (err: any) {
    return { videos: [], error: err?.message || 'Unable to load videos from Supabase' };
  }

  // Also check legacy/fallback video rows stored under category = 'video' so nothing is lost
  try {
    const { data: songVideoRows, error: songErr } = await supabase
      .from('songs')
      .select('*')
      .eq('category', 'video')
      .order('created_at', { ascending: false });

    if (!songErr && Array.isArray(songVideoRows) && songVideoRows.length > 0) {
      await Promise.all(
        songVideoRows.map(async (row) => {
          if (collected.has(String(row.id))) return;
          const sidecar = await fetchSidecarMetadata(row.user_id, String(row.id));
          const mapped = mapVideoRow(row, sidecar);
          if (mapped) collected.set(mapped.id, mapped);
        })
      );
    } else if (songErr && !videosTableExists) {
      return { videos: [], error: songErr.message };
    }
  } catch (err: any) {
    if (!videosTableExists) {
      return { videos: [], error: err?.message || 'Unable to load videos' };
    }
  }

  const result = Array.from(collected.values()).sort((a, b) => {
    const ta = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const tb = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    return tb - ta;
  });

  return { videos: result, error: null };
};

/**
 * Fetches a single video by ID from public.videos (or public.songs category='video' fallback).
 */
export const fetchVideoByIdFromSupabase = async (videoId: string): Promise<VideoItem | null> => {
  if (!videoId) return null;
  try {
    const { data: vRow, error: vErr } = await supabase
      .from('videos')
      .select('*')
      .eq('id', videoId)
      .maybeSingle();

    if (!vErr && vRow) {
      return mapVideoRow(vRow);
    }

    const { data: sRow, error: sErr } = await supabase
      .from('songs')
      .select('*')
      .eq('id', videoId)
      .eq('category', 'video')
      .maybeSingle();

    if (!sErr && sRow) {
      const sidecar = await fetchSidecarMetadata(sRow.user_id, String(sRow.id));
      return mapVideoRow(sRow, sidecar);
    }
  } catch {
    // ignore
  }
  return null;
};

export interface CreateVideoInput {
  id?: string;
  title: string;
  artist: string;
  description?: string;
  category: string;
  genre?: string;
  thumbnailUrl?: string;
  videoUrl: string;
  videoPath?: string;
  thumbnailPath?: string;
  fileSize?: number;
  mimeType?: string;
  qualityUrls?: Partial<Record<VideoQualityKey, string>>;
  defaultQuality?: VideoQualityKey;
  duration?: string;
  durationSec?: number;
}

/**
 * Inserts a newly uploaded video record into Supabase (public.videos primary, public.songs category='video' fallback).
 */
export const createVideoInSupabase = async (
  input: CreateVideoInput,
  userId?: string
): Promise<{ video: VideoItem | null; error: string | null }> => {
  try {
    let effectiveUserId = userId;
    if (!effectiveUserId) {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      effectiveUserId = user?.id;
    }

    if (!effectiveUserId) {
      return { video: null, error: 'You must be signed in to upload videos.' };
    }

    if (!input.videoUrl) {
      return { video: null, error: 'A valid uploaded video URL is required.' };
    }

    const itemId =
      input.id ||
      (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : undefined);

    const normalizedVideoUrl = normalizeR2Url(input.videoUrl) || input.videoUrl;
    const normalizedThumbUrl = normalizeR2Url(input.thumbnailUrl) || HERO_ASSETS.announcement;
    const defaultQuality: VideoQualityKey = input.defaultQuality || '720p';
    const qualityUrls = normalizeQualityUrls(input.qualityUrls, normalizedVideoUrl, defaultQuality);
    const cleanCategory = (input.category || 'Music Video').trim();
    const cleanGenre = (input.genre || cleanCategory || 'Afrobeat').trim();
    const cleanDurationSec = input.durationSec || 0;
    const cleanDuration = input.duration || formatVideoDuration(cleanDurationSec);

    // Ensure profile exists for RLS
    try {
      const { data: curProfile } = await supabase
        .from('profiles')
        .select('id, role')
        .eq('id', effectiveUserId)
        .maybeSingle();

      if (!curProfile) {
        await supabase.from('profiles').insert([
          {
            id: effectiveUserId,
            full_name: (input.artist || 'Artist').trim(),
            username: (input.artist || 'artist').trim().toLowerCase().replace(/[^a-z0-9_]/g, '_'),
            role: 'artist',
            updated_at: new Date().toISOString(),
          },
        ]);
      }
    } catch {
      // ignore profile helper errors
    }

    // 1. Primary insert into public.videos
    const videosBasePayload: Record<string, any> = {
      ...(itemId ? { id: itemId } : {}),
      user_id: effectiveUserId,
      title: input.title.trim(),
      artist: input.artist.trim(),
      description: (input.description || '').trim(),
      category: cleanCategory,
      genre: cleanGenre,
      thumbnail_url: normalizedThumbUrl,
      video_url: normalizedVideoUrl,
      quality_urls: qualityUrls,
      default_quality: defaultQuality,
      duration: cleanDuration,
      duration_sec: cleanDurationSec,
      views: 0,
      likes: 0,
    };

    const resolvedVideoPath = input.videoPath || extractR2KeyFromUrl(normalizedVideoUrl);
    const resolvedThumbPath = input.thumbnailPath || extractR2KeyFromUrl(normalizedThumbUrl);

    const videosExtendedPayload: Record<string, any> = {
      ...videosBasePayload,
      ...(resolvedVideoPath ? { video_path: resolvedVideoPath } : {}),
      ...(resolvedThumbPath ? { thumbnail_path: resolvedThumbPath } : {}),
      ...(input.fileSize ? { file_size: input.fileSize } : {}),
      ...(input.mimeType ? { mime_type: input.mimeType } : {}),
      storage_provider: 'cloudflare-r2',
    };

    let { data: insertedVideo, error: videosErr } = await supabase
      .from('videos')
      .insert([videosExtendedPayload])
      .select('*')
      .single();

    if (
      videosErr &&
      (videosErr.message?.includes('schema cache') ||
        videosErr.message?.includes('column') ||
        videosErr.code === 'PGRST204' ||
        videosErr.code === '42703')
    ) {
      const retryBase = await supabase
        .from('videos')
        .insert([videosBasePayload])
        .select('*')
        .single();
      insertedVideo = retryBase.data;
      videosErr = retryBase.error;
    }

    if (!videosErr && insertedVideo) {
      const mapped = mapVideoRow(insertedVideo);
      return { video: mapped, error: null };
    }

    if (videosErr && !isMissingTableError(videosErr)) {
      return { video: null, error: videosErr.message };
    }

    // 2. Seamless fallback when public.videos table has not been provisioned yet in Supabase SQL Editor
    const fallbackId =
      itemId || (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `vid-${Date.now()}`);

    const metaPayload = {
      description: (input.description || '').trim(),
      category: cleanCategory,
      genre: cleanGenre,
      qualityUrls,
      defaultQuality,
    };

    await uploadSidecarMetadata(effectiveUserId, fallbackId, metaPayload);

    const songsFallbackPayload: Record<string, any> = {
      id: fallbackId,
      user_id: effectiveUserId,
      title: input.title.trim(),
      artist: input.artist.trim(),
      genre: cleanCategory,
      duration: cleanDuration,
      duration_sec: cleanDurationSec || 180,
      category: 'video',
      cover_url: normalizedThumbUrl,
      audio_url: normalizedVideoUrl,
      plays: 0,
      likes: 0,
      rank: null,
    };

    const { data: insertedFallback, error: fallbackErr } = await supabase
      .from('songs')
      .insert([songsFallbackPayload])
      .select('*')
      .single();

    if (fallbackErr) {
      return { video: null, error: fallbackErr.message };
    }

    return { video: mapVideoRow(insertedFallback, metaPayload), error: null };
  } catch (err: any) {
    return { video: null, error: err?.message || 'Failed to save video in Supabase' };
  }
};

/**
 * Increments view count when a visitor plays a video.
 */
export const incrementVideoViewsInSupabase = async (videoId: string): Promise<number | null> => {
  if (!videoId) return null;
  try {
    const { data: vRow, error: vErr } = await supabase
      .from('videos')
      .select('views')
      .eq('id', videoId)
      .maybeSingle();

    if (!vErr && vRow) {
      const nextViews = (vRow.views || 0) + 1;
      await supabase.from('videos').update({ views: nextViews }).eq('id', videoId);
      return nextViews;
    }

    if (vErr && isMissingTableError(vErr)) {
      const { data: sRow } = await supabase
        .from('songs')
        .select('plays')
        .eq('id', videoId)
        .eq('category', 'video')
        .maybeSingle();
      if (sRow) {
        const nextViews = (sRow.plays || 0) + 1;
        await supabase.from('songs').update({ plays: nextViews }).eq('id', videoId);
        return nextViews;
      }
    }
  } catch {
    // non-critical
  }
  return null;
};

const LIKED_VIDEOS_STORAGE_KEY = 'teso_liked_videos_v1';

export const fetchLikedVideoIds = async (userId?: string | null): Promise<Set<string>> => {
  const liked = new Set<string>();

  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem(LIKED_VIDEOS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          parsed.forEach((id) => liked.add(String(id)));
        }
      }
    } catch {
      // ignore
    }
  }

  const effectiveId = userId || getOrCreateVisitorId();
  if (effectiveId) {
    try {
      const { data, error } = await supabase
        .from('video_likes')
        .select('video_id')
        .eq('user_id', effectiveId);
      if (!error && Array.isArray(data)) {
        data.forEach((row: any) => {
          if (row.video_id) liked.add(String(row.video_id));
        });
      }
    } catch {
      // ignore if table not created yet
    }
  }

  return liked;
};

export const toggleVideoLikeInSupabase = async (
  videoId: string,
  userId?: string | null,
  currentlyLiked = false
): Promise<{ isLiked: boolean; likesCount?: number }> => {
  const nextLiked = !currentlyLiked;
  const effectiveId = userId || getOrCreateVisitorId();

  // Persist locally immediately
  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem(LIKED_VIDEOS_STORAGE_KEY);
      const set = new Set<string>(raw ? JSON.parse(raw) : []);
      if (nextLiked) set.add(videoId);
      else set.delete(videoId);
      localStorage.setItem(LIKED_VIDEOS_STORAGE_KEY, JSON.stringify(Array.from(set)));
    } catch {
      // ignore
    }
  }

  // Persist in Supabase video_likes if available
  try {
    if (nextLiked) {
      await supabase
        .from('video_likes')
        .upsert([{ video_id: videoId, user_id: effectiveId }], { onConflict: 'video_id,user_id' });
    } else {
      await supabase
        .from('video_likes')
        .delete()
        .eq('video_id', videoId)
        .eq('user_id', effectiveId);
    }
  } catch {
    // ignore
  }

  // Update counter on public.videos (or public.songs fallback)
  try {
    const { data: vRow, error: vErr } = await supabase
      .from('videos')
      .select('likes')
      .eq('id', videoId)
      .maybeSingle();

    if (!vErr && vRow) {
      const nextCount = Math.max(0, (vRow.likes || 0) + (nextLiked ? 1 : -1));
      await supabase.from('videos').update({ likes: nextCount }).eq('id', videoId);
      return { isLiked: nextLiked, likesCount: nextCount };
    }

    if (vErr && isMissingTableError(vErr)) {
      const { data: sRow } = await supabase
        .from('songs')
        .select('likes')
        .eq('id', videoId)
        .eq('category', 'video')
        .maybeSingle();
      if (sRow) {
        const nextCount = Math.max(0, (sRow.likes || 0) + (nextLiked ? 1 : -1));
        await supabase.from('songs').update({ likes: nextCount }).eq('id', videoId);
        return { isLiked: nextLiked, likesCount: nextCount };
      }
    }
  } catch {
    // ignore
  }

  return { isLiked: nextLiked };
};

/**
 * Deletes a video and its associated media files from Storage & Supabase.
 */
export const deleteVideoFromSupabase = async (
  video: VideoItem
): Promise<{ success: boolean; error: string | null }> => {
  try {
    const urlsToDelete = new Set<string>();
    if (video.videoUrl) urlsToDelete.add(video.videoUrl);
    if (video.thumbnail && !video.thumbnail.startsWith('/src/') && !video.thumbnail.startsWith('data:')) {
      urlsToDelete.add(video.thumbnail);
    }
    if (video.qualityUrls) {
      Object.values(video.qualityUrls).forEach((u) => {
        if (u) urlsToDelete.add(u);
      });
    }

    await Promise.all(Array.from(urlsToDelete).map((u) => deleteStorageFile(u)));

    if (video.userId) {
      const cleanUser = video.userId.replace(/[^a-zA-Z0-9_-]/g, '');
      const cleanVideo = video.id.replace(/[^a-zA-Z0-9_-]/g, '');
      await deleteStorageFile(`${cleanUser}/attachments/${cleanVideo}/video-meta.json`);
    }

    let deleted = false;
    const { error: vErr } = await supabase.from('videos').delete().eq('id', video.id);
    if (!vErr) {
      deleted = true;
    } else if (!isMissingTableError(vErr)) {
      return { success: false, error: vErr.message };
    }

    const { error: sErr } = await supabase
      .from('songs')
      .delete()
      .eq('id', video.id)
      .eq('category', 'video');
    if (!sErr) {
      deleted = true;
    } else if (!deleted) {
      return { success: false, error: sErr.message };
    }

    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed to delete video' };
  }
};
