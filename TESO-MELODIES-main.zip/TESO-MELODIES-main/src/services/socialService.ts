/**
 * Social Service for TESO MELODIES
 * Handles genuine Likes and Artist Follows backed by Supabase PostgreSQL + Express fallback.
 * Preserves existing counts, prevents duplicates via UNIQUE constraints & atomic RPCs.
 */

import { supabase } from '../supabaseClient';

export interface LikesResponse {
  likesMap: Record<string, number>;
  userLikedSongIds: string[];
}

export interface FollowsResponse {
  followsMap: Record<string, number>;
  userFollowedArtistIds: string[];
}

export interface ArtistFollowerStatRow {
  artist_slug: string;
  artist_name: string;
  song_count: number;
  real_followers: number;
  bonus_followers: number;
  total_followers: number;
}

export const SONGS_PER_FOLLOWER_MILESTONE = 5;
export const FOLLOWERS_PER_FIVE_SONGS = 20;

/**
 * Every artist earns +20 bonus followers for every 5 songs they have uploaded,
 * stacked permanently on top of their genuine fan followers.
 */
export const calculateSongMilestoneFollowers = (songCount: number): number => {
  const safeCount = Math.max(0, Math.floor(Number(songCount) || 0));
  return Math.floor(safeCount / SONGS_PER_FOLLOWER_MILESTONE) * FOLLOWERS_PER_FIVE_SONGS;
};

const normalizeStatSlug = (value: string): string =>
  String(value || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');

/**
 * Fetch combined artist follower statistics directly from the public Supabase
 * view `public.artist_follower_stats` (visible to everyone, logged-in or visitor).
 */
export const fetchArtistFollowerStatsFromSupabase = async (): Promise<{
  rows: ArtistFollowerStatRow[];
  byKey: Map<string, ArtistFollowerStatRow>;
}> => {
  const byKey = new Map<string, ArtistFollowerStatRow>();
  try {
    const { data, error } = await supabase
      .from('artist_follower_stats')
      .select('artist_slug, artist_name, song_count, real_followers, bonus_followers, total_followers')
      .order('total_followers', { ascending: false });

    if (!error && Array.isArray(data)) {
      const rows: ArtistFollowerStatRow[] = data.map((row: any) => {
        const songCount = Math.max(0, Number(row.song_count) || 0);
        const realFollowers = Math.max(0, Number(row.real_followers) || 0);
        const bonusFollowers = Math.max(0, Number(row.bonus_followers) || 0);
        const totalFollowers =
          typeof row.total_followers === 'number'
            ? Math.max(0, row.total_followers)
            : realFollowers + bonusFollowers;
        const normalized: ArtistFollowerStatRow = {
          artist_slug: String(row.artist_slug || normalizeStatSlug(row.artist_name || '')),
          artist_name: String(row.artist_name || row.artist_slug || '').trim(),
          song_count: songCount,
          real_followers: realFollowers,
          bonus_followers: bonusFollowers,
          total_followers: totalFollowers,
        };

        const slugKey = normalized.artist_slug.toLowerCase().trim();
        const nameKey = normalized.artist_name.toLowerCase().trim();
        const derivedSlug = normalizeStatSlug(normalized.artist_name);
        if (slugKey) byKey.set(slugKey, normalized);
        if (nameKey) byKey.set(nameKey, normalized);
        if (derivedSlug) byKey.set(derivedSlug, normalized);
        return normalized;
      });
      return { rows, byKey };
    }
  } catch (err) {
    console.warn('Notice reading public.artist_follower_stats:', err);
  }
  return { rows: [], byKey };
};

/**
 * Fetch a single artist's live combined follower stats from `public.artist_follower_stats`.
 */
export const fetchSingleArtistFollowerStat = async (
  artistIdOrSlug?: string | null,
  artistName?: string | null
): Promise<ArtistFollowerStatRow | null> => {
  const slug = normalizeStatSlug(artistName || artistIdOrSlug || '');
  const rawName = String(artistName || '').trim();
  const rawSlug = String(artistIdOrSlug || '').trim().toLowerCase();

  try {
    if (slug) {
      const { data, error } = await supabase
        .from('artist_follower_stats')
        .select('artist_slug, artist_name, song_count, real_followers, bonus_followers, total_followers')
        .eq('artist_slug', slug)
        .maybeSingle();
      if (!error && data) {
        const real = Math.max(0, Number(data.real_followers) || 0);
        const bonus = Math.max(0, Number(data.bonus_followers) || 0);
        return {
          artist_slug: String(data.artist_slug || slug),
          artist_name: String(data.artist_name || rawName || slug),
          song_count: Math.max(0, Number(data.song_count) || 0),
          real_followers: real,
          bonus_followers: bonus,
          total_followers:
            typeof data.total_followers === 'number' ? Math.max(0, data.total_followers) : real + bonus,
        };
      }
    }

    if (rawName || (rawSlug && rawSlug !== slug)) {
      const { byKey } = await fetchArtistFollowerStatsFromSupabase();
      const match =
        (slug && byKey.get(slug)) ||
        (rawName && byKey.get(rawName.toLowerCase())) ||
        (rawSlug && byKey.get(rawSlug));
      if (match) return match;
    }
  } catch {
    // ignore
  }
  return null;
};

const isUuid = (val?: string | null): boolean =>
  Boolean(val && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(val));

const getBaseUrl = (): string => (typeof window !== 'undefined' ? '' : 'http://localhost:3000');

const GUEST_LIKED_SONGS_KEY = 'teso_guest_liked_songs_v1';

const getGuestLikedSongIds = (): string[] => {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(GUEST_LIKED_SONGS_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
};

const saveGuestLikedSongId = (songId: string, liked: boolean) => {
  if (typeof window === 'undefined') return;
  try {
    const set = new Set(getGuestLikedSongIds());
    if (liked) set.add(String(songId));
    else set.delete(String(songId));
    localStorage.setItem(GUEST_LIKED_SONGS_KEY, JSON.stringify(Array.from(set)));
  } catch {
    // ignore
  }
};

/**
 * 1. Fetch genuine song like counts and the current user/visitor's liked song IDs
 */
export const fetchSongLikesData = async (userId?: string | null): Promise<LikesResponse> => {
  const likesMap: Record<string, number> = {};
  const userLikedSet = new Set<string>();
  const songLikeActors = new Map<string, Set<string>>();

  let effectiveUserId = userId;
  let visitorId = '';
  if (typeof window !== 'undefined') {
    try {
      visitorId = localStorage.getItem('teso_visitor_id') || '';
    } catch {
      visitorId = '';
    }
  }

  try {
    if (!effectiveUserId || !isUuid(effectiveUserId)) {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (session?.user?.id) {
        effectiveUserId = session.user.id;
      }
    }
  } catch {
    // ignore
  }

  // A. Read genuine like totals from public.songs
  try {
    const { data: dbSongs, error: songsErr } = await supabase
      .from('songs')
      .select('id, likes')
      .neq('category', 'video');

    if (!songsErr && Array.isArray(dbSongs)) {
      dbSongs.forEach((s) => {
        const sId = String(s.id);
        likesMap[sId] = typeof s.likes === 'number' ? Math.max(0, s.likes) : 0;
      });
    }
  } catch (err) {
    console.warn('Notice querying Supabase songs likes:', err);
  }

  // B. Read genuine rows from public.song_likes and public.user_favorites
  let songLikesTableLoaded = false;
  try {
    const { data: allLikeRows, error: slErr } = await supabase
      .from('song_likes')
      .select('song_id, user_id');

    if (!slErr && Array.isArray(allLikeRows)) {
      songLikesTableLoaded = true;
      allLikeRows.forEach((row: any) => {
        if (!row.song_id || !row.user_id) return;
        const sId = String(row.song_id);
        const actor = String(row.user_id);
        if (!songLikeActors.has(sId)) {
          songLikeActors.set(sId, new Set<string>());
        }
        songLikeActors.get(sId)!.add(actor);

        if ((effectiveUserId && actor === effectiveUserId) || (visitorId && actor === visitorId)) {
          userLikedSet.add(sId);
        }
      });

      // Preserve existing songs.likes while never dropping below real song_likes count
      songLikeActors.forEach((actors, sId) => {
        const baseLikes = typeof likesMap[sId] === 'number' ? likesMap[sId] : 0;
        likesMap[sId] = Math.max(baseLikes, actors.size);
      });
    }
  } catch {
    // song_likes table optional
  }

  try {
    if (effectiveUserId && isUuid(effectiveUserId)) {
      const { data: favs, error: favErr } = await supabase
        .from('user_favorites')
        .select('song_id')
        .eq('user_id', effectiveUserId);

      if (!favErr && Array.isArray(favs)) {
        favs.forEach((f: any) => {
          if (f.song_id) userLikedSet.add(String(f.song_id));
        });
      }
    }
  } catch {
    // ignore
  }

  if (!songLikesTableLoaded) {
    getGuestLikedSongIds().forEach((id) => userLikedSet.add(id));
  }

  // C. Optional Express /api/likes merge for songs missing in Supabase
  try {
    const base = getBaseUrl();
    const actorParam = effectiveUserId || visitorId;
    const url = actorParam
      ? `${base}/api/likes?userId=${encodeURIComponent(actorParam)}`
      : `${base}/api/likes`;
    const res = await fetch(url);
    if (res.ok && (res.headers.get('content-type') || '').includes('application/json')) {
      const data = await res.json();
      if (data.success) {
        if (data.likesMap) {
          Object.entries(data.likesMap).forEach(([sId, count]) => {
            if (typeof count === 'number' && count >= 0 && likesMap[sId] === undefined) {
              likesMap[sId] = count;
            }
          });
        }
        if (!songLikesTableLoaded && Array.isArray(data.userLikedSongIds)) {
          data.userLikedSongIds.forEach((id: string) => userLikedSet.add(String(id)));
        }
      }
    }
  } catch {
    // API optional
  }

  return {
    likesMap,
    userLikedSongIds: Array.from(userLikedSet),
  };
};

/**
 * 2. Toggle like on a song permanently without duplicates or fake counts
 */
export const toggleSongLikeInBackend = async (
  songId: string,
  userId: string,
  currentlyLiked = false,
  userEmail?: string,
  userName?: string
): Promise<{ success: boolean; isLiked: boolean; totalLikes?: number; error?: string }> => {
  if (!songId) {
    return { success: false, isLiked: currentlyLiked, error: 'Song ID is required' };
  }

  let effectiveUserId = userId;
  let accessToken: string | undefined;
  try {
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (session?.user?.id) {
      effectiveUserId = session.user.id;
      accessToken = session.access_token;
    }
  } catch {
    // ignore
  }

  const actorId = (effectiveUserId || userId || 'anon-visitor').trim();
  const expectedNextLiked = !currentlyLiked;

  // 1. Preferred: Atomic PostgreSQL SECURITY DEFINER RPC (prevents duplicates + updates songs.likes)
  try {
    const { data: rpcData, error: rpcErr } = await supabase.rpc('toggle_song_like', {
      p_song_id: songId,
      p_actor_id: actorId,
      p_user_email: userEmail || null,
      p_user_name: userName || null,
    });

    if (!rpcErr && rpcData && typeof rpcData === 'object') {
      const resultLiked = Boolean((rpcData as any).is_liked);
      const resultTotal =
        typeof (rpcData as any).likes === 'number' ? Math.max(0, (rpcData as any).likes) : undefined;
      saveGuestLikedSongId(songId, resultLiked);
      return { success: true, isLiked: resultLiked, totalLikes: resultTotal };
    }
  } catch {
    // RPC may not exist yet before migration
  }

  // 2. Direct Supabase table toggle (public.song_likes + public.user_favorites)
  try {
    if (isUuid(effectiveUserId)) {
      const { data: existingFavs } = await supabase
        .from('user_favorites')
        .select('id')
        .eq('user_id', effectiveUserId)
        .eq('song_id', songId);

      if (existingFavs && existingFavs.length > 0) {
        await supabase
          .from('user_favorites')
          .delete()
          .eq('user_id', effectiveUserId)
          .eq('song_id', songId);
      } else {
        await supabase
          .from('user_favorites')
          .upsert([{ user_id: effectiveUserId, song_id: songId }], {
            onConflict: 'user_id,song_id',
          });
      }
    }

    const { data: existingLikes, error: likeQueryErr } = await supabase
      .from('song_likes')
      .select('id')
      .eq('song_id', String(songId))
      .eq('user_id', actorId);

    if (!likeQueryErr && Array.isArray(existingLikes)) {
      const willLike = existingLikes.length === 0;
      if (willLike) {
        await supabase.from('song_likes').upsert(
          [
            {
              song_id: String(songId),
              user_id: actorId,
              user_email: userEmail || null,
              user_name: userName || null,
            },
          ],
          { onConflict: 'song_id,user_id' }
        );
      } else {
        await supabase
          .from('song_likes')
          .delete()
          .eq('song_id', String(songId))
          .eq('user_id', actorId);
      }

      const [{ data: likeRows }, { data: songRow }] = await Promise.all([
        supabase.from('song_likes').select('user_id').eq('song_id', String(songId)),
        supabase.from('songs').select('likes').eq('id', songId).maybeSingle(),
      ]);

      const uniqueRowCount = Array.isArray(likeRows)
        ? new Set(likeRows.map((r: any) => String(r.user_id))).size
        : 0;
      const baseSongsLikes =
        songRow && typeof songRow.likes === 'number' ? Math.max(0, songRow.likes) : 0;
      const totalLikes = Math.max(uniqueRowCount, baseSongsLikes);

      saveGuestLikedSongId(songId, willLike);
      return { success: true, isLiked: willLike, totalLikes };
    }
  } catch (sbErr) {
    console.warn('Notice syncing to Supabase song_likes:', sbErr);
  }

  // 3. Express API fallback
  try {
    const base = getBaseUrl();
    const res = await fetch(`${base}/api/likes/toggle`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-visitor-id': actorId,
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      },
      body: JSON.stringify({
        songId,
        userId: actorId,
        currentlyLiked,
        userEmail,
        userName,
      }),
    });

    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      const data = await res.json();
      if (data.success) {
        const likedState = Boolean(data.isLiked);
        saveGuestLikedSongId(songId, likedState);
        return {
          success: true,
          isLiked: likedState,
          totalLikes: typeof data.totalLikes === 'number' ? Math.max(0, data.totalLikes) : undefined,
        };
      }
    }
  } catch (err: any) {
    console.warn('Notice calling /api/likes/toggle:', err);
  }

  return {
    success: false,
    isLiked: expectedNextLiked,
  };
};

/**
 * 3. Fetch real artist follower counts and current user's followed artist IDs
 */
export const fetchArtistFollowsData = async (userId?: string | null): Promise<FollowsResponse> => {
  const followsMap: Record<string, number> = {};
  const userFollowedSet = new Set<string>();
  const artistActors = new Map<string, Set<string>>();

  let effectiveUserId = userId;
  let visitorId = '';
  if (typeof window !== 'undefined') {
    try {
      visitorId = localStorage.getItem('teso_visitor_id') || '';
    } catch {
      visitorId = '';
    }
  }

  try {
    if (!effectiveUserId || !isUuid(effectiveUserId)) {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (session?.user?.id) {
        effectiveUserId = session.user.id;
      }
    }
  } catch {
    // ignore
  }

  const addFollowAliasCount = (rawValue: string, actorId: string) => {
    const lower = rawValue.toLowerCase().trim();
    const slug = lower.replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || lower;
    [lower, slug, lower.replace(/-/g, ' ')].filter(Boolean).forEach((alias) => {
      if (!artistActors.has(alias)) artistActors.set(alias, new Set());
      artistActors.get(alias)!.add(actorId);
    });
  };

  // A. Read ALL public.artist_follows rows from Supabase so everyone sees real follower counts
  try {
    const { data: follows, error } = await supabase
      .from('artist_follows')
      .select('artist_id, artist_name, user_id');

    if (!error && Array.isArray(follows)) {
      follows.forEach((f: any) => {
        const actor = f.user_id ? String(f.user_id) : '';
        if (actor) {
          if (f.artist_id) addFollowAliasCount(String(f.artist_id), actor);
          if (f.artist_name) addFollowAliasCount(String(f.artist_name), actor);
        }

        const isMe =
          (effectiveUserId && actor === effectiveUserId) || (visitorId && actor === visitorId);
        if (isMe) {
          if (f.artist_id) {
            const raw = String(f.artist_id).toLowerCase().trim();
            userFollowedSet.add(raw);
            userFollowedSet.add(raw.replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''));
            userFollowedSet.add(raw.replace(/-/g, ' '));
          }
          if (f.artist_name) {
            const rawName = String(f.artist_name).toLowerCase().trim();
            userFollowedSet.add(rawName);
            userFollowedSet.add(rawName.replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''));
          }
        }
      });

      artistActors.forEach((set, alias) => {
        followsMap[alias] = set.size;
      });
    }
  } catch (err) {
    console.warn('Notice querying Supabase artist_follows:', err);
  }

  // B. Optional Express /api/follows merge
  try {
    const base = getBaseUrl();
    const actorParam = effectiveUserId || visitorId;
    const url = actorParam
      ? `${base}/api/follows?userId=${encodeURIComponent(actorParam)}`
      : `${base}/api/follows`;
    const res = await fetch(url);
    if (res.ok && (res.headers.get('content-type') || '').includes('application/json')) {
      const data = await res.json();
      if (data.success) {
        if (data.followsMap) {
          Object.entries(data.followsMap).forEach(([k, count]) => {
            const key = k.toLowerCase().trim();
            if (typeof count === 'number' && followsMap[key] === undefined) {
              followsMap[key] = Math.max(0, count);
            }
          });
        }
        if (Array.isArray(data.userFollowedArtistIds)) {
          data.userFollowedArtistIds.forEach((id: string) => {
            userFollowedSet.add(String(id).toLowerCase().trim());
          });
        }
      }
    }
  } catch {
    // ignore
  }

  return {
    followsMap,
    userFollowedArtistIds: Array.from(userFollowedSet),
  };
};

/**
 * 4. Toggle follow on an artist permanently without duplicate rows,
 *    combining genuine fan followers + (+20 per 5 uploaded songs).
 */
export const toggleArtistFollowInBackend = async (
  artistId: string,
  artistName: string,
  userId: string,
  wasFollowed = false,
  userEmail?: string,
  userName?: string,
  options?: {
    artistUserId?: string;
    songCount?: number;
  }
): Promise<{
  success: boolean;
  isFollowed: boolean;
  realFollowers?: number;
  bonusFollowers?: number;
  followers?: number;
  error?: string;
}> => {
  if (!artistId && !artistName) {
    return { success: false, isFollowed: wasFollowed, error: 'Artist identifier is required' };
  }

  let effectiveUserId = userId;
  let accessToken: string | undefined;
  try {
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (session?.user?.id) {
      effectiveUserId = session.user.id;
      accessToken = session.access_token;
    }
  } catch {
    // ignore
  }

  const actorId = (effectiveUserId || userId || 'anon-visitor').trim();
  const cleanArtistId = (artistId || artistName || '').trim();
  const normalizedKey = (artistName || artistId || '').trim().toLowerCase();
  const slugKey = normalizedKey.replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'artist';
  const legacyUid = options?.artistUserId ? options.artistUserId.trim().toLowerCase() : '';
  const localBonus = calculateSongMilestoneFollowers(options?.songCount || 0);
  const candidateKeys = Array.from(
    new Set(
      [
        cleanArtistId,
        normalizedKey,
        slugKey,
        normalizedKey.replace(/-/g, ' '),
        legacyUid,
      ].filter(Boolean)
    )
  );
  const expectedNextFollowed = !wasFollowed;

  const parseRpcFollowPayload = (rpcData: any) => {
    const isFollowed = Boolean(rpcData.is_followed);
    if (
      typeof rpcData.real_followers === 'number' &&
      typeof rpcData.bonus_followers === 'number'
    ) {
      const realFollowers = Math.max(0, rpcData.real_followers);
      const bonusFollowers = Math.max(0, rpcData.bonus_followers);
      const totalFollowers =
        typeof rpcData.followers === 'number'
          ? Math.max(0, rpcData.followers)
          : realFollowers + bonusFollowers;
      return {
        success: true,
        isFollowed,
        realFollowers,
        bonusFollowers,
        followers: totalFollowers,
      };
    }
    const rawReal =
      typeof rpcData.followers === 'number' ? Math.max(0, rpcData.followers) : undefined;
    return {
      success: true,
      isFollowed,
      realFollowers: rawReal,
      bonusFollowers: localBonus,
      followers: rawReal !== undefined ? rawReal + localBonus : undefined,
    };
  };

  // 1. Preferred: Upgraded 6-arg Atomic PostgreSQL RPC (with legacy UUID + milestone calculation)
  try {
    const { data: rpcData, error: rpcErr } = await supabase.rpc('toggle_artist_follow', {
      p_artist_id: cleanArtistId,
      p_artist_name: artistName || cleanArtistId,
      p_actor_id: actorId,
      p_user_email: userEmail || null,
      p_user_name: userName || null,
      p_artist_user_id: legacyUid || null,
    });

    if (!rpcErr && rpcData && typeof rpcData === 'object') {
      return parseRpcFollowPayload(rpcData);
    }
  } catch {
    // 6-arg RPC may not be migrated yet — try existing 5-arg RPC
  }

  // 1b. Existing 5-arg Atomic PostgreSQL RPC fallback
  try {
    const { data: rpcData, error: rpcErr } = await supabase.rpc('toggle_artist_follow', {
      p_artist_id: cleanArtistId,
      p_artist_name: artistName || cleanArtistId,
      p_actor_id: actorId,
      p_user_email: userEmail || null,
      p_user_name: userName || null,
    });

    if (!rpcErr && rpcData && typeof rpcData === 'object') {
      return parseRpcFollowPayload(rpcData);
    }
  } catch {
    // RPC may not exist yet — try direct table toggle
  }

  // 2. Direct Supabase fallback on public.artist_follows
  try {
    const { data: allForActor, error: queryErr } = await supabase
      .from('artist_follows')
      .select('id, artist_id, artist_name')
      .eq('user_id', actorId);

    if (!queryErr && Array.isArray(allForActor)) {
      const candidateSet = new Set(candidateKeys.map((k) => k.toLowerCase().trim()));
      const matchingRows = allForActor.filter((row: any) => {
        const aId = String(row.artist_id || '').toLowerCase().trim();
        const aName = String(row.artist_name || '').toLowerCase().trim();
        return candidateSet.has(aId) || (aName && candidateSet.has(aName));
      });

      if (matchingRows.length > 0) {
        const idsToDelete = matchingRows.map((r: any) => r.id);
        const { error: delErr } = await supabase
          .from('artist_follows')
          .delete()
          .in('id', idsToDelete);
        if (delErr) {
          throw delErr;
        }
      } else {
        const payload = {
          user_id: actorId,
          artist_id: slugKey,
          artist_name: artistName || cleanArtistId,
          user_email: userEmail || null,
          user_name: userName || null,
        };
        const { error: upsertErr } = await supabase
          .from('artist_follows')
          .upsert([payload], { onConflict: 'artist_id,user_id' });

        if (upsertErr) {
          const minimalPayload = {
            user_id: actorId,
            artist_id: slugKey,
            artist_name: artistName || cleanArtistId,
          };
          const { error: insertErr } = await supabase
            .from('artist_follows')
            .insert([minimalPayload]);
          if (insertErr) {
            const barePayload = {
              user_id: actorId,
              artist_id: slugKey,
            };
            const { error: bareErr } = await supabase
              .from('artist_follows')
              .insert([barePayload]);
            if (bareErr) {
              throw bareErr;
            }
          }
        }
      }

      const { data: allArtistRows } = await supabase
        .from('artist_follows')
        .select('artist_id, artist_name, user_id');

      if (Array.isArray(allArtistRows)) {
        const uniqueFollowers = new Set(
          allArtistRows
            .filter((r: any) => {
              const rId = String(r.artist_id || '').toLowerCase().trim();
              const rName = String(r.artist_name || '').toLowerCase().trim();
              const rSlug = rName.replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
              return (
                candidateSet.has(rId) ||
                (rName && candidateSet.has(rName)) ||
                (rSlug && candidateSet.has(rSlug))
              );
            })
            .map((r: any) => String(r.user_id))
        );
        const realCount = uniqueFollowers.size;
        return {
          success: true,
          isFollowed: matchingRows.length === 0,
          realFollowers: realCount,
          bonusFollowers: localBonus,
          followers: realCount + localBonus,
        };
      }
    }
  } catch (sbErr) {
    console.warn('Notice syncing to Supabase artist_follows:', sbErr);
  }

  // 3. Call backend API (/api/follows/toggle)
  try {
    const base = getBaseUrl();
    const res = await fetch(`${base}/api/follows/toggle`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-visitor-id': actorId,
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      },
      body: JSON.stringify({
        artistId: cleanArtistId,
        artistName: artistName || cleanArtistId,
        artistUserId: legacyUid || undefined,
        songCount: options?.songCount || 0,
        userId: actorId,
        userEmail,
        userName,
      }),
    });

    if (res.ok && (res.headers.get('content-type') || '').includes('application/json')) {
      const data = await res.json();
      if (data.success) {
        const realCount =
          typeof data.realFollowers === 'number'
            ? Math.max(0, data.realFollowers)
            : typeof data.followers === 'number'
            ? Math.max(0, data.followers)
            : undefined;
        return {
          success: true,
          isFollowed: Boolean(data.isFollowed),
          realFollowers: realCount,
          bonusFollowers: localBonus,
          followers: realCount !== undefined ? realCount + localBonus : undefined,
        };
      }
    }
  } catch (err: any) {
    console.warn('Notice calling /api/follows/toggle:', err);
  }

  return {
    success: false,
    isFollowed: expectedNextFollowed,
    error: 'Unable to sync follow state with server right now.',
  };
};
