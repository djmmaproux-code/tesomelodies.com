import { supabase } from '../supabaseClient';

export type MobileMoneyProvider = 'MTN Mobile Money' | 'Airtel Money';
export type WithdrawalStatus = 'Pending' | 'Approved' | 'Paid' | 'Rejected';
export type EarningTransactionType =
  | 'likes_earning'
  | 'followers_earning'
  | 'downloads_earning'
  | 'streams_earning'
  | 'withdrawal'
  | 'payment'
  | 'adjustment';

export interface ArtistEarningSettings {
  id: number;
  likes_per_unit: number;
  likes_rate_ugx: number;
  followers_per_unit: number;
  followers_rate_ugx: number;
  downloads_per_unit: number;
  downloads_rate_ugx: number;
  streams_per_unit: number;
  streams_rate_ugx: number;
  min_withdrawal_ugx: number;
  updated_at?: string;
}

export interface ArtistEarningsSummary {
  user_id: string;
  registered_email: string;
  is_gmail: boolean;
  verified_gmail: string | null;
  earnings_verified: boolean;
  earnings_verified_at: string | null;
  verification_method: string | null;
  is_suspended: boolean;
  suspended_reason: string | null;
  song_count: number;
  total_likes: number;
  likes_earnings_ugx: number;
  qualifying_likes_progress?: number;
  total_followers: number;
  followers_earnings_ugx: number;
  qualifying_followers_progress?: number;
  total_downloads: number;
  downloads_earnings_ugx: number;
  qualifying_downloads_progress?: number;
  total_streams: number;
  streams_earnings_ugx: number;
  qualifying_streams_progress?: number;
  pending_earnings_ugx: number;
  total_earnings_ugx: number;
  amount_withdrawn_ugx: number;
  pending_withdrawals_ugx: number;
  available_balance_ugx: number;
  monthly_likes: number;
  monthly_followers: number;
  monthly_downloads: number;
  monthly_streams: number;
  monthly_earnings_ugx: number;
  previous_month_earnings_ugx: number;
  last_synced_at?: string;
}

export interface ArtistPayoutProfile {
  user_id: string;
  full_legal_name: string;
  country: string;
  phone_number: string;
  registered_gmail: string;
  mobile_money_provider: MobileMoneyProvider;
  mobile_money_number: string;
  created_at?: string;
  updated_at?: string;
}

export interface ArtistWithdrawalRequest {
  id: string;
  reference_code: string;
  user_id: string;
  artist_name: string;
  registered_gmail: string;
  amount_ugx: number;
  status: WithdrawalStatus;
  payout_full_name: string;
  payout_country: string;
  payout_phone: string;
  mobile_money_provider: MobileMoneyProvider;
  mobile_money_number: string;
  payment_reference?: string | null;
  admin_note?: string | null;
  rejection_reason?: string | null;
  approved_at?: string | null;
  paid_at?: string | null;
  rejected_at?: string | null;
  created_at: string;
  updated_at?: string;
}

export interface ArtistEarningTransaction {
  id: string;
  reference_code: string;
  user_id: string;
  artist_name?: string;
  artist_email?: string;
  transaction_type: EarningTransactionType;
  category_label?: string;
  direction: 'credit' | 'debit';
  amount_ugx: number;
  units_count: number;
  rate_applied_ugx?: number | null;
  status: 'Credited' | WithdrawalStatus;
  description: string;
  withdrawal_id?: string | null;
  payment_reference?: string | null;
  created_at: string;
  updated_at?: string;
}

export interface AdminAuditLogEntry {
  id: string;
  admin_id?: string | null;
  admin_email: string;
  action: string;
  target_type: string;
  target_id?: string | null;
  summary: string;
  details?: Record<string, any>;
  created_at: string;
}

export interface ArtistEarningsDashboardData {
  summary: ArtistEarningsSummary;
  settings: ArtistEarningSettings;
  payout_profile: ArtistPayoutProfile | null;
  withdrawals: ArtistWithdrawalRequest[];
  transactions: ArtistEarningTransaction[];
}

export interface AdminArtistEarningsRow extends ArtistEarningsSummary {
  artist_name: string;
  email: string;
  avatar_url?: string;
  role: string;
  joined_at: string;
  payout_profile: ArtistPayoutProfile | null;
}

export interface AdminEarningsOverview {
  settings: ArtistEarningSettings;
  artists: AdminArtistEarningsRow[];
  withdrawals: ArtistWithdrawalRequest[];
  transactions: ArtistEarningTransaction[];
  audit_logs?: AdminAuditLogEntry[];
}

export interface AdminMonetizationHealth {
  healthy: boolean;
  tables_ok: boolean;
  missing_tables: string[];
  settings_ok: boolean;
  metrics_ok: boolean;
  metrics_error: string | null;
  checked_at: string;
}

export const DEFAULT_EARNING_SETTINGS: ArtistEarningSettings = {
  id: 1,
  likes_per_unit: 30,
  likes_rate_ugx: 18,
  followers_per_unit: 100,
  followers_rate_ugx: 700,
  downloads_per_unit: 1,
  downloads_rate_ugx: 5,
  streams_per_unit: 25,
  streams_rate_ugx: 10,
  min_withdrawal_ugx: 15000,
};

export function formatUGX(amount: number | string | null | undefined): string {
  const num = Number(amount || 0);
  if (!Number.isFinite(num)) return 'UGX 0';
  return `UGX ${Math.round(num).toLocaleString('en-UG')}`;
}

export function getTransactionCategoryLabel(tx: ArtistEarningTransaction): string {
  if (tx.category_label && tx.category_label.trim()) {
    return tx.category_label;
  }
  switch (tx.transaction_type) {
    case 'likes_earning':
      return 'Likes Earnings';
    case 'followers_earning':
      return 'Followers Earnings';
    case 'downloads_earning':
      return 'Download Royalties';
    case 'streams_earning':
      return 'Streaming Royalties';
    case 'payment':
      return 'Payments';
    case 'withdrawal':
      return tx.status === 'Paid' ? 'Payments' : 'Withdrawal Requests';
    default:
      return 'Royalty Adjustment';
  }
}

export function isGmailAddress(email?: string | null): boolean {
  if (!email) return false;
  return /@(gmail\.com|googlemail\.com)$/i.test(email.trim());
}

function isMissingMigrationError(error: any): boolean {
  const msg = String(error?.message || error?.details || '').toLowerCase();
  const code = String(error?.code || '');
  // Explicitly do NOT classify SQL operator type mismatches (e.g. "operator does not exist: uuid = text")
  // as a missing migration table; handle those distinctly for admin diagnostics.
  if (msg.includes('operator does not exist')) {
    return false;
  }
  return (
    code === 'PGRST202' ||
    code === '42P01' ||
    msg.includes('could not find the function') ||
    (msg.includes('schema cache') && msg.includes('function')) ||
    (msg.includes('relation') && msg.includes('does not exist'))
  );
}

function isSchemaMismatchError(error: any): boolean {
  const msg = String(error?.message || error?.details || '').toLowerCase();
  const code = String(error?.code || '');
  return (
    (code === '42883' && msg.includes('operator does not exist')) ||
    code === '42703' ||
    msg.includes('operator does not exist') ||
    (msg.includes('column') && msg.includes('does not exist'))
  );
}

function sanitizeArtistFacingError(error: any, fallback: string): string {
  const raw = String(error?.message || '').trim();
  const lower = raw.toLowerCase();
  if (
    !raw ||
    isMissingMigrationError(error) ||
    isSchemaMismatchError(error) ||
    lower.includes('sql') ||
    lower.includes('pgrst') ||
    lower.includes('relation ') ||
    lower.includes('operator does not exist') ||
    lower.includes('column ') ||
    lower.includes('schema cache')
  ) {
    return fallback;
  }
  return raw;
}

/**
 * Fetch the authenticated artist's backend-calculated earnings dashboard.
 * Never returns SQL filenames, migration instructions, or internal DB errors to artists.
 */
export async function fetchArtistEarningsDashboard(): Promise<{
  data: ArtistEarningsDashboardData | null;
  serviceUnavailable?: boolean;
  error?: string;
}> {
  try {
    const { data, error } = await supabase.rpc('get_artist_earnings_dashboard');
    if (error) {
      if (isMissingMigrationError(error) || isSchemaMismatchError(error)) {
        return {
          data: null,
          serviceUnavailable: true,
        };
      }
      return {
        data: null,
        error: sanitizeArtistFacingError(
          error,
          'Unable to load your earnings right now. Please try again shortly.'
        ),
      };
    }
    return { data: data as ArtistEarningsDashboardData };
  } catch {
    return {
      data: null,
      error: 'Unable to load your earnings right now. Please try again shortly.',
    };
  }
}

/**
 * Subscribe to real-time Supabase changes affecting the authenticated artist's wallet
 * (earnings account, transactions ledger, and withdrawal requests).
 */
export function subscribeToArtistWalletChanges(
  userId: string,
  onWalletChanged: () => void
): () => void {
  if (!userId) return () => {};
  try {
    const channel = supabase
      .channel(`artist-wallet-${userId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'artist_earnings_accounts',
          filter: `user_id=eq.${userId}`,
        },
        () => onWalletChanged()
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'artist_earning_transactions',
          filter: `user_id=eq.${userId}`,
        },
        () => onWalletChanged()
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'artist_withdrawal_requests',
          filter: `user_id=eq.${userId}`,
        },
        () => onWalletChanged()
      )
      .subscribe();

    return () => {
      try {
        supabase.removeChannel(channel);
      } catch {
        // ignore channel cleanup errors
      }
    };
  } catch {
    return () => {};
  }
}

/**
 * Extract remaining rate-limit cooldown seconds from Supabase Auth error messages
 * (e.g. "For security purposes, you can only request this after 45 seconds.").
 */
function parseOtpCooldownSeconds(message?: string | null): number | undefined {
  if (!message) return undefined;
  const match = message.match(/after\s+(\d+)\s+second/i);
  if (match) {
    const secs = Number(match[1]);
    if (Number.isFinite(secs) && secs > 0) return secs;
  }
  return undefined;
}

/**
 * Step 1 of real Gmail 6-digit OTP verification (also used for Resend Verification Email):
 * - Confirms the signed-in artist has a registered Gmail address (no duplicate accounts).
 * - Uses Supabase Auth signInWithOtp({ email, options: { shouldCreateUser: false } })
 *   so Supabase generates and delivers a genuine, unique 6-digit Email OTP directly to Gmail.
 * - Only records/updates the server-side verification request timestamp & nonce AFTER
 *   Supabase Auth accepts the OTP request, so a rate-limited resend click never invalidates
 *   a previously delivered active 6-digit code.
 * - Strictly email-only (never SMS).
 */
export async function sendArtistGmailVerification(): Promise<{
  success: boolean;
  registeredEmail?: string;
  nonce?: string;
  alreadyVerified?: boolean;
  isGmail?: boolean;
  cooldownSeconds?: number;
  serviceUnavailable?: boolean;
  error?: string;
}> {
  try {
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user?.email) {
      return {
        success: false,
        error: 'Please sign in to your artist account to verify your email.',
      };
    }

    const registeredEmail = user.email.trim().toLowerCase();
    if (!isGmailAddress(registeredEmail)) {
      return {
        success: false,
        isGmail: false,
        registeredEmail,
        error:
          'Artist Monetization requires a registered Gmail address (@gmail.com). Update your account email to Gmail first.',
      };
    }

    // Request a genuine 6-digit Email OTP from Supabase Auth without creating duplicate accounts.
    // Intentionally omits emailRedirectTo so the flow stays strictly 6-digit Email OTP based.
    const { error: otpError } = await supabase.auth.signInWithOtp({
      email: registeredEmail,
      options: {
        shouldCreateUser: false,
      },
    });

    if (otpError) {
      const msg = String(otpError.message || '');
      const cooldownSeconds = parseOtpCooldownSeconds(msg);
      const lower = msg.toLowerCase();

      if (cooldownSeconds || lower.includes('rate limit') || otpError.status === 429) {
        return {
          success: false,
          registeredEmail,
          isGmail: true,
          cooldownSeconds: cooldownSeconds || 60,
          error: cooldownSeconds
            ? `Please wait ${cooldownSeconds} seconds before requesting another verification code. Your previous 6-digit code in Gmail is still valid.`
            : 'Too many verification email requests. Please wait a minute before clicking Resend Verification Email.',
        };
      }

      return {
        success: false,
        registeredEmail,
        isGmail: true,
        error: sanitizeArtistFacingError(
          otpError,
          'Could not send the 6-digit verification code to your Gmail right now. Please try again shortly.'
        ),
      };
    }

    // Record the fresh verification request timestamp & nonce in PostgreSQL after OTP dispatch succeeds
    const { data, error } = await supabase.rpc('initiate_artist_gmail_verification');
    if (error) {
      if (isMissingMigrationError(error) || isSchemaMismatchError(error)) {
        return {
          success: false,
          serviceUnavailable: true,
          error: 'Email verification is temporarily unavailable. Please try again shortly.',
        };
      }
      return {
        success: false,
        error: sanitizeArtistFacingError(
          error,
          'Could not register your verification request right now. Please try again.'
        ),
      };
    }

    const res = data as any;
    if (!res?.success) {
      return {
        success: false,
        isGmail: res?.is_gmail,
        registeredEmail: res?.registered_email || registeredEmail,
        error: res?.error || 'Could not initiate Gmail OTP verification.',
      };
    }

    if (res.already_verified) {
      return {
        success: true,
        alreadyVerified: true,
        registeredEmail: res.registered_email || registeredEmail,
      };
    }

    const nonce = String(res.nonce || '');
    try {
      window.sessionStorage.setItem('teso_earnings_verify_nonce', nonce);
    } catch {
      // ignore storage errors
    }

    return {
      success: true,
      registeredEmail: res.registered_email || registeredEmail,
      nonce,
      isGmail: true,
      cooldownSeconds: 60,
    };
  } catch (err: any) {
    return {
      success: false,
      error: sanitizeArtistFacingError(
        err,
        'Failed to send the verification code to your Gmail. Please try again.'
      ),
    };
  }
}

/**
 * Step 2: Verify the real 6-digit OTP code received in the artist's Gmail inbox
 * using Supabase Auth verifyOtp({ email, token, type: 'email' }), then unlock
 * the Artist Earnings Dashboard server-side.
 */
export async function verifyArtistGmailWithOtp(
  registeredEmail: string,
  otpCode: string,
  nonce?: string | null
): Promise<{
  success: boolean;
  verifiedGmail?: string;
  error?: string;
}> {
  const cleanEmail = registeredEmail.trim().toLowerCase();
  const cleanToken = otpCode.replace(/\D/g, '');

  if (!isGmailAddress(cleanEmail)) {
    return {
      success: false,
      error: 'A registered Gmail address (@gmail.com) is required to verify your artist account.',
    };
  }

  if (!/^\d{6}$/.test(cleanToken)) {
    return {
      success: false,
      error: 'Please enter the exact 6-digit verification code sent to your Gmail inbox.',
    };
  }

  try {
    // Primary Supabase Auth 6-digit Email OTP verification
    let verifyRes = await supabase.auth.verifyOtp({
      email: cleanEmail,
      token: cleanToken,
      type: 'email',
    });

    // Secondary support if the 6-digit code came from an unconfirmed signup email
    if (verifyRes.error) {
      const signupVerifyRes = await supabase.auth.verifyOtp({
        email: cleanEmail,
        token: cleanToken,
        type: 'signup',
      });
      if (!signupVerifyRes.error) {
        verifyRes = signupVerifyRes;
      }
    }

    if (verifyRes.error) {
      const msg = String(verifyRes.error.message || '').toLowerCase();
      if (msg.includes('expired') || msg.includes('invalid') || verifyRes.error.status === 403) {
        return {
          success: false,
          error:
            'The 6-digit code is incorrect or has expired. Check the latest TESO MELODIES email in Gmail or click "Resend Verification Email" for a new code.',
        };
      }
      return {
        success: false,
        error: sanitizeArtistFacingError(
          verifyRes.error,
          'Could not verify that code. Please check your Gmail and try again.'
        ),
      };
    }

    // Confirm Supabase Auth returned an authenticated user matching the artist's Gmail
    const verifiedUserEmail = (verifyRes.data?.user?.email || '').trim().toLowerCase();
    if (!verifiedUserEmail || verifiedUserEmail !== cleanEmail) {
      return {
        success: false,
        error: 'Verified email does not match your registered artist account.',
      };
    }

    const storedNonce =
      nonce ||
      (typeof window !== 'undefined'
        ? window.sessionStorage.getItem('teso_earnings_verify_nonce')
        : null);

    // Server-side unlock: verifies auth.users confirmation & timestamp in PostgreSQL
    const { data, error } = await supabase.rpc('complete_artist_gmail_verification', {
      p_method: 'gmail_otp',
      p_nonce: storedNonce || null,
    });

    if (error) {
      return {
        success: false,
        error: sanitizeArtistFacingError(
          error,
          'Could not unlock your Artist Earnings Dashboard right now. Please try again.'
        ),
      };
    }

    const result = data as any;
    if (!result?.success) {
      return {
        success: false,
        error: result?.error || 'Could not finalize Gmail OTP verification.',
      };
    }

    try {
      window.sessionStorage.removeItem('teso_earnings_verify_nonce');
    } catch {
      // ignore
    }

    return {
      success: true,
      verifiedGmail: result.verified_gmail || cleanEmail,
    };
  } catch (err: any) {
    return {
      success: false,
      error: sanitizeArtistFacingError(err, 'Verification failed. Please try again.'),
    };
  }
}

/**
 * Step 2B: Complete verification after artist clicks the real verification link in Gmail.
 * Waits briefly if Supabase Auth is still settling the URL session callback before confirming.
 */
export async function completeArtistGmailLinkVerification(nonce?: string | null): Promise<{
  success: boolean;
  verifiedGmail?: string;
  alreadyVerified?: boolean;
  error?: string;
}> {
  try {
    if (typeof window !== 'undefined') {
      const searchParams = new URLSearchParams(window.location.search);
      const authCode = searchParams.get('code');
      if (authCode) {
        try {
          await supabase.auth.exchangeCodeForSession(authCode);
        } catch {
          // detectSessionInUrl may have already exchanged the code
        }
      }
      await supabase.auth.getSession();
    }

    const callRpc = async () =>
      supabase.rpc('complete_artist_gmail_verification', {
        p_method: 'gmail_link',
        p_nonce: nonce || null,
      });

    let { data, error } = await callRpc();

    // Retry once briefly if session sign-in timestamp is still propagating after link click
    if (!error && !(data as any)?.success) {
      const msg = String((data as any)?.error || '').toLowerCase();
      if (msg.includes('fresh gmail otp') || msg.includes('confirmation is required')) {
        await new Promise((resolve) => setTimeout(resolve, 1200));
        await supabase.auth.getSession();
        const retry = await callRpc();
        data = retry.data;
        error = retry.error;
      }
    }

    if (error) {
      return {
        success: false,
        error: sanitizeArtistFacingError(
          error,
          'Could not confirm Gmail verification link right now. Please try again.'
        ),
      };
    }

    const result = data as any;
    if (!result?.success) {
      return { success: false, error: result?.error || 'Could not confirm Gmail verification link.' };
    }

    try {
      window.sessionStorage.removeItem('teso_earnings_verify_nonce');
    } catch {
      // ignore
    }

    return {
      success: true,
      verifiedGmail: result.verified_gmail,
      alreadyVerified: Boolean(result.already_verified),
    };
  } catch (err: any) {
    return {
      success: false,
      error: sanitizeArtistFacingError(err, 'Could not confirm verification link.'),
    };
  }
}

/**
 * In-place email update for existing artists registered with a non-Gmail address (no duplicate accounts).
 */
export async function updateArtistAccountEmailToGmail(newGmail: string): Promise<{
  success: boolean;
  error?: string;
}> {
  const clean = newGmail.trim().toLowerCase();
  if (!isGmailAddress(clean)) {
    return { success: false, error: 'Please enter a valid @gmail.com address.' };
  }

  try {
    const redirectOrigin =
      typeof window !== 'undefined' ? window.location.origin : 'https://tesomelodies.com';
    const { error } = await supabase.auth.updateUser(
      { email: clean },
      { emailRedirectTo: `${redirectOrigin}/dashboard?earnings_verify=1` }
    );
    if (error) {
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed to update account email.' };
  }
}

/**
 * Save private artist payout information (RLS-protected, owner + admin only).
 */
export async function saveArtistPayoutProfile(input: {
  fullLegalName: string;
  country: string;
  phoneNumber: string;
  mobileMoneyProvider: MobileMoneyProvider;
  mobileMoneyNumber: string;
}): Promise<{
  success: boolean;
  payoutProfile?: ArtistPayoutProfile;
  error?: string;
}> {
  try {
    const { data, error } = await supabase.rpc('save_artist_payout_profile', {
      p_full_legal_name: input.fullLegalName.trim(),
      p_country: input.country.trim() || 'Uganda',
      p_phone_number: input.phoneNumber.trim(),
      p_mobile_money_provider: input.mobileMoneyProvider,
      p_mobile_money_number: input.mobileMoneyNumber.trim(),
    });

    if (error) {
      return {
        success: false,
        error: sanitizeArtistFacingError(
          error,
          'Could not save payout information right now. Please try again.'
        ),
      };
    }
    const res = data as any;
    if (!res?.success) {
      return { success: false, error: res?.error || 'Could not save payout information.' };
    }
    return {
      success: true,
      payoutProfile: res.payout_profile as ArtistPayoutProfile,
    };
  } catch (err: any) {
    return {
      success: false,
      error: sanitizeArtistFacingError(err, 'Failed to save payout details.'),
    };
  }
}

/**
 * Request a withdrawal (backend enforces verified Gmail, non-suspended status,
 * minimum 15,000 UGX, available balance, and idempotency key).
 */
export async function requestArtistWithdrawal(
  amountUgx: number,
  idempotencyKey: string
): Promise<{
  success: boolean;
  withdrawal?: ArtistWithdrawalRequest;
  error?: string;
}> {
  try {
    const { data, error } = await supabase.rpc('request_artist_withdrawal', {
      p_amount_ugx: Math.round(amountUgx),
      p_idempotency_key: idempotencyKey,
    });

    if (error) {
      return {
        success: false,
        error: sanitizeArtistFacingError(
          error,
          'Could not submit withdrawal request right now. Please try again.'
        ),
      };
    }
    const res = data as any;
    if (!res?.success) {
      return { success: false, error: res?.error || 'Could not submit withdrawal request.' };
    }
    return {
      success: true,
      withdrawal: res.withdrawal as ArtistWithdrawalRequest,
    };
  } catch (err: any) {
    return {
      success: false,
      error: sanitizeArtistFacingError(err, 'Withdrawal request failed.'),
    };
  }
}

// ==============================================================================
// ADMIN EARNINGS MANAGEMENT API (Strictly enforced for tesomelodies@gmail.com)
// ==============================================================================

export async function checkAdminMonetizationHealth(): Promise<{
  health: AdminMonetizationHealth | null;
  migrationRequired?: boolean;
  error?: string;
}> {
  try {
    const { data, error } = await supabase.rpc('admin_check_monetization_health');
    if (error) {
      if (isMissingMigrationError(error)) {
        return {
          health: null,
          migrationRequired: true,
          error:
            'Latest supabase-artist-earnings-migration.sql update has not been executed yet in Supabase SQL Editor.',
        };
      }
      return { health: null, error: error.message };
    }
    return { health: data as AdminMonetizationHealth };
  } catch (err: any) {
    return { health: null, error: err?.message || 'Failed to check monetization backend health.' };
  }
}

export async function fetchAdminEarningsOverview(): Promise<{
  data: AdminEarningsOverview | null;
  migrationRequired?: boolean;
  schemaMismatch?: boolean;
  diagnosticDetail?: string;
  error?: string;
}> {
  try {
    const { data, error } = await supabase.rpc('admin_get_earnings_overview');
    if (error) {
      if (isMissingMigrationError(error)) {
        return {
          data: null,
          migrationRequired: true,
          diagnosticDetail: error.message,
          error:
            'Monetization tables or RPC functions are missing in Supabase. Run supabase-artist-earnings-migration.sql in your Supabase SQL Editor.',
        };
      }
      if (isSchemaMismatchError(error)) {
        return {
          data: null,
          migrationRequired: true,
          schemaMismatch: true,
          diagnosticDetail: error.message,
          error:
            'An older monetization SQL function conflicts with your live Supabase column types (e.g., user_favorites.song_id is TEXT). Re-run the updated supabase-artist-earnings-migration.sql in your Supabase SQL Editor to apply the fix.',
        };
      }
      return { data: null, diagnosticDetail: error.message, error: error.message };
    }
    return { data: data as AdminEarningsOverview };
  } catch (err: any) {
    return { data: null, error: err?.message || 'Failed to load admin earnings overview.' };
  }
}

export async function updateAdminEarningSettings(input: {
  downloadsRateUgx: number;
  downloadsPerUnit: number;
  streamsRateUgx: number;
  streamsPerUnit: number;
  likesRateUgx: number;
  likesPerUnit: number;
  followersRateUgx: number;
  followersPerUnit: number;
  minWithdrawalUgx: number;
}): Promise<{
  success: boolean;
  settings?: ArtistEarningSettings;
  error?: string;
}> {
  try {
    const { data, error } = await supabase.rpc('admin_update_earning_settings', {
      p_downloads_rate_ugx: input.downloadsRateUgx,
      p_downloads_per_unit: Math.max(1, Math.round(input.downloadsPerUnit)),
      p_streams_rate_ugx: input.streamsRateUgx,
      p_streams_per_unit: Math.max(1, Math.round(input.streamsPerUnit)),
      p_likes_rate_ugx: input.likesRateUgx,
      p_likes_per_unit: Math.max(1, Math.round(input.likesPerUnit)),
      p_followers_rate_ugx: input.followersRateUgx,
      p_followers_per_unit: Math.max(1, Math.round(input.followersPerUnit)),
      p_min_withdrawal_ugx: Math.round(input.minWithdrawalUgx),
    });

    if (error) {
      return { success: false, error: error.message };
    }
    const res = data as any;
    if (!res?.success) {
      return { success: false, error: res?.error || 'Failed to update royalty settings.' };
    }
    return { success: true, settings: res.settings as ArtistEarningSettings };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed to save royalty settings.' };
  }
}

export async function reviewAdminWithdrawal(input: {
  withdrawalId: string;
  action: 'approve' | 'mark_paid' | 'reject';
  paymentReference?: string;
  note?: string;
}): Promise<{
  success: boolean;
  withdrawal?: ArtistWithdrawalRequest;
  error?: string;
}> {
  try {
    const { data, error } = await supabase.rpc('admin_review_withdrawal', {
      p_withdrawal_id: input.withdrawalId,
      p_action: input.action,
      p_payment_reference: input.paymentReference?.trim() || null,
      p_note: input.note?.trim() || null,
    });

    if (error) {
      return { success: false, error: error.message };
    }
    const res = data as any;
    if (!res?.success) {
      return { success: false, error: res?.error || 'Could not update withdrawal status.' };
    }
    return { success: true, withdrawal: res.withdrawal as ArtistWithdrawalRequest };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed to process withdrawal action.' };
  }
}

export async function toggleAdminArtistSuspension(
  userId: string,
  suspended: boolean,
  reason?: string
): Promise<{
  success: boolean;
  error?: string;
}> {
  try {
    const { data, error } = await supabase.rpc('admin_toggle_artist_suspension', {
      p_user_id: userId,
      p_suspended: suspended,
      p_reason: reason?.trim() || null,
    });

    if (error) {
      return { success: false, error: error.message };
    }
    const res = data as any;
    if (!res?.success) {
      return { success: false, error: res?.error || 'Could not update artist suspension status.' };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Failed to update suspension status.' };
  }
}
