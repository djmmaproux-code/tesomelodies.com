import { createClient } from "@supabase/supabase-js";

// ==============================================================================
// 1. YOUR SUPABASE PROJECT URL
// Note: Supabase project URLs must NOT include '/rest/v1/'.
// It must only be the project root: https://<project-ref>.supabase.co
// ==============================================================================
const RAW_SUPABASE_URL = "https://csguerwyvykvzlnikwbf.supabase.co";

// ==============================================================================
// 2. YOUR SUPABASE ANON/PUBLIC KEY
// ==============================================================================
const SUPABASE_PUBLIC_KEY = "sb_publishable_oEIwYhatHiDPIC12hLmZPA_XrH8F1lA";

// Automatic URL cleaner: strips any accidental '/rest/v1' suffix or trailing slashes
// so Auth, Storage, and Database routes work without "Invalid path specified" errors.
const cleanUrl = (url) => {
  if (!url) return "";
  return url.replace(/\/rest\/v1\/?$/, "").replace(/\/+$/, "");
};

export const SUPABASE_URL = cleanUrl(RAW_SUPABASE_URL);
export { SUPABASE_PUBLIC_KEY };

// Initialize and export the Supabase client
export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLIC_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});
