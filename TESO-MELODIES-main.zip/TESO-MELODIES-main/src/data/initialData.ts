import { Song, Announcement, Artist, Genre, VideoItem } from '../types/music';

// Generated image assets
import heroManImg from '../assets/images/hero_man_headphones_1793906335751.jpg';
import adMegaphoneImg from '../assets/images/advertise_megaphone_1793906335776.jpg';
import kingSahaImg from '../assets/images/artist_king_saha_1793906336822.jpg';
import announcementImg from '../assets/images/music_announcement_1793906336740.jpg';
import afroGoldImg from '../assets/images/album_afro_gold_1793906353481.jpg';
import femaleQueenImg from '../assets/images/album_female_queen_1793906354511.jpg';
import dancehallFireImg from '../assets/images/album_dancehall_fire_1793906356018.jpg';
import kampalaNightsImg from '../assets/images/album_kampala_nights_1793906355580.jpg';

export const HERO_ASSETS = {
  heroMan: heroManImg,
  adMegaphone: adMegaphoneImg,
  kingSaha: kingSahaImg,
  announcement: announcementImg,
};

// ONLY the 11 requested categories:
// teso worship, Gospel, Akoogo, R&B, Reggae, Rock, Afrobeat, Country, Amapiano, Jazz, Teso Dancehall
export const INITIAL_GENRES: Genre[] = [
  { id: 'teso-worship', name: 'Teso Worship', color: 'bg-[#00897b]', icon: 'cross' },
  { id: 'gospel', name: 'Gospel', color: 'bg-[#1e88e5]', icon: 'cross' },
  { id: 'akoogo', name: 'Akoogo', color: 'bg-[#fb8c00]', icon: 'music' },
  { id: 'rnb', name: 'R&B', color: 'bg-[#c2185b]', icon: 'heart' },
  { id: 'reggae', name: 'Reggae', color: 'bg-[#43a047]', icon: 'palm' },
  { id: 'rock', name: 'Rock', color: 'bg-[#e53935]', icon: 'guitar' },
  { id: 'afrobeat', name: 'Afrobeat', color: 'bg-[#00acc1]', icon: 'africa' },
  { id: 'country', name: 'Country', color: 'bg-[#ffb300]', icon: 'hat' },
  { id: 'amapiano', name: 'Amapiano', color: 'bg-[#8e24aa]', icon: 'soundwave' },
  { id: 'jazz', name: 'Jazz', color: 'bg-[#3949ab]', icon: 'saxophone' },
  { id: 'teso-dancehall', name: 'Teso Dancehall', color: 'bg-[#e91e63]', icon: 'flame' },
];

export const INITIAL_NEW_SONGS: Song[] = [];
export const INITIAL_TRENDING_SONGS: Song[] = [];
export const INITIAL_HOT100_SONGS: Song[] = [];


export const INITIAL_VIDEOS: VideoItem[] = [];

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'Teso Melodies is Live!',
    description: 'Welcome to Teso Melodies. Stream, upload, share and earn!',
    fullContent: 'Welcome to Teso Melodies — East Africa\'s premier free music and video streaming portal! We are proud to connect artists, fans, and producers from Teso, Uganda, Kenya, and across the globe. Stream unlimited songs, download for offline listening, discover emerging voices, and enjoy high-definition audio without subscriptions.',
    date: 'Oct 28, 2024',
    thumbnail: announcementImg,
    badge: 'Launch',
  },
  {
    id: 'ann-2',
    title: 'New Artist Registration Open',
    description: 'Join our growing community of talented artists and get discovered!',
    fullContent: 'Are you a musician, songwriter, DJ, or audio creator? Artist registration is now officially open! Create your profile, upload your tracks and official music videos, access real-time play analytics, and monetize your content with our creator royalty program.',
    date: 'Oct 25, 2024',
    thumbnail: kingSahaImg,
    badge: 'Artists',
  },
  {
    id: 'ann-3',
    title: 'Earn More with Teso Melodies',
    description: 'Post your music, videos and get paid. No charges for fans!',
    fullContent: 'With our breakthrough Community Revenue Share, artists receive direct earnings based on streams, downloads, and fan engagement. Meanwhile, fans enjoy 100% free streaming with no subscriptions or hidden charges. Music unites us all!',
    date: 'Oct 20, 2024',
    thumbnail: afroGoldImg,
    badge: 'Earnings',
  },
];

export const INITIAL_ARTIST_KING_SAHA: Artist = {
  id: 'king-saha',
  name: 'King Saha',
  genre: 'Afrobeat / RnB',
  followers: 5,
  isFollowed: false,
  avatar: kingSahaImg,
  bio: 'King Saha is one of Uganda and East Africa\'s most versatile and celebrated vocalists, renowned for timeless melodic hits, soulful hooks, and energetic performances.',
  monthlyListeners: '3 likes',
  totalLikes: 3,
  totalSongs: 1,
  topTracks: [],
};
